<template>
	<Fragment>
		<!-- Order info title -->
		<div
			class="col col-12 font-weight-medium ma-3"
			v-text="$t('orderDetails.labels.orderInfo')"
		/>
		<v-col
			v-if="
				(getOrderItems && getOrderItems.length) ||
				(getOrderPlans && getOrderPlans.length)
			"
			cols="12"
			md="4"
			v-for="(items, index) in getOrderItems && getOrderItems.length
				? getOrderItems
				: getOrderPlans"
			:key="index"
			class="mb-3"
		>
			<v-card
				class="d-flex rounded-lg elevation-2"
				outlined
				@click="
					items.product_id || items.slug ? checkLocalePath(items) : ''
				"
			>
				<v-col cols="auto" class="pa-1">
					<!-- Order picture -->
					<v-img
						width="54"
						height="54"
						class="grey lighten-1 rounded-lg"
						:style="
							items.bg_color
								? `backgroundColor : ${items.bg_color} !important`
								: null
						"
						draggable="false"
						:lazy-src="`${getDomain}${
							items.img ? items.img : getDefaultImg
						}`"
						:src="`${getDomain}${
							items.img ? items.img : getDefaultImg
						}`"
					/>
				</v-col>
				<!-- Order description -->
				<v-col
					class="pa-1 pe-2 d-flex align-start font-size-subtitle-2 flex-shrink-1"
				>
					<div
						class="me-1 font-weight-medium"
						v-text="
							items.product_name ? items.product_name : items.name
						"
					/>
					<template v-if="items.prop_info">
						<span
							v-for="(props, index) in items.prop_info"
							:key="index"
							v-if="props.name"
							class="me-1"
						>
							- {{ props.name }}
						</span>
					</template>
					<span
						class="font-size-12 green--text"
						v-if="items.unit_sentence"
						v-text="' - ' + items.unit_sentence"
					/>
				</v-col>
				<!-- Order quantity and price -->
				<v-col
					cols="auto"
					class="d-flex align-end justify-space-between flex-column pa-1"
				>
					<div class="font-size-subtitle-1" v-if="items.count">
						{{ items.count }}
						<v-icon size="10">mdi-close</v-icon>
					</div>
					<span class="font-size-subtitle-1">
						<span class="font-weight-medium">
							{{
								$numberWithCommas(
									$roundDecimal(
										items.prop_info
											? priceCalculator(
													items.prop_info,
													items.price
											  )
											: items.price
									)
								)
							}}
						</span>
						<span
							class="font-size-13 font-weight-light"
							v-text="getShopMonetaryUnit"
						/>
					</span>
				</v-col>
			</v-card>
		</v-col>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	components: {
		Fragment,
	},
	computed: {
		...mapGetters({
			//SiteSetting getters
			getDomain: "siteSetting/getDomain",
			getDefaultImg: "siteSetting/getDefaultImg",
			//FirstData getters
			getShop: "firstData/getShop",
			//OrderDetails getters
			getOrderItems: "orderDetails/getOrderItems",
			getBranchId: "orderDetails/getBranchId",
			getOrderPlans: "orderDetails/getOrderPlans",
			getShopMonetaryUnit: "orderDetails/getShopMonetaryUnit",
		}),
	},
	methods: {
		checkLocalePath(order) {
			let slug = order.product_id;
			switch (
				this.getShop(this.getBranchId ? this.getBranchId : 1).card
					.description_style
			) {
				case "TAB_INFO":
					slug = order.product_id;
					break;
				case "SIMPLE":
					slug = order.slug ? order.slug : null;
					break;
				default:
					slug = order.product_id ? order.product_id : null;
					break;
			}
			if (slug) {
				this.$router.push(
					this.localePath(`/product/${slug}`, this.$i18n.locale)
				);
			}
		},
		priceCalculator(prop_info, product_price) {
			let sumPriceProps = 0;
			for (let prop of prop_info) {
				sumPriceProps += +prop.price;
			}
			return sumPriceProps + +product_price;
		},
	},
};
</script>
