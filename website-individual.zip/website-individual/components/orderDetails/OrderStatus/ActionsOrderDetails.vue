<template>
	<v-row
		no-gutters
		v-if="
			getOrderProcess &&
			(getOrderProcess.process_cancel ||
				getOrderProcess.process_reorder ||
				getOrderProcess.process_comment)
		"
		justify="center"
		class="mb-5"
	>
		<!-- Cancel button -->
		<v-col class="px-2" sm="4" v-if="getOrderProcess.process_cancel">
			<v-dialog v-model="dialogIsSureToRemove" max-width="290">
				<v-card elevation="3">
					<v-card-title class="font-size-14">
						{{ $t("orderDetails.labels.sureQuestion") }}
					</v-card-title>
					<v-card-actions>
						<v-spacer />
						<v-btn
							color="green darken-1"
							text
							:loading="loading"
							@click="dialogIsSureToRemove = false"
						>
							{{ $t("button.no") }}
						</v-btn>
						<v-btn
							color="red darken-1"
							text
							:loading="loading"
							@click="orderCalncell"
						>
							{{ $t("button.yes") }}
						</v-btn>
					</v-card-actions>
				</v-card>
			</v-dialog>
			<v-btn
				class="d-flex justify-center my-2"
				color="secondary"
				dark
				small
				block
				v-text="$t('orderDetails.buttons.cancelOrder')"
				@click="
					isAuth ? (dialogIsSureToRemove = true) : userNeedLogin()
				"
			/>
		</v-col>

		<!-- <v-row
			no-gutters
			v-if="
				getOrderProcess.process_reorder ||
				getOrderProcess.process_comment
			"
			class="font-size-12 font-weight-light"
		>
			<template v-if="getOrderProcess.process_comment">
				<v-col
					class="pa-2"
					cols="7"
					sm="3"
					v-text="$t('orderDetails.labels.orderRate')"
				/>
				<v-col class="px-2 d-flex align-center" sm="3">
					<v-btn color="secondary" small block depressed>
						{{ $t("orderDetails.buttons.submitComment") }}
					</v-btn>
				</v-col>
			</template>
			<template v-if="getOrderProcess.process_reorder">
				<v-col
					class="pa-2"
					v-text="$t('orderDetails.labels.reOrder')"
					cols="7"
					sm="3"
				/>
				<v-col class="px-2 d-flex align-center" sm="3">
					<v-btn
						color="secondary"
						small
						block
						depressed
					>
						:to="`/${$i18n.locale}/#main-section`"
						{{ $t("orderDetails.buttons.reOrder") }}
					</v-btn>
				</v-col>
			</template>
		</v-row> -->
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
import { profile } from "@/api";

export default {
	data: () => ({
		dialogIsSureToRemove: false,
		loading: false,
	}),
	computed: {
		...mapGetters({
			isAuth: "isAuth",
			getAuth: "getAuth",
			getOrderDetailId: "orderDetails/getOrderDetailId",
			getOrderProcess: "orderDetails/getOrderProcess",
			getUserId: "orderDetails/getUserId",
			getShopID: "orderDetails/getShopID",
		}),
	},
	methods: {
		//User need login snackbar and login card load
		userNeedLogin() {
			this.$store.dispatch("snackbar/isShow", true);
			this.$store.dispatch("snackbar/setColor", "red darken-2");
			this.$store.dispatch(
				"snackbar/setText",
				this.$t("orderDetails.labels.needLogin")
			);
			this.$store.commit("loginCard/SET_STATUS", 4);
		},

		//Order cancell
		orderCalncell() {
			//Check this user and login user id
			if (this.getAuth.user.user_id == this.getUserId) {
				this.loading = true;
				// User is authenticated ==> send order cancell req
				this.$axios
					.$post(profile.cancelOrder, {
						token: this.getAuth.access_token,
						order_id: this.getOrderDetailId,
						shop_id: this.getShopID,
					})
					.then(res => {
						if (res && res.status) {
							//Show successful snackbar
							this.$store.dispatch("snackbar/isShow", true);
							this.$store.dispatch(
								"snackbar/setColor",
								"green darken-2"
							);
							this.$store.dispatch(
								"snackbar/setText",
								this.$t("orderDetails.labels.cancelSuccessful")
							);
							//Get user order list
							this.$router.push(`/${this.$i18n.locale}/profile#orders`);
						} else {
							//Show Unsuccessful snackbar
							this.$store.dispatch("snackbar/isShow", true);
							this.$store.dispatch(
								"snackbar/setColor",
								"red darken-2"
							);
							this.$store.dispatch(
								"snackbar/setText",
								this.$t(
									"orderDetails.labels.cancelUnsuccessful"
								)
							);
						}
						this.loading = false;
					})
					.catch(err => console.error(err))
					.finally(() => (this.loading = false));
			} else {
				// User is not authenticated ===> return home page
				this.$router.push(this.localePath("index"));
			}
		},
	},
};
</script>
