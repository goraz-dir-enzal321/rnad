<template>
	<Fragment>
		<!-- Order status title -->
		<div
			class="font-weight-medium ma-3"
			v-text="$t('orderDetails.labels.orderStatus')"
			v-if="getOrderProcess"
		/>
		<!-- Order status images -->
		<v-row v-if="getOrderProcess" no-gutters justify="center">
			<v-col
				cols="12"
				md="6"
				class="pa-2 text-center"
				v-if="getOrderProcess.process_img"
			>
				<ProcessImage :id="getOrderProcess.id" />
			</v-col>
			<!-- process_schedule -->
			<v-col
				cols="12"
				md="6"
				v-if="getAreaTime || getProductTime"
				class="pa-5"
			>
				<div
					class="font-weight-medium pa-0"
					v-text="$t('orderDetails.labels.orderTime')"
				/>
				<div
					v-if="getAreaTime"
					class="font-size-12 ma-2 ms-4"
					v-text="
						$t('orderDetails.labels.orderPreparationTime') +
						' ' +
						`${
							setAreaTime().minutes
								? setAreaTime().minutes +
								  $t('orderDetails.labels.minutes') +
								  ' '
								: null + setAreaTime().hours
								? setAreaTime().hours +
								  ' ' +
								  $t('orderDetails.labels.hours')
								: null + setAreaTime().days
								? setAreaTime().days +
								  ' ' +
								  $t('orderDetails.labels.days') +
								  ' '
								: null
						}`
					"
				/>
				<div
					v-if="getProductTime"
					class="font-size-12 ma-2 ms-4"
					v-text="
						$t('orderDetails.labels.orderSendingTime') +
						' ' +
						`${
							setProductTime().minutes
								? setProductTime().minutes +
								  $t('orderDetails.labels.minutes') +
								  ' '
								: null + setProductTime().hours
								? setProductTime().hours +
								  ' ' +
								  $t('orderDetails.labels.hours')
								: null + setProductTime().days
								? setProductTime().days +
								  ' ' +
								  $t('orderDetails.labels.days') +
								  ' '
								: null
						}`
					"
				/>

				<CountdownTimer :date="deadLineCalculat()" />
			</v-col>
		</v-row>
		<!--Cancel, Reorder, Comment Buttons -->
		<ActionsOrderDetails />
	</Fragment>
</template>

<script>
import CountdownTimer from "@/components/orderDetails/CountdownTimer";
import ProcessImage from "@/components/orderDetails/ProcessImage";
import ActionsOrderDetails from "@/components/orderDetails/OrderStatus/ActionsOrderDetails.vue";
import { Fragment } from "vue-fragment";
import { mapGetters } from "vuex";
export default {
	components: {
		CountdownTimer,
		ProcessImage,
		ActionsOrderDetails,
		Fragment,
	},
	computed: {
		...mapGetters({
			// OrderDetails getters
			getOrderProcess: "orderDetails/getOrderProcess",
			getAreaTime: "orderDetails/getAreaTime",
			getProductTime: "orderDetails/getProductTime",
			getCreatedAt: "orderDetails/getCreatedAt",
		}),
	},
	methods: {
		// deadLine Calculator
		deadLineCalculat() {
			let areaTime = new Date(this.getAreaTime).getTime();
			// let areaTime = new Date("2021-01-31 09:00:00").getTime();
			let productTime = new Date(this.getProductTime).getTime();
			// let productTime = new Date("2021-01-31 10:30:00 ").getTime();
			let distance = productTime - areaTime;
			return new Date(areaTime + distance).toISOString();
		},
		// set area time minutes
		setAreaTime() {
			let areaTime = new Date(this.getAreaTime).getTime();
			let created = new Date(this.getCreatedAt).getTime();
			let distance = areaTime - created;
			let minutes = Math.trunc(distance / 1000 / 60) % 60;
			let hours = Math.trunc(distance / 1000 / 60 / 60) % 24;
			let days = Math.trunc(distance / 1000 / 60 / 60 / 24);

			return { minutes: minutes, hours: hours, days: days };
		},
		// set product time minutes
		setProductTime() {
			let areaTime = new Date(this.getAreaTime).getTime();
			let created = new Date(this.getCreatedAt).getTime();
			let distance = areaTime - created;
			let minutes = Math.trunc(distance / 1000 / 60) % 60;
			let hours = Math.trunc(distance / 1000 / 60 / 60) % 24;
			let days = Math.trunc(distance / 1000 / 60 / 60 / 24);

			return { minutes: minutes, hours: hours, days: days };
		},
	},
};
</script>
