<template>
	<v-container class="pa-0 pa-md-2">
		<v-card class="pa-md-5">
			<!-- order tracer title -->
			<v-card
				class="d-flex pa-0 pa-md-3 rounded-lg"
				:elevation="$device.isMobile ? 0 : 3"
			>
				<v-col class="pa-2" cols="6">
					<v-skeleton-loader
						width="50%"
						tile
						type="image"
						height="24px"
						class="rounded-pill d-inline-block"
					/>
				</v-col>
				<v-col
					class="pa-2"
					:class="`text-${$vuetify.rtl ? 'left' : 'right'}`"
					cols="6"
				>
					<v-skeleton-loader
						width="50%"
						tile
						type="image"
						height="24px"
						class="rounded-pill d-inline-block"
					/>
				</v-col>
			</v-card>
			<v-divider v-if="$device.isMobile" />
			<!-- order tracer status -->
			<div class="ma-3">
				<v-skeleton-loader type="heading" />
			</div>
			<!-- Order status images -->
			<v-row no-gutters>
				<v-col cols="12" md="6" class="pa-2">
					<v-skeleton-loader class="pa-0" type="image" />
				</v-col>

				<v-col cols="12" md="6" class="pa-2 pa-md-5">
					<v-col class="font-weight-medium ma-m-3 pa-0" cols="auto" />
					<v-skeleton-loader type="list-item-three-line" />
					<v-skeleton-loader height="100px" type="image" />
				</v-col>
				<!-- Order cancel btn -->
				<v-skeleton-loader
					:width="$device.isMobile ? '96%' : '34%'"
					height="35px"
					:class="$device.isMobile ? 'mx-auto' : 'ms-2'"
					type="image"
				/>
			</v-row>

			<!-- order tracer info -->
			<v-skeleton-loader class="ma-3" type="heading" />
			<div class="d-flex flex-wrap ma-1">
				<v-col cols="12" md="4" class="pa-1" v-for="i in 3" :key="i">
					<v-card class="d-flex rounded-lg elevation-2" outlined>
						<!-- Order picture -->
						<v-col cols="3" md="2">
							<v-skeleton-loader
								type="image"
								width="45"
								height="45"
							/>
						</v-col>
						<!-- Order description -->
						<v-col class="py-2" cols="5" md="6">
							<v-skeleton-loader type="paragraph" />
						</v-col>
					</v-card>
				</v-col>
			</div>

			<!-- order tracer place of service and questions -->
			<v-row class="mx-0">
				<v-col md="4" cols="12" class="pa-2" v-for="i in 2" :key="i">
					<v-skeleton-loader
						class="ma-3 mt-4"
						width="50%"
						type="heading"
					/>

					<v-card class="rounded-lg elevation-2" :class="i == 2 ?  'pa-2' : 'px-2 py-3'" outlined>
						<v-skeleton-loader
							class="mt-1"
							type="list-item-three-line"
						/>
						<!-- <div :class="$vuetify.rtl ? 'text-left' : 'text-right'">
							<v-btn text>
								<v-skeleton-loader
									class="rounded-lg rounded-br-0 rounded-tl-0"
									type="button"
								/>
							</v-btn>
						</div> -->
					</v-card>
				</v-col>
			</v-row>
		</v-card>
	</v-container>
</template>
