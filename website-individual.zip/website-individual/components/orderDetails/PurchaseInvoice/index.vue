<template>
	<v-col cols="12" class="py-md-4">
		<div
			class="section-price-lists-card pos-relative mx-auto"
			:style="$device.isMobile ? null : 'width: max-content'"
		>
			<PriceLists
				class="pb-8 pa-md-8 pa-5 mb-4"
				:collectItems="getOrderPriceList.collectItems"
				:discounts="getSalesInvoice.totalDiscount"
				:tax="getOrderPriceList.tax"
				:deliveryCost="getSalesInvoice.deliveryPrice"
				:wage="getOrderPriceList.totalWage"
				:monetaryUnit="getShopMonetaryUnit"
			/>
			<div class="text-center pos-absolute w-100" style="bottom: -24px;">
				<v-sheet
					class="d-inline-flex justify-space-between rounded-lg pa-3"
					color="secondary"
					dark
					:width="$device.isMobile ? '95%' : '80%'"
				>
					<div
						v-text="$t('orderDetails.labels.paymentAmount')"
						class="font-weight-bold"
					/>
					<div>
						<span
							v-text="
								$numberWithCommas(
									+getSalesInvoice.totalPrice +
										+getOrderPriceList.totalWage +
										+getOrderPriceList.tax +
										+getSalesInvoice.deliveryPrice
								)
							"
						/>
						<span
							class="font-size-13"
							v-text="getShopMonetaryUnit"
						/>
					</div>
				</v-sheet>
			</div>
		</div>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import PriceLists from "@/components/billSummary/PriceLists";
export default {
	components: {
		PriceLists,
	},
	computed: {
		...mapGetters({
			getShopMonetaryUnit: "orderDetails/getShopMonetaryUnit",
			getSalesInvoice: "orderDetails/getSalesInvoice",
			getOrderPriceList: "orderDetails/getOrderPriceList",
		}),
	},
};
</script>

<style scoped>
.section-price-lists-card {
	box-shadow: 0px 3px 1px 0px rgb(0 0 0 / 1%),
		0px 2px 2px 0px rgb(0 0 0 / 25%), 0px 0px 0px 0.5px rgb(0 0 0 / 20%);
	border-radius: 7px;
}
</style>
