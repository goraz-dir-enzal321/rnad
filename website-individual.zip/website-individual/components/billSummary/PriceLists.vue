<template>
	<v-row
		class="font-size-15 font-weight-medium pa-0 grey--text text--darken-2"
		no-gutters
	>
		<!-- All price products -->
		<SectionPriceList
			:data="{
				title: $t('billSummary.collectItems'),
				price: collectItems,
				monetaryUnit: monetaryUnit,
				isSubset: false,
			}"
			v-if="collectItems"
		/>
		<!-- It will be added to price => (tax, Delivery cost, wage) -->
		<v-col
			cols="12"
			class="d-flex flex-wrap justify-space-between"
			v-if="tax || deliveryCost || wage"
		>
			<v-col
				cols="auto"
				v-text="$t('billSummary.itWillBeAdded') + ' :'"
				class="red--text darken font-weight-bold pa-0 pl-2 pb-3"
			/>
			<v-col class="flex-shrink-1 pa-0 pr-3 pb-3 d-flex align-center">
				<v-divider />
			</v-col>
			<!-- tax -->
			<SectionPriceList
				v-if="tax"
				:data="{
					title: $t('billSummary.tax'),
					price: tax,
					monetaryUnit: monetaryUnit,
					isSubset: true,
				}"
			/>
			<!-- Delivery cost -->
			<SectionPriceList
				v-if="deliveryCost"
				:data="{
					title: $t('billSummary.deliveryCost'),
					price: deliveryCost,
					monetaryUnit: monetaryUnit,
					isSubset: true,
				}"
			/>
			<!-- Wage -->
			<SectionPriceList
				v-if="wage"
				:data="{
					title: $t('billSummary.wage'),
					price: wage,
					monetaryUnit: monetaryUnit,
					isSubset: true,
				}"
			/>
		</v-col>
		<!-- Is deducted to price -->
		<v-col
			cols="12"
			class="d-flex flex-wrap justify-space-between"
			v-if="discounts"
		>
			<v-col
				cols="auto"
				v-text="$t('billSummary.isDeducted') + ' :'"
				class="success--text darken font-weight-bold pa-0 pl-2 pb-3"
			/>
			<v-col class="flex-shrink-1 pa-0 pr-3 pb-3 d-flex align-center">
				<v-divider />
			</v-col>
			<SectionPriceList
				:data="{
					title: $t('billSummary.discounts'),
					price: discounts,
					monetaryUnit: monetaryUnit,
					isSubset: true,
				}"
			/>
		</v-col>

		<!-- Total price -->
		<SectionPriceList
			v-if="totalPrice"
			class="font-weight-bold font-size-18 grey--text text--darken-3"
			:data="{
				title: $t('billSummary.totalPrice'),
				price: totalPrice,
				monetaryUnit: monetaryUnit,
				isSubset: false,
			}"
		/>
	</v-row>
</template>

<script>
import SectionPriceList from "~/components/billSummary/SectionPriceList.vue";
export default {
	props: [
		"collectItems",
		"discounts",
		"tax",
		"deliveryCost",
		"wage",
		"totalPrice",
		"monetaryUnit",
	],
	components: {
		SectionPriceList,
	},
};
</script>
