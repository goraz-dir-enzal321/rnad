<template>
	<div>
		<v-sheet
			color="grey lighten-4"
			:elevation="1"
			class="mx-auto pa-3 mb-3"
			v-html="
				getDynamicText && getDynamicText('PROFILE')
					? getDynamicText('PROFILE')
					: $t('header.text.change_information')
			"
		/>
		<v-card class="mx-auto">
			<v-card-text class="text-center">
				<div class="text--primary mb-4">
					{{ $t("header.text.write_information") }}
				</div>
				<v-progress-linear
					class="mb-7"
					:color="
						getBtnStyle && getBtnStyle.bg
							? getBtnStyle.bg
							: Boolean(getSiteColor)
							? getSiteColor.secondColor
							: 'grey'
					"
					height="33"
					background-color="#eee"
					rounded
					reactive
					:value="progressPoint"
					:style="{
						color:
							getBtnStyle && getBtnStyle.text
								? getBtnStyle.text
								: '',
					}"
				>
					<strong>{{ Math.ceil(progressPoint) }}%</strong>
				</v-progress-linear>
				<v-form
					ref="form"
					@submit.prevent="validate"
					v-model="isValidForm"
				>
					<v-row>
						<v-col cols="12" md="6" lg="4">
							<v-text-field
								dense
								:value="userInformationComputed.mobile"
								:label="$t('form.label.phone')"
								filled
								outlined
								disabled
							/>
						</v-col>
						<v-col cols="12" md="6" lg="4">
							<v-text-field
								dense
								:label="$t('form.label.name')"
								outlined
								:placeholder="$t('form.label.name')"
								required
								v-model="userInformationComputed.fname"
								:rules="nameRules"
								:disabled="loading"
							/>
						</v-col>
						<v-col cols="12" md="6" lg="4">
							<v-text-field
								dense
								:label="$t('form.label.family')"
								outlined
								:placeholder="$t('form.label.family')"
								required
								v-model="userInformationComputed.lname"
								:disabled="loading"
							/>
						</v-col>
						<v-col cols="12" md="6" lg="4">
							<v-text-field
								:placeholder="
									userInformationComputed.second_tel
										? userInformationComputed.second_tel
										: '05********'
								"
								v-model="userInformationComputed.second_tel"
								:label="$t('form.label.second_number')"
								:disabled="loading"
								:rules="secondNumberRules"
								outlined
								required
								dense
								type="number"
								counter="11"
							/>
						</v-col>
						<v-col cols="12" md="6" lg="4">
							<v-menu
								:close-on-content-click="false"
								v-model="menu"
								transition="scale-transition"
								max-width="300px"
							>
								<template v-slot:activator="{ on }">
									<v-text-field
										dense
										v-on="on"
										:label="$t('form.label.birthday_date')"
										outlined
										v-model="userInformationBirthDate"
										readonly
										:disabled="loading"
									/>
								</template>
								<v-card min-width="300px">
									<v-date-picker
										v-model="
											userInformationComputed.birth_date
										"
										:first-day-of-week="
											$i18n.locale == 'fa' ? 6 : 0
										"
										:show-current="true"
										header-color="green lighten-1"
										width="300px"
										color="primary"
										title
										scrollable
										actions
										:locale="$i18n.locale"
										:max="(new Date().toISOString().slice(0, 10))"
									/>
									<v-card-text>
										<v-btn text @click="menu = false">{{
											$t("button.close")
										}}</v-btn>
									</v-card-text>
								</v-card>
							</v-menu>
						</v-col>
						<v-col cols="12" md="6" lg="4">
							<v-text-field
								v-model="userInformationComputed.email"
								:label="$t('form.label.email')"
								placeholder="example@gmail.com"
								:rules="emailRules"
								:disabled="loading"
								tyep="email"
								required
								dense
								outlined
							/>
						</v-col>
						<v-col cols="12" md="6" lg="4" class="mx-auto">
							<v-btn
								depressed
								block
								type="submit"
								:color="
									getBtnStyle && getBtnStyle.bg
										? getBtnStyle.bg
										: Boolean(getSiteColor)
										? getSiteColor.secondColor
										: 'grey'
								"
								:style="{
									color:
										getBtnStyle && getBtnStyle.text
											? getBtnStyle.text
											: '',
								}"
								:loading="loading"
								:disabled="loading"
								>{{ $t("button.save") }}</v-btn
							>
						</v-col>
					</v-row>
				</v-form>
			</v-card-text>
		</v-card>
		<v-snackbar
			v-model="isShowSnackbar"
			:color="snackbarSuccess ? 'cyan darken-2' : 'red accent-4'"
		>
			{{ snackbarText }}
			<v-btn icon text @click="isShowSnackbar = false">
				<v-icon>mdi-close</v-icon>
			</v-btn>
		</v-snackbar>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import { jalaliDate } from "~/utils/date";

const Cookie = process.client ? require("js-cookie") : undefined;
export default {
	name: "Profile",
	data() {
		return {
			isShowSnackbar: false,
			snackbarText: "",
			snackbarSuccess: true,
			userInformation: {},
			progressPoint: 0,
			date: null,
			menu: false,
			modal: false,
			isValidForm: false,
			nameRules: [v => !!v || this.$t("form.validation.error.require")],
			secondNumberRules: [
				v => {
					if (v && v.length > 12) {
						return this.$t("form.validation.error.limit_count");
					}
					return true;
				},
			],
			emailRules: [
				v => {
					if (v && v.length) {
						const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
						return (
							pattern.test(v) ||
							this.$t("form.validation.error.invalid")
						);
					}
					return true;
				},
			],
			autocompleteValue: "foo",
			items: ["foo", "bar", "fizz", "buzz"],
			loading: false,
		};
	},
	mounted() {
		this.getUserInformationApi();
	},
	methods: {
		validate() {
			this.$refs.form.validate() ? this.updateUserInfo() : false;
		},
		getUserInformationApi() {
			if (!this.getToken) {
				return this.$router.push(this.localePath("index"));
			}
			this.loading = true;
			this.$axios
				.$post("editUserInfo", {
					token: this.$store.state.auth.access_token,
					lang: this.$i18n.locale,
				})
				.then(res => {
					this.userInformation = res;
				})
				.catch(error => {
					console.error("error ", error);
					return (this.userInformation = {});
				})
				.finally(() => (this.loading = false));
		},
		updateUserInfo() {
			this.loading = true;
			let data = {
				token: this.$store.state.auth.access_token,
				fname: this.userInformation.fname,
				lname: this.userInformation.lname,
				// mobile: this.userInformation.mobile,
				second_tel: this.userInformation.second_tel,
				birth_date: this.userInformation.birth_date,
				email: this.userInformation.email,
				lang: this.$i18n.locale,
			};
			this.$axios
				.$post("updateUserInfo", data)
				.then(res => {
					if (res.status) {
						this.snackbarSuccess = true;
						this.isShowSnackbar = true;
						this.snackbarText = res.messages;
						const $auth = this.getAuth;
						let $authData = {
							access_token: $auth.access_token,
							user: {
								access_token: $auth.user.access_token,
								expires_in: $auth.user.expires_in,
								user_id: $auth.user.user_id,
								fname: this.userInformation.fname,
								lname: this.userInformation.lname,
								mobile: $auth.user.mobile,
								active: $auth.user.active,
								shop_id: $auth.user.shop_id,
								new_user: $auth.user.new_user,
								status: $auth.user.status,
								second_tel: this.userInformation.second_tel,
								birth_date: this.userInformation.birth_date,
								email: this.userInformation.email,
							},
							url: $auth.url,
						};
						this.$store.commit("setAuth", $authData); // mutating to store for client rendering
						Cookie.set("auth", $authData); // saving token in cookie for server rendering
					} else {
						this.snackbarSuccess = false;
						this.isShowSnackbar = true;
						this.snackbarText = res.messages;
					}
				})
				.catch(error => console.error("error ", error))
				.finally(() => (this.loading = false));
		},
	},
	computed: {
		...mapGetters({
			getAuth: "getAuth",
			getToken: "getToken",
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			getDynamicText: "siteSetting/getDynamicText",
		}),
		userInformationComputed() {
			let $point = 0;
			Object.keys(this.userInformation).map(item => {
				if (Boolean(this.userInformation[item])) {
					if (this.userInformation[item].length > 0) {
						return ($point += 16.666666667);
					}
				}
			});
			$point = $point > 100 ? 100 : $point;
			this.progressPoint = $point;
			return this.userInformation;
		},
		displayTime() {
			return `Formatted display time... ${this.time}`;
		},
		tabComputed: {
			get() {
				this.tab = this.$store.state.profileTab.tab;
				return this.tab;
			},
			set(tabId) {
				this.$store.dispatch(
					"profileTab/setTab",
					tabId ? tabId : "profile"
				);
			},
		},
		userInformationBirthDate() {
			const d = jalaliDate(
				this.userInformationComputed.birth_date,
				this.$i18n.locale == "fa" ? "jYYYY/jM/jD" : "YYYY/MM/DD"
			);
			return d;
		},
	},
};
</script>

<style scoped>
.v-application--is-rtl .v-progress-linear__background {
	left: 0 !important;
}
</style>
