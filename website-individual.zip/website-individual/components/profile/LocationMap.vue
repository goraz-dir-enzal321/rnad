<template>
	<v-dialog v-model="dialogStatus" width="500">
		<v-card :loading="loading">
			<v-card-title
				class="font-size-headline mb-3 justify-center"
				primary-title
				>{{ $t("header.text.add_address") }}</v-card-title
			>
			<v-divider />
			<v-card-text>
				<div id="map-wrap" style="width: 100%; height: 350px;"></div>
			</v-card-text>
			<v-divider />
			<v-card-actions>
				<v-btn
					color="teal"
					text
					@click="closeDialog"
					:loading="loading"
					:disabled="loading"
					>{{ $t("button.save") }}</v-btn
				>
				<v-btn
					color="red darken-3"
					text
					@click="closeDialog"
					:loading="loading"
					:disabled="loading"
					>{{ $t("button.close") }}</v-btn
				>
			</v-card-actions>
		</v-card>
	</v-dialog>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "LocationMap",
	data() {
		return {
			loading: false,
			voidMap: false,
			mapLat:
				this.getLatLng && this.getLatLng.lat
					? this.getLatLng.lat
					: "25.102339871949297",
			mapLng:
				this.getLatLng && this.getLatLng.lng
					? this.getLatLng.lng
					: "55.15250176191331",
			newLat: null,
			newLng: null,
		};
	},
	computed: {
		...mapGetters({
			getLocationDialog: "address/getLocationDialog",
			getLatLng: "address/getLatLng",
		}),
		dialogStatus: {
			get() {
				if (this.getLocationDialog) {
					setTimeout(() => {
						if (!this.voidMap) {
							this.getMap();
						}
					}, 1000);
				}
				return this.getLocationDialog;
			},
		},
	},
	methods: {
		getMap() {
			this.voidMap = true;
			/*if(Boolean(this.getLatLng.lat) && Boolean(this.getLatLng.lng)) {

                }*/
			let latlng = L.latLng(this.mapLat, this.mapLng);
			// initialize the map on the "map" div with a given center and zoom
			let map = new L.map("map-wrap", {
				center: latlng,
				zoom: 14,
			});
			// create a new tile layer
			let tileUrl =
				"https://tile.thunderforest.com/transport/{z}/{x}/{y}.png?apikey=c09591ed1cec46ff9ec390e6958a7516";
			let layer = new L.TileLayer(tileUrl, {
				maxZoom: 18,
			});
			let greenIcon = L.icon({
				iconUrl: "/icons/ic_location.png",
				iconSize: [24, 41], // size of the icon
				shadowSize: [26, 60], // size of the shadow
				iconAnchor: [22, 54], // point of the icon which will correspond to marker's location
				shadowAnchor: [4, 62], // the same for the shadow
				popupAnchor: [-3, -46], // point from which the popup should open relative to the iconAnchor
			});
			let marker = L.marker(latlng, {
				draggable: true,
				autoPan: true,
				icon: greenIcon,
			}).addTo(map);
			marker.on("drag", function (e) {
				let marker = e.target;
				let position = marker.getLatLng();
				// console.log(marker);
				this.newLat = marker._latlng.lat;
				this.newLng = marker._latlng.lng;
				// console.log($latInput.val(), $lngInput.val());
				// console.log(marker._latlng);
				//            marker.openPopup();
				// mymap.panTo([position.lat, position.lng], 250);
			});
			let onMapClick = e => {
				marker.setLatLng(e.latlng);
				map.setView([e.latlng.lat, e.latlng.lng]);
				this.newLat = e.latlng.lat;
				this.newLng = e.latlng.lng;
			};
			map.addLayer(layer);
			map.on("click", onMapClick);
		},
		_leafLetMapCustom($isPopup) {
			var $addressForm = $(".card_address-add");
			var $latInput = $('input[name="lat"]'),
				$lngInput = $('input[name="lng"]');
			/*var $latInput = $addressForm.find('input[name="lat"]'),
                    $lngInput = $addressForm.find('input[name="lng"]');*/
			// console.log('LAT LNG', $latInput , $lngInput);
			// https://stackoverflow.com/questions/14756420/emulate-click-on-leaflet-map-item
			var mymap = L.map("mapid", {
				center: [$latInput.val(), $lngInput.val()],
				zoom: 16,
				photonControl: false,
				photonControlOptions: {
					placeholder: "Try me â€¦",
					position: "topleft",
				},
			});
			var greenIcon = L.icon({
				// iconUrl: 'https://cdn.iconscout.com/icon/free/png-256/car-location-find-navigate-gps-location-29571.png',
				iconUrl: "/client/build/icons/ic_location.png",
				// shadowUrl: 'leaf-shadow.png',

				//            iconSize:     [38, 95], // size of the icon
				iconSize: [38, 47], // size of the icon
				shadowSize: [50, 64], // size of the shadow
				iconAnchor: [22, 54], // point of the icon which will correspond to marker's location
				shadowAnchor: [4, 62], // the same for the shadow
				popupAnchor: [-3, -76], // point from which the popup should open relative to the iconAnchor
			});
			var marker = L.marker([$latInput.val(), $lngInput.val()], {
				draggable: true,
				autoPan: true,
				title: "Ù…ÙˆÙ‚Ø¹ÛŒØª Ø´Ù…Ø§",
				icon: greenIcon,
				autoPanSpeed: 10, // default
			})
				.addTo(mymap)
				.on("mouseover", markerOnClick);

			function markerOnClick(e) {
				/*  alert(this.getLatLng());*/
			}

			var myHoverIcon = L.icon({
				//            iconUrl: 'http://leafletjs.com/examples/custom-icons/leaf-red.png'
			});
			marker.on("click", function (e) {
				/* marker.setIcon(greenIcon);*/
			});
			// marker.setIcon(greenIcon);
			// 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
			L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
				maxZoom: 18,
				attribution:
					'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
					'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
					'Imagery Â© <a href="https://www.mapbox.com/">Mapbox</a>',
				// id: 'mapbox.streets',
			}).addTo(mymap);
			// marker.bindPopup("<b>Ø´Ø±Ú©Øª Ø¢Ø±Ù†Ø§Ø¯</b> <br> Ù…ÙˆÙ‚Ø¹ÛŒØª Ø´Ù…Ø§ Ø¯Ø± Ù†Ù‚Ø´Ù‡").openPopup();
			if (
				$isPopup != false ||
				$isPopup == null ||
				$isPopup == undefined
			) {
				marker
					.bindPopup(
						"<b>Ø¬Ù‡Øª Ø§Ù†ØªØ®Ø§Ø¨ Ù…ÙˆÙ‚Ø¹ÛŒØª Ø®ÙˆØ¯ Ø±ÙˆÛŒ Ù†Ù‚Ø´Ù‡ Ú©Ù„ÛŒÚ© Ú©Ù†ÛŒØ¯</b>"
					)
					.openPopup();
			}

			marker.on("drag", function (e) {
				var marker = e.target;
				var position = marker.getLatLng();
				// console.log(marker);
				$latInput.val(marker._latlng.lat);
				$lngInput.val(marker._latlng.lng);
				// console.log($latInput.val(), $lngInput.val());
				// console.log(marker._latlng);
				//            marker.openPopup();
				// mymap.panTo([position.lat, position.lng], 250);
			});

			var popup = L.popup();

			function onMapClick(e) {
				marker.setLatLng(e.latlng);
				// mymap.setView([e.latlng.lat, e.latlng.lng],mymap._zoom);
				mymap.setView([e.latlng.lat, e.latlng.lng]);
				// popup.setLatLng(e.latlng).setContent("Ø´Ù…Ø§ Ø§ÛŒÙ† Ù…Ú©Ø§Ù† Ø±Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ù†Ù…ÙˆØ¯ÛŒØ¯").openOn(mymap);
				// console.log(e.latlng);
			}

			mymap.on("click", onMapClick);

			//stackoverflow.com/questions/23016863/adding-an-external-find-my-location-button-outside-of-the-map
			https: $(".my-location").on("click", function () {
				mymap.locate({ setView: true, maxZoom: 15 });
			});
			mymap.on("locationfound", onLocationFound);

			function onLocationFound(e) {
				// e.heading will contain the user's heading (in degrees) if it's available, and if not it will be NaN. This would allow you to point a marker in the same direction the user is pointed.
				$latInput.val(marker._latlng.lat);
				$lngInput.val(marker._latlng.lng);
				// L.marker(e.latlng)
				// L.marker([$latInput.val(), $lngInput.val()]).addTo(mymap);
				onMapClick(e);
				// marker.setIcon(greenIcon);
			}
		}, // _leafLetMapCustom
		closeDialog() {
			this.$store.dispatch("address/setLatLng", {
				lat: this.newLat,
				lng: this.newLng,
			});
			this.$store.dispatch("address/setLocationDialog", false);
			this.newLat = null;
			this.newLng = null;
		},
	},
};
</script>
