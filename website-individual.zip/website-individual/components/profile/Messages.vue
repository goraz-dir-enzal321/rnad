<template>
	<div>
		<v-sheet
			color="grey lighten-4"
			:elevation="1"
			class="mx-auto pa-3 mb-3"
			v-html="
				getDynamicText && getDynamicText('MESSAGE')
					? getDynamicText('MESSAGE')
					: $t('header.text.archive_messages')
			"
		/>
		<v-card
			class="mx-auto mb-2"
			v-for="(message, index) in messagesComputed"
			:key="index"
		>
			<v-card-title
				class="d-flex flex-column align-start grey lighten-4 py-0"
			>
				<p class="text--primary ma-0">{{ message.title }}</p>
				<div class="font-size-caption">{{(message.created)}}</div>
			</v-card-title>
			<v-card-text class="py-2">{{ message.body }}</v-card-text>
		</v-card>
		<v-btn
			class="ma-2"
			:loading="loading"
			:disabled="loading"
			v-on:click="getMessagessApi"
			v-if="hasMoreData"
			:color="
				getBtnStyle && getBtnStyle.bg
					? getBtnStyle.bg
					: Boolean(getSiteColor)
					? getSiteColor.secondColor
					: 'grey'
			"
			:style="[
				{
					color:
						getBtnStyle && getBtnStyle.text ? getBtnStyle.text : '',
				},
			]"
			>{{ $t("button.more") }}</v-btn
		>
	</div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	data() {
		return {
			loading: false,
			page: 0,
			messages: [],
			paginate: 0,
			hasMoreData: true,
		};
	},
	computed: {
		...mapGetters({
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			getDynamicText: "siteSetting/getDynamicText",
		}),
		messagesComputed: {
			get(data) {
				return this.messages;
			},
		},
	},
	mounted() {
		this.getMessagessApi();
	},
	methods: {
		getMessagessApi() {
			this.loading = true;
			this.$axios
				.$post("userMessages", {
					token: this.$store.state.auth.access_token,
					page: this.paginate,
					lang: this.$i18n.locale,
				})
				.then(res => {
					if (res.data.length) {
						this.paginate += 1;
						res.data.map(item => {
							return this.messages.push(item);
						});
					} else {
						return (this.hasMoreData = false);
					}
				})
				.catch(errror => {
					console.error("errror ", errror);
				});
			this.loading = false;
		},
	},
};
</script>
