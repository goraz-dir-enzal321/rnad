<template>
	<div>
		<v-sheet
			color="grey lighten-4"
			:elevation="1"
			class="mx-auto pa-3 mb-3"
			v-html="
				getDynamicText && getDynamicText('MY_ADDRESS')
					? getDynamicText('MY_ADDRESS')
					: $t('header.text.you_can_edit_address')
			"
		/>
		<v-row v-if="!isShowLoader">
			<v-col>
				<v-btn
					dark
					@click="(isEdit = false), getShopList()"
					class="mx-auto d-block"
					min-width="300px"
					:loading="loading"
					:disabled="loading"
					:color="
						getBtnStyle && getBtnStyle.bg
							? getBtnStyle.bg
							: Boolean(getSiteColor)
							? getSiteColor.secondColor
							: 'grey'
					"
					:style="[
						{
							color:
								getBtnStyle && getBtnStyle.text
									? getBtnStyle.text
									: '',
						},
					]"
				>
					<v-icon>mdi-plus</v-icon>
					{{ $t("button.new_address") }}
				</v-btn>
				<v-dialog v-model="dialog" width="500" persistent>
					<v-form ref="form" @submit.prevent="validate">
						<v-card :loading="loading">
							<v-card-title
								class="font-size-headline mb-3 justify-center"
								primary-title
								>{{
									$t("header.text.add_address")
								}}</v-card-title
							>
							<v-divider />
							<v-card-text>
								<v-select
									v-model="shopSelected"
									:items="shopLists"
									:item-text="translateText"
									item-value="id"
									return-object
									:disabled="loading"
									:label="$t('form.label.select')"
									required
									:rules="[rules.requiredArray]"
								/>

								<v-autocomplete
									v-model="areaSelected"
									:items="getAreaListsFromShopSelected"
									:item-text="translateText"
									item-value="id"
									return-object
									:disabled="loading"
									:label="$t('form.label.select_area')"
									required
									:rules="[rules.required]"
									autocomplete="off"
								/>
								<v-textarea
									v-model="addressDescription"
									:label="$t('form.label.your_address')"
									required
									:rules="[rules.required]"
									class="mb-4"
								/>
								<v-text-field
									dense
									v-model="addressPostalCode"
									:label="`${$t(
										'form.label.postal_code'
									)}  ( ${$t('form.label.optional')} )`"
									class="mb-4"
									:placeholder="$t('form.label.postal_code')"
									type="number"
									minlength="2"
									autocomplete="off"
									:rules="[rules.max]"
								/>
								<v-btn
									v-if="
										getHasFirstData &&
										getShops &&
										(getShops[0].has_send_product == 1 ||
											getShops[0].has_fixed_address == 1)
									"
									color="teal lighten-1 white--text"
									block
									@click="
										$store.dispatch(
											'address/setLocationDialog',
											true
										)
									"
									:loading="loading"
									:disabled="loading"
								>
									<v-icon>mdi-map</v-icon>
									{{ $t("button.set_your_location") }}
								</v-btn>
							</v-card-text>
							<v-divider />
							<v-card-actions>
								<div class="flex-grow-1"></div>
								<v-btn
									color="green darken-3"
									text
									type="submit"
									:loading="loading"
									:disabled="loading"
									>{{ $t("button.register") }}</v-btn
								>
								<!-- v-on:click="isEdit ? getUpdateAddress(true) : saveAddress(false)"-->
								<!-- <v-btn color="green darken-3" text v-on:click="getUpdateAddress(true)">{{$t('button.submit')}}</v-btn> -->
								<v-btn
									color="red darken-3"
									text
									@click="dialog = false"
									:loading="loading"
									:disabled="loading"
									>{{ $t("button.cancel") }}</v-btn
								>
								<div class="flex-grow-1"></div>
							</v-card-actions>
						</v-card>
					</v-form>
				</v-dialog>
				<LocationMap />
			</v-col>
		</v-row>
		<v-row v-if="!addresses.length">
			<v-col cols="6">
				<v-skeleton-loader
					type="image, card-heading, list-item"
					height="270px"
					tile
					v-if="isShowLoader"
				/>
			</v-col>
			<v-col cols="6">
				<v-skeleton-loader
					type="image, card-heading, list-item"
					height="270px"
					tile
					v-if="isShowLoader"
				/>
			</v-col>
		</v-row>
		<v-row v-if="addresses.length">
			<v-col
				cols="12"
				md="6"
				v-for="address in addressesComputed"
				:key="address.id"
			>
				<v-card
					class="mx-auto mb-2"
					:loading="loading"
					:disabled="loading"
				>
					<v-card-title class="d-flex flex-column align-start">
						<p class="text--primary ma-0">
							{{ $t("label.location") }}:
							{{ address.area ? address.area.name : "----" }}
						</p>
						<div class="font-size-body-2">
							{{ address.address }}
						</div>
					</v-card-title>
					<v-divider />
					<v-card-actions>
						<v-btn
							text
							color="green darken-3"
							@click="(isEdit = true), editAddress(address)"
						>
							<v-icon>mdi-home-edit</v-icon>
							{{ $t("button.edit") }}
						</v-btn>
						<v-btn
							text
							color="red darken-3"
							@click="removeAddress(address)"
						>
							<v-icon>mdi-delete</v-icon>
							{{ $t("button.delete") }}
						</v-btn>
					</v-card-actions>
				</v-card>
			</v-col>
		</v-row>
		<v-row class="text-center">
			<v-col cols="12">
				<v-btn
					class="ma-2"
					:loading="loading"
					:disabled="loading"
					@click="getAddressesApi"
					v-if="hasMoreData && !addresses.length"
					:color="
						getBtnStyle && getBtnStyle.bg
							? getBtnStyle.bg
							: Boolean(getSiteColor)
							? getSiteColor.secondColor
							: 'grey'
					"
					:style="[
						{
							color:
								getBtnStyle && getBtnStyle.text
									? getBtnStyle.text
									: '',
						},
					]"
					>{{ $t("button.more") }}</v-btn
				>
				<v-btn
					@click="getOrderPage"
					class="my-2 mx-auto"
					:loading="loading"
					:disabled="loading"
					color="info"
					width="280px"
					v-if="isNewAddress && addresses.length"
				>
					<!--&& addresses.length-->
					<v-icon>mdi-cart-arrow-right</v-icon>
					{{ $t("button.continue_shopping") }}
				</v-btn>
			</v-col>
		</v-row>
	</div>
</template>

<script>
import LocationMap from "~/components/profile/LocationMap";
import { mapGetters } from "vuex";

export default {
	name: "Addresses",
	components: { LocationMap },
	data() {
		return {
			addressId: null,
			isShowLoader: true,
			loading: false,
			dialog: false,
			locationDialog: true,
			shopLists: [],
			areasCategory: [],
			shopSelected: [],
			areaSelected: null,
			addresses: [],
			hasMoreData: true,
			paginate: 0,
			addressDescription: null,
			addressPostalCode: "",
			isEdit: false,
			valid: true,
			rules: {
				required: value =>
					!!value || this.$t("form.validation.error.require"),
				requiredArray: value => {
					return (
						Object.keys(value).length > 0 ||
						this.$t("form.validation.error.require")
					);
				},
				max: value => value.length <= 11 || "Max 11 characters",
			},
		};
	},
	computed: {
		...mapGetters({
			getLatLng: "address/getLatLng",
			isNewAddress: "order/isNewAddress",
			getSiteColor: "siteSetting/getSiteColor",
			getBtnStyle: "siteSetting/getBtnStyle",
			getHasFirstData: "firstData/getHasFirstData",
			getShops: "firstData/getShops",
			getDynamicText: "siteSetting/getDynamicText",
		}),
		addressesComputed: {
			get(data) {
				return this.addresses;
			},
		},
		getAreaListsFromShopSelected: {
			get() {
				return this.shopSelected.areas;
			},
		},
	},
	mounted() {
		this.getAddressesApi();
	},
	methods: {
		validate() {
			if (this.$refs.form.validate()) {
				this.valid = true;
				this.isEdit
					? this.getUpdateAddress(true)
					: this.saveAddress(false);
			} else {
				this.valid = false;
			}
		},
		getOrderPage() {
			this.$store.dispatch("order/newAddress", false);
			this.$router.push(this.localePath("order", this.$i18n.locale));
		},
		getAddressesApi() {
			this.loading = true;
			this.$axios
				.$post("userAddresses", {
					token: this.$store.state.auth.access_token,
					page: this.paginate,
					lang: this.$i18n.locale,
				})
				.then(res => {
					if (res.data.length) {
						this.paginate += 1;
						res.data.map(item => {
							this.addresses.push(item);
						});
					} else {
						this.hasMoreData = false;
					}
					this.isShowLoader = false;
				})
				.catch(error => {
					console.error("error ", error);
				})
				.finally(() => (this.loading = false));
		},
		saveAddress(isEdit) {
			if (!this.valid) {
				return;
			}
			this.loading = true;
			if (Object.keys(this.areaSelected).length) {
				let data = null;
				let $url = null;

				if (isEdit) {
					$url = "updateAddresses";
					data = {
						/* ............... data ............... */
					};
				} else {
					$url = "saveNewAddress";
					data = {
						token: this.$store.state.auth.access_token,
						area_id: this.areaSelected.id,
						postal_code: this.addressPostalCode,
						address: this.addressDescription,
						lat: this.getLatLng.lat,
						lng: this.getLatLng.lng,
						lang: this.$i18n.locale,
					};
				}
				this.$axios
					.$post($url, data)
					.then(res => {
						this.dialog = false;
						// if(isEdit) { this.paginate = 0; this.addresses = [] };
						this.paginate = 0;
						this.addresses = [];
						this.getAddressesApi();
					})
					.catch(error => {
						console.error(`${$url} => error `, error);
					})
					.finally(() => (this.loading = false));
			} // if
			else {
				alert(
					`Don't save because you don't select area of your branch :( !!!`
				);
				this.loading = false;
			}
		},
		getUpdateAddress(isEdit) {
			if (!this.valid) {
				return;
			}
			this.loading = true;
			if (Object.keys(this.areaSelected).length) {
				let data = {
					token: this.$store.state.auth.access_token,
					id: this.addressId,
					area_id: this.areaSelected.id,
					postal_code: this.addressPostalCode,
					address: this.addressDescription,
					lat: this.getLatLng.lat,
					lng: this.getLatLng.lng,
					lang: this.$i18n.locale,
				};
				this.$axios
					.$post("updateAddresses", data)
					.then(res => {
						this.dialog = false;
						this.paginate = 0;
						this.addresses = [];
						this.getAddressesApi();
					})
					.catch(error => {
						console.error(`error `, error);
					});
			} // if
			else {
				alert(
					`Don't save because you don't select area of your branch :( !!!`
				);
				this.loading = false;
			}
		},
		editAddress(address) {
			this.addressId = address.id;
			this.dialog = true;
			this.getShopList().then(() => {
				if (this.shopLists.length) {
					this.shopLists.map((shop, index) => {
						// if (shop.areas.length && Object.keys(address.area).length) {
						if (shop.areas.length && Object.keys(address).length) {
							shop.areas.map(area => {
								if (area.id == address.area_id) {
									this.shopSelected = shop;
									this.areaSelected = area;
								}
							});
						}
					});
				}
				this.addressPostalCode = address.postal_code;
				this.addressDescription = address.address;
				if (Object.keys(address.area).length) {
					this.areaSelected = {
						id: address.area.id,
						name: address.area.name,
					};
				}
			});
			if (Boolean(address.lat) && Boolean(address.lng)) {
				this.$store.dispatch("address/setLatLng", {
					lat: address.lat,
					lng: address.lng,
				});
			}
		},
		removeAddress(address) {
			this.loading = true;
			this.$axios
				.$post("deleteAddress", {
					token: this.$store.state.auth.access_token,
					address_id: address.id,
				})
				.then(res => {
					// this.getAddressesApi();
					this.addresses.map((item, index) => {
						this.addresses.map((item, index) => {
							if (address.id == item.id) {
								this.addresses.splice(index, 1);
							}
						});
					});
				})
				.catch(error => {
					console.error(`deleteAddress => error `, error);
				})
				.finally(() => (this.loading = false));
		},
		translateText(item) {
			if (item.translations) {
				for (const key in item.translations) {
					if (item.translations[key].locale == this.$i18n.locale) {
						return item.translations[key].title;
					}
				}
			}
			return item.name;
		},
		async getShopList() {
			this.dialog = true;
			this.loading = true;
			this.shopSelected = [];
			this.areaSelected = null;
			this.addressPostalCode = "";
			this.addressDescription = null;
			if (!this.shopLists.length) {
				await this.$axios
					.$post("areaList", {
						token: this.$store.state.auth.access_token,
						lang: this.$i18n.locale,
					})
					.then(res => {
						if (res.data.length) {
							res.data.map(shop => this.shopLists.push(shop));
						}
						this.loading = false;
					})
					.catch(error => {
						console.error("error ", error);
					});
			} else {
				this.loading = false;
			}
		},
	},
};
</script>
