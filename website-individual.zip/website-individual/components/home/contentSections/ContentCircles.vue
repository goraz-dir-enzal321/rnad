<template>
	<div
		:style="[{ 'background-color': getSectionColor }, 'min-height: 95vh']"
		v-if="sliderData.find(item => !!item.img)"
	>
		<v-container>
			<div
				class="d-flex justify-content-center align-center justify-center"
			>
				<v-carousel
					:height="$device.isMobile ? '100%' : '700px'"
					:class="[carouselClass, { 'pb-9': $device.isMobile }]"
					v-model="modelCarousel"
					:hide-delimiters="!$device.isMobile"
					:show-arrows="!$device.isMobile && sliderData.length > 1"
					hide-delimiter-background
				>
					<template v-for="(slide, i) in sliderData">
						<v-carousel-item
							:key="i"
							v-if="slide && slide.title && slide.text"
						>
							<v-row class="align-center fill-height">
								<ContentText
									:tinyTitle="slide.tiny_title"
									:txtColor="slide.txt_color"
									:title="slide.title"
									:contentTxt="slide.text"
									:link="slide.link"
									:btnTxt="slide.btn_text"
									:classColumn="`col-12 col-sm-${
										slide.img ? '6' : '12'
									} order-1 order-sm-0 p${
										slide.img ? 's-sm-6' : 'x-sm-6'
									}`"
								/>
								<v-col
									cols="12"
									sm="6"
									class="mb-3 mb-sm-5 pb-sm-5 order-0 order-sm-1"
									v-if="slide.img"
									:style="{
										height: $device.isMobile
											? '400px'
											: '500px',
									}"
								>
									<v-img
										style="border-radius: 100%;"
										class="mx-auto block"
										:width="
											$device.isMobile ? '100%' : '500px'
										"
										:height="
											$device.isMobile ? null : '500px'
										"
										:contain="true"
										:src="`${getDomain}storage/${slide.img}`"
										:lazy-src="`${getDomain}storage/${slide.img}`"
									>
										<template v-slot:placeholder>
											<v-card
												:width="
													$device.isMobile
														? '100%'
														: '500px'
												"
												height="500px"
												:aspect-ratio="1 / 1"
												class="fill-height ma-0 d-flex align-center justify-center"
												align="center"
												justify="center"
												elevation="0"
												color="#0003"
											>
												<v-progress-circular
													indeterminate
													:width="2"
													color="grey lighten-5"
												/>
											</v-card>
										</template>
									</v-img>
								</v-col>
							</v-row>
						</v-carousel-item>
					</template>
				</v-carousel>
			</div>
		</v-container>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import ContentText from "~/components/home/contentSections/common/ContentText.vue";
export default {
	name: "ContentCircles",
	props: ["sliderData"],
	components: {
		ContentText,
	},
	data() {
		return {
			modelCarousel: 0,
			carouselClass: "half-item",
		};
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
		getSectionColor() {
			let $item = this.sliderData[this.modelCarousel].img;
			if ($item) {
				this.carouselClass = "half-item";
			} else {
				this.carouselClass = "";
			}

			if (this.sliderData[this.modelCarousel].bg_color) {
				return this.sliderData[this.modelCarousel].bg_color;
			}
			return "transparent";
		},
	},
};
</script>