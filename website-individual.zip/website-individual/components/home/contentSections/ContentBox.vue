<template>
	<div
		:style="[
			{
				'background-color': sectionData.bg_color
					? sectionData.bg_color
					: 'grey lighten-5',
			},
			$device.isMobile ? { 'min-height': '97vh' } : { height: '97vh' },
		]"
	>
		<v-container style="height: 100%;" class="py-0">
			<v-row class="fill-height align-center">
				<v-col cols="12" md="5" style="height: 400px;">
					<v-img
						class="mx-auto rounded-lg"
						max-width="400"
						max-height="100%"
						min-height="350"
						:src="`${getDomain}storage/${sectionData.img}`"
						:lazy-src="`${getDomain}storage/${sectionData.img}`"
					>
						<template v-slot:placeholder>
							<v-card
								width="100%"
								height="400px"
								:aspect-ratio="1 / 1"
								class="fill-height ma-0 d-flex align-center justify-center"
								align="center"
								justify="center"
								elevation="0"
								color="#0003"
							>
								<v-progress-circular
									indeterminate
									:width="2"
									color="grey lighten-5"
								/>
							</v-card>
						</template>
					</v-img>
				</v-col>
				<ContentText
					v-if="sectionData.title && sectionData.text"
					:tinyTitle="sectionData.tiny_title"
					:txtColor="sectionData.txt_color"
					:title="sectionData.title"
					:contentTxt="sectionData.text"
					:link="sectionData.link"
					:btnTxt="sectionData.btn_text"
               classColumn='col-12 col-md-7 pe-md-12'
				/>
			</v-row>
		</v-container>
	</div>
</template>
<script>
import { mapGetters } from "vuex";
import ContentText from "~/components/home/contentSections/common/ContentText.vue";
export default {
	name: "ContentBox",
	props: ["sectionData"],
	components: {
		ContentText,
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
