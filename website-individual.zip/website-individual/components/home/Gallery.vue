<template>
	<div
		v-if="galleries.length"
		:style="[
			{
				'background-color': getGallerySettings.bg_color
					? getGallerySettings.bg_color
					: 'grey',
			},
		]"
	>
		<v-row class="fill-height ma-0" align="center">
			<v-col
				cols="12"
				class="font-size-title-custom font-weight-medium text-center pt-0"
				:style="[
					{
						color: getGallerySettings.header_txt_color
							? getGallerySettings.header_txt_color
							: '',
					},
				]"
				v-text="getGallerySettings.selected_category"
			/>
			<v-col cols="12" class="px-0">
				<VueSlickCarousel v-bind="settings">
					<div
						v-for="gallery in galleries"
						:key="gallery.id"
						class="px-2 rounded-0"
						:data-index="gallery.id"
					>
						<v-sheet
							flat
							class="text-center transparent mx-auto"
							:height="$device.isMobile ? '60vw' : '200px'"
							:width="$device.isMobile ? '60vw' : '200px'"
						>
							<v-img
								:height="$device.isMobile ? '60vw' : '200px'"
								:width="$device.isMobile ? '60vw' : '200px'"
								:src="
									gallery.img
										? getDomain + '/' + gallery.img
										: '/images/section-bg.jpg'
								"
								:lazy-src="
									gallery.thumbnail
										? getDomain + '/' + gallery.thumbnail
										: '/images/section-bg.jpg'
								"
								class="mx-auto rounded-lg elevation-2"
							/>
							<v-card-text
								v-text="gallery.description"
								class="pb-0"
							/>
						</v-sheet>
					</div>
				</VueSlickCarousel>
			</v-col>
			<v-col cols="12" class="text-center">
				<v-btn
					nuxt
					depressed
					min-width="200px"
					class="rounded-lg"
					:color="
						getGallerySettings.btn_bg_color
							? getGallerySettings.btn_bg_color
							: 'blue-grey darken-3'
					"
					:to="
						localePath({
							name: 'gallery-id-slug',
							params: {
								id: galleries[0].category.id,
								slug: galleries[0].category.name,
							},
						})
					"
					v-text="getGallerySettings.btn_txt"
					:style="{ color: getGallerySettings.btn_txt_color }"
				/>
			</v-col>
		</v-row>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import VueSlickCarousel from "vue-slick-carousel";
import "vue-slick-carousel/dist/vue-slick-carousel.css";
// optional style for arrows & dots
import "vue-slick-carousel/dist/vue-slick-carousel-theme.css";
import { gallery } from "@/api";

export default {
	components: { VueSlickCarousel },
	data() {
		return {
			settings: {
				autoplay: false,
				dots: false,
				arrows: false,
				infinite: true,
				speed: 500,
				slidesToShow: 8,
				initialSlide: 0,
				slidesToScroll: 1,
				centerMode: true,
				centerPadding: "30px",
				// speed: 500,
				// rtl: this.$vuetify.rtl
				responsive: [
					{
						breakpoint: 1749,
						settings: {
							slidesToShow: 7,
						},
					},
					{
						breakpoint: 1549,
						settings: {
							slidesToShow: 6,
						},
					},
					{
						breakpoint: 1332,
						settings: {
							slidesToShow: 5,
						},
					},
					{
						breakpoint: 1110,
						settings: {
							slidesToShow: 4,
						},
					},
					{
						breakpoint: 897,
						settings: {
							slidesToShow: 3,
						},
					},
					{
						breakpoint: 687,
						settings: {
							slidesToShow: 2,
						},
					},
					{
						breakpoint: 500,
						settings: {
							slidesToShow: 1,
						},
					},
				],
			},
			galleries: [],
		};
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getGallerySettings: "siteSetting/getGallerySettings",
			getMainShopId: "siteSetting/getMainShopId",
		}),
	},
	mounted() {
		this.getData();
	},
	methods: {
		async getData() {
			await this.$axios
				.post(gallery.galleriesShow, {
					shop_id: this.getMainShopId,
				})
				.then(res => (this.galleries = res.data.galleries))
				.catch(err => console.error({ err }));
		},
	},
};
</script>
<style lang="scss">
.slick-track {
	display: flex !important;
	justify-content: center !important;
}
</style>
