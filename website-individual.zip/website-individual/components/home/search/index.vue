<template>
	<div class="section-search-home">
		<loading v-if="getLoadingBoxSearch" />
		<v-sheet
			class="pos-relative overflow-hidden section-search d-flex align-center"
			min-height="91vh"
			height="90vh"
			v-else-if="
				getBoxSearch &&
				(getBoxSearch.title ||
					getBoxSearch.search ||
					getBoxSearch.text ||
					(getBoxSearch.btn_text && getBoxSearch.btn_link))
			"
			:color="
				getBoxSearch && getBoxSearch.bg_color
					? getBoxSearch.bg_color
					: '#232323'
			"
		>
			<imageSearch
				:isVideo="getBoxSearch.has_video"
				:file="getBoxSearch.link"
				:opacity="getBoxSearch.opacity"
			/>
			<v-sheet
				class="pos-relative row align-center justify-center mx-auto no-gutters"
				:style="
					getBoxSearch.txt_color
						? { color: getBoxSearch.txt_color }
						: { color: '#eee' }
				"
				:max-width="$device.isMobile ? '90%' : '40%'"
				color="transparent"
				no-gutters
				v-if="
					getBoxSearch.title ||
					getBoxSearch.search ||
					getBoxSearch.text ||
					(getBoxSearch.btn_text && getBoxSearch.btn_link)
				"
			>
				<v-col
					v-if="getBoxSearch.title"
					cols="12"
					class="font-size-text-h5 font-weight-black text-center py-2 mb-5"
					v-text="getBoxSearch.title"
				/>
				<v-col cols="12" v-if="getBoxSearch.search" class="mb-5">
					<v-text-field
						rounded
						v-model="textSearchComputed"
						:placeholder="
							getBoxSearch.hint ? getBoxSearch.hint : ''
						"
						solo
						type="search"
						hide-details="false"
						@keyup.enter="magnify()"
						@click:append="magnify()"
						append-icon="mdi-magnify"
						:rules="[() => !!textSearch]"
					/>
				</v-col>
				<v-col
					v-if="getBoxSearch.text"
					cols="12"
					class="mb-5 mt-1 px-2 text-center"
					v-html="getBoxSearch.text"
				/>
				<v-col
					v-if="getBoxSearch.btn_text && getBoxSearch.btn_link"
					cols="12"
					class="text-center"
				>
					<v-btn
						outlined
						large
						:color="
							getBoxSearch.txt_color
								? getBoxSearch.txt_color
								: '#eee'
						"
						:href="
							getBoxSearch.btn_link == 'SAVE_ORDER'
								? Object.keys(this.getFirstData).length &&
								  getHasStartOrder2
									? '#select-branch'
									: this.getFirstData.shops.length > 1
									? '#swiper-section'
									: '#main-section'
								: getBoxSearch.btn_link
						"
					>
						<span v-text="getBoxSearch.btn_text" />
						<v-icon
							v-text="
								$vuetify.rtl
									? 'mdi-chevron-left'
									: 'mdi-chevron-right'
							"
							right
							medium
						/>
					</v-btn>
				</v-col>
			</v-sheet>
		</v-sheet>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import imageSearch from "@/components/home/search/imageSearch";
import loading from "@/components/home/search/loading";
export default {
	data: () => ({
		textSearch: "",
	}),
	components: {
		imageSearch,
		loading,
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getBoxSearch: "search/getBoxSearch",
			getDomain: "siteSetting/getDomain",
			getLoadingBoxSearch: "search/getLoadingBoxSearch",
			getHasStartOrder2: "firstData/getHasStartOrder2",
		}),
		textSearchComputed: {
			get() {
				return this.textSearch;
			},
			set(value) {
				this.textSearch = value;
				this.$store.dispatch("search/setTextSearch", this.textSearch);
			},
		},
	},
	methods: {
		magnify() {
			if (this.textSearch && this.textSearch.length) {
				this.$router.push(
					`/${this.$i18n.locale}/search?keyword=${this.textSearch}`
				);
			}
		},
	},
	created() {
		this.textSearch = this.getTextSearch;
		this.$store.dispatch("search/setLoadingFilter", true);
		this.$store.dispatch("search/setLoadingSearch", true);
	},
};
</script>
