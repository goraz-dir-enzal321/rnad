<template>
	<v-dialog v-model="open" scrollable max-width="300px">
		<v-card :loading="loading" :disabled="loading">
			<v-card-title
				class="font-size-title justify-center align-center"
				primary-title
			>
				<div>
					{{
						headCategory ? headCategory : $t("header.text.category")
					}}
				</div>
				<v-btn
					@click="removeItemFromBreadcrumb(parent_id)"
					icon
					small
					absolute
					:left="!$vuetify.rtl"
					:right="$vuetify.rtl"
					v-if="headCategory"
				>
					<v-icon
						>mdi-{{
							$vuetify.rtl ? "arrow-right" : "arrow-left"
						}}</v-icon
					>
				</v-btn>
				<v-btn
					v-else
					@click="
						$store.commit('categories/SET_IS_SHOW_CATEGORIES_MODAL')
					"
					icon
					small
					absolute
					:left="!$vuetify.rtl"
					:right="$vuetify.rtl"
				>
					<v-icon>mdi-close</v-icon>
				</v-btn>
			</v-card-title>
			<v-divider />
			<v-card-text class="mt-3 pa-2" style="height: 400px;">
				<div
					@click="addItemToBreadcrumb(item)"
					v-for="(item, index) in items"
					:key="index"
					class="hover-text pa-1 mb-1 row-children-style d-flex justify-space-between"
				>
					<div class="px-2 d-flex align-center">{{ item.name }}</div>
					<v-icon v-if="item.child.length"
						>mdi-chevron-{{
							$vuetify.rtl ? "left" : "right"
						}}</v-icon
					>
				</div>
			</v-card-text>
		</v-card>
	</v-dialog>
</template>
<script>
import * as moment from "moment";
import { mapGetters } from "vuex";

export default {
	props: ["serverData", "isShowDialog"],
	data() {
		return {
			headCategory: null,
			parent_id: null,
			dialog: false,
			items: [],
			newBreadcrumb: [],
			loading: false,

			type: "selector",
			selector: "#main-section",
			duration: 1000,
			offset: 70,
			easing: "easeInOutCubic",
		};
	},
	computed: {
		...mapGetters({
			getBranchSelectedForCategories:
				"branch/getBranchSelectedForCategories",
			// getIsShowCategoriesModal: 'categories/getIsShowCategoriesModal',
			getCategoriesChildren: "branch/getCategoriesChildren",
			getSelectedChildren: "categories/getSelectedChildren",
			getSelectedBreadcrumb: "categories/getSelectedBreadcrumb",
		}),
		open: {
			get() {
				return this.isShowDialog;
			},
			set(val) {
				this.$store.commit(
					"categories/SET_IS_SHOW_CATEGORIES_MODAL",
					val
				);
			},
		},
		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},
		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	mounted() {
		this.items = this.serverData;

		// this.getSelectedBreadcrumb => has one item of this.serverData
		this.goToBreadcrumb(this.getSelectedBreadcrumb);
	},
	methods: {
		findCategory(itemId) {
			this.loading = true;
			if (!itemId) {
				this.setParentId(null);
				this.setCategoryName(null);
				this.items = this.serverData;
				// this.newBreadcrumb = [];
				this.loading = false;
				return;
			}
			let found = false;
			let recurse = treeDataArr => {
				for (let i = 0; i < treeDataArr.length; i++) {
					if (treeDataArr[i].id === itemId) {
						found = true;
						if (treeDataArr[i].child.length) {
							this.setParentId(treeDataArr[i].parent_id);
							this.setCategoryName(treeDataArr[i].name);
							this.items = [];
							this.items = treeDataArr[i].child;
							this.loading = false;
						} else {
							// done axios
							this.loading = true;

							if (!this.getBranchSelectedForCategories) {
								this.$store.dispatch("branch/emptyCategories");
								return;
							}
							let $branch = this.getBranchSelectedForCategories;
							let $data = {
								category_id: treeDataArr[i].id,
								lang: this.$i18n.locale,
							};
							this.$axios
								.$post("getCategoryProducts", $data)
								.then(res => {
									if (res.status) {
										// If it branch has_approve. The user needs administrator approval to pay
										this.$store.dispatch(
											"branch/hasApprove",
											$branch.has_approve
										);
										this.$store.dispatch(
											"productInfo/setStyledProductShop",
											{
												basket_btn_type:
													$branch.card
														.basket_btn_type,
												description_style:
													$branch.card
														.description_style,
												description_btn:
													$branch.card
														.description_btn,
												has_product_voice:
													$branch.has_product_voice,
											}
										);

										// Set card style
										this.$store.dispatch(
											"branch/cardStyle",
											$branch.card
										);

										try {
											let userLocaleUtcTime = moment()
												.utc()
												.format("HH:mm:ss");
											let isOpenBranch =
												($branch.am_time_start <=
													userLocaleUtcTime &&
													userLocaleUtcTime <=
														$branch.am_time_end) ||
												($branch.pm_time_start <=
													userLocaleUtcTime &&
													userLocaleUtcTime <=
														$branch.pm_time_end);
											this.$store.dispatch(
												"branch/setIsOpenBranch",
												isOpenBranch
											);
											this.$vuetify.goTo(
												this.target,
												this.options
											);
											if (
												!Object.keys(res.categories)
													.length
											) {
												this.$store.dispatch(
													"snackbar/isShow",
													true
												);
												this.$store.dispatch(
													"snackbar/setText",
													"No any categories"
												);
												this.$store.dispatch(
													"snackbar/setColor",
													"warning"
												);
											} else {
												this.$store.dispatch(
													"branch/setBranchSelectedData",
													res.categories
												);
											}
										} catch (e) {
											console.error("catch ", e);
										}
										this.$store.dispatch(
											"categories/setEmptyCategoryBreadCrumbs"
										);
										this.newBreadcrumb.map(val => {
											this.$store.dispatch(
												"categories/setCategoryBreadCrumbs",
												val
											);
										});
									} // if(res.status)
								})
								.catch(err => console.error(err))
								.finally(() => {
									this.loading = false;
									this.$store.commit(
										"categories/SET_IS_SHOW_CATEGORIES_MODAL"
									);
								});
							return;
						}
						break;
					} else {
						// Are there children / sub-categories? YES
						if (treeDataArr[i].child.length > 0) {
							recurse(treeDataArr[i].child);
							if (found) {
								break;
							}
						}
					}
				}
			};
			recurse(this.serverData);
			return this.items;
		},
		setCategoryName(name) {
			this.headCategory = name;
		},
		setParentId(itemId) {
			this.parent_id = itemId;
		},
		addItemToBreadcrumb(item) {
			let sameParent = null,
				sameId = null;

			this.newBreadcrumb.find(value => {
				sameId = value.id == item.id;
				sameParent = value.parent_id == item.parent_id;
			});

			/* if (sameParent && !sameId) {
				this.newBreadcrumb.pop();
			} */

			/* if (!sameId) {
				this.newBreadcrumb.push(item);
			} */

			return this.findCategory(item.id);
		},
		removeItemFromBreadcrumb(parent_id) {
			this.newBreadcrumb = this.newBreadcrumb.filter(
				(value, index, arr) => value.parent_id == parent_id
			);
			return this.findCategory(parent_id);
		},
		goToBreadcrumb(item) {
			if (this.getSelectedChildren.length && !this.newBreadcrumb.length) {
				this.newBreadcrumb = this.getSelectedChildren;
			}

			if (this.newBreadcrumb.length && item) {
				let $index = this.newBreadcrumb.findIndex(x => x.id == item.id),
					arr = this.newBreadcrumb.filter(
						(item, key) => $index >= key
					);
				this.newBreadcrumb = arr;
			}

			if (!item) {
				return;
			}

			return this.findCategory(item.parent_id);
		},
	},
};
</script>
<style scoped>
.row-children-style {
	box-shadow: 1px 0 3px #eee;
	border: 2px solid #eee !important;
	border-radius: 12px;
	max-width: 400px;
	transition: all 0.25s ease-in-out;
	min-height: 40px;
}
.hover-text:hover {
	cursor: pointer;
}
.hover-text:not(.no-shadow):hover {
	background-color: #eee;
}
</style>
