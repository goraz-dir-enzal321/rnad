<template>
	<v-sheet
		color="transparent"
		class="col col-auto pa-0 text-center pos-relative d-inline-block"
		max-width="178"
	>
		<v-img
			:width="$device.isMobile ? 155 : '100%'"
			class="rounded-lg"
			:src="
				img.startsWith(`http`) || img.startsWith(`storage/`)
					? img.startsWith(`storage/`)
						? getDomain + img
						: img
					: `${getDomain}storage/${img}`
			"
			:alt="$t('offer.AmazingOffer')"
		/>
		<div class="mx-2 mt-1">
			<v-btn
				block
				:color="txt_color ? txt_color : '#222'"
				outlined
				@click="
					$router.push(`/${$i18n.locale}/search?has_discount=true`)
				"
			>
				<span v-text="btn_text ? btn_text : $t('offer.SeeAll')" />
				<v-icon
					v-text="
						$vuetify.rtl ? 'mdi-chevron-left' : 'mdi-chevron-right'
					"
					right
					medium
				/>
			</v-btn>
		</div>
		<div class="section-more-in-mobile" v-if="$device.isMobile">
			<v-icon large dark light v-text="'mdi-chevron-right'" />
		</div>
	</v-sheet>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["img", "txt_color", "btn_text"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
