<template>
	<v-col
		class="pos-relative"
		:class="
			$device.isMobile ? 'overflow-x-auto' : 'overflow-hidden rounded-lg'
		"
		cols="12"
		sm="10"
	>
		<!-- slider -->
		<template v-if="$device.isMobile">
			<div style="white-space: nowrap;" class="d-flex">
				<infoOffer
					:img="productSetting.img"
					:txt_color="productSetting.txt_color"
					:btn_text="productSetting.btn_text"
					v-if="$device.isMobile"
				/>
				<template v-for="(product, index) in products">
					<v-col
						cols="auto"
						:key="index"
						class="pa-0 ps-2 d-inline-block"
						style="width: 220px;"
					>
						<product
							:slideStatus="true"
							:btnColorMore="productSetting.bg_color"
							:product="product"
							v-if="product"
						/>
					</v-col>
				</template>
				<v-col
					cols="auto"
					class="py-0 px-2 d-inline-block"
					style="width: 220px;"
				>
					<v-card
						:height="$device.isMobile ? '100%' : 366"
						class="section-product-search pt-sm-1 rounded-lg direction-rtl"
						:class="[
							$device.isMobile ? 'font-size-15' : 'font-size-13',
						]"
						outlined
						nuxt
						@click="
							$router.push(
								`/${$i18n.locale}/search?has_discount=true`
							)
						"
					>
						<v-row
							class="mx-0 py-2 h-100"
							justify="center"
							align="center"
						>
							<!-- img product -->
							<v-col sm="12" class="pa-0 text-center" cols="auto">
								<v-btn
									depressed
									fab
									icon
									outlined
									x-large
									color="info"
									><v-icon
										v-text="
											$vuetify.rtl
												? $device.isMobile
													? 'mdi-arrow-left'
													: 'mdi-arrow-right'
												: $device.isMobile
												? 'mdi-arrow-right'
												: 'mdi-arrow-left'
										"
										medium
								/></v-btn>
								<div
									v-text="productSetting.btn_text"
									class="py-2 font-size-15 font-weight-medium"
								/>
							</v-col>
						</v-row>
					</v-card>
				</v-col>
			</div>
		</template>
		<template v-else>
			<VueSlickCarousel
				ref="carouselOffer"
				v-bind="settingsCarousel"
				:arrows="false"
				class="row no-gutters"
			>
				<template v-for="(product, index) in products">
					<v-col
						cols="auto"
						:key="index"
						class="pa-0 ps-2 d-inline-block"
						style="width: 220px;"
					>
						<product
							:slideStatus="true"
							:btnColorMore="productSetting.bg_color"
							:product="product"
							v-if="product"
						/>
					</v-col>
				</template>
			</VueSlickCarousel>
			<!-- button next and prev -->
			<template
				v-if="
					windowWidth &&
					windowWidth >= 850 &&
					((windowWidth <= 1904 &&
						windowWidth >= 1264 &&
						products.length > 5) ||
						(windowWidth <= 1264 && products.length > 4))
				"
			>
				<v-btn
					absolute
					depressed
					class="section-arrow-carousel section-next"
					large
					fab
					:dark="!$wc_hex_is_light(productSetting.bg_color)"
					:light="$wc_hex_is_light(productSetting.bg_color)"
					:color="productSetting.bg_color"
					@click="showNextSlide()"
				>
					<v-icon
						v-text="
							$vuetify.rtl
								? 'mdi-chevron-left'
								: 'mdi-chevron-right'
						"
						large
					/>
				</v-btn>
				<v-btn
					absolute
					depressed
					class="section-arrow-carousel section-prev"
					fab
					large
					:dark="!$wc_hex_is_light(productSetting.bg_color)"
					:light="$wc_hex_is_light(productSetting.bg_color)"
					:color="productSetting.bg_color"
					@click="showPrevSlide()"
				>
					<v-icon
						v-text="
							$vuetify.rtl
								? 'mdi-chevron-right'
								: 'mdi-chevron-left'
						"
						large
					/>
				</v-btn>
			</template>
		</template>
	</v-col>
</template>

<script>
import product from "@/components/search/result/product";
import infoOffer from "@/components/home/offer/infoOffer";
import VueSlickCarousel from "vue-slick-carousel";
export default {
	components: {
		product,
		infoOffer,
		VueSlickCarousel,
	},
	props: ["products", "productSetting"],
	data: () => ({
		settingsCarousel: {
			autoplay: true,
			speed: 500,
			autoplaySpeed: 4500,
			slidesToShow: 4,
			swipeToSlide: true,
			pauseOnDotsHover: true,
			pauseOnFocus: true,
			pauseOnHover: true,
			responsive: [
				{
					breakpoint: 1904,
					settings: {
						slidesToShow: 5,
					},
				},
				{
					breakpoint: 1264,
					settings: {
						slidesToShow: 4,
					},
				},
				{
					breakpoint: 849,
					settings: {
						slidesToShow: 3,
					},
				},
				{
					breakpoint: 580,
					settings: {
						// slidesToShow: 2,
						slidesToShow: 1,

						// slidesToScroll: 1,
					},
				},
			],
		},
		windowWidth: null,
	}),
	mounted() {
		this.windowWidth = window.innerWidth;
		if (this.$device.isMobile) {
			this.settingsCarousel["centerMode"] = true;
			this.settingsCarousel["infinite"] = false;
			this.settingsCarousel["autoplay"] = false;
			this.settingsCarousel["speed"] = 250;
			this.settingsCarousel["rtl"] = this.$vuetify.rtl;
		}
	},

	methods: {
		showNextSlide() {
			this.$refs.carouselOffer.next();
		},
		showPrevSlide() {
			this.$refs.carouselOffer.prev();
		},
	},
};
</script>
