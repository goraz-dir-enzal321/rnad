<template>
	<v-container
		:style="[
			{ background: bgImage },
			{ 'background-size': 'cover' },
			{ 'min-height': '70vh' },
		]"
		v-if="hasData"
		fluid
		class="d-flex justify-center align-center"
	>
		<v-row>
			<v-col>
				<v-sheet
					style="max-width: 800px;"
					class="transparent mx-auto pa-3"
				>
					<h2
						class="font-size-title-custom mb-5"
						:style="[
							{
								color: startOrderingData.txt_color
									? startOrderingData.txt_color
									: '',
							},
						]"
						v-text="startOrderingData.title"
					/>
					<div class="d-flex flex-column justify-space-between">
						<p
							class="sfProLight text-justify"
							:style="[
								'max-width: 500px;',
								{
									color: startOrderingData.txt_color
										? startOrderingData.txt_color
										: '',
								},
							]"
							v-text="startOrderingData.text"
						/>
						<v-btn
							style="min-width: 200px; max-width: 300px;"
							:loading="loading"
							:disabled="loading"
							:color="
								startOrderingData.txt_color
									? startOrderingData.txt_color
									: ''
							"
							@click="
								getProduct(getFirstData.shops[0].product_type)
							"
							v-text="startOrderingData.btn_text"
							outlined
							dark
						/>
					</div>
				</v-sheet>
			</v-col>
		</v-row>
	</v-container>
</template>
<script>
import { mapGetters } from "vuex";
export default {
	name: "StartOrdering",
	props: ["startOrderingData"],
	data() {
		return {
			hasData: 0,
			bgImage: null,
			loading: false,
		};
	},
	mounted() {
		this.checkData();
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getDomain: "siteSetting/getDomain",
			getBranchWarning: "branch/getBranchWarning",
		}),
	},
	methods: {
		getProduct(productType) {
			this.loading = true;
			this.$store.dispatch("branch/setBranchWarning", {
				beforeBranch: this.getBranchWarning.thisBranch,
				thisBranch: this.getFirstData.shops[0].min_product_error,
			});
			this.$store.dispatch(
				"branch/setBranch",
				this.getFirstData.shops[0]
			);
			this.$store.dispatch(
				"shop/setShopId",
				this.getFirstData.shops[0].id
			);
			this.$store.dispatch("productInfo/setStyledProductShop", {
				basket_btn_type: this.getFirstData.shops[0].card
					.basket_btn_type,
				description_style: this.getFirstData.shops[0].card
					.description_style,
				description_btn: this.getFirstData.shops[0].card
					.description_btn,
				has_product_voice: this.getFirstData.shops[0].has_product_voice,
			});
			if (productType == "MULTI_PRO" || productType == "SINGLE_PRO") {
				if (
					Boolean(this.getFirstData.categories) &&
					this.getFirstData.shops.length == 1
				) {
					// this.categoriesComputed = this.getFirstData.categories;
					this.$store.dispatch(
						"branch/setBranchSelectedData",
						this.getFirstData.categories
					);
				}
				if (
					this.getFirstData &&
					this.getFirstData.shops &&
					this.getFirstData.shops.length == 1
				) {
					// this.hasManyProductComputed = this.getFirstData.shops[0].has_many_product;

					// If it branch has_approve. The user needs administrator approval to pay
					this.$store.dispatch(
						"branch/hasApprove",
						this.getFirstData.shops[0].has_approve
					);

					// Set card style
					this.$store.dispatch(
						"branch/cardStyle",
						this.getFirstData.shops[0].card
					);
				}
				this.loading = false;
			} // if(productType == 'MULTI_PRO' || productType == 'SINGLE_PRO')
			else if (productType == "CATEGORISE") {
				// console.log('branch: this.getFirstData.shops[0], branchId: this.getFirstData.shops[0].id, lang: this.$i18n.locale ', {branch: this.getFirstData.shops[0], branchId: this.getFirstData.shops[0].id, lang: this.$i18n.locale})
				this.$store
					.dispatch("branch/categories", {
						branch: this.getFirstData.shops[0],
						branchId: this.getFirstData.shops[0].id,
						lang: this.$i18n.locale,
					})
					.then(res => {
						this.$store.dispatch(
							"categories/setSelectedBreadcrumb",
							{
								item: null,
								isStartOrdering2: false,
							}
						);
						this.$store.commit(
							"categories/SET_IS_SHOW_CATEGORIES_MODAL"
						);
						this.loading = false;
					});
			}
		},
		checkData() {
			let hasCountData = 0;
			if (
				Boolean(this.startOrderingData) &&
				Object.keys(this.startOrderingData).length &&
				this.startOrderingData.img
			) {
				let $image = this.startOrderingData;
				if ($image.title && $image.btn_text && $image.text) {
					hasCountData += 1;
					this.hasData = 1;
					this.bgImage =
						"transparent url(" +
						this.getDomain +
						"storage/" +
						$image.img +
						") no-repeat center center";
				}
			}
			return hasCountData;
		},
	},
};
</script>
