<template>
	<v-container
		fluid
		:style="[
			{
				'background-color': getCallUs.bg_color
					? getCallUs.bg_color
					: 'grey',
			},
		]"
		class="py-0 box-shadow-custom"
		v-if="Boolean(getCallUs)"
	>
		<v-row class="py-0">
			<v-col cols="12" class="py-0">
				<v-container class="py-0">
					<v-row class="py-0">
						<v-col cols="12" class="py-0">
							<div
								class="d-flex justify-center align-center"
								:class="[{ 'flex-column': $device.isMobile }]"
								style="position: relative; min-height: 56px;"
							>
								<div
									style="
										width: 80px;
										position: relative;
										min-height: 52px;
									"
									:class="[$vuetify.rtl ? 'ml-4' : 'mr-4']"
									v-if="!$device.isMobile"
								>
									<v-img
										:src="`${getDomain}storage/${getCallUs.img}`"
										height="50"
										width="50"
										style="
											width: 40px;
											height: auto;
											position: absolute;
											right: 0;
											top: -39%;
										"
									/>
								</div>
								<p
									class="font-size-body-2 mx-3 my-1"
									v-html="getCallUs.text"
									:style="[
										{ 'max-width': '450px' },
										{
											color: getCallUs.txt_color
												? getCallUs.txt_color
												: '',
										},
									]"
								/>
								<div class="d-flex align-center">
									<v-list dense class="pa-0 transparent">
										<v-list-item
											class="pa-0"
											style="min-height: 0;"
										>
											<v-list-item-icon
												class="ma-0"
												:style="[
													{
														color: getCallUs.txt_color
															? getCallUs.txt_color
															: '',
													},
												]"
											>
												<!-- <v-icon size="17" :color="getCallUs.txt_color ? getCallUs.txt_color : ''" >mdi-telegram</v-icon>-->
												<svg
													:fill="
														getCallUs.txt_color
															? getCallUs.txt_color
															: ''
													"
													enable-background="new 0 0 512 512"
													version="1.1"
													viewBox="0 0 512 512"
													xml:space="preserve"
													xmlns="http://www.w3.org/2000/svg"
													width="20"
													height="20"
												>
													<path
														d="m436.99 74.953c-99.989-99.959-262.08-99.935-362.04 0.055s-99.935 262.08 0.055 362.04 262.08 99.935 362.04-0.055c48.006-48.021 74.968-113.15 74.953-181.05-0.014-67.89-26.995-132.99-75.008-180.99zm-49.289 281.65c-0.011 0.011-0.022 0.023-0.034 0.034v-0.085l-12.971 12.885c-16.775 16.987-41.206 23.976-64.427 18.432-23.395-6.262-45.635-16.23-65.877-29.525-18.806-12.019-36.234-26.069-51.968-41.899-14.477-14.371-27.483-30.151-38.827-47.104-12.408-18.242-22.229-38.114-29.184-59.051-7.973-24.596-1.366-51.585 17.067-69.717l15.189-15.189c4.223-4.242 11.085-4.257 15.326-0.034 0.011 0.011 0.023 0.022 0.034 0.034l47.957 47.957c4.242 4.223 4.257 11.085 0.034 15.326l-28.194 28.194c-8.08 7.992-9.096 20.692-2.389 29.867 10.185 13.978 21.456 27.131 33.707 39.339 13.659 13.718 28.508 26.197 44.373 37.291 9.167 6.394 21.595 5.316 29.525-2.56l27.221-27.648c4.223-4.242 11.085-4.257 15.326-0.034l0.034 0.034 48.043 48.128c4.243 4.222 4.258 11.083 0.035 15.325z"
													/>
												</svg>
											</v-list-item-icon>
										</v-list-item>
										<v-list-item
											class="pa-0"
											style="min-height: 0;"
											:href="
												getCallUs.social_link
													? getCallUs.social_link
													: 'javascript:void(0)'
											"
											:target="
												getCallUs.social_link
													? '_blank'
													: '_self'
											"
										>
											<v-list-item-icon
												class="ma-0"
												:style="[
													{
														color: getCallUs.txt_color
															? getCallUs.txt_color
															: '',
													},
												]"
											>
												<!-- <v-icon size="17" :color="getCallUs.txt_color ? getCallUs.txt_color : ''" >mdi-linkedin-box</v-icon>-->
												<svg
													:fill="
														getCallUs.txt_color
															? getCallUs.txt_color
															: ''
													"
													enable-background="new 0 0 512 512"
													version="1.1"
													viewBox="0 0 512 512"
													xml:space="preserve"
													xmlns="http://www.w3.org/2000/svg"
													width="20"
													height="20"
												>
													<path
														d="m256.06 0h-0.128c-141.15 0-255.94 114.82-255.94 256 0 56 18.048 107.9 48.736 150.05l-31.904 95.104 98.4-31.456c40.48 26.816 88.768 42.304 140.83 42.304 141.15 0 255.94-114.85 255.94-256s-114.78-256-255.94-256zm148.96 361.5c-6.176 17.44-30.688 31.904-50.24 36.128-13.376 2.848-30.848 5.12-89.664-19.264-75.232-31.168-123.68-107.62-127.46-112.58-3.616-4.96-30.4-40.48-30.4-77.216s18.656-54.624 26.176-62.304c6.176-6.304 16.384-9.184 26.176-9.184 3.168 0 6.016 0.16 8.576 0.288 7.52 0.32 11.296 0.768 16.256 12.64 6.176 14.88 21.216 51.616 23.008 55.392 1.824 3.776 3.648 8.896 1.088 13.856-2.4 5.12-4.512 7.392-8.288 11.744s-7.36 7.68-11.136 12.352c-3.456 4.064-7.36 8.416-3.008 15.936 4.352 7.36 19.392 31.904 41.536 51.616 28.576 25.44 51.744 33.568 60.032 37.024 6.176 2.56 13.536 1.952 18.048-2.848 5.728-6.176 12.8-16.416 20-26.496 5.12-7.232 11.584-8.128 18.368-5.568 6.912 2.4 43.488 20.48 51.008 24.224 7.52 3.776 12.48 5.568 14.304 8.736 1.792 3.168 1.792 18.048-4.384 35.52z"
													/>
												</svg>
											</v-list-item-icon>
										</v-list-item>
									</v-list>
									<v-list dense class="pa-0 transparent">
										<v-list-item
											class="pa-0"
											style="min-height: 0;"
											v-for="(phone,
											index) in getCallUs.phones"
											:key="index"
										>
											<v-list-item-title
												class="pa-0 ma-0 font-size-body-2"
												:style="[
													{
														color: getCallUs.txt_color
															? getCallUs.txt_color
															: '',
													},
												]"
												>{{ phone }}</v-list-item-title
											>
										</v-list-item>
									</v-list>
								</div>
							</div>
						</v-col>
					</v-row>
				</v-container>
			</v-col>
		</v-row>
	</v-container>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "call_info",
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getFirstData: "firstData/getFirstData",
			getCallUs: "firstData/getCallUs",
		}),
	},
};
</script>
<style scoped>
.box-shadow-custom {
	-webkit-box-shadow: 0 -2px 4px -1px rgba(0, 0, 0, 0.2),
		0 -4px 5px 0 rgba(0, 0, 0, 0.14), 0 -1px 10px 0 rgba(0, 0, 0, 0.12);
	box-shadow: 0 -2px 4px -1px rgba(0, 0, 0, 0.2),
		0 -4px 5px 0 rgba(0, 0, 0, 0.14), 0 -1px 10px 0 rgba(0, 0, 0, 0.12);
}
</style>
