<template>
	<v-card>
		<v-subheader
			inset
			v-text="
				type == 'android'
					? $t('appDownload.androidDownload')
					: type == 'ios'
					? $t('appDownload.iosDownload')
					: $t('appDownload.donwloadApp')
			"
		/>
		<template v-for="(item, index) in market">
			<a
				:href="
					item.url.startsWith(`http`) ||
					item.url.startsWith(`storage/`) ||
					item.url.startsWith(`itms-services:`) ||
					item.url.startsWith(`www.`) ||
					item.url.endsWith(`.plist`) ||
					item.url.endsWith(`.apk`)
						? item.url.startsWith(`storage/`)
							? getDomain + item.url
							: item.url
						: `${getDomain}storage/${item.url}`
				"
				target="_blank"
				:key="index"
				class="text-decoration-none"
				v-if="market && market.length"
			>
				<v-list-item v-ripple>
					<v-img
						v-if="item.img"
						max-width="50"
						height="50"
						class="me-2"
						:src="
							item.img.startsWith(`http`) ||
							item.img.startsWith(`storage/`)
								? item.img.startsWith(`storage/`)
									? getDomain + item.img
									: item.img
								: `${getDomain}storage/${item.img}`
						"
					/>
					<v-sheet
						v-else
						width="50"
						height="50"
						class="rounded me-2"
						:color="color"
					/>
					<v-list-item-content>
						<v-list-item-title v-text="item.name" />
					</v-list-item-content>
					<v-list-item-action>
						<v-btn
							depressed
							:color="
								color.txt_color
									? color.txt_color
									: getSiteColor.color
									? getSiteColor.color
									: 'grey darken-3'
							"
							:dark="
								color.txt_color
									? !$wc_hex_is_light(color.txt_color)
									: true
							"
							:light="
								color.txt_color
									? $wc_hex_is_light(color.txt_color)
									: false
							"
						>
							<v-icon v-text="'mdi-download'" left />
							<span v-text="$t('button.download')" />
						</v-btn>
					</v-list-item-action>
				</v-list-item>
			</a>
		</template>
		<div
			class="pa-2"
			v-if="
				type == 'ios' && $device.isMobileOrTablet && getIsHasWebVertion
			"
		>
			<v-btn
				color="#30c00f"
				block
				height="56"
				depressed
				class="white--text rounded-lg"
				@click="
					$store.dispatch('appDownload/setDialogWebVertion', true)
				"
			>
				<v-row no-gutters class="ma-0 mx-3">
					<v-col cols="auto" class="me-2">
						<v-icon
							v-text="'mdi-apple'"
							style="font-size: 44px;"
							color="white"
						/>
					</v-col>
					<v-col
						class="flex-shrink-1"
						:class="$vuetify.rtl ? 'text-right' : 'text-left'"
					>
						<div
							class="font-size-12 font-weight-light"
							v-text="$t('appDownload.recommendedForIosUsers')"
						/>
						<div
							class="font-size-18 font-weight-bold"
							v-text="
								$t('appDownload.webVersionOfTheApplication')
							"
						/>
					</v-col>
				</v-row>
			</v-btn>
			<webVertion />
		</div>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import webVertion from "~/components/home/appInfo/downloadSection/webVertion";
export default {
	name: "downloadSection",
	components: {
		webVertion,
	},
	props: ["market", "type", "color"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getSiteColor: "siteSetting/getSiteColor",
			getIsHasWebVertion: "appDownload/getIsHasWebVertion",
		}),
	},
};
</script>
