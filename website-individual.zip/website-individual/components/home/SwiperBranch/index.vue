<template>
	<div
		v-if="Object.keys(getFirstData).length && getFirstData.shops.length > 1"
		id="swiper-section"
		:style="[
			{
				'background-color': getSwiperBgColor
					? getSwiperBgColor
					: 'rgba(0, 0, 0, 0.3)',
			},
		]"
	>
		<v-container class="py-0">
			<v-row>
				<template v-if="Boolean(getSettingLength)">
					<v-col
						cols="12"
						class="text-center font-weight-bold"
						:class="
							$device.isMobile
								? 'font-size-text-h5'
								: 'font-size-text-h4'
						"
						v-if="getBranchTitle"
						v-text="getBranchTitle"
					/>
				</template>
				<v-col
					cols="12"
					md="12"
					class="pb-0 px-0 px-sm-2"
					:class="
						getFirstData.shops.length <= 4
							? $device.isMobileOrTablet
								? 'd-flex overflow'
								: 'd-flex justify-center'
							: null
					"
				>
					<template v-if="getFirstData.shops.length > 4">
						<div
							v-swiper:mySwiper="{
								freeMode: true,
								slidesPerView: 'auto',
							}"
						>
							<div class="swiper-wrapper d-flex align-stretch">
								<div
									class="swiper-slide mb-4 mx-1 mt-2"
									v-for="branch in getFirstData.shops"
									:key="branch.name"
									:style="
										$device.isMobile
											? { width: '212px' }
											: { width: '200px' }
									"
								>
									<cardBranch
										:branch="branch"
										v-if="branch"
									/>
								</div>
							</div>
							<!--                  <div class="swiper-button-prev" slot="button-prev" v-if="getFirstData.shops.length > 3" />-->
							<!--                  <div class="swiper-button-next" slot="button-next" v-if="getFirstData.shops.length > 3" />-->
							<!--                  <div class="swiper-pagination swiper-pagination-bullets"></div>-->
							<!--                  <div class="swiper-scrollbar" slot="scrollbar" v-if="getFirstData.shops.length > 3" />-->
						</div>
					</template>
					<template v-if="getFirstData.shops.length <= 4">
						<div
							class="mb-3 mt-1 ms-2 d-inline-block"
							v-for="(branch, index) in getFirstData.shops"
							:key="index"
							:style="
								$device.isMobileOrTablet
									? { width: '212px' }
									: { width: '230px' }
							"
						>
							<cardBranch
								:branch="branch"
								v-if="branch"
								:class="
									index ==
									($vuetify.rtl
										? 0
										: getFirstData.shops.length - 1)
										? 'me-2'
										: ''
								"
							/>
						</div>
					</template>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>
<script>
import { mapGetters } from "vuex";
import cardBranch from "~/components/home/SwiperBranch/cardBranch";
export default {
	name: "SwiperBranch",
	components: {
		cardBranch,
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getSwiperBgColor: "siteSetting/getSwiperBgColor",
			getSettingLength: "siteSetting/getSettingLength",
			getBranchTitle: "siteSetting/getBranchTitle",
		}),
	},
};
</script>
