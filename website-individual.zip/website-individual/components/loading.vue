<template lang="html">
	<div class="loading-page" v-if="loading">
		<div class="spinner">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
		</div>
	</div>
</template>

<script>
export default {
	data: () => ({
		loading: true,
	}),
	mounted() {
		this.$nextTick(() => {
			this.$nuxt.$loading.start();
		});
	},
	methods: {
		start() {
			this.loading = true;
		},
		finish() {
			this.loading = false;
		},
	},
};
</script>

<style scoped>
.loading-page {
	position: fixed;
	/* display: flex;
  justify-content: center;
  align-items: center; */
	top: 0;
	left: 0;
	bottom: 0;
	right: 0;
	/* width: 100%;
  height: 100%; */
	/* background: rgba(255, 255, 255, 0.8); */
	background: white;
	text-align: center;
	padding-top: 200px;
	/* font-size: 30px; */
	/* font-family: sans-serif; */
	z-index: 999999;
}
.spinner {
	margin: 100px auto 0;
	width: 70px;
	text-align: center;
}

.spinner > div {
	width: 18px;
	height: 18px;
	background-color: rgb(49, 196, 115);

	border-radius: 100%;
	display: inline-block;
	-webkit-animation: sk-bouncedelay 1s infinite ease-in-out both;
	animation: sk-bouncedelay 1s infinite ease-in-out both;
}

.spinner .bounce1 {
	-webkit-animation-delay: -0.32s;
	animation-delay: -0.32s;
}

.spinner .bounce2 {
	-webkit-animation-delay: -0.16s;
	animation-delay: -0.16s;
}

@-webkit-keyframes sk-bouncedelay {
	0%,
	80%,
	100% {
		-webkit-transform: scale(0);
	}
	40% {
		-webkit-transform: scale(1);
	}
}

@keyframes sk-bouncedelay {
	0%,
	80%,
	100% {
		-webkit-transform: scale(0);
		transform: scale(0);
	}
	40% {
		-webkit-transform: scale(1);
		transform: scale(1);
	}
}
</style>
