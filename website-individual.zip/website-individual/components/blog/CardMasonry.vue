<template>
	<masonry :cols="cols" :gutter="gutter">
		<v-hover v-slot:default="{ hover }" v-for="item in data" :key="item.id">
			<v-card
				class="mb-4"
				:elevation="hover ? 2 : 1"
				hover
				nuxt
				:ripple="false"
				:to="
					localePath(
						{
							name: 'blog-id-slug',
							params: { id: item.id, slug: item.slug },
						},
						$i18n.loccale
					)
				"
			>
				<v-img :src="`${getDomain}/${item.img}`" />
				<v-card-text
					v-html="
						item.title
							? item.title
							: $t('message.text.no_description')
					"
				/>
				<v-card-actions>
					<v-row no-gutters justify="space-between">
						<div class="font-size-caption grey--text lighten-3">
							{{ item.category.title }}
						</div>
						<div class="font-size-caption grey--text lighten-3">
							{{ getLocaleDate(item.created_at) }}
						</div>
					</v-row>
				</v-card-actions>
			</v-card>
		</v-hover>
	</masonry>
</template>

<script>
import VueMasonry from "~/plugins/vueMasonry";
import { mapGetters } from "vuex";
import { utcToLocale } from "~/utils/date";

export default {
	name: "blog-card-masonry",
	props: ["data"],
	data() {
		return {
			cols: { default: 4, 600: 1, 960: 2, 1264: 3, 1366: 3 },
			gutter: { default: "24px" },
		};
	},
	created() {
		VueMasonry();
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
	methods: {
		getLocaleDate(utcTime) {
			let locale = this.$i18n.locale;
			if (locale == "fa") {
				return utcToLocale(utcTime, "jYYYY/jM/jD", locale);
			}
			return utcToLocale(utcTime, "YYYY/MM/DD", locale);
		},
	},
};
</script>
