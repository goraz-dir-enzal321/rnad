<template>
	<v-banner :sticky="!$device.isMobileOrTablet">
		<v-card tile>
			<v-card-title :class="[getBlogSettings.btn_bg_color]">
				<span class="text-center w-100">{{
					$t("header.text.category")
				}}</span>
			</v-card-title>
			<v-list>
				<v-list-item
					v-for="item of categories"
					:key="item.id"
					:color="getBlogSettings.btn_bg_color"
					@click.stop="getBlogList(item.id)"
				>
					<v-list-item-title>{{ item.title }}</v-list-item-title>
				</v-list-item>
			</v-list>
		</v-card>
	</v-banner>
</template>

<script>
import { mapGetters } from "vuex";
import { blog } from "@/api";
export default {
	name: "blog_categories",
	props: {
		categories: Array,
		title: String | null,
	},
	computed: {
		...mapGetters({
			getBlogSettings: "siteSetting/getBlogSettings",
			getMainShopId: "siteSetting/getMainShopId",
		}),
	},
	methods: {
		getBlogList(category_id) {
			this.$nextTick(() => {
				this.$nuxt.$loading.start();
			});
			this.$axios
				.post(blog.blogList, {
					shop_id: this.getMainShopId,
					page: 1,
					category_id,
				})
				.then(res => res.data)
				.then(res => {
					this.callNewCategory(res);
				})
				.catch(err => console.error("Error ", err));
		},
		callNewCategory(newBlogs) {
			this.$emit("callCategory", newBlogs);
		},
	},
};
</script>
