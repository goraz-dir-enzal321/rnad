<template>
	<v-banner
		:sticky="!$device.isMobileOrTablet"
		elevation="3"
		:style="{ top: $device.isMobileOrTablet ? '0' : '60px' }"
	>
		<v-card>
			<v-card-title :class="[getBlogSettings.btn_bg_color]">
				<span class="text-center w-100">{{
					$t("header.text.related_articles")
				}}</span>
			</v-card-title>
			<v-divider />
			<v-list two-line>
				<v-list-item
					v-for="(list, index) of lists"
					:key="list.id"
					nuxt
					:to="
						localePath(
							{
								name: 'blog-id-slug',
								params: { id: list.id, slug: list.slug },
							},
							$i18n.locale
						)
					"
					:exact="false"
					:color="getBlogSettings.btn_bg_color"
				>
					<v-list-item-content style="padding: 0 !important;">
						<v-list-item-title class="text-truncate black--text">{{
							list.title
						}}</v-list-item-title>
						<v-list-item-subtitle
							v-text="getLocaleDate(list.created_at)"
						/>
						<v-divider v-if="index + 1 !== lists.length" />
					</v-list-item-content>
				</v-list-item>
			</v-list>
		</v-card>
	</v-banner>
</template>

<script>
import { mapGetters } from "vuex";
import { utcToLocale } from "~/utils/date";

export default {
	name: "blog-lists",
	props: ["lists"],
	computed: {
		...mapGetters({
			getBlogSettings: "siteSetting/getBlogSettings",
		}),
	},
	methods: {
		getLocaleDate(utcTime) {
			let locale = this.$i18n.locale;
			if (locale == "fa") {
				return utcToLocale(utcTime, "jYYYY/jM/jD", locale);
			}
			return utcToLocale(utcTime, "YYYY/MM/DD", locale);
		},
	},
};
</script>
<style scoped>
.v-banner .v-banner__wrapper {
	padding-top: 0 !important;
	padding-bottom: 0 !important;
}
</style>
