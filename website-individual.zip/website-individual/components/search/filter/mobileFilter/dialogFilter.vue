<template>
	<v-dialog
		v-model="dialogComputed"
		fullscreen
		hide-overlay
		transition="dialog-bottom-transition"
		class="pos-relative"
	>
		<v-card tile>
			<v-toolbar
				dark
				:color="
					getSiteColor && getSiteColor.color
						? getSiteColor.color
						: 'cyan darken-2'
				"
			>
				<v-toolbar-title v-text="$t('search.filters')" />
				<v-spacer />
				<v-btn icon dark @click="dialogComputed = false">
					<v-icon>mdi-close</v-icon>
				</v-btn>
			</v-toolbar>

			<div class="pt-3 pb-13">
				<filters />
			</div>

			<v-btn
				fixed
				block
				color="red lighten-1"
				dark
				depressed
				tile
				v-text="$t('search.advancedSearch')"
				class="bot-0 py-2 font-weight-bold"
				x-large
				nuxt
				@click="goToResultSearch()"
			/>
		</v-card>
		<div class="nothing">{{ openSheet }}</div>
	</v-dialog>
</template>

<script>
import filters from "@/components/search/filter/filters";
import { mapGetters } from "vuex";
export default {
	components: {
		filters,
	},
	data: () => ({
		dialog: false,
	}),
	computed: {
		...mapGetters({
			getDialogSearchFilter: "search/getDialogSearchFilter",
			getFiltersObjectSenderAxios: "search/getFiltersObjectSenderAxios",
			getSiteColor: "siteSetting/getSiteColor",
		}),
		dialogComputed: {
			get() {
				return this.dialog;
			},
			set(value) {
				this.dialog = value;
				this.$store.dispatch("search/setDialogSearchFilter", value);
			},
		},
		openSheet() {
			this.dialogComputed = this.getDialogSearchFilter;
		},
	},
	methods: {
		goToResultSearch() {
			this.$store.dispatch("search/setPaginationSearch", 1);
			this.$store.dispatch("search/setResultSearch").then(() => {
				this.$router.push("search");
				this.$router.push({
					query: this.getFiltersObjectSenderAxios,
				});
			});
		},
	},
};
</script>
