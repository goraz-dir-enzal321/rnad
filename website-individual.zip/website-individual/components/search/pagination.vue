<template>
	<v-col
		cols="12"
		v-if="
			getDataResponseSearch &&
			Boolean(Object.keys(getDataResponseSearch).length) &&
			getDataResponseSearch.count &&
			getDataResponseSearch.count > 36
		"
	>
		<v-pagination
			v-model="pageComputed"
			circle
			color="primary"
			:disabled="getLoadingFilter || getLoadingSearch"
			:length="Math.ceil(getDataResponseSearch.count / 36)"
			:total-visible="9"
		/>
		<div class="nothing">{{ getPageSearchComputed }}</div>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		page: 1,
	}),
	computed: {
		...mapGetters({
			getLoadingFilter: "search/getLoadingFilter",
			getLoadingSearch: "search/getLoadingSearch",
			getDataResponseSearch: "search/getDataResponseSearch",
			getPageSearch: "search/getPageSearch",
		}),
		pageComputed: {
			get() {
				return this.page;
			},
			set(value) {
				this.page = value;
				this.$store
					.dispatch("search/setPaginationSearch", this.page)
					.then(() => this.$store.dispatch("search/setResultSearch"));
			},
		},
		getPageSearchComputed() {
			return (this.pageComputed = this.getPageSearch);
		},
	},
	created() {
		this.$store.dispatch("search/setPaginationSearch", 1);
	},
};
</script>
