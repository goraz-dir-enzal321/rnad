<template>
	<v-col cols="12" sm="3" class="pt-0">
		<template v-if="$device.isMobile">
			<v-row class="mt-2">
				<v-card
					v-for="index in 2"
					:key="index"
					class="flex-grow-1 pt-3 pb-2"
					tile
					flat
				>
					<v-skeleton-loader
						class="px-6"
						transition="fade-transition"
						type="text"
					/>
				</v-card>
			</v-row>
		</template>
		<template v-else>
			<v-card outlined class="pa-3">
				<v-skeleton-loader
					v-for="index in 3"
					:key="index"
					class="mx-auto mb-2"
					transition="fade-transition"
					type="image"
					max-width="300"
					width="100%"
				/>
			</v-card>
		</template>
	</v-col>
</template>
