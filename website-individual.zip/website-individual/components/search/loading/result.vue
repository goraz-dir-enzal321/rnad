<template>
	<v-col cols="12" sm="9">
		<v-card outlined class="section-result-search">
			<v-row no-gutters class="section-row-result-search">
				<v-col
					cols="12"
					sm="3"
					class="pt-0"
					v-for="index in 6"
					:key="index"
				>
					<productLoading />
				</v-col>
			</v-row>
		</v-card>
	</v-col>
</template>
<script>
import productLoading from "@/components/search/loading/productLoading";
export default {
	components: {
		productLoading,
	},
};
</script>
