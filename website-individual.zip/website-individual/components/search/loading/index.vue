<template>
	<Fragment>
		<loadingFilter v-if="getLoadingFilter" />
		<loadingResult v-if="getLoadingSearch" />
	</Fragment>
</template>

<script>
import loadingFilter from "@/components/search/loading/filter";
import loadingResult from "@/components/search/loading/result";
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	components: {
		loadingFilter,
		loadingResult,
		Fragment,
	},
	computed: {
		...mapGetters({
			getLoadingFilter: "search/getLoadingFilter",
			getLoadingSearch: "search/getLoadingSearch",
		}),
	},
};
</script>
