<template>
	<v-col
		cols="12"
		sm="9"
		class="flex-sm-shrink-1 flex-sm-grow-1 pa-sm-3"
		:class="$device.isMobile ? 'pa-0' : 'pa-1'"
	>
		<v-card
			:min-height="$device.isMobile ? '75vh' : 100"
			outlined
			class="section-result-search"
			:class="
				$device.isMobile ? 'rounded-0' : 'rounded-lg overflow-hidden'
			"
		>
			<template
				v-if="
					getDataResponseSearch &&
					Boolean(Object.keys(getDataResponseSearch).length)
				"
			>
				<v-row
					no-gutters
					class="section-row-result-search"
					v-if="
						getDataResponseSearch.status &&
						getDataResponseSearch.results &&
						getDataResponseSearch.results.length
					"
				>
					<template
						v-for="(product,
						index) in getDataResponseSearch.results"
					>
						<v-col
							cols="12"
							sm="4"
							lg="3"
							:key="index"
							v-if="product && product.existence"
						>
							<product :product="product" />
						</v-col>
					</template>
					<template
						v-for="(product,
						index) in getDataResponseSearch.results"
					>
						<v-col
							cols="12"
							sm="4"
							lg="3"
							:key="index"
							v-if="product && !product.existence"
						>
							<product :product="product" />
						</v-col>
					</template>
				</v-row>
				<v-row justify="center" v-else class="ma-0">
					<v-col cols="12" sm="6">
						<v-sheet
							v-if="!getDataResponseSearch.status"
							width="100%"
							:height="$device.isMobile ? 125 : 225"
							class="d-flex mx-auto justify-center align-center rounded grey lighten-3"
						>
							<v-icon
								v-text="'mdi-database-search'"
								:style="
									$device.isMobile
										? { 'font-size': '24px' }
										: { 'font-size': '64px' }
								"
							/>
							<span v-text="$t('search.informationError')" />
						</v-sheet>
						<v-sheet
							v-else-if="
								getDataResponseSearch.results &&
								!getDataResponseSearch.results.length
							"
							width="100%"
							:height="$device.isMobile ? 125 : 225"
							class="d-flex mx-auto justify-center align-center rounded grey lighten-3"
						>
							<v-icon
								v-text="'mdi-magnify'"
								:style="
									$device.isMobile
										? { 'font-size': '24px' }
										: { 'font-size': '64px' }
								"
							/>
							<span v-text="$t('search.searchNotFound')" />
						</v-sheet>
					</v-col>
				</v-row>
			</template>

			<v-row justify="center" v-else class="ma-0">
				<v-col cols="12" sm="6">
					<v-sheet
						width="100%"
						:height="$device.isMobile ? 125 : 225"
						class="d-flex mx-auto justify-center align-center rounded grey lighten-3"
					>
						<v-icon
							v-text="'mdi-magnify'"
							:style="
								$device.isMobile
									? { 'font-size': '24px' }
									: { 'font-size': '64px' }
							"
						/>
						<span v-text="$t('search.haveNotSearched')" />
					</v-sheet>
				</v-col>
			</v-row>
		</v-card>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import product from "@/components/search/result/product/index.vue";
export default {
	components: {
		product,
	},
	computed: {
		...mapGetters({
			getDataResponseSearch: "search/getDataResponseSearch",
		}),
	},
};
</script>
