<template>
	<v-card
		v-ripple="!slideStatus"
		:height="$device.isMobile ? '100%' : 366"
		class="section-product-search py-2"
		:class="[
			$device.isMobile ? 'font-size-15' : 'font-size-13 ',
			slideStatus
				? 'rounded-lg direction-rtl py-sm-1'
				: 'py-sm-3 rounded-0',
		]"
		outlined
		nuxt
		@mouseup="setLocationMouse($event, 'new')"
		@mousedown="setLocationMouse($event, 'old')"
		@click="checkLocalePath()"
	>
		<v-row class="mx-0" justify="center">
			<!-- img product -->
			<v-col
				:cols="slideStatus ? '12' : 'auto'"
				sm="12"
				class="pa-0"
				:class="slideStatus ? 'px-sm-1' : 'px-sm-3'"
			>
				<v-img
					:width="
						$device.isMobile
							? slideStatus
								? 192
								: 125
							: slideStatus
							? '100%'
							: 225
					"
					:height="
						$device.isMobile
							? slideStatus
								? 192
								: 125
							: slideStatus
							? 235
							: 225
					"
					:src="
						product.img
							? product.img.startsWith(`http`) ||
							  product.img.startsWith(`storage/`)
								? product.img.startsWith(`storage/`)
									? getDomain + product.img
									: product.img
								: `${getDomain}storage/${product.img}`
							: getDefaultImg
							? getDefaultImg.startsWith(`http`) ||
							  getDefaultImg.startsWith(`storage/`)
								? getDefaultImg.startsWith(`storage/`)
									? getDomain + getDefaultImg
									: getDefaultImg
								: `${getDomain}storage/${getDefaultImg}`
							: '/images/img-default.jpeg'
					"
					:lazy-src="
						product.thumbnail.startsWith(`http`) ||
						product.thumbnail.startsWith(`storage/`)
							? product.thumbnail.startsWith(`storage/`)
								? getDomain + product.thumbnail
								: product.thumbnail
							: `${getDomain}storage/${product.thumbnail}`
					"
					class="rounded mx-auto"
					:alt="product.name"
				/>
			</v-col>
			<!-- name & price & discount & discount_price & monetary_unit & rate-->
			<v-col
				class="pa-0 pe-2 pb-sm-0 px-sm-3 flex-shrink-1"
				sm="12"
				v-if="product.name || product.price || product.monetary_unit"
			>
				<v-row align-content="space-between" class="h-100">
					<!-- name -->
					<v-col
						cols="12"
						class="py-2 ms-2 pt-sm-3 pb-sm-0 font-weight-medium"
						v-if="product.name"
						v-text="product.name"
					/>
					<!-- price & discount & discount_price & monetary_unit -->
					<priceProduct
						v-if="
							(getShop(product.branch_id ? product.branch_id : 1)
								.has_product_voice &&
								!product.single_purchase) ||
							!getShop(product.branch_id ? product.branch_id : 1)
								.has_product_voice
						"
						:existence="product.existence"
						:unit_sentence="product.unit_sentence"
						:price="product.price"
						:discount_price="product.discount_price"
						:monetary_unit="product.monetary_unit"
						:discount="product.discount"
					/>

					<!-- rate -->
					<v-col
						cols="12"
						class="py-2 font-weight-medium order-sm-3 order-4"
						:class="product.existence ? 'py-sm-0' : 'pt-sm-2 pb-0'"
						v-if="+product.rate"
					>
						<v-icon class="text--accent-3" v-text="'mdi-star'" />
						<span v-text="+product.rate" />
					</v-col>
				</v-row>
			</v-col>
		</v-row>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import priceProduct from "@/components/search/result/product/priceProduct";
export default {
	props: ["product", "btnColorMore", "slideStatus"],
	data: () => ({
		isMoveProduct: false,
		locationMouse: {
			old: "",
			new: "",
		},
	}),
	components: {
		priceProduct,
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getDefaultImg: "siteSetting/getDefaultImg",
			getShop: "firstData/getShop",
		}),
	},
	methods: {
		// check is mouse clivk
		setLocationMouse(e, time) {
			if (time == "old") this.locationMouse.old = e.clientX;
			else if (time == "new") {
				this.locationMouse.new = e.clientX;
				if (this.locationMouse.old >= this.locationMouse.new)
					if (
						this.locationMouse.old + 15 < this.locationMouse.new ||
						this.locationMouse.old - 15 < this.locationMouse.new
					)
						this.isMoveProduct = true;
					else this.isMoveProduct = false;
				else if (this.locationMouse.old <= this.locationMouse.new)
					if (
						this.locationMouse.old + 15 > this.locationMouse.new ||
						this.locationMouse.old - 15 > this.locationMouse.new
					)
						this.isMoveProduct = true;
					else this.isMoveProduct = false;
			}
		},
		checkLocalePath() {
			if (this.isMoveProduct) {
				let $slug = this.product.id;
				switch (
					this.getShop(
						this.product.branch_id ? this.product.branch_id : 1
					).card.description_style
				) {
					case "TAB_INFO":
						$slug = this.product.id;
						break;
					case "SIMPLE":
						$slug = this.product.slug ? this.product.slug : null;
						break;
					default:
						$slug = this.product.id ? this.product.id : null;
						break;
				}
				if ($slug)
					this.$router.push(
						this.localePath(`/product/${$slug}`, this.$i18n.locale)
					);

				this.isMoveProduct = false;
			}
		},
	},
};
</script>
