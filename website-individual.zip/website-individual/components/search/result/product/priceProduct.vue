<template>
	<Fragment>
		<v-col
			v-if="!existence"
			cols="12"
			class="py-2 pt-sm-3 pb-sm-0 direction-ltr order-5"
		>
			<v-row no-gutters align="center">
				<v-divider class="flex-grow-1 flex-shrink-1" />
				<span
					v-text="$t('search.unavailable')"
					class="mx-2 font-weight-medium grey--text text--darken-2 font-size-15"
				/>
				<v-divider class="flex-grow-1 flex-shrink-1" />
			</v-row>
		</v-col>
		<v-col
			cols="12"
			class="py-2 pt-sm-3 pb-sm-0 direction-ltr order-sm-2 order-3"
			v-else-if="monetary_unit || price"
		>
			<v-row no-gutters>
				<!-- monetary_unit -->
				<v-col
					cols="auto"
					class="mr-1 text--darken-3"
					:class="[
						$device.isMobile ? 'font-size-14' : 'font-size-12',
						discount_price == 0
							? 'mt-6'
							: discount_price != price
							? 'mt-5'
							: null,
					]"
					v-if="monetary_unit"
					v-text="monetary_unit"
				/>
				<!-- discount_price & price-->
				<v-col
					cols="auto"
					class="flex-shrink-1 flex-grow-1"
					v-if="price"
				>
					<div
						cols="auto"
						:class="
							discount
								? 'text-decoration-line-through'
								: 'font-weight-bold font-size-16'
						"
						v-if="price"
						v-text="$numberWithCommas($roundDecimal(price))"
					/>
					<div
						cols="auto"
						class="mb-1 font-weight-bold text--darken-5"
						:class="
							$device.isMobile ? 'font-size-16' : 'font-size-14'
						"
						v-if="discount"
						v-text="
							discount_price
								? $numberWithCommas(
										$roundDecimal(discount_price)
								  )
								: discount_price == 0
								? $t('productInfo.free')
								: null
						"
					/>
				</v-col>
				<!-- discount-->
				<v-col
					cols="auto"
					class="mr-1 text--darken-5 text-right"
					:class="$device.isMobile ? 'font-size-14' : null"
					v-if="discount || unit_sentence"
				>
					<div v-text="unit_sentence" v-if="unit_sentence" />

					<v-chip
						v-if="discount"
						color="red"
						small
						text-color="white"
					>
						{{ discount }} %
					</v-chip>
				</v-col>
			</v-row>
		</v-col>
	</Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
export default {
	props: [
		"price",
		"discount_price",
		"monetary_unit",
		"discount",
		"existence",
		"unit_sentence",
	],

	components: {
		Fragment,
	},
};
</script>
