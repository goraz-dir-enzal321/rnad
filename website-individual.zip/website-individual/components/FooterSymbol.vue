<template>
	<v-footer
		color="grey lighten-3"
		class="pa-4"
		v-if="
			getFirstData && getFirstData.header && getFirstData.header.LICENSE
		"
	>
		<v-row justify="center" no-gutters>
			<v-col
				v-if="
					getFirstData.header.LICENSE_TEXT &&
					getFirstData.header.LICENSE_TEXT.length
				"
				cols="12"
				:sm="checkLargerThanFour(8, 12)"
				class="row pb-2 flex-shrink-0 font-size-body-2 align-center"
			>
				<!-- :sm="getFirstData.header.LICENSE_TEXT[0].img ? checkLargerThanFour(8, 12) :  checkLargerThanFour(8, 12) "
        :cols="$device.isMobileOrTablet ? 12 : 'auto'" -->
				<template
					v-for="(optionOfTextLisense, index) in getFirstData.header
						.LICENSE_TEXT"
				>
					<v-col
						:key="index"
						cols="12"
						sm="auto"
						v-if="optionOfTextLisense.img"
					>
						<v-img
							class="rounded-pill elevation-4 d-inline-flex"
							:width="$device.isMobileOrTablet ? 250 : 75"
							:height="$device.isMobileOrTablet ? 250 : 75"
							:src="
								optionOfTextLisense.img.startsWith(`http`)
									? optionOfTextLisense.img
									: getDomain +
									  'storage/' +
									  optionOfTextLisense.img
							"
						/>
					</v-col>
					<v-col
						:key="index"
						class="flex-grow-1 pb-2"
						v-if="optionOfTextLisense.text"
						v-html="optionOfTextLisense.text"
					/>
				</template>
				<!-- <v-col
            :cols="$device.isMobileOrTablet ? 12 : 'auto'"
            class="flex-grow-0 flex-shrink-0 pl-2"
            v-if="itemsAPI.imageCatopmSumbol"
        >
            <v-img
                class="rounded-pill elevation-4 d-inline-flex"
                :width="$device.isMobileOrTablet ? 250 : 75"
                :height="$device.isMobileOrTablet ? 250 : 75"
                :src="itemsAPI.imageCatopmSumbol"
            ></v-img>
        </v-col> -->
			</v-col>

			<v-col cols="12" :sm="checkLargerThanFour(4, 12)">
				<v-row
					align="center"
					no-gutters
					:justify="checkLargerThanFour(`center`, `left`)"
				>
					<v-spacer
						:class="
							getFirstData.header.LICENSE_TEXT &&
							getFirstData.header.LICENSE_TEXT[0].text
								? checkLargerThanFour('d-block', 'd-none')
								: 'd-none'
						"
					/>
					<template
						v-for="(item, index) in getFirstData.header.LICENSE"
					>
						<a
							v-if="item.img_url && item.onclick"
							:href="item.onclick"
							target="_blank"
							:key="index"
						>
							<v-sheet
								class="mx-1 mb-1 elevation-3 align-center d-inline-flex"
								width="100px"
								min-width="90.1px"
								max-height=" 122px"
								min-height=" 122.1px"
							>
								<img
									style="width: 100%;"
									class="rounded"
									:src="
										item.img_url.startsWith(`http`)
											? item.img_url
											: getDomain +
											  'storage/' +
											  item.img_url
									"
								/>
							</v-sheet>
						</a>
						<!-- <template v-else>
              <v-sheet
                class="mx-1 mb-1 elevation-3 align-center d-inline-flex text justify-center"
                width="100px"
                min-width="90.1px"
                max-height=" 122px"
                min-height=" 122.1px"
                :key="index"
              >
                <span>{{ $t("errorShortText") }}</span>
              </v-sheet>
            </template> -->
					</template>
				</v-row>
			</v-col>
		</v-row>
	</v-footer>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "FooterSymbol",
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getFirstData: "firstData/getFirstData",
		}),
	},
	methods: {
		checkLargerThanFour(Valuetrue, ValueFalse, ifHaveText = false) {
			if (ifHaveText === true) {
				if (
					this.getFirstData &&
					this.getFirstData.header &&
					this.getFirstData.header.LICENSE &&
					this.getFirstData.header.LICENSE_TEXT
				) {
					this.getFirstData.header.LICENSE_TEXT.forEach(element => {
						if (element.text) {
							return this.getFirstData.header.LICENSE.length <= 4
								? ValueFalse
								: Valuetrue;
						}
					});
				}
			}
			return this.getFirstData.header.LICENSE.length <= 4
				? Valuetrue
				: ValueFalse;
		},
	},
};
</script>
