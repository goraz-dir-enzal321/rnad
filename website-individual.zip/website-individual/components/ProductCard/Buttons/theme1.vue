<template>
  <Fragment>
    <!-- // Button types // -->
    <v-btn
      v-if="btnStatus == 'BTN_MULTI'"
      rounded
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
      @click.prevent="callAddToCard('BTN_MULTI')"
    >
      <v-icon size="15">{{ isSelected ? "mdi-minus" : "mdi-plus" }}</v-icon>
      {{ getBtnName ? getBtnName.btnText : "" }}
    </v-btn>
    <v-btn
      v-if="
        btnStatus == 'BTN_TXT' && getBtnName && getBtnName.btnType != 'MENU'
      "
      rounded
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
      @click.prevent="callAddToCard('BTN_TXT')"
    >
      <v-icon size="15" v-if="getBtnName && getBtnName.btnType != 'MENU'">{{
        isSelected ? "mdi-minus" : "mdi-plus"
      }}</v-icon>
      {{ getBtnName ? getBtnName.btnText : "" }}
    </v-btn>
    <v-btn
      v-if="
        btnStatus == 'BTN_TXT' && getBtnName && getBtnName.btnType == 'MENU'
      "
      rounded
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
    >
      <v-icon size="15" v-if="getBtnName && getBtnName.btnType != 'MENU'">{{
        isSelected ? "mdi-minus" : "mdi-plus"
      }}</v-icon>
      {{ getBtnName ? getBtnName.btnText : "" }}
    </v-btn>
    <template v-if="btnStatus == 'NUMERIC'" text color="teal">
      <div class="d-flex justify-center align-center">
        <v-btn
          depressed
          small
          icon
          color="red darken-3"
          @click.prevent="
            $store.dispatch(
              'shop/minusItem',
              productIds.id
                ? productIds.id
                : productIds.product_id
                ? productIds.product_id
                : -1
            )
          "
        >
          <v-icon>mdi-minus-circle-outline</v-icon>
        </v-btn>
        <span
          class="mx-0 font-size-body-2 blue-grey--text darken-4 text-center"
          style="min-width: 25px;"
          >{{
            getItemCount(
              productIds.id
                ? productIds.id
                : productIds.product_id
                ? productIds.product_id
                : -1
            )
          }}</span
        >
        <v-btn
          depressed
          small
          icon
          color="teal lighten-1"
          @click.prevent="callAddToCard('NUMERIC')"
        >
          <v-icon>mdi-plus-circle-outline</v-icon>
        </v-btn>
      </div>
    </template>
    <v-btn
      v-if="btnStatus == 'BTN_SEL'"
      rounded
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
      @click.prevent="callAddToCard('BTN_SEL')"
    >
      <v-icon size="15">{{ isSelected ? "mdi-minus" : "mdi-plus" }}</v-icon>
      {{ getBtnName ? getBtnName.btnText : "" }}
    </v-btn>
    <v-btn
      v-if="btnStatus == 'CHECKBOX'"
      rounded
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
      @click.prevent="callAddToCard('CHECKBOX')"
    >
      <v-icon size="15">{{ isSelected ? "mdi-minus" : "mdi-plus" }}</v-icon>
      {{ getBtnName ? getBtnName.btnText : "" }}
    </v-btn>
    <v-btn
      v-if="btnStatus == 'REQUEST'"
      small
      :outlined="!isSelected"
      :color="isSelected ? 'primary white--text' : null"
      @click.prevent="openDialog"
    >
      {{ $t("button.request_call_btn") }}
    </v-btn>
  </Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
export default {
  components: {
    Fragment,
  },
  props: ["btnStatus", "isSelected", "getItemCount", "loading", "btnType", "getBtnName","productIds"],
  methods: {
    callAddToCard($btn_status) {
      this.$emit("addToCart", $btn_status );
    },
    openDialog() {
      this.$emit("openDialog");
    }
  },
};
</script>
