<template>
	<Fragment>
		<!-- BTN_TXT == 'MENU'-->
		{{/* NUMERIC  */}}
		<numeric
			v-if="btnStatus == 'NUMERIC'"
			:btnStatus="btnStatus"
			:productIds="productIds"
			@sendAddToCart="callAddToCard"
		/>
		<!-- BTN_SEL | CHECKBOX | REQUEST | BTN_TXT -> if(btn == !MENU) | BTN_MULTI-->
		<v-row
			no-gutters
			v-if="
				btnStatus == 'BTN_SEL' ||
				btnStatus == 'CHECKBOX' ||
				btnStatus == 'REQUEST' ||
				(btnStatus == 'BTN_TXT' && getBtnName.btnType != 'MENU') ||
				btnStatus == 'BTN_MULTI'
			"
		>
			<!-- BTN_SEL -> is if(select)-> AlertAdding else-> add_to_shoping_cart -->
			<v-col
				v-if="
					btnStatus == 'BTN_SEL' ||
					btnStatus == 'CHECKBOX' ||
					btnStatus == 'REQUEST' ||
					(btnStatus == 'BTN_TXT' && getBtnName.btnType != 'MENU') ||
					btnStatus == 'BTN_MULTI'
				"
			>
				<v-btn
					small
					dark
					block
					depressed
					:color="isSelected ? 'success accent-2' : 'red lighten-1'"
					@click.prevent="callAddToCard(btnStatus)"
				>
					<v-icon v-if="$vuetify.rtl" class="pl-1" size="12">{{
						isSelected ? "mdi-close" : ""
					}}</v-icon>
					{{
						isSelected
							? $t("productInfo.buy.AlertAdding")
							: getBtnName
							? getBtnName.btnText
							: $t("button.add_to_shoping_cart")
					}}
					<v-icon v-if="!$vuetify.rtl" class="pr-1" size="12">{{
						isSelected ? "mdi-close" : ""
					}}</v-icon>
				</v-btn>
			</v-col>
			<!-- BTN_SEL -> is if(select)-> FinalBuy  -->
			<template
				v-if="
					((isSelected == true && btnStatus == 'BTN_SEL') ||
						btnStatus == 'CHECKBOX' ||
						btnStatus == 'REQUEST' ||
						btnStatus == 'BTN_MULTI') &&
					$router.currentRoute.path != `/${$i18n.locale}/order`
				"
			>
				<v-col v-if="isSelected">
					<v-btn
						small
						dark
						block
						depressed
						color="white red--text text--lighten-1"
						:class="{ 'mr-1': $vuetify.rtl, 'ml-1': $vuetify.rtl }"
						:to="isAuth ? localePath('order', $i18n.locale) : null"
						@click.prevent="goToOrder()"
					>
						{{ $t("productInfo.buy.FinalBuy") }}
					</v-btn>
				</v-col>
			</template>
		</v-row>
	</Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
import numeric from "@/components/ProductCard/Buttons/them2/numeric";
export default {
	components: {
		Fragment,
		numeric,
	},
	props: [
		"btnStatus",
		"isSelected",
		"loading",
		"btnType",
		"getBtnName",
		"productIds",
		"isAuth",
	],
	methods: {
		callAddToCard($btn_status) {
			this.$emit("addToCart", $btn_status);
		},
		openDialog() {
			this.$emit("openDialog");
		},
		goToOrder() {
			if (!this.isAuth) {
				this.$store.commit("loginCard/SET_STATUS", 1);
				this.$store.dispatch("loginCard/setGoToOrderPage", true);
			}
		},
	},
};
</script>
