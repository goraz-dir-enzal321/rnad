<template>
	<Fragment>
		<template
			v-if="
				getCardStyle &&
				getStyledProductShop.description_btn != 'NONE' &&
				!product.plan_id
			"
		>
			<template v-if="getStyledProductShop.description_style == 'SIMPLE'">
				<Theme1
					@addToCart="addItemToShop"
					@openDialog="dialog = true"
					:btnStatus="btnStatus"
					:isSelected="isSelected"
					:getItemCount="getItemCount"
					:loading="loading"
					:btnType="btnType"
					:getBtnName="getBtnName"
					:productIds="{
						id: product ? product.id : null,
						product_id: product ? product.product_id : null,
					}"
				/>
			</template>
			<template
				v-if="getStyledProductShop.description_style == 'TAB_INFO'"
			>
				<Theme2
					@addToCart="addItemToShop"
					@openDialog="dialog = true"
					:btnStatus="btnStatus"
					:isSelected="isSelected"
					:getItemCount="getItemCount"
					:loading="loading"
					:btnType="btnType"
					:getBtnName="getBtnName"
					:productIds="{
						id: product ? product.id : null,
						product_id: product ? product.product_id : null,
					}"
					:isAuth="isAuth"
				/>
			</template>
		</template>
		<v-dialog v-model="dialog" width="500" persistent>
			<v-form ref="form" @submit.prevent="validate">
				<v-card :loading="loading">
					<v-card-title
						class="font-size-headline justify-center"
						primary-title
					>
						{{ $t("header.text.request_call_back") }}
					</v-card-title>
					<v-divider />
					<v-card-text>
						<v-text-field
							v-model="name"
							:label="$t('form.label.name')"
							class="mb-4"
							:disabled="loading"
						/>
						<div
							v-bind:class="[
								'd-flex ',
								{ 'flex-row-reverse': $vuetify.rtl },
							]"
						>
							<div
								class="flex-grow-0 mx-1"
								v-if="getCountries && getCountries.length"
							>
								<v-select
									v-if="getCountries.length != 1"
									v-model="countryCodeSelected"
									:items="getCountries"
									item-value="id"
									item-text="code"
									hide-details
									dense
									label="AE"
									:rules="[rules.required]"
									style="width: 100px;"
									required
									class="country-select"
									return-object
									:disabled="loading"
								/>
								<v-card
									height="40"
									class="direction-ltr mb-3 mx-0"
									outlined
									v-else-if="getCountries[0].code"
								>
									<p
										class="font-size-15 grey--text my-0 px-3 py-2 text--darken-1"
									>
										{{ getCountries[0].code }}
									</p>
								</v-card>
							</div>
							<div class="flex-grow-1">
								<v-text-field
									dense
									:disabled="loading"
									:label="$t('form.label.phone_number')"
									:rules="[rules.required]"
									v-model="checkInput"
									maxlength="11"
									required
								/>
							</div>
						</div>
						<v-text-field
							v-model="email"
							:label="$t('form.label.email')"
							:rules="[rules.email]"
							class="mb-4"
							:disabled="loading"
						/>
						<v-textarea
							v-model="description"
							:label="`${$t('form.label.describe_more')}  ( ${$t(
								'form.label.optional'
							)} )`"
							:disabled="loading"
						/>
						<v-sheet
							class="pa-3 red lighten-2"
							v-if="errorComputed.length"
						>
							<div
								v-for="(err, index) in errorComputed"
								:key="index"
							>
								{{ index + 1 }}: {{ err }}
							</div>
						</v-sheet>
					</v-card-text>
					<v-card-actions>
						<div class="flex-grow-1"></div>
						<v-btn
							color="red darken white--text"
							small
							@click="closeDialog"
							:loading="loading"
							:disabled="loading"
							style="min-width: 100px;"
							>{{ $t("button.cancel") }}</v-btn
						>
						<v-btn
							color="green darken white--text"
							small
							type="submit"
							:loading="loading"
							:disabled="loading"
							style="min-width: 100px;"
							>{{ $t("button.submit") }}</v-btn
						>
						<div class="flex-grow-1"></div>
					</v-card-actions>
				</v-card>
			</v-form>
		</v-dialog>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { callRequest } from "@/api";
import { Fragment } from "vue-fragment";
import theme1 from "@/components/ProductCard/Buttons/theme1";
import theme2 from "@/components/ProductCard/Buttons/them2";
export default {
	components: {
		Theme1: theme1,
		Theme2: theme2,
		Fragment,
	},
	name: "ProductCardButtons",
	props: ["product", "customData", "btnType"], // customData: this props is custom client-specific data if return => TRUE
	data() {
		return {
			loading: false,
			dialog: false,
			valid: false,
			rules: {
				required: value =>
					!!value || this.$t("form.validation.error.require"),
				requiredArray: value => {
					return (
						Object.keys(value).length > 0 ||
						this.$t("form.validation.error.require")
					);
				},
				max: value => value.length <= 11 || "Max 11 characters",
				email: v =>
					/.+@.+\..+/.test(v) ||
					v == null ||
					v == "" ||
					"E-mail must be valid",
			},
			countryCodeSelected: "",
			phoneNumber: null,
			name: null,
			email: null,
			description: null,
			errors: [],
		}; // return
	},
	computed: {
		...mapGetters({
			getCardStyle: "branch/getCardStyle",
			getShopIdInStore: "shop/getShopIdInStore",
			cartCount: "shop/cartCount",
			getCountries: "firstData/getCountries", // send to created() , fill out the data () countryCodes
			getBranchSelectedData: "branch/getBranchSelectedData",
			getBranchWarning: "branch/getBranchWarning",
			getItemCount: "shop/itemCount",
			getStyledProductShop: "productInfo/getStyledProductShop",
			isAuth: "isAuth",
		}),
		btnStatus: {
			get() {
				let $thisBtnType = this.btnType;
				let $btnType = null;
				if (
					this.product &&
					this.product.hasOwnProperty("rec_call") &&
					this.product.rec_call == 1
				) {
					$thisBtnType = "REQUEST";
					$btnType = "REQUEST";
				}
				switch ($thisBtnType) {
					case "BASKET":
						let $basketBtnStyle = Boolean(this.getOldBtnType)
							? this.getOldBtnType.basket_btn_type
							: this.getCardStyle.basket_btn_type;
						$btnType = this.checkBtnType($basketBtnStyle);
						break;
					//////////////////////////////////
					case "MENU":
						$btnType = this.checkBtnType(
							this.getCardStyle.menu_btn_type
						);
						break;
					//////////////////////////////////
					case "DESCRIPTION":
						$btnType = this.checkBtnType(
							this.getCardStyle.description_btn
						);
						break;
				}
				return $btnType;
			},
		},
		isSelected: {
			get() {
				return (
					this.getItemCount(
						this.product.id
							? this.product.id
							: this.product.product_id
							? this.product.product_id
							: -1
					) > 0
				);
			},
		},
		getBtnName: {
			get() {
				let $thisBtnType = this.btnType;
				let $btnText = null;
				let $menuBtnStyle = null;
				if (
					this.product &&
					this.product.hasOwnProperty("rec_call") &&
					this.product.rec_call == 1
				) {
					$thisBtnType = "REQUEST";
					// $btnType     = 'REQUEST';
				}
				if ($thisBtnType == "BASKET" && this.cartCount > 0) {
					$menuBtnStyle = Boolean(this.getOldBtnType)
						? this.getOldBtnType
						: this.getCardStyle;
				} else {
					$menuBtnStyle = this.getCardStyle;
				}

				if ($menuBtnStyle.translations) {
					const $item = $menuBtnStyle.translations.find(
						item => item.locale == this.$i18n.locale
					);
					if ($item) {
						switch ($thisBtnType) {
							case "BASKET":
								$btnText = $item.basket_button_text;
								break;
							case "MENU":
								$btnText = $item.menu_button_text;
								break;
							case "DESCRIPTION":
								$btnText = $item.description_button_text;
								break;
						}
					} else {
						switch ($thisBtnType) {
							case "BASKET":
								$btnText = $menuBtnStyle.basket_button_text
									? $menuBtnStyle.basket_button_text
									: this.$t("button.add_to_cart");
								break;
							case "MENU":
								$btnText = $menuBtnStyle.menu_button_text
									? $menuBtnStyle.menu_button_text
									: this.$t("button.add_to_cart");
								break;
							case "DESCRIPTION":
								$btnText = $menuBtnStyle.description_button_text
									? $menuBtnStyle.description_button_text
									: this.$t("button.add_to_cart");
								break;
						}
					}
				} else {
					switch ($thisBtnType) {
						case "BASKET":
							$btnText = $menuBtnStyle.basket_button_text
								? $menuBtnStyle.basket_button_text
								: this.$t("button.add_to_cart");
							break;
						case "MENU":
							$btnText = $menuBtnStyle.menu_button_text
								? $menuBtnStyle.menu_button_text
								: this.$t("button.add_to_cart");
							break;
						case "DESCRIPTION":
							$btnText = $menuBtnStyle.description_button_text
								? $menuBtnStyle.description_button_text
								: this.$t("button.add_to_cart");
							break;
					}
				}
				return { btnText: $btnText, btnType: $thisBtnType };
			},
		},
		checkInput: {
			get() {
				return this.phoneNumber;
			},
			set(value) {
				if (/^0/.test(value)) {
					value = value.replace(/^0/, "");
				}
				if (value.length <= 11) {
					this.phoneNumber = value;
				}
			},
		},
		errorComputed() {
			return this.errors;
		},
	},
	methods: {
		addItemToShop($btn_status) {
			// this.$store.dispatch('branch/cardStyle', null);
			let $product = this.product;
			if (this.btnType == "BASKET") {
				this.$store.dispatch("shop/addToCart", {
					...this.product,
					btn_status: $btn_status,
				});
			} else {
				if (this.customData) {
					if (Object.keys(this.product).length) {
						let $productName = null;
						if (this.cartCount <= 0) {
							this.$store.dispatch(
								"shop/setShopId",
								this.product.shopId
							);
						} else if (
							this.cartCount > 0 &&
							this.getShopIdInStore != this.product.shopId
						) {
							this.$store.dispatch("branch/oldCardStyle", null);
							this.$store.dispatch(
								"shop/setShopId",
								this.product.shopId
							);
						}
						let item = {
							shopId: this.product.shopId
								? this.product.shopId
								: this.product.branch_id,
							name: this.product.translations.length
								? this.product.translations
								: this.product.name,
							price: this.product.price,
							product_id: this.product.product_id,
							discount_amount: Boolean(this.product.discount)
								? this.product.discount
								: 0,
							discount_price:
								this.product.discount == 0
									? 0
									: parseFloat(
											this.product.discount_price
									  ).toFixed(2),
							image: Boolean(this.product.thumbnail)
								? this.product.thumbnail
								: this.product.image,
							monetary_unit: this.product.monetary_unit,
							min_count: this.product.min_count
								? this.product.min_count
								: 0,
							//////////////////////////////
							btn_type: this.getCardStyle.menu_btn_type,
							btn_text: this.getCardStyle.menu_button_text,
							//////////////////////////////
							count: 1,
							//////////////////////////////
							properties: this.product.properties
								? this.product.properties
								: [],
							calculationProperty: this.product
								.calculationProperty
								? this.product.calculationProperty
								: 0,
						};

						if (this.getShopIdInStore && this.product.existence) {
							this.$store.dispatch("shop/addToCart", {
								product: item,
								btn_status: $btn_status,
							});
							this.$store.dispatch(
								"branch/oldCardStyle",
								this.getCardStyle
							);
							this.$store.dispatch("branch/setBranchWarning", {
								beforeBranch: null,
								thisBranch: this.getBranchWarning.thisBranch,
							});
						} else {
							alert("Has problem to add item in shopping cart");
						}
					} // if
				} else if (Object.keys(this.product).length) {
					let $productName = null;
					let $discountAmount = Boolean(this.product.discount)
						? this.product.discount.percent
						: 0;
					let $discountPrice = 0;

					if (this.cartCount <= 0) {
						this.$store.dispatch(
							"shop/setShopId",
							this.product.branch_id
						);
					} else if (this.cartCount > 0) {
						if (this.getShopIdInStore != this.product.branch_id) {
							this.$store.dispatch("branch/oldCardStyle", null);
							this.$store.dispatch(
								"shop/setShopId",
								this.product.branch_id
							);
						}
					}
					if (
						Boolean(this.product.translations) &&
						this.product.translations.length
					) {
						$productName = this.product.translations.find(
							translate => translate.locale == this.$i18n.locale
						).title;
					} else if (
						Boolean(this.product.name) &&
						Array.isArray(this.product.name) &&
						this.product.name.length
					) {
						$productName = this.product.name.find(
							translate => translate.locale == this.$i18n.locale
						).title;
					}
					if (this.product.minPrice) {
						// $discountPrice = ((100 - $discountAmount) * this.product.minPrice ) / 100;
						$discountPrice = (
							this.product.minPrice -
							(
								(this.product.minPrice *
									this.product.discount.percent) /
								100
							).toFixed(2)
						).toFixed(2);
					} else if ($discountAmount) {
						// $discountPrice = ((100 - $discountAmount) * this.product.price ) / 100;
						$discountPrice = (
							this.product.price -
							(
								(this.product.price *
									this.product.discount.percent) /
								100
							).toFixed(2)
						).toFixed(2);
					}

					let item = {
						shopId: this.product.shopId
							? this.product.shopId
							: this.product.branch_id,
						name: this.product.translations.length
							? this.product.translations
							: this.product.name,
						price: this.product.price,
						product_id: this.product.id,
						discount_amount: Boolean($discountAmount)
							? $discountAmount
							: 0,
						discount_price: $discountPrice,
						image: Boolean(this.product.thumbnail)
							? `storage/${this.product.thumbnail}`
							: `storage/${this.product.image}`,
						monetary_unit: this.product.monetary_unit,
						min_count: this.product.min_count,
						//////////////////////////////
						btn_type: this.getCardStyle.menu_btn_type,
						btn_text: this.getCardStyle.menu_button_text,
						//////////////////////////////
						count: 1,
						//////////////////////////////
						properties: this.product.properties
							? this.product.properties
							: [],
						calculationProperty: this.product.calculationProperty
							? this.product.calculationProperty
							: 0,
					};
					if (this.getShopIdInStore && this.product.existence) {
						this.$store.dispatch("shop/addToCart", {
							product: item,
							btn_status: $btn_status,
						});
						this.$store.dispatch(
							"branch/oldCardStyle",
							this.getCardStyle
						);
					} else {
						alert("Has problem to add item in shopping cart");
					}
				} // else
			} // else(isShopping)
		},
		validate() {
			if (this.$refs.form.validate()) {
				this.valid = true;
				this.getRequest(this.product);
			} else {
				this.valid = false;
			}
		},
		getRequest($prod) {
			if (this.valid) {
				this.loading = true;
				if (
					this.getCountries &&
					this.getCountries.length &&
					this.getCountries.length == 1
				) {
					this.countryCodeSelected = this.getCountries[0];
				}
				let $data = {
					shop_id: this.getBranchSelectedData[0].shop_id,
					product_id: $prod.id ? $prod.id : $prod.product_id,
					country_code_id: this.countryCodeSelected.country_id,
					name: this.name ? this.name : null,
					phone: this.phoneNumber ? this.phoneNumber : null,
					email: this.email ? this.email : null,
					description: this.description ? this.description : null,
				};
				this.$axios
					.$post(callRequest, $data)
					.then(res => {
						this.$store.dispatch("snackbar/isShow", true);
						this.$store.dispatch("snackbar/setText", res.message);
						this.$store.dispatch(
							"snackbar/setColor",
							res.status ? "teal" : "warning"
						);
						if (res.status) {
							this.closeDialog();
						}
						if (res.errors.length) {
							this.errors = res.errors;
						} else {
							this.errors = [];
						}
					})
					.catch(err => console.error(err))
					.finally(() => (this.loading = false));
			} // if
		},
		closeDialog() {
			this.dialog = false;
			this.errors = [];
			this.countryCodeSelected = "";
			this.phoneNumber = null;
			this.name = null;
			this.email = null;
			this.description = null;
		}, // closeDialog
		checkBtnType(btnStyle) {
			if (
				btnStyle == "BTN_MULTI" ||
				btnStyle == "BTN_TXT" ||
				btnStyle == "NUMERIC" ||
				btnStyle == "BTN_SEL" ||
				btnStyle == "CHECKBOX"
			)
				return btnStyle;
			return "NULL";
		},
	},
};
</script>
