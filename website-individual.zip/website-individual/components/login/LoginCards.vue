<template>
	<Fragment>
		<LoginCardPhone />
		<LoginCardCode />
		<LoginCardFullName />
		<LoginCardUser />
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
import LoginCardCode from "./LoginCardCode";
import LoginCardPhone from "./LoginCardPhone";
import LoginCardFullName from "./LoginCardFullName";
import LoginCardUser from "./LoginCardUser";

export default {
	name: "login_cards",
	components: {
		LoginCardPhone,
		LoginCardCode,
		LoginCardFullName,
		LoginCardUser,
		Fragment,
	},
	computed: {
		...mapGetters({
			getGoToOrderPage: "loginCard/getGoToOrderPage",
			isAuth: "isAuth",
		}),
	},
	watch: {
		isAuth(newVal, oldVal) {
			if (newVal && this.getGoToOrderPage) {
				this.$router.push(this.localePath("order", this.$i18n.locale));
			}
		},
	},
};
</script>
