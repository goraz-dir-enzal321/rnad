<template>
	<v-bottom-sheet v-model="loginCard_status" inset max-width="400px">
		<v-sheet
			class="text-center pa-5 justify-content-center rounded-t-lg"
			style="position: relative !important;"
		>
			<v-btn
				class="mx-2"
				absolute
				left
				top
				dark
				small
				icon
				color="grey"
				@click="loginCard_status = 0"
				style="top: 5px; left: 0px;"
			>
				<v-icon>mdi-close</v-icon>
			</v-btn>
			<!-- <v-btn class="mt-6" text color="red" v-on:click="loginCard_status = 0">close</v-btn> -->
			<h5>{{ $t("header.loginCard.fullName") }}</h5>
			<v-icon size="100" class="my-5">mdi-account-card-details</v-icon>
			<v-form ref="form" @submit.prevent="validate">
				<v-text-field
					dense
					:label="$t('form.placeholder.enter_your_name')"
					:rules="[rules.required]"
					minlength="2"
					outlined
					type="text"
					autocomplete="off"
					v-model="name"
					required
				/>
				<v-text-field
					dense
					:label="$t('form.placeholder.enter_your_family')"
					:rules="[rules.required]"
					minlength="2"
					outlined
					type="text"
					autocomplete="off"
					v-model="family"
					required
				/>
				<template v-if="getSiteSetting.getLeaderView() == 'SIGNUP'">
					<v-text-field
						v-model="code"
						:label="$t('form.label.reagent_code')"
						autocomplete="off"
						outlined
						hide-details="false"
						dense
						:disabled="
							loading ||
							!!(discountIdFormReagentCode && code.length)
						"
						:loading="loading"
					>
						<template v-slot:append-outer>
							<v-btn
								color="error"
								style="top: -7px;"
								@click="callParent"
								:loading="loading"
								:disabled="
									loading ||
									!code.length ||
									!!(discountIdFormReagentCode && code.length)
								"
								v-text="$t('button.check')"
							/>
						</template>
					</v-text-field>
					<div
						v-if="hintFormReagentCode.length"
						class="darken-1 pa-1 mb-4 font-size-13"
						:class="
							isErrorFormReagentCode ? 'red--text' : 'green--text'
						"
					>
						<v-icon
							small
							left
							:color="isErrorFormReagentCode ? 'red' : 'green'"
							v-text="
								isErrorFormReagentCode
									? 'mdi-alert-circle-outline'
									: 'mdi-check'
							"
						/>
						{{ hintFormReagentCode }}
					</div>
				</template>
				<v-btn
					depressed
					color="success"
					block
					:loading="loading"
					:disabled="loading"
					type="submit"
					v-text="$t('button.submit')"
				/>
				<!-- <v-btn depressed small color="primary" block dark v-on:click="loginCard_status = 2" type="submit">submit</v-btn> -->
			</v-form>
		</v-sheet>
	</v-bottom-sheet>
</template>
<script>
import { mapGetters } from "vuex";
import { login } from "@/api";

const Cookie = process.client ? require("js-cookie") : undefined;
export default {
	name: "loginCardFullName",
	data: () => ({
		valid: true,
		loading: false,
		// code reagent

		code: "",
		hintFormReagentCode: "",
		discountIdFormReagentCode: 0,
		isErrorFormReagentCode: false,

		name: "",
		family: "",
		rules: {
			required: null,
			min: null,
		},
	}),
	mounted() {
		this.hintFormReagentCode = "";
		this.code = "";
		this.discountIdFormReagentCode = 0;
		this.rules.required = value =>
			!!value || this.$t("form.validation.error.require");
		this.rules.min = value => value.length >= 2 || "Min 2 characters";
	},
	computed: {
		...mapGetters({
			getCountryId: "loginCard/getCountryId",
			getCountryText: "loginCard/getCountryText",
			getPhone: "loginCard/getPhone",
			getDomain: "siteSetting/getDomain",
			getMainShopId: "siteSetting/getMainShopId",
			getSiteSetting: "siteSetting/getSiteSetting",
		}),
		loginCard_status: {
			get() {
				return this.$store.state.loginCard.status == 3;
			},
			set(value) {
				this.$store.commit("loginCard/SET_STATUS", value ? value : 0);
			},
		},
	},
	methods: {
		async callParent() {
			this.loading = true;
			await this.$axios
				.$post(login.checkLeaderSignUp, {
					shop_id: this.getMainShopId,
					code: this.code,
				})
				.then(res => {
					if (!res.status) {
						this.hintFormReagentCode = this.$t(
							"message.error.your_code_not_found"
						);
						this.isErrorFormReagentCode = true;
					} else {
						this.discountIdFormReagentCode =
							res.data.discountIdFormReagentCode;
						this.hintFormReagentCode = this.$t(
							"message.success.accepted_code"
						);
						this.isErrorFormReagentCode = false;
					}
				})
				.catch(err => {
					this.hintFormReagentCode = this.$t(
						"message.error.your_code_not_found"
					);
					this.isErrorFormReagentCode = true;
					console.error(err, `ReagentCode`);
				})
				.finally(() => {
					this.loading = false;
				});
		},
		validate() {
			this.$refs.form.validate() ? this.signUp() : (this.valid = false);
		},
		async signUp() {
			if (
				!this.discountIdFormReagentCode &&
				this.code &&
				this.getSiteSetting.getLeaderView() == "SIGNUP"
			) {
				await this.callParent();
				if (this.isErrorFormReagentCode == true) {
					return;
				}
			}
			this.loading = true;
			await this.$axios
				.$post(login.signUp, {
					name: this.name,
					family: this.family,
					shop_id: this.getMainShopId,
					mobile: this.getPhone,
					lang: this.$i18n.locale,
					country_code_id: this.getCountryId,
					leader_discount_id: this.discountIdFormReagentCode,
				})
				.then(response => {
					if (response.status && !Boolean(response.new_user)) {
						response.country_id = this.getCountryId;
						response.country_text = this.getCountryText;
						const auth = {
							access_token: response.access_token,
							user: response,
							url: this.getDomain,
						};
						this.$store.commit("setAuth", auth); // mutating to store for client rendering
						Cookie.set("auth", auth, { expires: 2 }); // saving token in cookie for server rendering
						this.loading = false;
						this.loginCard_status = 0;
					} else {
						alert("In there has some problems about signup ...");
					}
				})
				.catch(error => {
					console.error(
						"LoginCardFullName.vue methods/signup => error ",
						error
					);
				})
				.finally(() => {
					this.loading = false;
				});
		}, // signUp()
	},
};
</script>
