<template>
	<!-- <v-btn depressed small color="primary" dark v-on:click="nextCard">User </v-btn> -->
	<v-bottom-sheet v-model="loginCard_status" inset max-width="400px">
		<v-sheet
			class="text-center pa-5 justify-content-center rounded-t-lg"
			style="position: relative !important;"
		>
			<v-btn
				class="mx-2"
				absolute
				left
				top
				dark
				small
				icon
				color="grey"
				@click="loginCard_status = 0"
				style="top: 5px; left: 0px;"
			>
				<v-icon>mdi-close</v-icon>
			</v-btn>
			<!-- <v-btn class="mt-6" text color="red" v-on:click="loginCard_status = 0">close</v-btn> -->
			<h5>{{ $t("header.loginCard.code") }}</h5>
			<v-icon size="100" class="my-5">mdi-lock</v-icon>
			<v-form ref="form" @submit.prevent="confirmCode">
				<v-text-field
					dense
					:label="$t('form.placeholder.enter_your_code')"
					outlined
					type="text"
					autocomplete="off"
					v-model="form.code"
				/>
				<v-btn
					depressed
					color="success"
					block
					:loading="loading"
					:disabled="loading"
					type="submit"
					>{{ $t("button.submit") }}</v-btn
				>
				<!-- <v-btn depressed small color="primary" block dark v-on:click="loginCard_status = 2" type="submit">submit</v-btn> -->
			</v-form>
		</v-sheet>
	</v-bottom-sheet>
</template>
<script>
const Cookie = process.client ? require("js-cookie") : undefined;
import { mapGetters } from "vuex";

export default {
	name: "loginCardCode",
	data() {
		return {
			loading: false,
			form: {
				phone_number: null,
				shop_id: this.getMainShopId,
				code: null,
			},
		};
	},
	computed: {
		...mapGetters({
			getCountryId: "loginCard/getCountryId",
			getCountryText: "loginCard/getCountryText",
			getDomain: "siteSetting/getDomain",
			getMainShopId: "siteSetting/getMainShopId",
		}),
		loginCard_status: {
			get() {
				return this.$store.state.loginCard.status == 2;
			},
			set(value) {
				this.$store.commit("loginCard/SET_STATUS", value ? value : 0);
			},
		},
	},
	methods: {
		confirmCode(elem) {
			const data = {
				mobile: this.$store.state.loginCard.phone,
				code: this.form.code,
				shop_id: this.getMainShopId,
				lang: this.$i18n.locale,
				country_code_id: this.getCountryId,
			};
			this.loading = true;

			this.$axios
				.$post("confirmCode", data)
				.then(response => {
					if (response.status && !Boolean(response.new_user)) {
						response.country_id = this.getCountryId;
						response.country_text = this.getCountryText;
						const auth = {
							access_token: response.access_token,
							user: response,
							url: this.getDomain,
						};
						this.$store.commit("setAuth", auth); // mutating to store for client rendering
						Cookie.set("auth", auth, { expires: 2 }); // saving token in cookie for server rendering
						this.loading = false;
						this.loginCard_status = 0;
					} else if (response.status && Boolean(response.new_user)) {
						this.loading = false;
						this.loginCard_status = 3;
						this.$store.commit(
							"loginCard/set_code",
							this.form.code
						);
					}
				})
				.catch(error => {
					// console.error("Authentication api err * ", error);
					if (error.response && error.response.data) {
						this.$store.dispatch("snackbar/isShow", true);
						this.$store.dispatch(
							"snackbar/setText",
							error.response.data.message
						);
						this.$store.dispatch(
							"snackbar/setColor",
							"red darken-2"
						);
					}
				})
				.finally(() => {
					this.loading = false;
				});
		},
	},
};
</script>
