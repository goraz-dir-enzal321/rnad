<template>
	<v-bottom-sheet
		v-model="isOpen"
		inset
		max-width="430px"
		style="overflow-y: auto !important; position: relative !important;"
	>
		<v-sheet
			class="px-3 justify-content-center rounded-t-lg"
			style="overflow-y: auto !important; position: relative !important;"
		>
			<div class="py-2 d-flex mx-2">
				<span
					v-text="$t('productInfo.buy.Cart')"
					class="font-size-subtitle-1 font-weight-bold"
				/>
				<v-spacer />
				<v-btn
					dark
					small
					color="red"
					text
					rounded
					@click="isOpen = !isOpen"
				>
					<span v-text="$t('button.close')" />
					<v-icon right small>mdi-close</v-icon>
				</v-btn>
			</div>
			<ShopingCart :isBtn="isBtn" />
		</v-sheet>
	</v-bottom-sheet>
</template>

<script>
import ShopingCart from "./Cart";

export default {
	name: "absoluteCart",
	components: { ShopingCart },
	props: ["isBtn"],
	computed: {
		isOpen: {
			get() {
				return this.$store.state.shop.isOpen == true;
			},
			set(value) {
				this.$store.dispatch("shop/isOpenCart", value ? value : false);
			},
		},
	},
};
</script>

<style lang="scss" scoped>
.v-bottom-sheet.v-dialog {
	overflow-y: auto !important;
}
</style>
