<template>
	<v-footer color="grey lighten-3" padless>
		<v-tabs
			center-active
			centered
			background-color="grey lighten-2"
			show-arrows
			color="grey darken-3"
			v-if="
				getSiteSetting.hasTextsLength() &&
				getSiteSetting
					.getTexts()
					.some(
						item =>
							item.location == 'FOOTER' || item.location == 'BOTH'
					)
			"
		>
			<v-tabs-slider color="transparent" />
			<template v-for="(textItem, index) in getSiteSetting.getTexts()">
				<v-tab
					v-if="
						textItem.location == 'FOOTER' ||
						textItem.location == 'BOTH'
					"
					:to="
						getSiteSetting.getTextsUrl(textItem).group ==
						'DYNAMIC_PAGE'
							? `/${$i18n.locale}/page/${
									getSiteSetting.getTextsUrl(textItem).route
							  }`
							: getSiteSetting.getTextsUrl(textItem).group ==
							  'STATIC_PAGE'
							? localePath(
									getSiteSetting.getTextsUrl(textItem).route,
									$i18n.locale
							  )
							: null
					"
					text
					class="my-2"
					nuxt
					:key="index"
					v-text="textItem.name"
				/>
			</template>
		</v-tabs>
		<v-row justify="center" no-gutters>
			<v-col cols="12" class="mx-auto">
				<v-divider />
			</v-col>
			<v-col
				class="white text-center font-size-caption"
				:class="$device.isMobile ? 'pb-11 mb-12 pt-4' : 'py-4'"
				cols="12"
			>
				<div class="d-flex justify-space-between align-center px-3">
					<strong
						v-if="
							Object.keys(getFirstData).length &&
							getFirstData.manufacture_info
						"
					>
						<v-btn
							text
							:href="
								getFirstData.manufacture_info.link
									? 'http://' +
									  getFirstData.manufacture_info.link
									: 'javascript:void(0)'
							"
							target="blank"
							v-text="getFirstData.manufacture_info.text"
						/>
					</strong>
					<span>
						<v-icon size="15">mdi-copyright</v-icon>
						{{ $store.getters["siteSetting/getCompanyName"] }}
						{{ new Date().getFullYear() }}
					</span>
				</div>
			</v-col>
		</v-row>
	</v-footer>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getSettingLength: "siteSetting/getSettingLength",
			getSiteSetting: "siteSetting/getSiteSetting",
		}),
	},
};
</script>
<style lang="scss" scoped>
.v-tab {
	text-transform: none !important;
	letter-spacing: unset !important;
}
</style>
