<template>
	<v-container fluid class="pa-0">
		<v-row no-gutters>
			<template
				v-if="
					Boolean(getSettingLength) &&
					Object.keys(getHeaderSettings).length &&
					getTheme
				"
			>
				<template v-if="getTheme.type != 'TOP_LARGE_SLIDER'">
					<v-app-bar
						:color="
							Boolean(getSiteColor) ? getSiteColor.color : 'grey'
						"
						primary
						fixed
					>
						<v-toolbar-title>
							<nuxt-link :to="localePath('index')">
								<v-img
									v-if="getSiteLogo"
									:src="`${getDomain}storage/${getSiteLogo}`"
									:lazy-src="`${getDomain}storage/${getSiteLogo}`"
									:contain="true"
									max-width="100"
									max-height="50"
								/>
								<v-btn text color="white" v-else>LOGO</v-btn>
							</nuxt-link>
						</v-toolbar-title>
						<div class="flex-grow-1"></div>
						<div class="d-flex justify-center align-center">
							<template
								v-if="
									$device.isMobileOrTablet && getSettingLength
								"
							>
								<v-menu offset-y>
									<template v-slot:activator="{ on }">
										<v-btn
											depressed
											small
											:color="
												Boolean(getSiteColor)
													? getSiteColor.secondColor
													: 'grey'
											"
											:class="[
												{ 'pr-0': $vuetify.rtl },
												{ 'pl-0': !$vuetify.rtl },
												'mx-1',
											]"
											dark
											v-on="on"
											style="
												text-transform: uppercase !important;
											"
										>
											<v-icon>mdi-dots-vertical</v-icon>
											{{ $t("button.more") }}
										</v-btn>
									</template>
									<v-list class="pa-0">
										<template
											v-for="(textItem,
											index) in getSiteSetting.getTexts()"
										>
											<v-list-item
												v-if="
													getSiteSetting.getTextsUrl(
														textItem
													).group == 'DYNAMIC_PAGE'
												"
												text
												dense
												nuxt
												:to="`/${$i18n.locale}/page/${
													getSiteSetting.getTextsUrl(
														textItem
													).route
												}`"
												v-text="textItem.name"
												:key="index"
											/>

											<v-list-item
												v-else-if="
													getSiteSetting.getTextsUrl(
														textItem
													).group == 'STATIC_PAGE'
												"
												text
												dense
												nuxt
												:to="
													localePath(
														getSiteSetting.getTextsUrl(
															textItem
														).route,
														$i18n.locale
													)
												"
												v-text="textItem.name"
												:key="index"
											/>
										</template>
									</v-list>
								</v-menu>

								<template
									v-for="(textItem,
									index) in getSiteSetting.getTexts()"
								>
									<v-btn
										v-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'LOGIN'
										"
										depressed
										small
										outlined
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										dark
										@click="openLoginCard"
										class="mx-1"
									>
										{{
											isAuth
												? userName
													? userName
													: textItem.name
												: textItem.name
										}}
										<v-icon
											size="19"
											:class="
												$vuetify.rtl ? 'mr-2' : 'ml-2'
											"
											>mdi-account</v-icon
										>
									</v-btn>
									<v-btn
										v-if="
											$device.isDesktopOrTablet &&
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'BASKET_BTN'
										"
										depressed
										small
										outlined
										color="white"
										dark
										class="mx-1"
										@click="
											$store.dispatch(
												'shop/isOpenCart',
												true
											)
										"
									>
										<v-chip
											x-small
											label
											:color="
												Boolean(getSiteColor)
													? getSiteColor.secondColor
													: 'grey'
											"
											v-if="cartCount"
										>
											{{ cartCount }}
										</v-chip>
										<span v-else>{{ textItem.name }}</span>
										<v-icon
											size="15"
											:class="
												$vuetify.rtl ? 'mr-2' : 'ml-2'
											"
											>mdi-cart</v-icon
										>
									</v-btn>
									<v-menu
										v-else-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'LANG'
										"
										offset-y
									>
										<template v-slot:activator="{ on }">
											<v-btn
												depressed
												small
												outlined
												:color="
													Boolean(getSiteColor)
														? getSiteColor.secondColor
														: 'grey'
												"
												dark
												v-on="on"
												style="
													text-transform: uppercase !important;
												"
											>
												{{ $i18n.locale }}
											</v-btn>
										</template>
										<v-list class="pa-0">
											<v-list-item
												dense
												v-for="locale in $store.getters[
													'siteSetting/getLocales'
												]"
												v-if="locale !== $i18n.locale"
												:key="`locale-key-${locale}`"
												@click="() => changeDir(locale)"
											>
												<v-list-item-title
													style="
														text-transform: uppercase !important;
													"
													>{{
														locale
													}}</v-list-item-title
												>
											</v-list-item>
										</v-list>
									</v-menu>
								</template>
							</template>
							<template v-else-if="getSettingLength">
								<template
									v-for="(textItem,
									index) in getSiteSetting.getTexts()"
									v-if="
										textItem.location == 'HEADER' ||
										textItem.location == 'BOTH'
									"
								>
									<v-btn
										v-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'DYNAMIC_PAGE'
										"
										depressed
										small
										outlined
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										class="mx-1"
										:key="index"
										dark
										nuxt
										:to="`/${$i18n.locale}/page/${
											getSiteSetting.getTextsUrl(textItem)
												.route
										}`"
										exact
									>
										{{ textItem.name }}
									</v-btn>
									<v-btn
										v-else-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'STATIC_PAGE'
										"
										depressed
										small
										outlined
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										class="mx-1"
										:key="index"
										dark
										nuxt
										:to="
											localePath(
												getSiteSetting.getTextsUrl(
													textItem
												).route,
												$i18n.locale
											)
										"
										exact
									>
										{{ textItem.name }}
									</v-btn>
									<v-btn
										v-else-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'LOGIN'
										"
										depressed
										small
										outlined
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										dark
										@click="openLoginCard"
										class="mx-1"
										:key="index"
									>
										{{
											isAuth
												? userName
													? userName
													: textItem.name
												: textItem.name
										}}
										<v-icon
											size="19"
											:class="
												$vuetify.rtl ? 'mr-2' : 'ml-2'
											"
											>mdi-account</v-icon
										>
									</v-btn>
									<v-btn
										v-else-if="
											$device.isDesktopOrTablet &&
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'BASKET_BTN'
										"
										depressed
										small
										outlined
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										dark
										class="mx-1"
										@click="
											$store.dispatch(
												'shop/isOpenCart',
												true
											)
										"
										:key="index"
									>
										<v-chip
											x-small
											label
											:color="
												Boolean(getSiteColor)
													? getSiteColor.secondColor
													: 'grey'
											"
											v-if="cartCount"
										>
											{{ cartCount }}
										</v-chip>
										<span v-else>{{ textItem.name }}</span>
										<v-icon
											size="15"
											:class="
												$vuetify.rtl ? 'mr-2' : 'ml-2'
											"
											>mdi-cart</v-icon
										>
									</v-btn>
									<v-menu
										v-else-if="
											getSiteSetting.getTextsUrl(textItem)
												.group == 'ACTION_BTN' &&
											textItem.type == 'LANG'
										"
										offset-y
										:key="index"
									>
										<template v-slot:activator="{ on }">
											<v-btn
												depressed
												small
												outlined
												color="white"
												dark
												v-on="on"
												style="
													text-transform: uppercase !important;
												"
											>
												{{ $i18n.locale }}
											</v-btn>
										</template>
										<v-list class="pa-0">
											<v-list-item
												dense
												v-for="locale in $store.getters[
													'siteSetting/getLocales'
												]"
												v-if="locale !== $i18n.locale"
												:key="`locale-key-${locale}`"
												@click="() => changeDir(locale)"
											>
												<v-list-item-title
													style="
														text-transform: uppercase !important;
													"
													>{{
														locale
													}}</v-list-item-title
												>
											</v-list-item>
										</v-list>
									</v-menu>
								</template>
							</template>
							<v-btn
								v-if="
									$device.isDesktopOrTablet &&
									Boolean(getSettingLength) &&
									Object.keys(getHeaderSettings).length &&
									getHeaderSettings.has_book_now
								"
								@click="goBookNow"
								class="mx-1 book-now-btn white--text pa-0"
								:style="[
									getHeaderSettings.book_now_color
										? {
												'background-color':
													getHeaderSettings.book_now_color,
										  }
										: {
												'background-color': Boolean(
													getSiteColor
												)
													? getSiteColor.secondColor
													: 'grey',
										  },
								]"
								style="min-width: 100px;"
							>
								<span v-if="getTranslations">{{
									getTranslations.find(
										item => item.locale == $i18n.locale
									).book_now_btn_txt
								}}</span>
								<svg
									xmlns="http://www.w3.org/2000/svg"
									:fill="[
										getHeaderSettings.book_now_color
											? getHeaderSettings.book_now_color
											: Boolean(getSiteColor)
											? getSiteColor.secondColor
											: '#9e9e9e',
									]"
									viewBox="0 0 313 140"
								>
									<path
										id="Path_25"
										data-name="Path 25"
										d="M0,0H313V120a20,20,0,0,1-20,20L156.48,84.387,20,140A20,20,0,0,1,0,120Z"
									/>
								</svg>
							</v-btn>
						</div>
					</v-app-bar>
				</template>
				<v-app-bar
					:color="Boolean(getSiteColor) ? getSiteColor.color : 'grey'"
					primary
					fixed
					v-else-if="getTheme.type == 'TOP_LARGE_SLIDER'"
				>
					<v-toolbar-title>
						<nuxt-link :to="localePath('index')">
							<v-img
								v-if="getSiteLogo"
								:src="`${getDomain}storage/${getSiteLogo}`"
								:lazy-src="`${getDomain}storage/${getSiteLogo}`"
								:contain="true"
								max-width="100"
								max-height="60"
							/>
							<v-btn text color="white" v-else>LOGO</v-btn>
						</nuxt-link>
					</v-toolbar-title>
					<div class="flex-grow-1"></div>
					<div class="d-flex justify-center align-center">
						<template
							v-if="$device.isMobileOrTablet && getSettingLength"
						>
							<v-menu offset-y>
								<template v-slot:activator="{ on }">
									<v-btn
										depressed
										small
										outlined
										color="white"
										:class="[
											{ 'pr-0': $vuetify.rtl },
											{ 'pl-0': !$vuetify.rtl },
											'mx-1',
										]"
										dark
										v-on="on"
										style="
											text-transform: uppercase !important;
										"
									>
										<v-icon>mdi-dots-vertical</v-icon>
										{{ $t("button.more") }}
									</v-btn>
								</template>
								<v-list class="pa-0">
									<template
										v-for="(textItem,
										index) in getSiteSetting.getTexts()"
									>
										<v-list-item
											v-if="
												getSiteSetting.getTextsUrl(
													textItem
												).group == 'DYNAMIC_PAGE'
											"
											text
											dense
											nuxt
											:to="`/${$i18n.locale}/page/${
												getSiteSetting.getTextsUrl(
													textItem
												).route
											}`"
											v-text="textItem.name"
											:key="index"
										/>

										<v-list-item
											v-else-if="
												getSiteSetting.getTextsUrl(
													textItem
												).group == 'STATIC_PAGE'
											"
											text
											dense
											nuxt
											:to="
												localePath(
													getSiteSetting.getTextsUrl(
														textItem
													).route,
													$i18n.locale
												)
											"
											v-text="textItem.name"
											:key="index"
										/>
									</template>
								</v-list>
							</v-menu>
							<template
								v-for="(textItem,
								index) in getSiteSetting.getTexts()"
							>
								<v-btn
									v-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'LOGIN'
									"
									depressed
									small
									outlined
									color="white"
									dark
									@click="openLoginCard"
									class="mx-1"
								>
									{{
										isAuth
											? userName
												? userName
												: textItem.name
											: textItem.name
									}}
									<v-icon
										size="19"
										:class="$vuetify.rtl ? 'mr-2' : 'ml-2'"
										>mdi-account</v-icon
									>
								</v-btn>
								<v-btn
									v-if="
										$device.isDesktopOrTablet &&
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'BASKET_BTN'
									"
									depressed
									small
									outlined
									color="white"
									dark
									class="mx-1"
									@click="
										$store.dispatch('shop/isOpenCart', true)
									"
								>
									<v-chip
										x-small
										label
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										v-if="cartCount"
									>
										{{ cartCount }}
									</v-chip>
									<span v-else>{{ textItem.name }}</span>
									<v-icon
										size="15"
										:class="$vuetify.rtl ? 'mr-2' : 'ml-2'"
										>mdi-cart</v-icon
									>
								</v-btn>
								<v-menu
									v-else-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'LANG'
									"
									offset-y
								>
									<template v-slot:activator="{ on }">
										<v-btn
											depressed
											small
											outlined
											color="white"
                                 class="mx-0 mx-sm-1"
											dark
											v-on="on"
											style="
												text-transform: uppercase !important;
											"
										>
											{{ $i18n.locale }}
										</v-btn>
									</template>
									<v-list class="pa-0">
										<v-list-item
											dense
											v-for="locale in $store.getters[
												'siteSetting/getLocales'
											]"
											v-if="locale !== $i18n.locale"
											:key="`locale-key-${locale}`"
											@click="() => changeDir(locale)"
										>
											<v-list-item-title
												style="
													text-transform: uppercase !important;
												"
												>{{ locale }}</v-list-item-title
											>
										</v-list-item>
									</v-list>
								</v-menu>
							</template>
						</template>

						<template v-else-if="getSettingLength">
							<template
								v-for="(textItem,
								index) in getSiteSetting.getTexts()"
								v-if="
									textItem.location == 'HEADER' ||
									textItem.location == 'BOTH'
								"
							>
								<v-btn
									v-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'DYNAMIC_PAGE'
									"
									depressed
									small
									outlined
									color="white"
									class="mx-1"
									:key="index"
									dark
									nuxt
									:to="`/${$i18n.locale}/page/${
										getSiteSetting.getTextsUrl(textItem)
											.route
									}`"
									exact
								>
									{{ textItem.name }}
								</v-btn>
								<v-btn
									v-else-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'STATIC_PAGE'
									"
									depressed
									small
									outlined
									color="white"
									class="mx-1"
									:key="index"
									dark
									nuxt
									:to="
										localePath(
											getSiteSetting.getTextsUrl(textItem)
												.route,
											$i18n.locale
										)
									"
									exact
								>
									{{ textItem.name }}
								</v-btn>
								<v-btn
									v-else-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'LOGIN'
									"
									depressed
									small
									outlined
									color="white"
									dark
									@click="openLoginCard"
									class="mx-1"
									:key="index"
								>
									{{
										isAuth
											? userName
												? userName
												: textItem.name
											: textItem.name
									}}
									<v-icon
										size="19"
										:class="$vuetify.rtl ? 'mr-2' : 'ml-2'"
										>mdi-account</v-icon
									>
								</v-btn>
								<v-btn
									v-else-if="
										$device.isDesktopOrTablet &&
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'BASKET_BTN'
									"
									depressed
									small
									outlined
									color="white"
									dark
									class="mx-1"
									@click="
										$store.dispatch('shop/isOpenCart', true)
									"
									:key="index"
								>
									<v-chip
										x-small
										label
										:color="
											Boolean(getSiteColor)
												? getSiteColor.secondColor
												: 'grey'
										"
										v-if="cartCount"
									>
										{{ cartCount }}
									</v-chip>
									<span v-else>{{ textItem.name }}</span>
									<v-icon
										size="15"
										:class="$vuetify.rtl ? 'mr-2' : 'ml-2'"
										>mdi-cart</v-icon
									>
								</v-btn>
								<v-menu
									v-else-if="
										getSiteSetting.getTextsUrl(textItem)
											.group == 'ACTION_BTN' &&
										textItem.type == 'LANG'
									"
									offset-y
									:key="index"
								>
									<template v-slot:activator="{ on }">
										<v-btn
											depressed
											small
											outlined
											color="white"
									      class="mx-0 mx-sm-1"
											dark
											v-on="on"
											style="
												text-transform: uppercase !important;
											"
										>
											{{ $i18n.locale }}
										</v-btn>
									</template>
									<v-list class="pa-0">
										<v-list-item
											dense
											v-for="locale in $store.getters[
												'siteSetting/getLocales'
											]"
											v-if="locale !== $i18n.locale"
											:key="`locale-key-${locale}`"
											@click="() => changeDir(locale)"
										>
											<v-list-item-title
												style="
													text-transform: uppercase !important;
												"
												>{{ locale }}</v-list-item-title
											>
										</v-list-item>
									</v-list>
								</v-menu>
							</template>
						</template>
					</div>
					<div class="flex-grow-1"></div>
					<v-btn
						v-if="
							$device.isDesktopOrTablet &&
							Boolean(getSettingLength) &&
							Object.keys(getHeaderSettings).length &&
							getHeaderSettings.has_book_now
						"
						@click="goBookNow"
						:ripple="false"
						class="mx-1 book-now-btn white--text pa-0"
						:style="[
							getHeaderSettings.book_now_color
								? {
										'background-color':
											getHeaderSettings.book_now_color,
								  }
								: {
										'background-color': Boolean(
											getSiteColor
										)
											? getSiteColor.secondColor
											: 'grey',
								  },
						]"
						style="min-width: 100px;"
					>
						<span v-if="getTranslations">{{
							getTranslations.find(
								item => item.locale == $i18n.locale
							).book_now_btn_txt
						}}</span>
						<svg
							xmlns="http://www.w3.org/2000/svg"
							:fill="[
								getHeaderSettings.book_now_color
									? getHeaderSettings.book_now_color
									: Boolean(getSiteColor)
									? getSiteColor.secondColor
									: '#9e9e9e',
							]"
							viewBox="0 0 313 140"
						>
							<path
								id="Path_25"
								data-name="Path 25"
								d="M0,0H313V120a20,20,0,0,1-20,20L156.48,84.387,20,140A20,20,0,0,1,0,120Z"
							/>
						</svg>
					</v-btn>
				</v-app-bar>
				<div style="margin-top: 57px;" />
			</template>
			<v-bottom-navigation
				:color="
					Boolean(getSiteColor) ? getSiteColor.secondColor : 'grey'
				"
				grow
				v-if="$device.isMobileOrTablet"
				fixed
				v-model="activeBtn"
			>
				<v-btn value="1" nuxt :to="localePath('index')" exact>
					<span>{{ $t("button.home") }}</span>
					<v-icon>mdi-home</v-icon>
				</v-btn>
				<v-btn value="2" nuxt :to="localePath('download')" exact>
					<span>{{ $t("button.app") }}</span>
					<v-icon>mdi-cellphone-arrow-down</v-icon>
				</v-btn>
				<v-btn
					color="grey--text"
					v-on:click="$store.dispatch('shop/isOpenCart', true)"
				>
					<span>{{ $t("button.shopping_cart") }}</span>
					<v-badge
						:value="Boolean(cartCount) ? true : false"
						:color="
							Boolean(getSiteColor)
								? getSiteColor.secondColor
								: 'primary'
						"
					>
						<template v-slot:badge>{{ cartCount }}</template>
						<v-icon>mdi-cart</v-icon>
					</v-badge>
				</v-btn>
				<v-btn color="grey--text" @click="openLoginCard" v-if="isAuth">
					<span>{{ getUserName }}</span>
					<v-icon>mdi-account</v-icon>
				</v-btn>
				<v-btn color="grey--text" @click="openLoginCard" v-else>
					<span>{{ $t("button.profile") }}</span>
					<v-icon>mdi-account</v-icon>
				</v-btn>
			</v-bottom-navigation>
		</v-row>
	</v-container>
</template>

<script>
const Cookie = process.client ? require("js-cookie") : undefined;
import { mapGetters } from "vuex";

export default {
	data() {
		return {
			loading: false,
			activeBtn: 1,
			customStore: this.$store.state.auth,
			type: "selector",
			selector: "#main-section",
			duration: 1000,
			offset: 50,
			easing: "easeInOutCubic",
		};
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			cartCount: "shop/cartCount",
			isAuth: "isAuth",
			getUserName: "getUserName",
			getSiteLogo: "siteSetting/getSiteLogo",
			getDomain: "siteSetting/getDomain",
			getSiteColor: "siteSetting/getSiteColor",
			getHeaderSettings: "siteSetting/getHeaderSettings",
			getSettingLength: "siteSetting/getSettingLength",
			getTranslations: "siteSetting/getTranslations",
			getTheme: "siteSetting/getTheme",
			getSiteSetting: "siteSetting/getSiteSetting",
			getTextsUrl: "siteSetting/getTextsUrl",
		}),
		userName: {
			get() {
				const $username = this.getUserName;
				return $username;
			},
		},
		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},
		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	mounted() {
		this.$nextTick(() => {
			this.$nuxt.$loading.start();
			setTimeout(() => this.$nuxt.$loading.finish(), 2000);
		});
	},
	methods: {
		changeDir(localee) {
			// this.$nuxt.$loading.start();
			// this.$router.push(this.switchLocalePath(localee));
			window.location.href = `${window.location.origin}/${localee}`;
		},
		openLoginCard() {
			if (this.isAuth) {
				this.$store.commit("loginCard/SET_STATUS", 4);
			} else this.$store.commit("loginCard/SET_STATUS", 1);
		},
		goBookNow() {
			this.loading = true;
			this.$router.push(this.localePath("index", this.$i18n.locale));
			setTimeout(
				() => {
					this.$vuetify.goTo(this.target, this.options);
					if (
						Object.keys(this.getFirstData).length &&
						this.getFirstData.shops.length > 1
					) {
						this.selector = "#swiper-section";
					} else {
						this.selector = "#main-section";
					}
					this.$vuetify.goTo(this.target, this.options);
					this.loading = false;
				},
				this.$route.path === "/" + this.$i18n.locale ? 0 : 1000
			);
		},
	},
};
</script>
<style lang="scss" scoped>
.navbar-layout .navbar-layout-brand .nav-link {
	color: white !important;
}

.book-now-btn {
	position: relative;
	border-radius: 3px 3px 0 0;
	outline: none !important;
}

.book-now-btn:active,
.book-now-btn:focus,
.book-now-btn:hover {
	/*opacity: 1 !important;*/
	/*background-color: none !important;*/
	&:before {
		position: relative !important;
	}
}

.book-now-btn:hover {
	cursor: pointer;
	opacity: 1;
	/*-webkit-transition: none!important;*/
	/*transition: none !important;*/
}

.book-now-btn svg {
	position: absolute;
	top: 100%;
	width: 100%;
	height: auto;
	left: 0;
	right: 0;
}

#dropdownMenuButton > button {
	width: 100%;
}

#dropdownMenuButton__BV_toggle_ {
	width: 100%;
}
</style>
