<template>
	<v-row
		width="100%"
		class="rounded-16 white pt-2 pb-6 pb-sm-2 px-1"
		:class="{
			'direction-rtl': $vuetify.rtl,
			'direction-ltr': !$vuetify.rtl,
			'elevation-6': $device.isMobile,
		}"
		no-gutters
	>
		<v-col
			cols="5"
			sm="12"
			lg="12"
			v-if="!timeWorkShop || !productData.existence"
		>
			<v-chip
				label
				active
				class="pa-1"
				style="height: auto;"
				v-if="!timeWorkShop"
				v-text="$t('label.store_is_closed')"
			/>
			<v-chip
				label
				active
				class="pa-1"
				style="height: auto;"
				v-else-if="!productData.existence"
				v-text="$t('label.not_exist')"
			/>
		</v-col>
		<v-col cols="5" sm="12" lg="12" class="me-1 d-flex align-center">
			<ProductCardButtons
				:product="productData"
				:customData="true"
				btnType="DESCRIPTION"
				v-if="timeWorkShop && productData.existence"
			/>
		</v-col>

		<v-col v-if="$device.isMobile">
			<v-row
				no-gutters
				:class="[
					'mt-1',
					{
						'direction-rtl': !$vuetify.rtl,
						'direction-ltr': $vuetify.rtl,
					},
				]"
			>
				<portionPrice
					:price="getProductData.price"
					:discount_price="getProductData.discount_price"
					:monetary_unit="getProductData.monetary_unit"
					:discount="getProductData.discount"
					:unit_sentence="getProductData.unit_sentence"
				/>
			</v-row>
		</v-col>
		<div class="nothing" v-text="watchCalculationProperty" />
	</v-row>
</template>

<script>
import ProductCardButtons from "@/components/ProductCard/Buttons";
import portionPrice from "@/components/Product/productInfo_t2/counter/portionPrice";

import { mapGetters } from "vuex";
import * as moment from "moment";

export default {
	data: () => ({
		productData: {
			shopId: "",
			name: "",
			translations: "",
			price: "",
			product_id: "",
			discount_price: "",
			thumbnail: "",
			image: "",
			monetary_unit: "",
			min_count: "",
			existence: "",
		},
		isShopOpen: null,
		isShowDetailBuy: false,
		countBuy: 0,
	}),
	components: {
		ProductCardButtons,
		portionPrice,
	},
	computed: {
		...mapGetters({
			getProductData: "productInfo/getProductData",
			getCalculationProperty: "productInfo/getCalculationProperty",
			getTimeWorkShop: "productInfo/getTimeWorkShop",
			getSymbolSendPorperties: "productInfo/getSymbolSendPorperties",
			cartCount: "shop/cartCount",
			isAuth: "isAuth",
		}),
		timeWorkShop() {
			if (this.getTimeWorkShop) {
				let userLocaleUtcTime = moment().utc().format("HH:mm:ss");
				// console.log(
				//   this.getTimeWorkShop.am_time_start,
				//   this.getTimeWorkShop.am_time_end,
				//   this.getTimeWorkShop.pm_time_start,
				//   this.getTimeWorkShop.pm_time_end
				// );
				this.isShopOpen =
					(this.getTimeWorkShop.am_time_start <= userLocaleUtcTime &&
						userLocaleUtcTime <=
							this.getTimeWorkShop.am_time_end) ||
					(this.getTimeWorkShop.pm_time_start <= userLocaleUtcTime &&
						userLocaleUtcTime <= this.getTimeWorkShop.pm_time_end);
				return this.isShopOpen;
			}
		},
		watchCalculationProperty() {
			this.setProductData();
		},
	},
	methods: {
		setProductData() {
			let productData = {
				shopId: this.getProductData.shop_id
					? this.getProductData.shop_id
					: "",
				name: this.getProductData.name ? this.getProductData.name : "",
				translations: this.getProductData.name
					? this.getProductData.name
					: "",
				price: this.getProductData.price
					? this.getProductData.price
					: "",
				product_id: this.getProductData.product_id
					? this.getProductData.product_id
					: this.getProductData.id
					? this.getProductData.id
					: "",
				discount_price: this.getProductData.discount_price
					? this.getProductData.discount_price
					: this.getProductData.price
					? this.getProductData.price
					: 0,
				discount: this.getProductData.discount
					? this.getProductData.discount
					: 0,
				thumbnail: this.getProductData.thumbnail
					? this.getProductData.thumbnail
					: this.getProductData.img,
				image: this.getProductData.img ? this.getProductData.img : "",
				monetary_unit: this.getProductData.monetary_unit
					? this.getProductData.monetary_unit
					: "",
				min_count: this.getProductData.min_count
					? this.getProductData.min_count
					: "",
				existence: this.getProductData.existence
					? this.getProductData.existence
					: "",
				properties: this.getSymbolSendPorperties
					? this.getSymbolSendPorperties
					: "",
				calculationProperty: this.getCalculationProperty
					? this.getCalculationProperty
					: 0,
			};
			this.productData = productData;
		},
	},
	created() {
		this.setProductData();
	},
};
</script>
