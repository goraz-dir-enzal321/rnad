<template>
	<Fragment>
		<!-- discount & price & monetary_unit & getCalculationProperty -->
		<v-col
			:cols="price && discount ? 'auto' : '12'"
			v-if="price && monetary_unit"
			class="mr-2 d-flex align-center"
		>
			<!-- monetary_unit -->
			<span
				class="d-inline-block font-size-12 mt-1"
				:class="discount ? 'grey--text' : 'grey--text text--darken-3 '"
				v-if="monetary_unit"
				v-text="monetary_unit"
				style="transform: rotate(-90deg);"
			/>
			<!-- discount price -->
			<span class="d-inline-block mr-1">
				<span
					class="font-weight-medium"
					:class="
						discount
							? 'red--text font-size-16'
							: 'grey--text text--darken-3 font-size-19 '
					"
					v-text="
						$numberWithCommas(
							$roundDecimal(
								discount
									? +price +
											(getCalculationProperty
												? getCalculationProperty
												: 0) -
											(+price +
												(getCalculationProperty
													? getCalculationProperty
													: 0)) *
												(discount / 100)
									: +price +
											(getCalculationProperty
												? getCalculationProperty
												: 0)
							)
						)
					"
				/>
				<div
					v-if="unit_sentence"
					v-text="unit_sentence"
					class="font-size-13 text--green"
				/>
			</span>
			<!-- getCalculationProperty -->
			<!-- <span
				class="d-inline-block grey--text text--darken-2"
				v-if="getCalculationProperty"
			>
				<v-icon x-small>mdi-plus</v-icon>
				{{ $numberWithCommas($roundDecimal(getCalculationProperty)) }}
			</span> -->
		</v-col>
		<!-- price & discount -->
		<v-col class="flex-shrink-1 d-flex align-center" v-if="price && discount">
			<!-- price -->
			<span
				class="text-decoration-line-through d-inline-block mt-1"
				v-if="price && discount_price != price"
				v-text="
					$numberWithCommas(
						$roundDecimal(
							+price +
								(getCalculationProperty
									? getCalculationProperty
									: 0)
						)
					)
				"
			/>
			<v-spacer v-if="price && discount" />
			<!-- discount -->
			<v-chip
				color="red"
				small
				text-color="white"
				v-if="discount"
				v-text="discount + ' % '"
			/>
		</v-col>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	props: [
		"price",
		"discount_price",
		"monetary_unit",
		"discount",
		"unit_sentence",
	],
	components: {
		Fragment,
	},
	computed: {
		...mapGetters({
			getOptions: "productInfo/getOptions",
			getItemCount: "shop/itemCount",
			getCalculationProperty: "productInfo/getCalculationProperty",
		}),
	},
};
</script>
