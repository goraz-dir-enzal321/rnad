<template>
	<v-dialog
		v-model="dialogComputed"
		max-width="1300"
		v-if="videoOne && videoOne.file"
	>
		<v-card>
			<v-row no-gutters>
				<v-col cols="10" class="py-2" v-if="videoOne.desc">
					<v-card-title
						v-if="!$device.isMobile"
						class="font-weight-medium py-1 font-size-24"
						v-text="videoOne.desc"
					/>
					<div
						v-else
						class="font-weight-medium py-1 px-4 font-size-15"
						v-text="videoOne.desc"
					/>
				</v-col>
				<v-col
					cols="2"
					class="text-center py-2 d-flex justify-end align-center"
					v-if="videoOne.desc"
				>
					<v-btn
						class="mx-4"
						color="error"
						icon
						@click="dialogComputed = false"
					>
						<v-icon>mdi-close</v-icon>
					</v-btn>
				</v-col>
				<v-col cols="12">
					<vue-plyr>
						<video>
							<source
								:src="
									videoOne.file.startsWith(`http`) ||
									videoOne.file.startsWith(`storage/`)
										? videoOne.file.startsWith(`storage/`)
											? getDomain + videoOne.file
											: videoOne.file
										: `${getDomain}storage/${videoOne.file}`
								"
								type="video/mp4"
							/>
							Your browser does not support the video tag.
						</video>
					</vue-plyr>
				</v-col>
			</v-row>
		</v-card>
		<div class="nothing">
			{{ openSheet }}
		</div>
	</v-dialog>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["videoOne"],
	data: () => ({
		dialog: false,
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getDomain: "siteSetting/getDomain",
			getDialogVideo: "productInfo/getDialogVideo",
		}),
		dialogComputed: {
			get() {
				return this.dialog;
			},
			set(value) {
				this.dialog = value;
				this.$store.dispatch("productInfo/setDialogVideo", {
					status: value,
					id: this.videoOne.id,
				});
			},
		},
		openSheet() {
			if (this.getDialogVideo &&( this.getDialogVideo.id == this.videoOne.id))
				this.dialogComputed = this.getDialogVideo.status;
		},
	},
};
</script>
