<template>
	<v-col cols="12">
		<v-tabs
			v-model="tab"
			align-with-title
			:background-color="AllColors.site_color"
			color="white"
			class="rounded white--text"
			dark
		>
			<template v-for="(item, index) in tabItems">
				<v-tab
					v-if="item && item.data"
					:key="`tab-${index}`"
					v-text="item.name"
               class="font-weight-medium"
               style="letter-spacing: 0.03em;"
				/>
			</template>
			<v-tabs-slider color="white" />
		</v-tabs>
		<v-tabs-items v-model="tab">
			<template v-for="tabItem in tabItems">
				<v-card v-if="tab == tabItem.tabId" flat :key="tabItem.id">
					<component :is="tabItem.component" />
				</v-card>
			</template>
		</v-tabs-items>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import comments from "@/components/Product/productInfo_t2/tabs/comments";
import downloads from "@/components/Product/productInfo_t2/tabs/downloads";
import detailsComponnent from "@/components/Product/productInfo_t2/tabs/details";
import explanation from "@/components/Product/productInfo_t2/tabs/explanation";

export default {
	components: {
		comments,
		downloads,
		detailsComponnent,
		explanation,
	},
	data: () => ({
		tab: 0,
		tabItems: [],
		addIdData: 0,
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getComments: "productInfo/getComments",
			getDetails: "productInfo/getDetails",
			getDownloads: "productInfo/getDownloads",
			getExplanation: "productInfo/getExplanation",
			getStyledProductShop: "productInfo/getStyledProductShop",
		}),
	},
	methods: {
		setTabs(getGettersTab, nameOfGetters, componentName, checkLength = 1) {
			if (getGettersTab && getGettersTab.type && getGettersTab.data) {
				if (
					checkLength == 1 &&
					getGettersTab.data.length &&
					getGettersTab.data.length != 0 &&
					Object.keys(getGettersTab.data).length
				) {
					getGettersTab.tabId = this.addIdData;
					getGettersTab.name = nameOfGetters;
					getGettersTab.component = componentName;
					this.tabItems.push(getGettersTab);
					this.addIdData += 1;
				} else if (checkLength == 2 && nameOfGetters && componentName) {
					getGettersTab.tabId = this.addIdData;
					getGettersTab.name = nameOfGetters;
					getGettersTab.component = componentName;
					this.tabItems.push(getGettersTab);
					this.addIdData += 1;
				} else if (
					getGettersTab.data.length &&
					getGettersTab.data.length != 0 &&
					Object.keys(getGettersTab.data).length
				) {
					getGettersTab.tabId = this.addIdData;
					getGettersTab.name = nameOfGetters;
					getGettersTab.component = componentName;
					this.tabItems.push(getGettersTab);
					this.addIdData += 1;
				}
			}
		},
	},
	created() {
		this.tabItems = [];
		this.addIdData = 0;
		this.setTabs(
			this.getDownloads,
			this.$t("productInfo.tabs.play"),
			downloads,
			0
		);
		this.setTabs(
			this.getExplanation,
			this.$t("productInfo.tabs.explanation"),
			explanation,
			0
		);
		this.setTabs(
			this.getDetails,
			this.$t("productInfo.tabs.details"),
			detailsComponnent
		);
		if (this.getStyledProductShop.has_order_comment)
			this.setTabs(
				this.getComments,
				this.$t("productInfo.tabs.comments"),
				comments,
				1
			);
	},
};
</script>
