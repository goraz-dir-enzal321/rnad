<template>
	<v-card
		:outlined="$device.isMobile ? true : false"
		:elevation="$device.isMobile ? 2 : 0"
		:link="false"
		:nuxt="false"
		v-ripple="false"
		@click="
			optionsTabs.type == 'details' &&
			optionsTabs.data &&
			optionsTabs.data.length > 3
				? $store.dispatch('productInfo/setOpenSheetDetails', true)
				: optionsTabs.type == 'explanation' &&
				  optionsTabs.data &&
				  optionsTabs.data.length > 61
				? $store.dispatch('productInfo/setOpenSheetExplanation', true)
				: null
		"
		class="rounded-16 section-card-properties py-0 px-1 mb-2 mb-md-0"
	>
		<v-row class="py-2 px-3 pa-md-0">
			<!-- title -->
			<v-col cols="12" class="py-0">
				<explanation v-if="optionsTabs.type == 'explanation'" />
				<v-divider
					v-if="
						optionsTabs.type == 'explanation' &&
						optionsTabs.data &&
						optionsTabs.type == 'details' &&
						optionsTabs.data
					"
				/>
				<detailsComponnent v-if="optionsTabs.type == 'details'" />
				<downloads v-if="optionsTabs.type == 'downloads'" />
				<comments v-if="optionsTabs.type == 'comments'" />
			</v-col>
		</v-row>
	</v-card>
</template>

<script>
import comments from "@/components/Product/productInfo_t2/tabs/comments";
import downloads from "@/components/Product/productInfo_t2/tabs/downloads";
import detailsComponnent from "@/components/Product/productInfo_t2/tabs/details";
import explanation from "@/components/Product/productInfo_t2/tabs/explanation";

export default {
	components: {
		comments,
		downloads,
		detailsComponnent,
		explanation,
	},
	props: ["optionsTabs"],
};
</script>
