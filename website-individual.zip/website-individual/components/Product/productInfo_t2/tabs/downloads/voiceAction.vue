<template>
	<v-card outlined :ripple="false">
		<v-row class="px-3">
			<v-col cols="3" sm="auto" class="pa-1">
				<v-sheet
					:width="$device.isMobile ? '50px' : '75px'"
					:height="$device.isMobile ? '50px' : '75px'"
					:color="AllColors.site_color"
					class="d-inline-flex justify-center align-center rounded"
				>
					<v-img
						v-if="voiceOne && voiceOne.img"
						height="100%"
						class="rounded"
						:src="
							voiceOne.img.startsWith(`http`) ||
							voiceOne.img.startsWith(`storage/`)
								? voiceOne.img.startsWith(`storage/`)
									? getDomain + voiceOne.img
									: voiceOne.img
								: `${getDomain}storage/${voiceOne.img}`
						"
					/>
				</v-sheet>
			</v-col>
			<v-col
				cols="7"
				sm="auto"
				class="pa-1 d-flex"
				v-if="
					voiceOne.desc || voiceOne.duration || voiceOne.duration == 0
				"
			>
				<v-row no-gutters class="flex-grow-1" align="center">
					<v-col
						cols="12"
						class="py-0 py-sm-1 grey--text text--darken-4"
						:class="{
							'font-size-12': $device.isMobile,
							'font-size-15': !$device.isMobile,
						}"
						v-if="voiceOne.desc"
						v-text="voiceOne.desc"
					/>
				</v-row>
			</v-col>
			<v-spacer v-if="!$device.isMobile" />
			<v-col
				class="pa-0 pl-1 pa-sm-1 d-flex align-center no-gutters"
				cols="12"
				sm="9"
				:class="{ 'col-12': $device.isMobile, 'pr-1': !isCanDownload }"
				v-if="voiceOne && voiceOne.file"
			>
				<v-col class="plyr-download" cols="auto" v-if="isCanDownload">
					<v-sheet
						:color="
							getSiteColor.color
								? getSiteColor.color
								: 'grey darken-3'
						"
						class="rounded-l-0 rounded-r"
						height="100%"
						width="100%"
					>
						<a
							:href="
								voiceOne &&
								(voiceOne.file.startsWith(`https`) ||
								voiceOne.file.startsWith(`storage/`)
									? voiceOne.file.startsWith(`storage/`)
										? getDomain + voiceOne.file
										: voiceOne.file
									: `${getDomain}storage/${voiceOne.file}`)
							"
							class="text-decoration-none d-inline-flex justify-center align-center"
							download
							target="_blank"
						>
							<v-icon>mdi-download</v-icon>
						</a>
					</v-sheet>
				</v-col>
				<v-col class="flex-shrink-1">
					<!-- <vue-plyr
						:class="[
							'ma-n1 ma-sm-0',
							{ 'rounded-r-0': isCanDownload },
						]"
					> -->
					<audio
						controlsList="nodownload"
                  class="w-100"
						:id="`audio_${voiceOne.id}`"
						controls
						:style="{
							'--plyr-audio-controls-background': getSiteColor.color
								? getSiteColor.color
								: 'grey darken-3',
						}"
					>
						<source
							:src="
								voiceOne &&
								(voiceOne.file.startsWith(`https`) ||
								voiceOne.file.startsWith(`storage/`)
									? voiceOne.file.startsWith(`storage/`)
										? getDomain + voiceOne.file
										: voiceOne.file
									: `${getDomain}storage/${voiceOne.file}`)
							"
							type="audio/mpeg"
						/>
					</audio>
					<!-- </vue-plyr> -->
				</v-col>
			</v-col>
		</v-row>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["voiceOne"],
	data: () => ({
		isCanDownload: false,
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getDomain: "siteSetting/getDomain",
			getSiteColor: "siteSetting/getSiteColor",
		}),
	},
};
</script>
