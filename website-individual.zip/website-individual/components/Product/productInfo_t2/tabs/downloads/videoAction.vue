<template>
	<v-card
		outlined
		v-ripple
		@click="
			$store.dispatch('productInfo/setDialogVideo', {
				status: true,
				id: videoOne.id,
			})
		"
	>
		<v-row class="px-3">
			<v-col cols="3" sm="2" lg="1" class="pa-1">
				<v-sheet
					:width="$device.isMobile ? '50px' : '75px'"
					:min-height="$device.isMobile ? '50px' : '75px'"
					:color="AllColors.site_color"
					class="d-inline-flex justify-center align-center rounded"
				>
					<v-img
						v-if="videoOne && videoOne.img"
						height="100%"
						class="rounded"
						:src="
							videoOne.img.startsWith(`http`) ||
							videoOne.img.startsWith(`storage/`)
								? videoOne.img.startsWith(`storage/`)
									? getDomain + videoOne.img
									: videoOne.img
								: `${getDomain}storage/${videoOne.img}`
						"
					>
					</v-img>
				</v-sheet>
			</v-col>
			<v-col
				cols="7"
				sm="9"
				class="pa-1 d-flex"
				v-if="videoOne.desc || videoOne.duration"
			>
				<v-row no-gutters class="flex-grow-1" align="center">
					<v-col
						cols="12"
						class="py-1 font-size-15 grey--text text--darken-4"
						v-if="videoOne.desc"
						v-text="videoOne.desc"
					/>
					<v-col
						cols="12"
						class="py-0 px-2 font-size-14 grey--text text--darken-2"
						v-if="videoOne.duration || videoOne.duration == 0"
						v-text="videoOne.duration"
					/>
				</v-row>
			</v-col>
			<v-col cols="2" class="pa-1 d-flex align-center justify-end">
				<v-btn
					fab
					dark
					:x-small="$device.isMobile"
					:small="!$device.isMobile"
					class="darken-4 mx-1"
					:color="AllColors.site_color"
					depressed
				>
					<v-icon dark>mdi-play</v-icon>
				</v-btn>
			</v-col>
		</v-row>
		<videoDialog :videoOne="videoOne" />
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import videoDialog from "@/components/Product/productInfo_t2/tabs/common/videoDialog";
export default {
	components: {
		videoDialog,
	},
	props: ["videoOne"],
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>