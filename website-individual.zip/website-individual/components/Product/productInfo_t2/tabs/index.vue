<template>
	<v-col cols="12" class="order-11 py-0">
		<v-row>
			<DesktopTabs v-if="!$device.isMobile" />
			<template v-else v-for="(item, index) in tabItems">
				<v-col
					cols="12"
					class="py-0"
					v-if="item"
					:key="`item-tab-${index}`"
				>
					<MobileTabs :optionsTabs="item" />
				</v-col>
			</template>
		</v-row>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import DesktopTabs from "@/components/Product/productInfo_t2/tabs/DesktopTabs";
import MobileTabs from "@/components/Product/productInfo_t2/tabs/MobileTabs";
export default {
	components: {
		DesktopTabs,
		MobileTabs,
	},
	data: () => ({
		tab: null,
		tabItems: [],
		addIdData: 0,
		text:
			"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getComments: "productInfo/getComments",
			getDetails: "productInfo/getDetails",
			getDownloads: "productInfo/getDownloads",
			getStyledProductShop: "productInfo/getStyledProductShop",
			getExplanation: "productInfo/getExplanation",
		}),
	},
	methods: {
		setTabs(getGettersTab, nameOfGetters, checkLength = true) {
			if (checkLength == true) {
				if (
					getGettersTab &&
					getGettersTab.type &&
					getGettersTab.data &&
					getGettersTab.data.length &&
					getGettersTab.data.length != 0 &&
					Object.keys(getGettersTab.data).length
				) {
					getGettersTab.id = this.addIdData;
					getGettersTab.name = nameOfGetters;
					this.tabItems.push(getGettersTab);
					this.addIdData += 1;
				}
			} else if (
				getGettersTab &&
				getGettersTab.type &&
				getGettersTab.data
			) {
				getGettersTab.name = nameOfGetters;
				getGettersTab.id = this.addIdData;
				this.tabItems.push(getGettersTab);
				this.addIdData += 1;
			}
		},
	},
	created() {
		this.tabItems = [];
		this.addIdData = 0;
		this.setTabs(
			this.getExplanation,
			this.$t("productInfo.tabs.explanation"),
			false
		);
		this.setTabs(this.getDetails, this.$t("productInfo.tabs.details"));
		if (this.getStyledProductShop.has_order_comment)
			this.setTabs(
				this.getComments,
				this.$t("productInfo.tabs.comments")
			);
		this.setTabs(this.getDownloads, this.$t("productInfo.tabs.play"));
	},
};
</script>
