<template>
	<v-row>
		<v-col cols="12">
			<comments
				:product_id="getOptions.product_id"
				:canComment="4"
				:commentsDataProps="getComments.data"
				:isAuth="isAuth"
			/>
		</v-col>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
import comments from "@/components/Product/common/comments";
export default {
	components: {
		comments,
	},
	computed: {
		...mapGetters({
			isAuth: "isAuth",
			getComments: "productInfo/getComments",
			getOptions: "productInfo/getOptions",
		}),
	},
};
</script>
