<template>
	<Fragment>
		<template v-if="$device.isMobile">
			<v-col
				cols="auto"
				class="pt-0 pb-1 font-size-18 font-weight-bold text--darken-3 grey--text"
				v-if="textDescription"
				v-text="$t('productInfo.tabs.explanation')"
			/>
			<v-spacer />
			<v-col
				cols="auto"
				class="pt-0 pb-1 light-blue--text"
				v-if="textDescription && textDescription.length > 165"
			>
				{{ $t("productInfo.more") }}
				<v-icon
					class="light-blue--text"
					v-text="
						$vuetify.rtl ? 'mdi-chevron-left' : 'mdi-chevron-right'
					"
				/>
			</v-col>
			<v-col
				cols="12"
				class="pt-0 pb-1 grey--text text--darken-3 overflow-y-hidden pos-relative"
				:style="['line-height: 1.833; font-size: .857rem;']"
			>
				<p
					:class="
						textDescription && textDescription.length > 165
							? 'section-text-less-show ma-0'
							: 'section-text-lesser ma-0'
					"
					v-html="
						textDescription && typeof textDescription === 'string'
							? textDescription.substring(0, 165)
							: ''
					"
				/>
				<div
					class="section-less-show-shadow-bottom pos-absolute top-0 left-0 right-0 h-100"
					v-if="textDescription && textDescription.length > 165"
				/>
				<v-bottom-sheet
					v-model="sheetComputed"
					v-if="textDescription && textDescription.length > 165"
				>
					<v-sheet
						class="overflow-x-hidden overflow-y rounded-top-16 py-2 px-1 font-size-16 font-weight-light"
						max-height="90vh"
					>
						<v-row no-gutters>
							<div
								class="px-3 py-1 font-size-20 font-weight-medium"
								v-text="$t('productInfo.tabs.explanation')"
							/>
							<v-spacer></v-spacer>
							<v-btn
								depressed
								color="grey"
								text
								class="ps-3 py-1 text--darken-3 font-weight-medium"
								@click="sheetComputed = false"
							>
								<span class="me-n2 d-inline-block">
									{{ $t("productInfo.back") }}
								</span>
								<v-icon right v-text="'mdi-chevron-left'" />
							</v-btn>
							<v-col cols="12" class="px-3 py-1">
								<v-divider />
							</v-col>
						</v-row>
						<p
							class="pa-2"
							v-html="
								textDescription &&
								typeof textDescription === 'string'
									? textDescription
									: ''
							"
						/>
					</v-sheet>
					<div class="nothing">{{ openSheet }}</div>
				</v-bottom-sheet>
			</v-col>
		</template>
		<template v-else>
			<v-col
				cols="12"
				v-html="
					textDescription && typeof textDescription === 'string'
						? textDescription
						: ''
				"
			/>
		</template>
	</Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
import { mapGetters } from "vuex";
export default {
	props: ["textDescription"],
	components: {
		Fragment,
	},
	data: () => ({
		sheet: false,
	}),
	computed: {
		...mapGetters({
			getOpenSheetExplanation: "productInfo/getOpenSheetExplanation",
		}),
		sheetComputed: {
			get() {
				return this.sheet;
			},
			set(value) {
				this.sheet = value;
				this.$store.dispatch(
					"productInfo/setOpenSheetExplanation",
					value
				);
			},
		},
		openSheet() {
			this.sheetComputed = this.getOpenSheetExplanation;
		},
	},
};
</script>
