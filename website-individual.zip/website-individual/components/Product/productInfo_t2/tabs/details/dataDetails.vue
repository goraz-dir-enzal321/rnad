<template>
	<v-row
		:class="{
			'grey mb-1 rounded lighten-4 ma-0 grey--text text--darken-3':
				$device.isMobile,
		}"
		v-if="details.name || details.value"
	>
		<v-col cols="8" sm="3" class="pa-0 pa-sm-1" v-if="details.name">
			<div
				:class="[
					'px-2 py-1',
					{ 'grey rounded lighten-3 ': !$device.isMobile },
					{ 'd-flex ': $device.isMobile },
				]"
			>
				{{ details.name }}
				<template v-if="$device.isMobile">
					:
					<v-spacer></v-spacer>
				</template>
			</div>
		</v-col>
		<v-col cols="4" sm="9" class="pa-0 pa-sm-1" v-if="details.value">
			<div
				:class="[
					'px-2 py-1',
					{ 'grey rounded lighten-3 ': !$device.isMobile },
					{ 'd-flex': $device.isMobile },
				]"
				v-text="details.value"
			/>
		</v-col>
	</v-row>
</template>

<script>
export default {
	props: ["details"],
};
</script>
