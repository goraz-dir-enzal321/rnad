<template>
	<v-col cols="12">
		<v-row
			no-gutters
			:class="{
				'justify-space-between':
					getImage &&
					getImage.gallery &&
					getImage.gallery.length &&
					getImage.gallery.length > 6,
			}"
		>
			<v-col
				v-if="getVideo && getVideo.file"
				cols="2"
				class="pa-1 section-of-gallery border br-grey rounded"
				:class="[
					{ 'mr-0 ml-2': $vuetify.rtl == true },
					{ 'mr-2 ml-0': $vuetify.rtl == false },
				]"
				@click="
					$store.dispatch('productInfo/setDialogVideo', {
						status: true,
						id: 'Single video',
					})
				"
			>
				<div
					class="section-blur-box d-flex justify-center align-center h-100"
				>
					<v-img
						height="100%"
						class="rounded blur-3"
						:src="
							getImage.image
								? getImage.image.startsWith(`http`) ||
								  getImage.image.startsWith(`storage/`)
									? getImage.image.startsWith(`storage/`)
										? getDomain + getImage.image
										: getImage.image
									: `${getDomain}storage/${getImage.image}`
								: '/images/img-default.jpeg'
						"
					/>
					<div class="section-blur-circle text-center white--text">
						<v-icon dark>mdi-play</v-icon>
					</div>
				</div>
				<videoDialog
					:videoOne="{
						file: getVideo.file,
						desc: getVideo.title,
						id: 'Single video',
					}"
				/>
			</v-col>
			<template
				v-if="getImage && getImage.gallery && getImage.gallery.length"
			>
				<template v-for="(item, index) in gallery">
					<v-col
						:key="index"
						v-if="item && item.img"
						cols="2"
						class="pa-1 section-of-gallery border br-grey rounded"
						:class="[
							{ 'mr-0 ml-2': $vuetify.rtl == true },
							{ 'mr-2 ml-0': $vuetify.rtl == false },
						]"
						@click="selectedGallery(item)"
					>
						<template v-if="index == indexShowMoreGallery">
							<div class="section-blur-box">
								<v-img
									width="100%"
									class="rounded blur-3"
									:src="
										item.img.startsWith(`http`) ||
										item.img.startsWith(`storage/`)
											? item.img.startsWith(`storage/`)
												? getDomain + item.img
												: item.img
											: `${getDomain}storage/${item.img}`
									"
								/>
								<div
									class="section-blur-circle text-center white--text"
								>
									<v-icon dark>mdi-dots-horizontal</v-icon>
								</div>
							</div>
						</template>
						<template v-else>
							<v-img
								width="100%"
								class="rounded"
								:src="
									item.img.startsWith(`http`) ||
									item.img.startsWith(`storage/`)
										? item.img.startsWith(`storage/`)
											? getDomain + item.img
											: item.img
										: `${getDomain}storage/${item.img}`
								"
							/>
						</template>
					</v-col>
				</template>
			</template>
		</v-row>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import videoDialog from "@/components/Product/productInfo_t2/tabs/common/videoDialog";
export default {
	components: {
		videoDialog,
	},
	data: () => ({
		gallery: [],
		indexShowMoreGallery: 5,
	}),
	computed: {
		...mapGetters({
			getImage: "productInfo/getImage",
			getDomain: "siteSetting/getDomain",
			getVideo: "productInfo/getVideo",
		}),
	},
	methods: {
		setIsMoreGallery(value) {
			this.gallery = [];
			if (this.getVideo) {
				this.gallery.push(value);
				for (let j = 0; j < 4; j++) {
					const element = value[j];
					this.gallery.push(element);
				}
				this.indexShowMoreGallery = 4;
			} else if (this.getImage.gallery.length > 6) {
				for (let j = 0; j < 5; j++) {
					const element = value[j];
					this.gallery.push(element);
				}
				this.indexShowMoreGallery = 5;
			} else {
				this.gallery = value;
			}
		},
		selectedGallery(item) {
			this.$store.dispatch("productInfo/setGallerySelected", item);
			this.$store.dispatch("productInfo/setDialogStatus", true);
		},
	},
	created() {
		this.setIsMoreGallery(this.getImage.gallery);
	},
};
</script>
