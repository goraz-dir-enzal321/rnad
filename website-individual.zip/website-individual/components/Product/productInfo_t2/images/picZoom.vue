<template>
	<div
		class="d-flex justify-content-center align-center"
		v-if="imageThumb && idForSetElement && imageHires"
	>
		<div
			:id="`${idForSetElement}_image_thumb_box`"
			class="image"
			@mouseover="enterImage"
			@mouseout="leaveImage"
			@mousemove="move"
			@wheel="zoomer"
		>
			<!-- @mouseleave="hover = false" -->
			<a
				:id="`${idForSetElement}_href_click`"
				:href="imageThumb"
				target="_blank"
			>
				<img
					:id="`${idForSetElement}_image_thumb`"
					:src="imageHires ? imageHires : imageThumb"
					alt=""
					class="rounded-4"
				/>
			</a>
		</div>

		<div :id="`${idForSetElement}_image_hires_box`" class="zoom">
			<img
				:id="`${idForSetElement}_image_hires`"
				class="zoom-image rounded-4"
				:src="imageHires ? imageHires : imageThumb"
				alt=""
			/>
		</div>
	</div>
</template>

<script>
export default {
	props: ["idForSetElement", "imageThumb", "imageHires", "height"],
	data: () => ({
		image: "",
		zoom: "",
		zoomImage: "",
		zoomLevel: 1.5,
	}),
	methods: {
		enterImage(e) {
			if (e.cancelable) {
				this.zoom.classList.add("loading");
				let posX, posY;
				posX = e.clientX;
				posY = e.clientY;

				this.zoom.style.top = `${posY - this.zoom.offsetHeight / 2}px`;
				this.zoom.style.left = `${posX - this.zoom.offsetWidth / 2}px`;

				// remove the loading class
				e.preventDefault();
				// e.deltaY > 0 ? this.zoomLevel-- : this.zoomLevel++;

				if (this.zoomLevel < 1.25) this.zoomLevel = 1.25;
				if (this.zoomLevel > 4) this.zoomLevel = 4;

				this.zoom.style.transform = `scale(${this.zoomLevel})`;
				this.zoom.classList.remove("loading");
				this.zoom.classList.add("show");
			}
		},
		leaveImage() {
			// remove scaling to prevent non-transition
			this.zoom.style.transform = null;
			this.zoomLevel = 1.5;
			this.zoom.classList.add("loading");
			this.zoom.classList.remove("show");
		},
		move(e) {
			if (e.cancelable) {
				e.preventDefault();
				if (this.image) {
					let posX, posY;

					posX = e.offsetX;
					posY = e.offsetY;
					// move the zoom a little bit up on mobile (because of your fat fingers :<)
					this.zoom.style.top = `${
						posY - this.zoom.offsetHeight / 2
					}px`;
					this.zoom.style.left = `${
						posX - this.zoom.offsetWidth / 2
					}px`;

					let percX =
							(posX - this.image.offsetLeft) /
							this.image.offsetWidth,
						percY =
							(posY - this.image.offsetTop) /
							this.image.offsetHeight;

					let zoomLeft =
							-percX * this.zoomImage.offsetWidth +
							this.zoom.offsetWidth / 2,
						zoomTop =
							-percY * this.zoomImage.offsetHeight +
							this.zoom.offsetHeight / 2;

					this.zoomImage.style.left = `${zoomLeft}px`;
					this.zoomImage.style.top = `${zoomTop}px`;
				}
			}
		},
		zoomer(e) {
			if (e.cancelable) {
				e.preventDefault();
				e.deltaY > 1.5
					? (this.zoomLevel -= 0.5)
					: (this.zoomLevel += 0.5);

				if (this.zoomLevel < 1.25) this.zoomLevel = 1.25;
				if (this.zoomLevel > 2.5) this.zoomLevel = 2.5;

				this.zoom.style.transform = `scale(${this.zoomLevel})`;
			}
		},
	},
	updated() {
		this.image = document.getElementById(
			`${this.idForSetElement}_image_thumb_box`
		);
		this.zoom = document.getElementById(
			`${this.idForSetElement}_image_hires_box`
		);
		this.zoomImage = document.getElementById(
			`${this.idForSetElement}_image_hires`
		);
		document.getElementById(
			`${this.idForSetElement}_image_thumb`
		).style.height = this.height + "px";
		this.zoomImage.style.height = this.height + "px";
		document
			.getElementById(`${this.idForSetElement}_image_hires`)
			.setAttribute(
				"src",
				this.imageHires ? this.imageHires : this.imageThumb
			);
	},
	mounted() {
		this.image = document.getElementById(
			`${this.idForSetElement}_image_thumb_box`
		);
		this.zoom = document.getElementById(
			`${this.idForSetElement}_image_hires_box`
		);
		this.zoomImage = document.getElementById(
			`${this.idForSetElement}_image_hires`
		);
		if (document.getElementById(`${this.idForSetElement}_image_thumb`)) {
			document.getElementById(
				`${this.idForSetElement}_image_thumb`
			).style.height = this.height + "px";
		}
		this.zoomImage.style.height = this.height + "px";
		document
			.getElementById(`${this.idForSetElement}_image_hires`)
			.setAttribute(
				"src",
				this.imageHires ? this.imageHires : this.imageThumb
			);
	},
};
</script>

<style lang="scss" scoped>
.image {
	max-width: 100%;
	cursor: none;
	a {
		cursor: none;
	}
	img {
		max-width: 100%;
		vertical-align: middle;
		z-index: 1;
	}
}
.zoom {
	width: 14rem;
	height: 14rem;
	z-index: 5;
	background: #fff;
	border-radius: 50%;
	position: absolute;
	// box-shadow: inset 0 0 0 1px #000;
	pointer-events: none;
	transition: transform 0.25s ease, opacity 0s linear 0.25s,
		background 0.25s ease;
	opacity: 0;
	transform: scale(0);
	transform-origin: 50% 50%;
	overflow: hidden;
	&:before {
		content: "";
		position: absolute;
		margin: auto;
		left: 0;
		top: 0;
		right: 0;
		bottom: 0;
		width: 100%;
		height: 100%;
		border-radius: 50%;
		display: none;
	}
	&.show {
		transform: scale(1.5);
		opacity: 1;
		transition: transform 0.25s ease, opacity 0s linear;
	}
	&.loading {
		background: transparent;
		&:before {
			display: block;
			animation: loading 0.5s ease infinite alternate;
		}
		@keyframes loading {
			0% {
				transform: scale(0.1);
				box-shadow: inset 0 0 0 150px transparent;
			}
			50% {
				transform: scale(1.5);
				box-shadow: inset 0 0 0 140px #fff;
			}
			100% {
				box-shadow: inset 0 0 0 0 transparent;
			}
		}
		.zoom-image {
			opacity: 0;
		}
	}
	.zoom-image {
		position: absolute;
		left: 0;
		top: 0;
		transition: opacity 0.25s ease;
	}
}
</style>
