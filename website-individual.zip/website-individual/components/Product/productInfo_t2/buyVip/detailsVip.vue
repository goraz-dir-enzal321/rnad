<template>
	<v-dialog v-model="dialog" max-width="290">
		<template v-slot:activator="{ on, attrs }">
			<v-col cols="12" class="pb-2 text-center">
				<v-btn
					:color="colorBg"
					class="py-2 px-5 font-wight-medium"
					small
               depressed
					rounded
					block
					v-bind="attrs"
					v-on="on"
					:dark="!$wc_hex_is_light(bg_colorHex6)"
					v-text="$t('productInfo.buy.courses') + nameCourses"
					style="white-space: unset; height: auto;"
				/>
			</v-col>
		</template>
		<v-card color="white">
			<v-row
				no-gutters
				:style="{
					background: `linear-gradient(to top, ${colorBg}5 , #0000)`,
				}"
			>
				<v-col cols="10" class="py-0" v-if="nameCourses">
					<v-card-title
						class="font-size-13 py-0 font-weight-medium"
						v-text="nameCourses"
					/>
				</v-col>
				<v-col
					cols="2"
					class="text-center py-0 d-flex justify-end align-center"
				>
					<v-btn
						class="mx-4"
						color="grey darken-2"
						icon
						@click="dialog = false"
						x-small
					>
						<v-icon small>mdi-close</v-icon>
					</v-btn>
				</v-col>
				<v-col cols="12" class="pb-1">
					<v-divider :style="{ 'border-color': `${colorBg}5` }" />
				</v-col>
				<v-col
					cols="12"
					class="pt-1 pb-2 px-3"
				>
					<div
						class="py-1 mb-2 font-size-13"
						v-text="
							$t('productInfo.buy.courses') + nameCourses + ':'
						"
					/>
					<div
						class="liDashbefor font-size-13"
						v-for="(item, index) in propsdetails"
						:key="index"
						v-text="item.name"
					/>
				</v-col>
			</v-row>
		</v-card>
	</v-dialog>
</template>

<script>
export default {
	props: ["propsdetails", "colorBg", "nameCourses", "bg_colorHex6"],
	data() {
		return {
			dialog: false,
		};
	},
};
</script>
