<template>
	<v-container class="pt-0 section-description font-size-14">
		<!-- loading -->
		<loading v-if="getLoading == true" />
		<!-- /loading -->
		<v-row v-else class="white py-3 rounded mx-lg-12">
			<!-- Caption Title ** on mobile **  caption title here -->
			<v-col
				cl
				cols="12"
				class="d-flex d-sm-none py-0 pr-5"
				v-if="getOptions && getOptions.name && $device.isMobile"
			>
				<captionTitle />
			</v-col>
			<!-- /Caption Title ** on mobile **  caption title here -->
			<!-- image box -->
			<images />
			<!-- /image box -->
			<!-- controles -> infos & buy -->
			<v-col cols="12" sm="7" class="pt-0 pt-sm-3">
				<v-row>
					<v-col cols="12" class="pt-0" v-if="!$device.isMobile">
						<!-- caption title-->
						<captionTitle />
						<!-- /caption title-->
					</v-col>
					<!-- infos -->
					<infos />
					<!-- /infos -->
					<!-- buy -->
					<counter />
					<!-- /buy -->
				</v-row>
			</v-col>
			<!-- tab(s) -->
			<tabs />
			<!-- /tab(s) -->
			<!-- /controles -> infos & buy -->
			<!-- button buy if(on mobile) -->
			<div
				class="py-0 rounded-16 section-btn-card"
				v-if="
					((getStyledProductShop &&
						getStyledProductShop.has_product_voice &&
						!getOptions.single_purchase) ||
						!(
							getStyledProductShop &&
							getStyledProductShop.has_product_voice
						)) &&
					$device.isMobile &&
					getStyledProductShop.description_btn != 'NONE'
				"
			>
				<counterBuy />
			</div>
			<!-- /button buy if(on mobile) -->
			<div class="nothing" v-text="isAuthComputed" />
		</v-row>
	</v-container>
</template>

<script>
import loading from "@/components/Product/productInfo_t2/loading";

import images from "@/components/Product/productInfo_t2/images";
import infos from "@/components/Product/productInfo_t2/infos";
import captionTitle from "@/components/Product/productInfo_t2/captionTitle";
import counter from "@/components/Product/productInfo_t2/counter";
import tabs from "@/components/Product/productInfo_t2/tabs";
import counterBuy from "@/components/Product/productInfo_t2/counter/counterBuy";

import { product } from "~/api";
import { mapGetters } from "vuex";

export default {
	props: ["res", "slug"],
	components: {
		loading,
		images,
		infos,
		captionTitle,
		counter,
		tabs,
		counterBuy,
	},
	data: () => ({
		productData: null,
		isGetProduct: null,
		isAuthChange: false,
	}),
	computed: {
		...mapGetters({
			isAuth: "isAuth",
			getAuth: "getAuth",
			getOptions: "productInfo/getOptions",
			getStyledProductShop: "productInfo/getStyledProductShop",
			getBranchWarning: "branch/getBranchWarning",
			getShops: "firstData/getShops",
			getLoading: "productInfo/getLoading",
			getMainShopId: "siteSetting/getMainShopId",
		}),
		metaTagComputed: {
			get() {
				return this.metaTag;
			},
			set(products_val) {
				this.metaTag.title = products_val.seo_title;
				this.metaTag.desc = products_val.seo_desc;
			},
		},
		isAuthComputed: {
			get() {
				if (this.isAuthChange != this.isAuth) {
					this.$store.dispatch("productInfo/setLoading", true);
					this.isAuthChange = this.isAuth;
					return this.getProductInfo();
				}
			},
		},
	},
	created() {
		this.$store.dispatch("productInfo/setLoading", true);
	},
	mounted() {
		this.getProductInfo();
		this.$store.dispatch("productInfo/setDialogStatusVip", false);
		this.isAuthChange = this.isAuth;
	},
	methods: {
		async getProductInfo() {
			await this.$axios
				.$post(product.getProductInfoV2, {
					product_id: this.slug,
					branch_id: this.getMainShopId ? this.getMainShopId : null,
					user_id:
						this.getAuth &&
						this.getAuth.user &&
						this.getAuth.user.user_id
							? this.getAuth.user.user_id
							: null,
					lang: this.$i18n.locale,
				})
				.then(res => {
					this.productData = res.products;
					if (res.status) {
						try {
							this.$store.dispatch(
								"shop/setShopId",
								res.products.shop_id
							);
							const $shop = this.getShops.find(shop => {
								if (shop.id == res.products.shop_id) {
									this.$store.dispatch(
										"productInfo/setStyledProductShop",
										{
											basket_btn_type:
												shop.card.basket_btn_type,
											description_style:
												shop.card.description_style,
											description_btn:
												shop.card.description_btn,
											has_order_comment:
												shop.has_order_comment,
											has_product_voice:
												shop.has_product_voice,
										}
									);
									this.$store.dispatch(
										"productInfo/setTimeWorkShop",
										{
											am_time_start: shop.am_time_start,
											am_time_end: shop.am_time_end,
											pm_time_start: shop.pm_time_start,
											pm_time_end: shop.pm_time_end,
										}
									);
								}
								return shop.id == res.products.shop_id
									? shop
									: "";
							});
							if ($shop) {
								this.shop_description_style =
									$shop.card.description_style;
								this.$store.dispatch(
									"branch/cardStyle",
									$shop.card
								);
							}
							if (this.getBranchWarning)
								this.$store.dispatch(
									"branch/setBranchWarning",
									{
										beforeBranch: this.getBranchWarning
											.thisBranch,
										thisBranch: null,
									}
								);
							this.$store.dispatch(
								"productInfo/setProductData",
								res.products
							);
							this.callResult(res.products);
						} catch (e) {
							console.error("catch ", e);
						}
					} else {
						this.$router.push(this.localePath("index"));
					}
				})
				.catch(error => {
					console.error("error ", error);
					// this.$router.push(this.localePath("index"));
				})
				.finally(() => {
					this.$nextTick(() => this.$nuxt.$loading.finish());
					this.$store.dispatch("productInfo/setLoading", false);
				});
		},
		callResult(products_data) {
			this.$emit("callResultMetaTags", products_data);
		},
	},
};
</script>
