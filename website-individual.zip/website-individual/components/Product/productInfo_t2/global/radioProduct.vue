<template>
	<v-radio-group
		v-model="SetIdproductComputed"
		row
		class="section-properties-radio ma-0"
		:class="$device.isMobile ? ' justify-center' : ''"
	>
		<!-- loop -> section of property of properties -->
		<!--         ^^^^^^                            -->
		<template v-for="(item, index) in itemProductMembers">
			<label
				v-if="
					saveSelected == 'setGallerySelected'
						? item && item.img
						: true
				"
				:for="`radio${item.id}-${index}`"
				:key="`onTheLabel-${item.id}-${index}`"
				class="mb-2 mx-1"
			>
				<v-radio :id="`radio${item.id}-${index}`" :value="item.id" />
				<radioProduct :propsMember="item"></radioProduct>
			</label>
			<v-btn
				v-if="
					index == itemProductMembers.length - 1 &&
					isMore &&
					productMembers.length > 6
				"
				:key="`onTheButton-${item.id}-${index}`"
				color="blue text--darken-3"
				text
				@click="setSeeMore"
				style="height: 33px;"
				class="font-size-14"
			>
				<v-icon
					v-if="isClickMore == true"
					:right="!$vuetify.rtl ? true : false"
					:left="$vuetify.rtl ? true : false"
					v-text="isClickMore ? 'mdi-arrow-right' : 'mdi-arrow-left'"
				/>
				{{
					isClickMore
						? $t("button.less")
						: `${$t("button.more")} ( ${
								productMembers.length -
								itemProductMembers.length
						  } )`
				}}
				<v-icon
					v-if="isClickMore == false"
					:right="$vuetify.rtl ? true : false"
					:left="!$vuetify.rtl ? true : false"
					v-text="isClickMore ? 'mdi-arrow-right' : 'mdi-arrow-left'"
				/>
			</v-btn>
		</template>
		<!-- /loop -->
		<div class="nothing">
			{{ setGallerySelect }}
		</div>
	</v-radio-group>
</template>

<script>
import radioProduct from "@/components/Product/productInfo_t2/global/radioProductCard";
import { mapGetters } from "vuex";
export default {
	components: { radioProduct },
	props: [
		"productMembers",
		"indexProduct",
		"defaultAttr",
		// "nameComponent",
		"saveSelected",
		"isIndexProduct",
		"isMore",
	],
	data() {
		return {
			itemProductMembers: [],
			radioSelsect: "",
			attrSelcet: "",
			isClickMore: false,
		};
	},
	computed: {
		...mapGetters({
			gallerySelected: "productInfo/getGallerySelected",
		}),
		// because this component is global
		/*
      componentWasWana() {
       if (this.nameComponent) {
         if (this.nameComponent == "radioProperties") {
           return radioProperties;
         }
         if (this.nameComponent == "radioGalleryCard") {
           return radioGalleryCard;
         }
       }
      },
     */
		setGallerySelect() {
			if (
				this.saveSelected == "setGallerySelected" &&
				this.gallerySelected
			) {
				this.SetIdproductComputed = this.gallerySelected.id;
			}
			return this.gallerySelected;
		},
		productComputed: {
			get() {
				return this.attrSelcet;
			},
			set(value) {
				this.attrSelcet = value;
				if (this.saveSelected)
					for (let j = 0; j < this.productMembers.length; j++) {
						const element = this.productMembers[j];
						if (this.attrSelcet == element.id) {
							if (this.isIndexProduct == true) {
								this.attrSelcet = {
									id: this.indexProduct,
									data: element,
									type: "Single",
								};
							} else {
								this.attrSelcet = element;
							}

							this.$store.dispatch(
								`productInfo/${this.saveSelected}`,
								this.attrSelcet
							);
							return this.attrSelcet;
						}
					}
			},
		},
		SetIdproductComputed: {
			get() {
				return this.radioSelsect;
			},
			set(value) {
				this.radioSelsect = value;
				this.productComputed = value;
			},
		},
	},
	methods: {
		setSeeMore() {
			this.isClickMore = !this.isClickMore;
			if (this.isClickMore == true) {
				this.itemProductMembers = this.productMembers;
			} else {
				this.itemProductMembers = [];
				this.productMembers.filter((id, i) =>
					id && i <= 4 ? this.itemProductMembers.push(id) : ""
				);
			}
		},
	},
	mounted() {
		if (this.defaultAttr) {
			this.SetIdproductComputed = this.defaultAttr;
		}
	},
	created() {
		if (this.isMore && this.productMembers.length >= 5) {
			this.productMembers.filter((id, i) =>
				id && i <= 4 ? this.itemProductMembers.push(id) : ""
			);
		} else {
			this.itemProductMembers = this.productMembers;
		}
	},
};
</script>

<style scoped>
.text-decoration-underline {
	text-decoration: underline;
}
</style>
