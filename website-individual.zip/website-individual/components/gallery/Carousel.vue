<template>
	<v-card class="pt-3" flat>
		<h1 class="text-center">Latest Photos</h1>
		<VueSlickCarousel :arrows="false" :dots="false" v-bind="settings">
			<div v-for="item in items" :key="item.id" class="rounded-0">
				<v-card class="pa-1" flat>
					<v-img
						max-height="500"
						:src="imageLink(item.img)"
						:lazy-src="imageLink(item.img)"
						class="white--text align-end text-center"
					>
						<v-card-title
							class="text-center d-block carousel-label"
							v-text="item.description"
						/>
					</v-img>
				</v-card>
			</div>
		</VueSlickCarousel>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import VueSlickCarousel from "vue-slick-carousel";
import "vue-slick-carousel/dist/vue-slick-carousel.css";
// optional style for arrows & dots
import "vue-slick-carousel/dist/vue-slick-carousel-theme.css";
export default {
	name: "gallery-carousel",
	components: { VueSlickCarousel },
	props: ["items"],
	data() {
		return {
			settings: {
				dots: false,
				arrows: false,
				infinite: true,
				slidesToScroll: 1,
				rtl: this.$vuetify.rtl,
			},
		};
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
	methods: {
		imageLink(link) {
			let $link = "/images/section-bg.jpg";

			if (link) $link = this.getDomain + "/" + link;

			return $link;
		},
	},
};
</script>

<style scoped>
.carousel-label::before {
	content: "";
	background: black !important;
	opacity: 0.5;
	height: 60px;
	position: absolute;
	right: 0;
	left: 0;
	bottom: 0;
	z-index: -1;
}
</style>
