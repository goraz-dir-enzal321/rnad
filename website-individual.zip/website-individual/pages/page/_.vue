<template>
	<div>
		<v-container>
			<v-row>
				<v-col cols="12" sm="12">
					<v-card>
						<v-img
							src="/images/head_wallpaper.jpg"
							height="160px"
							lazy-src="/images/head_wallpaper.jpg"
							gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
						>
							<v-card-title
								class="font-size-display-1 white--text align-center justify-center fill-height pa-0"
							>
								<template
									v-if="getFirstData && getFirstData.footer"
								>
									<template
										v-for="footer in getFirstData.footer"
										v-if="
											footer.name ==
											$route.params.pathMatch
										"
									>
										{{ footer.title }}
									</template>
								</template>
								<template v-else>
									{{ $route.params.pathMatch }}
								</template>
							</v-card-title>
						</v-img>
					</v-card>
				</v-col>
				<v-col cols="12">
					<v-card tile class="fill-height">
						<v-card-text
							v-if="
								pageDataComputed &&
								pageDataComputed.text.translations
							"
						>
							<template
								v-if="pageDataComputed.text.translations.length"
							>
								<template
									v-for="translate in pageDataComputed.text
										.translations"
									v-if="translate.locale == $i18n.locale"
								>
									<p
										:key="translate.id"
										v-if="translate.content"
										v-html="translate.content"
									/>
									<p
										:key="translate.id"
										class="text--primary"
										v-else
									>
										---------
									</p>
								</template>
							</template>
							<template v-else> ---------- </template>
						</v-card-text>
					</v-card>
				</v-col>
			</v-row>
		</v-container>
		<absoluteCart :isBtn="true" />
	</div>
</template>

<script>
import absoluteCart from "@/components/shopingCart/absoluteCart";
import { mapGetters } from "vuex";

export default {
	components: { absoluteCart },
	watchQuery: ["page"],
	key: to => to.fullPath,
	head() {
		return {
			title: Object.keys(this.pageData)
				? this.pageData.title
				: this.$route.params.pathMatch,
		};
	},
	data() {
		return {
			pageData: {},
		};
	},
	mounted() {
		this.getTextFields();
	},
	methods: {
		getTextFields() {
			this.$axios
				.$post("getTextFields", {
					fieldName: this.$route.params.pathMatch,
					lang: this.$i18n.locale,
				})
				.then(res => {
					return (this.pageData = res);
				})
				.catch(err => console.error(err));
		}, // getTextFields()
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
		}),
		pageDataComputed() {
			let $result = Object.keys(this.pageData).length
				? this.pageData
				: false;
			return $result;
		},
	},
};
</script>
