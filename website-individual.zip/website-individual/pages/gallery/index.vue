<template>
	<v-container>
		<v-row>
			<v-col cols="12">
				<Carousel :items="last_photos" />
			</v-col>
			<v-col
				cols="12"
				md="6"
				v-for="gallery in galleries"
				:key="gallery.id"
			>
				<CategoriesLists :item="gallery" />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import Carousel from "@/components/gallery/Carousel";
import CategoriesLists from "@/components/gallery/CategoriesLists";
import { gallery } from "@/api";
import { mapGetters } from "vuex";

export default {
	name: "gallery_index",
	components: {
		Carousel,
		CategoriesLists,
	},
	async asyncData({ app, store, redirect }) {
		const has_gallery = store.getters["siteSetting/getHasGallery"];
		const default_lang = store.getters["siteSetting/getDefaultLang"];
		let last_photos = [];
		let galleries = [];
		let data = {
			shop_id: store.getters["siteSetting/getMainShopId"],
			page: 1,
		};

		if (!has_gallery) {
			return redirect(app.localePath("index", default_lang));
		} else {
			await app.$axios
				.post(gallery.galleryCategories, data)
				.then(res => {
					const { data } = res;

					last_photos = data.last_photos;
					galleries = data.galleries;
				})
				.catch(err => console.error({ err }));
		}

		return { last_photos, galleries };
	},
};
</script>
