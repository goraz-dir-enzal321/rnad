<template>
	<v-container>
		<v-row>
			<v-col cols="12">
				<v-card flat class="pa-3">
					<v-card-title
						class="pt-0 text-center d-block font-size-text-h4"
						v-text="pageTitle"
					/>
					<v-divider class="red darken-3" />
					<v-row>
						<v-col
							v-for="(photo, index) in photos"
							:key="photo.id"
							cols="12"
							md="3"
							lg="2"
						>
							<v-dialog
								v-model="dialog['dialog_' + index]"
								max-width="500"
								content-class="elevation-0"
							>
								<template v-slot:activator="{ on }">
									<v-card
										flat
										class="pa-1 text-center"
										v-on="on"
									>
										<v-hover v-slot:default="{ hover }">
											<v-sheet
												:elevation="hover ? '4' : '2'"
												class="transition-swing"
											>
												<v-img
													:src="
														imageLink(
															photo.thumbnail
														)
													"
													class="mx-auto"
												/>
											</v-sheet>
										</v-hover>
										<v-card-text
											v-text="photo.description"
											class="pb-0"
										/>
									</v-card>
								</template>
								<v-card
									flat
									class="pa-1 text-center transparent"
								>
									<v-img
										:src="imageLink(photo.img)"
										class="mx-auto"
									/>
									<v-card-title
										v-text="photo.description"
										class="text-center d-block"
									/>
								</v-card>
							</v-dialog>
						</v-col>
					</v-row>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
import { gallery } from "@/api";

export default {
	async asyncData({ app, store, redirect, params }) {
		const has_gallery = store.getters["siteSetting/getHasGallery"];
		const default_lang = store.getters["siteSetting/getDefaultLang"];
		let photos = [];
		let pageTitle = "";
		let dialog = [];
		let data = {
			shop_id: store.getters["siteSetting/getMainShopId"],
			category_id: params.id,
			page: 1,
		};

		if (!has_gallery) {
			return redirect(app.localePath("index", default_lang));
		} else {
			await app.$axios
				.post(gallery.galleryList, data)
				.then(res => {
					const { data } = res;

					photos = data.photos;

					pageTitle = photos[0].category.name;
				})
				.catch(err => redirect(app.localePath("index", default_lang)));
		}

		return { photos, pageTitle, dialog };
	},
	...mapGetters({
		getDomain: "siteSetting/getDomain",
	}),
	methods: {
		imageLink(link) {
			let $link = "/images/section-bg.jpg";

			if (link)
				$link =
					this.$store.getters["siteSetting/getDomain"] + "/" + link;

			return $link;
		},
	},
};
</script>
