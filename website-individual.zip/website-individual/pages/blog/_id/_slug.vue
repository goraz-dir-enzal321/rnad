<template>
	<v-container fluid class="pt-0">
		<v-row class="flex-row justify-space-between white pt-3">
			<v-col md="8">
				<v-card elevation="0">
					<v-img
						:src="`${getDomain}${blogData.image[0].img}`"
						tile
						class="mb-3"
						:contain="true"
					>
						<template v-slot:placeholder>
							<v-row
								class="fill-height ma-0 grey"
								align="center"
								justify="center"
							>
								<v-progress-circular
									indeterminate
									color="grey lighten-5"
								/>
							</v-row>
						</template>
					</v-img>
					<v-card-subtitle class="py-0">
						<v-row justify="space-between">
							<span
								>{{ blogData.creator.fname }}
								{{ blogData.creator.lname }}</span
							>
							<span>{{
								getLocaleDate(blogData.created_at)
							}}</span>
						</v-row>
					</v-card-subtitle>
					<v-card-title>{{ blogData.title }}</v-card-title>
					<v-card-text
						class="text--primary"
						v-html="
							blogData.description
								? blogData.description
								: $t('message.text.no_description')
						"
					/>
				</v-card>
			</v-col>

			<v-col md="4">
				<blog-lists :lists="blogLists" />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { blog } from "@/api";
import { mapGetters } from "vuex";
import { utcToLocale } from "~/utils/date";
import BlogLists from "~/components/blog/BlogLists";

export default {
	name: "blog",
	components: {
		"blog-lists": BlogLists,
	},
	async asyncData({ params, $axios }) {
		let blogData = {};
		let blogLists = [];
		await $axios
			.$post(blog.blogDetail, { blog_id: params.id })
			.then(res => {
				blogData = res.data;
				blogLists = res.list;
			})
			.catch(err => console.error(res));
		return { blogData, blogLists };
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
	methods: {
		getLocaleDate(utcTime) {
			let locale = this.$i18n.locale;
			if (locale == "fa") {
				return utcToLocale(utcTime, "jYYYY/jM/jD", locale);
			}
			return utcToLocale(utcTime, "YYYY/MM/DD", locale);
		},
	},
};
</script>
