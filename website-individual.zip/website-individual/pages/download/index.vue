<template>
	<v-row class="mx-0 my-4">
		<template v-if="getLoadingDownload">
			<loadingDownload v-for="index in 2" :key="index" />
		</template>

		<template
			v-else-if="
				getDataAppDownload &&
				getDataAppDownload.markets &&
				getDataAppDownload.settings
			"
		>
			<v-col
				:class="
					$device.isAndroid && $device.isWindows
						? 'order-0'
						: 'order-1'
				"
				cols="12"
				sm="6"
				v-if="
					getDataAppDownload.markets.android &&
					getDataAppDownload.markets.android.length
				"
			>
				<downloadSection
					:market="getDataAppDownload.markets.android"
					:color="
						getDataAppDownload.settings.colors
							? getDataAppDownload.settings.colors
							: 'grey'
					"
					type="android"
				/>
			</v-col>
			<v-col
				:class="
					$device.isIos && $device.isMacOS ? 'order-0' : 'order-1'
				"
				cols="12"
				sm="6"
				v-if="
					(getDataAppDownload.markets.ios &&
						getDataAppDownload.markets.ios.length) ||
					(getIsHasWebVertion && $device.isMobileOrTablet)
				"
			>
				<downloadSection
					:market="
						getDataAppDownload.markets.ios &&
						getDataAppDownload.markets.ios.length
							? getDataAppDownload.markets.ios
							: false
					"
					:color="
						getDataAppDownload.settings.colors
							? getDataAppDownload.settings.colors
							: 'grey'
					"
					type="ios"
				/>
			</v-col>
		</template>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
import downloadSection from "@/components/home/appInfo/downloadSection/index";
import loadingDownload from "@/components/home/appInfo/loadingDownload";
export default {
	components: {
		downloadSection,
		loadingDownload,
	},
	computed: {
		...mapGetters({
			getDataAppDownload: "appDownload/getDataAppDownload",
			getLoadingDownload: "appDownload/getLoadingDownload",
			getIsHasWebVertion: "appDownload/getIsHasWebVertion",
		}),
	},
	mounted() {
		if (!this.getDataAppDownload)
			this.$store.dispatch("appDownload/setDataAppDownload");
	},
};
</script>
