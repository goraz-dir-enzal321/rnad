<template>
	<div>
		<v-container>
			<v-row>
				<v-col cols="12" sm="12">
					<v-card>
						<v-img
							src="/images/head_wallpaper.jpg"
							height="160px"
							lazy-src="/images/head_wallpaper.jpg"
							gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
						>
							<v-card-title
								class="font-size-display-1 white--text align-center justify-center fill-height pa-0"
							>
								{{ $t("header.page.survey") }}
							</v-card-title>
						</v-img>
					</v-card>
				</v-col>
			</v-row>
			<v-row class>
				<v-col cols="12" sm="5" class="mx-auto">
					<v-card class="mx-auto mb-5" v-if="header">
						<v-card-text v-html="header" />
					</v-card>
					<v-card
						class="mx-auto mb-4"
						v-if="isAuth"
						:loading="loading"
					>
						<v-form @submit.prevent="saveFeedback" class="pa-3">
							<v-container>
								<v-row no-gutters>
									<v-col
										class="text--secondary text-center"
										cols="12"
									>
										<v-btn-toggle
											v-model="toggle_rate"
											background-color="white"
											light
											backg
											group
											color="blue-grey darken-2"
										>
											<v-btn color="white" value="1">
												<v-icon
													color="blue-grey darken-2"
													>mdi-emoticon-confused-outline</v-icon
												>
											</v-btn>
											<v-btn color="white" value="2">
												<v-icon
													color="blue-grey darken-2"
													>mdi-emoticon-sad-outline</v-icon
												>
											</v-btn>
											<v-btn color="white" value="3">
												<v-icon
													color="blue-grey darken-2"
													>mdi-emoticon-neutral-outline</v-icon
												>
											</v-btn>
											<v-btn color="white" value="4">
												<v-icon
													color="blue-grey darken-2"
													>mdi-emoticon-cool-outline</v-icon
												>
											</v-btn>
											<v-btn color="white" value="5">
												<v-icon
													color="blue-grey darken-2"
													>mdi-emoticon-kiss-outline</v-icon
												>
											</v-btn>
										</v-btn-toggle>
									</v-col>
								</v-row>
							</v-container>
							<v-textarea
								v-model="feedback"
								name="input-7-1"
								:label="$t('form.label.write_your_suggestion')"
								:disabled="loading"
                        outlined
							/>
							<v-btn
								block
								class="mb-3"
								:loading="loading"
								:disabled="loading"
								type="submit"
								:color="
									getBtnStyle && getBtnStyle.bg
										? getBtnStyle.bg
										: Boolean(getSiteColor)
										? getSiteColor.secondColor
										: 'grey'
								"
								:style="[
									{
										color:
											getBtnStyle && getBtnStyle.text
												? getBtnStyle.text
												: '',
									},
								]"
								>{{ $t("button.submit") }}</v-btn
							>
						</v-form>
					</v-card>
					<template v-else-if="!isAuth">
						<v-hover v-slot:default="{ hover }">
							<v-card
								v-on:click="
									$store.commit('loginCard/SET_STATUS', 1)
								"
								class="mx-auto mb-5"
								color="cyan darken-4"
								:elevation="hover ? 12 : 2"
							>
								<v-card-text>
									<div class="white--text">
										{{
											$t(
												"label.please_sign_In_to_comment"
											)
										}}
									</div>
								</v-card-text>
							</v-card>
						</v-hover>
					</template>
					<template v-if="feedbacksComputed.length">
						<v-card
							class="mx-auto mb-4"
							v-for="feedback in feedbacksComputed"
							:key="`feedback-${feedback.id}`"
						>
							<v-list-item three-line>
								<v-list-item-content>
									<div class="overline">
										{{ feedback.created_at }}
									</div>
									<v-list-item-title
										class="font-size-subtitle-1 mb-1"
										v-if="feedback.user"
										>{{
											feedback.user.fullName
										}}</v-list-item-title
									>
									<v-list-item-subtitle>
										{{ feedback.content }}
										<v-card
											color="teal lighten-5"
											class="my-3"
											v-if="feedback.responder"
										>
											<v-list-item>
												<v-list-item-content>
													<v-list-item-title
														class="font-size-subtitle-1 mb-1"
														v-if="
															feedback.responder
														"
														>{{
															feedback.responder
																.responderName
														}}</v-list-item-title
													>
													<v-list-item-subtitle>{{
														feedback.response
													}}</v-list-item-subtitle>
												</v-list-item-content>
											</v-list-item>
										</v-card>
									</v-list-item-subtitle>
								</v-list-item-content>
							</v-list-item>
						</v-card>
						<v-btn
							@click="getFeedbacks"
							block
							:loading="loading"
							:disabled="loading"
							v-if="hasMorePage"
							:color="
								getBtnStyle && getBtnStyle.bg
									? getBtnStyle.bg
									: Boolean(getSiteColor)
									? getSiteColor.secondColor
									: 'grey'
							"
							:style="[
								{
									color:
										getBtnStyle && getBtnStyle.text
											? getBtnStyle.text
											: '',
								},
							]"
							>{{ $t("button.more") }}</v-btn
						>
					</template>
				</v-col>
			</v-row>
		</v-container>
		<absoluteCart :isBtn="true" />
		<v-snackbar
			v-model="isShowSnackbar"
			:color="snackbarSuccess ? 'cyan darken-2' : 'red accent-4'"
		>
			{{ snackbarText }}
			<v-btn icon text @click="isShowSnackbar = false">
				<v-icon>mdi-close</v-icon>
			</v-btn>
		</v-snackbar>
	</div>
</template>

<script>
import absoluteCart from "~/components/shopingCart/absoluteCart";
import { survey } from "~/api";
import { mapGetters } from "vuex";
export default {
	name: "survey",
	components: { absoluteCart },
	data() {
		return {
			feedback: null,
			feedbacks: [],
			loading: false,
			snackbarSuccess: true,
			isShowSnackbar: false,
			snackbarText: "",
			page: 0,
			hasMorePage: true,
			header: null,
			toggle_rate: null,
		};
	},
	mounted() {
		this.getFeedbacks();
	},
	computed: {
		...mapGetters({
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			isAuth: "isAuth",
			getToken: "getToken",
		}),
		feedbacksComputed: {
			get() {
				return this.feedbacks;
			},
		},
	},
	methods: {
		saveFeedback() {
			this.loading = true;
			const data = {
				token: this.getToken,
				lang: this.$i18n.locale,
				text: this.feedback,
				rate: this.toggle_rate,
			};
			if (this.feedback && this.toggle_rate) {
				// survey.saveFeedback ==> site-api/saveFeedback/
				this.$axios
					.$post(survey.saveFeedback, data)
					.then(res => {
						this.isShowSnackbar = true;
						this.snackbarSuccess = true;
						this.snackbarText = `${res.message}`;
						this.feedback = null;
					})
					.catch(err => {
						this.isShowSnackbar = true;
						this.snackbarSuccess = false;
						this.snackbarText = `${res.message}`;
						console.error(err);
					})
					.finally(() => (this.loading = false));
			} else {
				this.isShowSnackbar = true;
				this.snackbarSuccess = false;
				this.snackbarText = this.$t("label.fill_out_form");
				this.loading = false;
			}
		}, // saveFeedback()
		getFeedbacks() {
			this.loading = true;
			const data = {
				// token: this.$store.state.auth.access_token,
				lang: this.$i18n.locale,
				page: this.page,
			};
			this.$axios
				.$post("getFeedback", data)
				.then(res => {
					if (res) {
						if (res.state && res.data.length) {
							this.feedback = null;
							++this.page;
							this.feedbacks = res.data;
							// res.data.map(comment => {
							//   return this.commentsComputed = comment;
							// });
						} else {
							this.hasMorePage = false;
						}

						if (res.header) {
							this.header = res.header;
						}
					} // if(res)
				})
				.catch(err => {
					this.isShowSnackbar = true;
					this.snackbarSuccess = false;
					this.snackbarText = err.message;
					console.error(err.message);
				})
				.finally(res => {
					this.loading = false;
				});
		}, // getFeedbacks()
		/*reverseItems(val) {
      // let s = val.split(' ');
      // console.log(typeof s);
      let s = '123-1-23';
      console.log(s.split("").reverse());
        // return val.slice().reverse();
    }*/
	},
};
</script>
