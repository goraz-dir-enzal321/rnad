<template>
	<div>
		<search />
		<!--*(header) Slider & banner & video big & video mini -->
		<v-container
			class="pa-0"
			v-if="
				Object.keys(getFirstData).length &&
				getSettingLength &&
				getTheme &&
				(getTheme.type == null ||
					getTheme.type == 'DEFAULT' ||
					getTheme.type == 'TOP_VIDEO' ||
					(getTheme.type == 'TOP_LARGE_SLIDER' &&
						Object.keys(getFirstData.header)))
			"
		>
			<v-row class="mx-0">
				<!--* video big -->
				<template
					v-if="
						getTheme.type == null ||
						getTheme.type == 'DEFAULT' ||
						getTheme.type == 'TOP_VIDEO'
					"
				>
					<v-col cols="12">
						<VideoSection />
					</v-col>
					<v-col cols="12" md="8">
						<HomeSlider />
					</v-col>
					<v-col cols="12" md="4">
						<nuxt-link nuxt :to="localePath('download')">
							<v-img
								height="300px"
								:contain="true"
								:src="
									Boolean(
										getFirstData.setting[0].main_page_image
									)
										? `${getDomain}storage/${getFirstData.setting[0].main_page_image}`
										: '/images/app.jpg'
								"
								draggable="false"
							>
								<template v-slot:placeholder>
									<v-row
										class="fill-height ma-0 white"
										align="center"
										justify="center"
									>
										<v-progress-circular
											indeterminate
											color="grey"
										/>
									</v-row>
								</template>
							</v-img>
						</nuxt-link>
					</v-col>
				</template>
				<!--*/ video big -->
				<!--* Slider & banner & video mini -->
				<template v-if="getTheme.type == 'TOP_LARGE_SLIDER'">
					<!--* Slider -->
					<v-col cols="12" v-if="getFirstData.header.SLIDER">
						<HomeSlider />
					</v-col>
					<!--*/ Slider -->
					<!--* video mini -->
					<v-col
						cols="12"
						sm="6"
						class="pt-0"
						v-if="
							Boolean(getFirstData.header.VIDEO) &&
							getFirstData.header.VIDEO.length
						"
					>
						<VideoSection />
					</v-col>
					<!--*/ video mini -->
					<!--* banner -->
					<v-col
						cols="12"
						sm="6"
						v-if="
							Boolean(getFirstData.header.BANNER) &&
							Boolean(getFirstData.header.BANNER.length)
						"
					>
						<a
							:href="
								getFirstData.header.BANNER[0].link
									? getFirstData.header.BANNER[0].link
									: 'javascript:void(0)'
							"
							:target="
								getFirstData.header.BANNER[0].link
									? '_blank'
									: '_self'
							"
						>
							<!-- :aspect-ratio="(getTheme.type == 'TOP_LARGE_SLIDER') ? 18/9 : 19/5"-->
							<!-- :min-height="$device.isDesktop ? '350px' : '100px'"-->
							<v-img
								:contain="false"
								draggable="false"
								:height="300"
								:src="
									getFirstData.header.BANNER[0].img
										? getDomain +
										  'storage/' +
										  getFirstData.header.BANNER[0].img
										: ''
								"
							>
								<template v-slot:placeholder>
									<v-row
										class="fill-height ma-0 white"
										align="center"
										justify="center"
									>
										<v-progress-circular
											indeterminate
											color="grey"
										/>
									</v-row>
								</template>
							</v-img>
						</a>
					</v-col>
					<!--*/ banner -->
				</template>
				<!--*/ Slider & banner & video mini-->
			</v-row>
		</v-container>
		<!--*/(header) Slider & banner & video mini -->
		<!--*Offer -->
		<offer />
		<!--*/Offer -->
		<!-- start ordring 2 -->
		<StartOrdering2 />
		<!-- start ordring 2 -->
		<!--* section us -->
		<div
			v-if=" 
				Object.keys(getFirstData).length &&
				Boolean(Object.keys(getFirstData.header).length)
			"
		>
			<template
				v-if="
					getFirstData.header.SHORT_TEXT &&
					getFirstData.header.SHORT_TEXT.length >= 1
				"
			>
				<ContentBox :sectionData="getFirstData.header.SHORT_TEXT[0]" />
			</template>
			<ContentCircles
				v-if="
					Boolean(getFirstData.header.CIRCLE_SLIDER) &&
					getFirstData.header.CIRCLE_SLIDER.length
				"
				:sliderData="getFirstData.header.CIRCLE_SLIDER"
			/>
			<template
				v-if="
					getFirstData.header.SHORT_TEXT &&
					getFirstData.header.SHORT_TEXT.length == 2
				"
			>
				<ContentBox :sectionData="getFirstData.header.SHORT_TEXT[1]" />
			</template>
		</div>
		<client-only>
			<BlogSection
				v-if="
					getSettingLength &&
					getHasBlog == 1 &&
					getBlogSettings &&
					getBlogSettings.show_event == 1
				"
			/>
			<Gallery
				v-if="
					getSettingLength &&
					getHasGallery == 1 &&
					getGallerySettings &&
					getGallerySettings.show_gallery == 1
				"
			/>
		</client-only>
		<!--*/ section us -->

		<StartOrdering
			v-if="
				Object.keys(getFirstData).length &&
				Boolean(Object.keys(getFirstData.header).length) &&
				Boolean(getFirstData.header.START_ORDER) &&
				getFirstData.shops.length == 1
			"
			:startOrderingData="getFirstData.header.START_ORDER[0]"
		/>
		<!--* Swiper Section Categories-->
		<SwiperBranch />
		<ChildTest
			:serverData="getCategoriesChildren"
			:isShowDialog="getIsShowCategoriesModal"
			v-if="getIsShowCategoriesModal"
		/>
		<!--*/ Swiper Section Categories -->
		<!-- section cards description / start ordring 1 -->
		<v-container
			class="pa-0"
			:style="[
				productFilterComputed.length
					? ''
					: 'height: 0; overflow: hidden; padding: 0;',
			]"
			id="main-section"
		>
			<v-row
				v-resize="onResize"
				class="ma-0 mb-2"
				v-if="
					Object.keys(getFirstData).length &&
					productFilterComputed &&
					Boolean(getBranchSelectedData)
				"
			>
				<!--* card of description & filter of top infos & section start ordring 1-->
				<v-col
					cols="12"
					md="8"
					class="py-0"
					:class="$device.isMobile ? 'order-1' : 'order-0'"
				>
					<v-row>
						<!-- filter of top infos (search and select branch)-->
						<template v-if="Boolean(getBranchSelectedData)">
							<v-sheet
								class="col col-12 col-sm px-2 py-3"
								color="transparent"
								single-line
							>
								<v-text-field
									dense
									v-model="search"
									hide-details
									solo
									:label="$t('form.label.search')"
									prepend-inner-icon="mdi-magnify"
									class="font-size-14"
								/>
							</v-sheet>
							<v-sheet
								class="col col-12 col-sm px-2 py-3"
								color="transparent"
								single-line
								v-if="
									getSelectedChildren &&
									getSelectedChildren.length
								"
								v-bind:style="[
									{ right: $vuetify.rtl ? '0' : '' },
								]"
							>
								<v-sheet
									color="grey darken-2"
									style="position: relative;"
								>
									<div
										class="d-flex align-center"
										style="position: relative;"
									>
										<v-col class="pa-1">
											<div class="d-flex flex-row">
												<div
													v-for="(item,
													index) in getSelectedChildren"
													:key="index"
												>
													<v-btn
														text
														@click="
															changeCategory(item)
														"
														small
														class="px-0 white--text"
														>{{ item.name }}</v-btn
													>
													<span
														v-if="
															getSelectedChildren.length >
															index + 1
														"
													>
														<v-icon color="white">
															mdi-chevron-{{
																$vuetify.rtl
																	? "left"
																	: "right"
															}}
														</v-icon>
													</span>
												</div>
											</div>
										</v-col>
										<v-btn
											@click="
												changeCategory(
													getSelectedChildren[
														getSelectedChildren.length -
															1
													]
												)
											"
											color="white info--text"
											small
											class="mx-1"
											rounded
											absolute
											:right="!$vuetify.rtl"
											:left="$vuetify.rtl"
											:style="[
												$vuetify.rtl
													? 'left: 2px'
													: 'right: 2px',
											]"
											>{{ $t("button.change") }}</v-btn
										>
									</div>
								</v-sheet>
							</v-sheet>
						</template>

						<!--*/ filter of top infos (search and select branch)-->
						<!-- card of description & section start ordring 1 -->
						<template v-if="productFilterComputed">
							<v-row
								class="ma-0 pa-0 col col-12"
								v-if="productFilterComputed.length"
							>
								<v-col
									cols="12"
									sm="4"
									md="6"
									lg="4"
									xl="3"
									class="pa-2"
									v-for="product in productFilterComputed"
									:key="product.id"
								>
									<ProductCard
										:isOpenBranch="
											$store.getters[
												'branch/getIsOpenBranch'
											]
										"
										:customData="false"
										:product="product"
										btnType="MENU"
									/>
								</v-col>
							</v-row>
							<v-col cols="12" v-else-if="getBranchSelectedData">
								<v-img
									src="images/not-found.jpeg"
									lazy-src="images/not-found.jpeg"
									width="300"
									class="mx-auto rounded-lg"
								>
									<template v-slot:placeholder>
										<v-row
											class="fill-height ma-0 grey"
											align="center"
											justify="center"
										>
											<v-progress-circular
												indeterminate
												color="grey lighten-5"
											/>
										</v-row>
									</template>
								</v-img>
							</v-col>
						</template>
						<!--*/ card of description & section start ordring 1 -->
					</v-row>
				</v-col>
				<!--/* card of description & filter of top infos -->
				<v-col
					class="py-0"
					cols="12"
					md="4"
					:class="$device.isMobile ? 'order-0' : 'order-1'"
				>
					<v-expansion-panels
						multiple
						:value="[0]"
						:readonly="false"
						class="mb-3"
						v-if="
							hasManyProductComputed &&
							getBranchSelectedData &&
							categoriesSelected.length
						"
					>
						<v-expansion-panel>
							<v-expansion-panel-header>
								{{ $t("header.text.category") }}
							</v-expansion-panel-header>
							<v-expansion-panel-content>
								<v-list dense>
									<v-list-item-group
										multiple
										v-model="categoriesSelected"
									>
										<template
											v-for="category in getBranchSelectedData"
										>
											<v-divider
												v-if="!category"
												:key="`divider-${category.name}`"
											/>
											<template
												v-for="translate in category.translations"
											>
												<v-list-item
													:key="translate.id"
													:value="category.id"
													v-if="
														translate.locale ===
														$i18n.locale
													"
												>
													<template
														v-slot:default="{
															active,
															toggle,
														}"
													>
														<v-list-item-content>
															<v-list-item-title
																v-text="
																	translate.title
																"
															/>
														</v-list-item-content>
														<v-list-item-action>
															<v-checkbox
																:input-value="
																	active
																"
																:true-value="
																	category.id
																"
																color="deep-purple accent-4"
																@click="toggle"
															/>
														</v-list-item-action>
													</template>
												</v-list-item>
											</template>
										</template>
									</v-list-item-group>
								</v-list>
							</v-expansion-panel-content>
						</v-expansion-panel>
					</v-expansion-panels>
					<v-sheet
						color="transparent"
						:sticky="true"
						single-line
						width="100%"
						style="top: 71px;"
						class="pos-sticky"
						v-if="
							Boolean(getBranchSelectedData) && $device.isDesktop
						"
					>
						<Cart :isBtn="true" :isMenu="true" />
					</v-sheet>
				</v-col>
			</v-row>
		</v-container>
		<!-- cards description aplication / start ordring 1 -->
		<AppInfo v-if="Boolean(Object.keys(getFirstData).length)" />
		<!-- :appDetails="getFirstData.header.APP_INFO" -->
		<v-snackbar v-model="isShowSnackbar" color="cyan darken-2">
			{{ snackbarText }}
			<v-btn icon text @click="isShowSnackbar = false">
				<v-icon>mdi-close</v-icon>
			</v-btn>
		</v-snackbar>
		<absoluteCart :isBtn="true" v-if="$device.isMobile" />
	</div>
</template>
<script>
import { mapGetters } from "vuex";
import * as moment from "moment";
import VideoSection from "~/components/home/VideoSection";
import HomeSlider from "~/components/home/HomeSlider";
import SwiperBranch from "~/components/home/SwiperBranch";
import Categories from "~/components/home/Categories";

import ContentBox from "~/components/home/contentSections/ContentBox.vue";
import ContentCircles from "~/components/home/contentSections/ContentCircles.vue";
import StartOrdering from "~/components/home/startOrdering/startOrdering_t1/index.vue";
import StartOrdering2 from "~/components/home/startOrdering/startOrdering_t2/index.vue";
import AppInfo from "~/components/home/appInfo/index.vue";
import absoluteCart from "~/components/shopingCart/absoluteCart";
import ProductCard from "~/components/ProductCard";
import Cart from "~/components/shopingCart/Cart";
import ChildTest from "~/components/home/childtest";
import BlogSection from "~/components/home/BlogSection";
import Gallery from "~/components/home/Gallery";
import search from "~/components/home/search";
import offer from "~/components/home/offer";

export default {
	name: "indexPage",
	// middleware: "i18n",
	components: {
		absoluteCart,
		Cart,
		ProductCard,
		ContentBox,
		ContentCircles,
		VideoSection,
		HomeSlider,
		SwiperBranch,
		Categories,
		StartOrdering,
		StartOrdering2,
		AppInfo,
		ChildTest,
		Gallery,
		BlogSection,
		search,
		offer,
	},
	data() {
		return {
			categoriesSelected: [],
			isShowSnackbar: false,
			snackbarText: "",
			loading: false,
			hasAddBtn: false,
			isOpenStore: true,
			categories: null,
			hasManyProduct: null,
			search: "",
			filter: [],
			windowSize: false,
			type: "selector",
			selector: "#main-section",
			duration: 1000,
			offset: 70,
			easing: "easeInOutCubic",
			root: {
				text: "Root Folder",
				leaf: false,
				expanded: true,
				is_root: true,
				first: true,
				child: [],
			},
		};
	},
	mounted() {
		this.$nextTick(() => {
			this.$nuxt.$loading.start();
			setTimeout(() => this.$nuxt.$loading.finish(), 2000);
		});
		this.onResize();
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getCartLists: "shop/cart",
			getAllPrices: "shop/allPrice",
			getAllDiscount: "shop/discounts",
			getPayablePrice: "shop/getPayablePrice",
			getShopIdInStore: "shop/getShopIdInStore",
			cartCount: "shop/cartCount",
			isAuth: "isAuth",
			getDomain: "siteSetting/getDomain",
			getTheme: "siteSetting/getTheme",
			getSettingLength: "siteSetting/getSettingLength",
			getHasGallery: "siteSetting/getHasGallery",
			getHasBlog: "siteSetting/getHasBlog",
			getGallerySettings: "siteSetting/getGallerySettings",
			getBlogSettings: "siteSetting/getBlogSettings",
			getBranchSelectedData: "branch/getBranchSelectedData",
			getCategoriesChildren: "branch/getCategoriesChildren",
			getSelectedChildren: "categories/getSelectedChildren",
			getIsShowCategoriesModal: "categories/getIsShowCategoriesModal",
		}),
		productFilterComputed: {
			get() {
				this.filter = [];
				let contain = [];
				let pushedProduct = false;
				if (
					Object.keys(this.getFirstData).length &&
					this.getFirstData.shops &&
					this.getFirstData.shops.length == 1
				) {
					let $branch = this.getFirstData.shops[0];
					this.btnTypeCounterComputed =
						$branch.has_btn_counter_product;
					this.hasManyProductComputed = $branch.has_many_product;
					try {
						let userLocaleUtcTime = moment()
							.utc()
							.format("HH:mm:ss");
						this.isOpenStore =
							($branch.am_time_start <= userLocaleUtcTime &&
								userLocaleUtcTime <= $branch.am_time_end) ||
							($branch.pm_time_start <= userLocaleUtcTime &&
								userLocaleUtcTime <= $branch.pm_time_end);
					} catch (e) {
						console.error("catch ", e);
					}
				}
				if (this.getBranchSelectedData) {
					this.getBranchSelectedData.map(category => {
						if (!this.categoriesSelected.length) {
							if (category.products.length) {
								category.products.map(product => {
									pushedProduct = false;
									if (
										product.translations &&
										!pushedProduct
									) {
										return product.translations.map(
											translate => {
												if (
													translate.title.indexOf(
														this.search
													) !== -1 &&
													!pushedProduct
												) {
													pushedProduct = true;
													product.branch_id =
														category.shop_id;
													contain.push(product);
													this.filter.push(product);
												}
											}
										);
									}
								});
							}
						} //(!this.categoriesSelected.length)
						else {
							this.categoriesSelected.map(catSelected => {
								if (catSelected == category.id) {
									if (category.products.length) {
										category.products.map(product => {
											pushedProduct = false;
											if (
												product.translations &&
												!pushedProduct
											) {
												return product.translations.map(
													translate => {
														if (
															translate.title.indexOf(
																this.search
															) !== -1 &&
															!pushedProduct
														) {
															pushedProduct = true;
															product.branch_id =
																category.shop_id;
															contain.push(
																product
															);
															this.filter.push(
																product
															);
														}
													}
												);
											}
										});
									} // if(category.products.length)
								}
							}); // this.categoriesSelected.map(() => {})
						} // else
					});
				}
				return this.filter;
			},
		},
		testRootChildren: {
			get() {
				this.root.child = this.getCategoriesChildren;
				return this.root;
			},
		},
		categoriesComputed: {
			get() {
				return this.categories;
			},
			set(categories) {
				this.categories = categories;
			},
		},
		btnTypeCounterComputed: {
			get() {
				return this.hasAddBtn;
			},
			set(hasBtnCounter) {
				this.hasAddBtn = hasBtnCounter;
			},
		},
		hasManyProductComputed: {
			get() {
				return this.hasManyProduct;
			},
			set(hasManyProduct) {
				this.hasManyProduct = hasManyProduct;
			},
		},
		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},
		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	methods: {
		onResize() {
			this.windowSize = window.innerWidth < 960;
		},
		openLoginCard() {
			if (this.isAuth) {
				this.$store.commit("loginCard/SET_STATUS", 4);
			} else this.$store.commit("loginCard/SET_STATUS", 1);
		}, // openLoginCard
		getSlugMethod(product) {
			// product.translations.length ? product.translations.find(item => item.locale == this.$i18n.locale).slug : product.slug
			if (product.translations.length) {
				const $item = product.translations.find(
					item => item.locale == this.$i18n.locale
				);
				if ($item) {
					return $item.slug;
				}
			}
			return product.slug;
		},
		changeCategory(item) {
			this.$store.dispatch("categories/setSelectedBreadcrumb", {
				item,
				isStartOrdering2: false,
			});
			this.$store.commit("categories/SET_IS_SHOW_CATEGORIES_MODAL");
		},
	},
};
</script>
<style lang="scss" scoped>
.v-banner__wrapper {
	padding-right: 0 !important;
	padding-left: 0 !important;
	padding-top: 15px !important;
	padding-bottom: 0 !important;
	border: none !important;
	background-color: #fff !important;
	.v-banner__text {
		width: 100%;
	}
}

.v-expansion-panel-content__wrap {
	padding: 0;
}

.v-overflow-btn .v-input__control::before {
	height: 0 !important;
}

.icon_active-radius {
	height: 17px !important;
	width: 17px !important;
	position: absolute;
	border-radius: 19px;

	&.active {
		border: 2px solid #00c853 !important;
	}

	&.deactive {
		border: 2px solid #ff7043 !important;
	}

	// &::before {
	//   content: '';
	//   // position: re
	//   border: 1px solid red;
	// }
}

.swiper-container {
	//  height: 200px;
	& .swiper-slide {
		height: auto !important;
		// height: 500px;
		// img {

		// }
	}
}

.swiper-button-next,
.swiper-container-rtl .swiper-button-prev {
	filter: hue-rotate(90deg) brightness(150%) contrast(10%);
}
</style>
