<template>
	<!-- Loading page -->
	<Loading v-if="getLoading" />
	<!-- Order detaile components -->
	<orderDetail v-else-if="getOrderStatus" />
	<!-- If order is ot found or order is null -->
	<div
		v-else-if="getOrderStatus == false"
		class="d-flex h-100 align-center justify-center"
	>
		<v-alert
			:width="$device.isMobile ? '90%' : '75%'"
			type="error"
			icon="mdi-comment-alert"
		>
			{{ $t("orderDetails.labels.orderNull") }}
		</v-alert>
	</div>
</template>

<script>
import { mapGetters } from "vuex";

import orderDetail from "@/components/orderDetails";
import Loading from "@/components/orderDetails/Loading";
export default {
	components: {
		orderDetail,
		Loading,
	},
	computed: {
		...mapGetters({
			getLoading: "orderDetails/getLoading",
			getOrderStatus: "orderDetails/getOrderStatus",
		}),
	},
	async mounted() {
		//Get Api order details and save in store
		await this.$store.dispatch(
			"orderDetails/getApiOrderDetail",
			this.$route.params.id
		);
	},
};
</script>
