import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _45ef7294 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _77b1b29c = () => interopDefault(import('..\\pages\\blog\\index.vue' /* webpackChunkName: "pages/blog/index" */))
const _26d4e5a0 = () => interopDefault(import('..\\pages\\contactUs.vue' /* webpackChunkName: "pages/contactUs" */))
const _28c485e8 = () => interopDefault(import('..\\pages\\download\\index.vue' /* webpackChunkName: "pages/download/index" */))
const _488d9b4a = () => interopDefault(import('..\\pages\\events\\index.vue' /* webpackChunkName: "pages/events/index" */))
const _22e0676e = () => interopDefault(import('..\\pages\\gallery\\index.vue' /* webpackChunkName: "pages/gallery/index" */))
const _0809161c = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _14a89b0a = () => interopDefault(import('..\\pages\\invitation2.vue' /* webpackChunkName: "pages/invitation2" */))
const _24bda450 = () => interopDefault(import('..\\pages\\navbartest.vue' /* webpackChunkName: "pages/navbartest" */))
const _4f48e11c = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _475e48b7 = () => interopDefault(import('..\\pages\\profile\\index.vue' /* webpackChunkName: "pages/profile/index" */))
const _3f078e6c = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _25ead208 = () => interopDefault(import('..\\pages\\survey.vue' /* webpackChunkName: "pages/survey" */))
const _f55af9d6 = () => interopDefault(import('..\\pages\\vipMembership.vue' /* webpackChunkName: "pages/vipMembership" */))
const _fb9e0fe2 = () => interopDefault(import('..\\pages\\events\\_slug\\index.vue' /* webpackChunkName: "pages/events/_slug/index" */))
const _23d76403 = () => interopDefault(import('..\\pages\\invitation\\_id.vue' /* webpackChunkName: "pages/invitation/_id" */))
const _3923bc69 = () => interopDefault(import('..\\pages\\product\\_slug.vue' /* webpackChunkName: "pages/product/_slug" */))
const _797e3740 = () => interopDefault(import('..\\pages\\blog\\_id\\_slug.vue' /* webpackChunkName: "pages/blog/_id/_slug" */))
const _271eb924 = () => interopDefault(import('..\\pages\\gallery\\_id\\_slug.vue' /* webpackChunkName: "pages/gallery/_id/_slug" */))
const _731cec32 = () => interopDefault(import('..\\pages\\page\\_.vue' /* webpackChunkName: "pages/page/_" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/ar",
    component: _45ef7294,
    name: "index___ar"
  }, {
    path: "/en",
    component: _45ef7294,
    name: "index___en"
  }, {
    path: "/fa",
    component: _45ef7294,
    name: "index___fa"
  }, {
    path: "/fr",
    component: _45ef7294,
    name: "index___fr"
  }, {
    path: "/ar/blog",
    component: _77b1b29c,
    name: "blog___ar"
  }, {
    path: "/ar/contactUs",
    component: _26d4e5a0,
    name: "contactUs___ar"
  }, {
    path: "/ar/download",
    component: _28c485e8,
    name: "download___ar"
  }, {
    path: "/ar/events",
    component: _488d9b4a,
    name: "events___ar"
  }, {
    path: "/ar/gallery",
    component: _22e0676e,
    name: "gallery___ar"
  }, {
    path: "/ar/inspire",
    component: _0809161c,
    name: "inspire___ar"
  }, {
    path: "/ar/invitation2",
    component: _14a89b0a,
    name: "invitation2___ar"
  }, {
    path: "/ar/navbartest",
    component: _24bda450,
    name: "navbartest___ar"
  }, {
    path: "/ar/order",
    component: _4f48e11c,
    name: "order___ar"
  }, {
    path: "/ar/profile",
    component: _475e48b7,
    name: "profile___ar"
  }, {
    path: "/ar/search",
    component: _3f078e6c,
    name: "search___ar"
  }, {
    path: "/ar/survey",
    component: _25ead208,
    name: "survey___ar"
  }, {
    path: "/ar/vipMembership",
    component: _f55af9d6,
    name: "vipMembership___ar"
  }, {
    path: "/en/blog",
    component: _77b1b29c,
    name: "blog___en"
  }, {
    path: "/en/contactUs",
    component: _26d4e5a0,
    name: "contactUs___en"
  }, {
    path: "/en/download",
    component: _28c485e8,
    name: "download___en"
  }, {
    path: "/en/events",
    component: _488d9b4a,
    name: "events___en"
  }, {
    path: "/en/gallery",
    component: _22e0676e,
    name: "gallery___en"
  }, {
    path: "/en/inspire",
    component: _0809161c,
    name: "inspire___en"
  }, {
    path: "/en/invitation2",
    component: _14a89b0a,
    name: "invitation2___en"
  }, {
    path: "/en/navbartest",
    component: _24bda450,
    name: "navbartest___en"
  }, {
    path: "/en/order",
    component: _4f48e11c,
    name: "order___en"
  }, {
    path: "/en/profile",
    component: _475e48b7,
    name: "profile___en"
  }, {
    path: "/en/search",
    component: _3f078e6c,
    name: "search___en"
  }, {
    path: "/en/survey",
    component: _25ead208,
    name: "survey___en"
  }, {
    path: "/en/vipMembership",
    component: _f55af9d6,
    name: "vipMembership___en"
  }, {
    path: "/fa/blog",
    component: _77b1b29c,
    name: "blog___fa"
  }, {
    path: "/fa/contactUs",
    component: _26d4e5a0,
    name: "contactUs___fa"
  }, {
    path: "/fa/download",
    component: _28c485e8,
    name: "download___fa"
  }, {
    path: "/fa/events",
    component: _488d9b4a,
    name: "events___fa"
  }, {
    path: "/fa/gallery",
    component: _22e0676e,
    name: "gallery___fa"
  }, {
    path: "/fa/inspire",
    component: _0809161c,
    name: "inspire___fa"
  }, {
    path: "/fa/invitation2",
    component: _14a89b0a,
    name: "invitation2___fa"
  }, {
    path: "/fa/navbartest",
    component: _24bda450,
    name: "navbartest___fa"
  }, {
    path: "/fa/order",
    component: _4f48e11c,
    name: "order___fa"
  }, {
    path: "/fa/profile",
    component: _475e48b7,
    name: "profile___fa"
  }, {
    path: "/fa/search",
    component: _3f078e6c,
    name: "search___fa"
  }, {
    path: "/fa/survey",
    component: _25ead208,
    name: "survey___fa"
  }, {
    path: "/fa/vipMembership",
    component: _f55af9d6,
    name: "vipMembership___fa"
  }, {
    path: "/fr/blog",
    component: _77b1b29c,
    name: "blog___fr"
  }, {
    path: "/fr/contactUs",
    component: _26d4e5a0,
    name: "contactUs___fr"
  }, {
    path: "/fr/download",
    component: _28c485e8,
    name: "download___fr"
  }, {
    path: "/fr/events",
    component: _488d9b4a,
    name: "events___fr"
  }, {
    path: "/fr/gallery",
    component: _22e0676e,
    name: "gallery___fr"
  }, {
    path: "/fr/inspire",
    component: _0809161c,
    name: "inspire___fr"
  }, {
    path: "/fr/invitation2",
    component: _14a89b0a,
    name: "invitation2___fr"
  }, {
    path: "/fr/navbartest",
    component: _24bda450,
    name: "navbartest___fr"
  }, {
    path: "/fr/order",
    component: _4f48e11c,
    name: "order___fr"
  }, {
    path: "/fr/profile",
    component: _475e48b7,
    name: "profile___fr"
  }, {
    path: "/fr/search",
    component: _3f078e6c,
    name: "search___fr"
  }, {
    path: "/fr/survey",
    component: _25ead208,
    name: "survey___fr"
  }, {
    path: "/fr/vipMembership",
    component: _f55af9d6,
    name: "vipMembership___fr"
  }, {
    path: "/ar/events/:slug",
    component: _fb9e0fe2,
    name: "events-slug___ar"
  }, {
    path: "/ar/invitation/:id?",
    component: _23d76403,
    name: "invitation-id___ar"
  }, {
    path: "/ar/product/:slug?",
    component: _3923bc69,
    name: "product-slug___ar"
  }, {
    path: "/en/events/:slug",
    component: _fb9e0fe2,
    name: "events-slug___en"
  }, {
    path: "/en/invitation/:id?",
    component: _23d76403,
    name: "invitation-id___en"
  }, {
    path: "/en/product/:slug?",
    component: _3923bc69,
    name: "product-slug___en"
  }, {
    path: "/fa/events/:slug",
    component: _fb9e0fe2,
    name: "events-slug___fa"
  }, {
    path: "/fa/invitation/:id?",
    component: _23d76403,
    name: "invitation-id___fa"
  }, {
    path: "/fa/product/:slug?",
    component: _3923bc69,
    name: "product-slug___fa"
  }, {
    path: "/fr/events/:slug",
    component: _fb9e0fe2,
    name: "events-slug___fr"
  }, {
    path: "/fr/invitation/:id?",
    component: _23d76403,
    name: "invitation-id___fr"
  }, {
    path: "/fr/product/:slug?",
    component: _3923bc69,
    name: "product-slug___fr"
  }, {
    path: "/ar/blog/:id/:slug?",
    component: _797e3740,
    name: "blog-id-slug___ar"
  }, {
    path: "/ar/gallery/:id/:slug?",
    component: _271eb924,
    name: "gallery-id-slug___ar"
  }, {
    path: "/en/blog/:id/:slug?",
    component: _797e3740,
    name: "blog-id-slug___en"
  }, {
    path: "/en/gallery/:id/:slug?",
    component: _271eb924,
    name: "gallery-id-slug___en"
  }, {
    path: "/fa/blog/:id/:slug?",
    component: _797e3740,
    name: "blog-id-slug___fa"
  }, {
    path: "/fa/gallery/:id/:slug?",
    component: _271eb924,
    name: "gallery-id-slug___fa"
  }, {
    path: "/fr/blog/:id/:slug?",
    component: _797e3740,
    name: "blog-id-slug___fr"
  }, {
    path: "/fr/gallery/:id/:slug?",
    component: _271eb924,
    name: "gallery-id-slug___fr"
  }, {
    path: "/fr/page/*",
    component: _731cec32,
    name: "page-all___fr"
  }, {
    path: "/fa/page/*",
    component: _731cec32,
    name: "page-all___fa"
  }, {
    path: "/en/page/*",
    component: _731cec32,
    name: "page-all___en"
  }, {
    path: "/ar/page/*",
    component: _731cec32,
    name: "page-all___ar"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
