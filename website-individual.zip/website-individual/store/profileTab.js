export const state = () => ({
    tab: 'profile'
});
export const mutations = {
    SET_TAB(state, tab) {
        state.tab = tab
    }
}
export const getters = {
    getTab: state => {
        let tab = state.tab;
        return tab;
    }
}
export const actions = {
    setTab({ commit }, tab) {
        commit('SET_TAB', tab)
    },
}