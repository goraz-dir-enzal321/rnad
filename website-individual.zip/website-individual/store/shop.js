export const state = () => ({
	cart: [],
	vip: null,
	shopId: null,
	isOpen: false,
	hasShopIdCart: 0,
	alertAddProductToOtherBranch: {},
});
export const mutations = {
	ADD_ITEM(state, data) {
		if (data) {
			const dataProduct = data.product ? data.product : data;
			const $btnType = data.btn_status;
			let $findCartItem = state.cart.find(ci => {
				return ci.product_id == dataProduct.product_id;
			});
			let $cartItemsWithProps = state.cart.filter(
				ci => ci.product_id == dataProduct.product_id
			);
			const campareProps = (cartItem, data) => {
				let $flag = true;
				Object.keys(cartItem).map((val, key) => {
					let itemData = data[val.toString()];
					let cartItemVal = cartItem[val.toString()];

					if (cartItemVal && itemData) {
						if (
							cartItemVal.ids.toString() !==
							itemData.ids.toString()
						) {
							$flag = false;
						}
					} else {
						$flag = false;
					}
				});
				return $flag;
			};
			if ($btnType != "CHECKBOX") {
				if (!$findCartItem) {
					state.cart = [...state.cart, dataProduct];
					if ($btnType == "BTN_TXT") {
						this.commit("shop/SET_OPEN", true);
					}
				} else {
					switch ($btnType) {
						case "BTN_MULTI":
							this.commit(
								"shop/REMOVE_ITEM",
								dataProduct.product_id
							);
							break;
						case "BTN_TXT":
							this.commit(
								"shop/REMOVE_ITEM",
								dataProduct.product_id
							);
							break;
						case "NUMERIC":
							let $flag = 0;
							for (
								let index = 0;
								index < $cartItemsWithProps.length;
								index++
							) {
								const $cartItem = $cartItemsWithProps[index];
								if (
									$cartItem.product_id ==
									dataProduct.product_id
								) {
									if (
										$cartItem.properties &&
										dataProduct.properties &&
										campareProps(
											$cartItem.properties,
											dataProduct.properties
										)
									) {
										$cartItem.count++;
										$flag = 1;
									}
								} else if (index === state.cart.length - 1) {
									$flag = 1;
									state.cart = [...state.cart, dataProduct];
									break;
								} // index === cart.length -1
							}
							if ($flag == 0) {
								state.cart = [...state.cart, dataProduct];
							}
							break;
						case "BTN_SEL":
							if (dataProduct.plan_id) {
								let indexPlanIdcart = state.cart.findIndex(
									element => element.plan_id
								);
								if (indexPlanIdcart != -1)
									state.cart.splice(
										indexPlanIdcart,
										1,
										dataProduct
									);
								else state.cart = [...state.cart, dataProduct];
							} else {
								if (
									$cartItemsWithProps &&
									$cartItemsWithProps.some(item =>
										item.plan_id ? item.plan_id : false
									)
								) {
									state.cart = [...state.cart, dataProduct];
								} else {
									this.commit(
										"shop/REMOVE_ITEM",
										dataProduct.product_id
									);
								}
							}
							break;
					}
				}
			} // $btnType != "CHECKBOX"
			else if ($btnType == "CHECKBOX") {
				if (!$findCartItem) {
					state.cart = [];
					state.cart = [...state.cart, dataProduct];
				} else if ($findCartItem) {
					state.cart = [];
				}
			} //  else if ($btnType == "CHECKBOX") {
		}
		// state.cart.find((e, i) => console.log(i + " count :>> ", e.count));
		// state.cart.find((e, i) => console.log(i + " name :>>  ", e.name));
		// console.log("state.cart :>> ", state.cart);
		// state.cart.find((e, i) =>
		// 	console.log(i + " properties :>> ", e.properties)
		// );
	},
	REMOVE_ITEM(state, productId) {
		if (state.cart.length >= 1) {
			const indexToDelete = state.cart.findIndex(cart => {
				return cart.product_id == productId;
			});
			state.cart = [
				...state.cart.slice(0, indexToDelete),
				...state.cart.slice(indexToDelete + 1),
			];
		} // if()
	},
	MINUS_ITEM(state, productId) {
		if (state.cart.length >= 1) {
			for (var $cartItem in state.cart) {
				if (state.cart[$cartItem].product_id === productId) {
					state.cart[$cartItem].count--;
					if (state.cart[$cartItem].count <= 0) {
						state.cart.splice($cartItem, 1);
					}
				} // if()
			} // for()
		} // if()
		// saveCart();
	},
	EMPTY_CART(state, payload) {
		state.cart = [];
	},
	SET_OPEN(state, payload) {
		state.isOpen = payload;
	},
	SET_SHOP_ID(state, shopId) {
		state.shopId = shopId;
	},
	SET_VIP_PERCENTAGE(state, vipPercentage) {
		state.vip = vipPercentage;
	},
	SET_HAS_SHOP_ID_CARD(state, _shopId) {
		state.hasShopIdCart = _shopId;
	},
	SET_ALERT_ADD_PRODUCT_TO_OTHER_BRANCH(state, _object) {
		state.alertAddProductToOtherBranch = _object;
	},
};
export const getters = {
	discounts: (state, getters) => {
		let allDiscounts = 0;
		state.cart.filter(cart => {
			if (Boolean(cart.discount_amount)) {
				if (cart.calculationProperty) {
					allDiscounts +=
						(+cart.price + cart.calculationProperty) *
						cart.count *
						(cart.discount_amount / 100);
				} else {
					allDiscounts +=
						+cart.price * cart.count * (cart.discount_amount / 100);
				}
			}
		});
		if (allDiscounts) {
			// allDiscounts = parseInt(+allDiscounts * 100)/100;
			// allDiscounts = +(Math.round((allDiscounts) + "e+" + 2) + "e-" + 2)
			allDiscounts = allDiscounts.toFixed(2);
			/*let re = new RegExp('^-?\\d+(?:\.\\d{0,' + (2 || -1) + '})?');
            allDiscounts = allDiscounts.toString().match(re)[0];*/
			// allDiscounts = Number(allDiscounts).toFixed(2)
			// allDiscounts = parseFloat(Math.round(allDiscounts * 100) / 100).toFixed(2);
			// allDiscounts = (Math.floor(allDiscounts * 100) / 100).toFixed(2)
			// allDiscounts = allDiscounts.toFixed(2)
			// console.log('allDiscount ', allDiscounts);
			// allDiscounts = ($getPayablePrice - ($getPayablePrice * vipPercentage / 100).toFixed(2)).toFixed(2);

			// allDiscounts = parseFloat(Math.round(allDiscounts * 100) / 100).toFixed(2);
		}
		return allDiscounts;
	},
	discount: state => productId => {
		let discountPrice = 0;
		// state.cart.filter(cart => {
		//   if (cart.product_id == productId) {
		//     console.log('shop discount', cart)
		//     discountPrice += Boolean(cart.discount_price) ? (cart.discount_price * cart.count) : 0;
		//   }
		// });
		return discountPrice;
	},
	cart: state => state.cart, // would need action/mutation if data fetched async
	allPrice: (state, getters) => {
		let sum = 0;
		state.cart.filter(cart => {
			if (cart.calculationProperty) {
				sum += (+cart.price + cart.calculationProperty) * cart.count;
			} else {
				sum += +cart.price * cart.count;
			}
		});
		return sum.toFixed(2);
	},
	cartCount: state => {
		let counts = 0;
		state.cart.filter(cart => (counts += cart.count));
		return counts;
	},
	hasCountError: state => {
		let hasItem = state.cart.find(item => {
			if (item.count < item.min_count) {
				return true;
			}
		});
		if (hasItem) {
			return "YES";
		} else {
			return "NO";
		}
	},
	getPayablePrice: (state, getters) => {
		let $payablePrice = getters["allPrice"] - getters["discounts"];
		// let re = new RegExp('^-?\\d+(?:\.\\d{0,' + (2 || -1) + '})?');
		return $payablePrice.toFixed(2);
		// return $payablePrice.toString().match(re)[0];
	},
	getPayablePriceWithVip: (state, getters) => vipPercentage => {
		if (vipPercentage) {
			let $getPayablePrice = getters["getPayablePrice"];
			// $getPayablePrice = ((100 - vipPercentage) * $getPayablePrice) /100;
			$getPayablePrice = (
				$getPayablePrice -
				(($getPayablePrice * vipPercentage) / 100).toFixed(2)
			).toFixed(2);

			return $getPayablePrice;

			// let re = new RegExp('^-?\\d+(?:\.\\d{0,' + (2 || -1) + '})?');
			// return $getPayablePrice.toString().match(re)[0];
		} else {
			return false;
		}
	},
	getShopIdInStore: state => state.shopId,
	totalAmount: state => (state.cart ? state.cart.length : 0),
	totalQuantity(state) {
		return state.totalQuantity;
	},
	itemCount: state => productId => {
		let itemCount = 0;
		state.cart.filter(cart => {
			if (cart.product_id == productId) {
				itemCount = cart.count;
			}
		});
		return itemCount;
	},
	getTaxFirstBranchPrice: (
		state,
		getters,
		rootState,
		rootGetters
	) => totalPrice => {
		if (rootGetters["firstData/getTaxFirstBranch"]) {
			if (totalPrice) {
				return +(
					(totalPrice * rootGetters["firstData/getTaxFirstBranch"]) /
					100
				);
			}
		}
		return null;
	},
	getCommissionFirstBranchPrice: (
		state,
		getters,
		rootState,
		rootGetters
	) => totalPrice => {
		let $Commission = 0;

		if (totalPrice) {
			if (
				rootGetters["firstData/getCommissionFirstBranch"] &&
				rootGetters["firstData/getCommissionFirstBranch"].percent
			)
				$Commission =
					totalPrice *
					(rootGetters["firstData/getCommissionFirstBranch"].percent /
						100);
			if (
				rootGetters["firstData/getCommissionFirstBranch"] &&
				rootGetters["firstData/getCommissionFirstBranch"].mount
			)
				$Commission =
					+$Commission +
					+rootGetters["firstData/getCommissionFirstBranch"].mount;
		}
		return +$Commission;
	},
	getHasShopIdCart: state => state.hasShopIdCart,
	getAlertAddProductToOtherBranch: state =>
		state.alertAddProductToOtherBranch,
};

// actions
export const actions = {
	addToCart({ commit, state, dispatch }, data) {
		if (data && data.product && data.product.shopId)
			if (state.cart.length == 0) {
				commit("ADD_ITEM", data);
				dispatch("setHasShopIdCart", data.product.shopId);
			} else if (data.product.shopId == state.hasShopIdCart) {
				commit("ADD_ITEM", data);
			} else if (!data.isAddProductToOtherBranch) {
				dispatch("setAlertAddProductToOtherBranch", {
					statusDialog: true,
					prevShopId: state.hasShopIdCart,
					newShopId: data.product.shopId,
					data: data,
				});
			} else if (data.isAddProductToOtherBranch) {
				dispatch("shop/emptyCart");
				commit("ADD_ITEM", data);
			}
		// this.$store.dispatch("branch/oldCardStyle", null);
	},
	minusItem({ commit }, productId) {
		commit("MINUS_ITEM", productId);
	},
	removeItem({ commit }, productId) {
		commit("REMOVE_ITEM", productId);
	},
	emptyCart({ commit }) {
		commit("EMPTY_CART");
	},
	isOpenCart({ commit }, isOpen) {
		commit("SET_OPEN", isOpen);
	},
	setShopId({ commit }, shopId) {
		commit("SET_SHOP_ID", shopId);
	},
	setVipPercentage({ commit }, precentage) {
		commit("SET_VIP_PERCENTAGE", precentage);
	},
	setHasShopIdCart({ commit }, _shopId) {
		commit("SET_HAS_SHOP_ID_CARD", _shopId);
	},
	setAlertAddProductToOtherBranch({ commit }, _object) {
		commit("SET_ALERT_ADD_PRODUCT_TO_OTHER_BRANCH", _object);
	},
};

// let a = "69.696";
// let b = "0.799111";
// let c = 39.2+30.495;
// let d = 67.673;
//
// // console.log(c)
// console.log(trimNum(""+b))
// console.log(roundToX(0.799111, 3))
//
//
// function trimNum(num) {
//   num += '';
//   let sub = num.split(".");// "0.799111" => ["0", "799111"]
//   let $firstNum = sub[1].substring(0, 1); // "0.799111" => 7
//   let $make = sub[0]+'.'+$firstNum; // "0.799111" => "0.7"
//   let $roundDecimal = Math.round("0."+sub[1].substring(1)); // "0.799111" => "1"
//   let $result = sub[0]+'.'+$firstNum + $roundDecimal; // "0.799111" => "0.71"
//   return test;
// //  return Math.round("0."sub[1].substring(1));
// //  return sub[0] + "." + sub2;
// }
//
// function roundToX(num, X) {
//   return +(Math.round(num + "e+"+X)  + "e-"+X);
// }
//
//
// // sub2.substring(1, sub2.indexOf('.') + 3)

/// +(Math.round(29.99 + "e+"+2)  + "e-"+2)

/*const totals = (payloadArr) => {
  const totalAmount = payloadArr.map(cartArr => {
    return cartArr.price * cartArr.quantity
  }).reduce((a, b) => a + b, 0)*/
/* const totalQuantity = payloadArr.map(cartArr => {
    return cartArr.quantity
  }).reduce((a, b) => a + b, 0)*/
/*  return {
    amount: totalAmount.toFixed(2),
    qty: totalQuantity
  }
}*/
