export const state = () => {
	return {
      loadingBranchs: false,
		branch: null,
		branchSelectedData: null,
		hasApprove: null,
		cardStyle: null,
		oldBtnType: null, // oldBtnType: => some times this might several product add to cart and after that user get to change branch and we need to keep old btn styles in shopping cart
		isOpenBranch: false,
		categoriesAndChildren: [],
		branchSelectedForCategories: null,
		branchWarning: { beforeBranch: null, thisBranch: null },
		categoryBreadcrumbs: [],
	};
};
export const mutations = {
	SET_LOADING_BRANCHS(state, status) {
		state.loadingBranchs = status;
	},
	SET_BREADCRUMBS(state, data) {
		state.categoryBreadcrumbs = data;
	},
	SET_BRANCH_SELECTED_DATA(state, data) {
		state.branchSelectedData = data;
	},
	SET_HAS_APPROVE(state, payload) {
		state.hasApprove = payload;
	},
	SET_CARD_STYLE(state, payload) {
		state.cardStyle = payload;
	},
	SET_OLD_BTN_TYPE(state, oldBtnType) {
		state.oldBtnType = oldBtnType;
	},
	SET_IS_OPEN_BRANCH(state, payload) {
		state.isOpenBranch = payload;
	},
	SET_CATEGORIES_CHILDREN(state, data) {
		state.categoriesAndChildren = data;
	},
	SET_BRANCH_SELECTED_FOR_CATEGORIES(state, branch) {
		state.branchSelectedForCategories = branch;
	},
	SET_BRANCH_WARNING(state, data) {
		state.branchWarning = data;
	},
	SET_BRANCH(state, branch) {
		state.branch = branch;
	},
};
export const getters = {
	getLoadingBranchs: state => state.loadingBranchs,
	getHasApprove: state => state.hasApprove,
	getCardStyle: state => state.cardStyle,
	getCardWidth: state => {
		let $cardWidth = 250;
		if (state.cardStyle) {
			switch (state.cardStyle.web_style) {
				case "LARGE_PIC":
					$cardWidth = 250;
					break;
				case "SMALL_PIC":
					$cardWidth = 250;
					// $cardWidth = 180;
					break;
				case "FOUR_COL":
					$cardWidth = 250;
					break;
				case "FULL_PIC":
					$cardWidth = "100%";
					break;
				default:
					return $cardWidth;
			}
		}
		return $cardWidth;
	},
	getOldBtnType: state => state.oldBtnType,
	getBranchSelectedData: state => state.branchSelectedData,
	getIsOpenBranch: state => state.isOpenBranch,
	getCategoriesChildren: state => {
		return state.categoriesAndChildren;
	},
	getBranchSelectedForCategories: state => state.branchSelectedForCategories,
	getBranchWarning: state => state.branchWarning,
	getSelectedChildren: state => state.categoryBreadcrumbs,
	getBranch: state => state.branch,
};
export const actions = {
   setLoadingBranchs({ commit }, status) {
		commit("SET_LOADING_BRANCHS", status);
	},
	setCategoryBreadCrumbs({ commit }, categoryBreadcrumbs) {
		commit("SET_BREADCRUMBS", categoryBreadcrumbs);
	},
	hasApprove({ commit }, has_approve) {
		commit("SET_HAS_APPROVE", has_approve);
	},
	cardStyle({ commit }, type) {
		commit("SET_CARD_STYLE", type);
	},
	oldCardStyle({ commit }, type) {
		commit("SET_OLD_BTN_TYPE", type);
	},
	setBranchSelectedData({ commit }, data) {
		commit("SET_BRANCH_SELECTED_DATA", data);
	},
	setBranchWarning({ commit }, data) {
		commit("SET_BRANCH_WARNING", data);
	},
	setIsOpenBranch({ commit }, isOpen) {
		commit("SET_IS_OPEN_BRANCH", isOpen);
	},
	emptyCategories({ commit }, data) {
		commit("SET_CATEGORIES_CHILDREN", []);
		commit("SET_BRANCH_SELECTED_FOR_CATEGORIES", null);
		// commit('SET_IS_SHOW_CATEGORIES_MODAL', false)
	},
	async categories({ commit }, data) {
		let $data = {
			branch_id: data.branchId,
			lang: data.lang,
		};
		await this.$axios
			.$post("getCategories", $data)
			.then(res => {
				if (res.status) {
					const { cats } = res;
					commit("SET_BRANCH_SELECTED_FOR_CATEGORIES", data.branch);
					commit("SET_CATEGORIES_CHILDREN", cats);
					// commit('SET_IS_SHOW_CATEGORIES_MODAL', true)
				}
			})
			.catch(err => console.error(err));
	},
	setBranch({ commit }, branch) {
		commit("SET_BRANCH", branch);
	},
};
