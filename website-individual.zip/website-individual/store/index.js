import { URL } from "~/config";
const cookieparser = process.server ? require("cookieparser") : undefined;
// export const strict = false;
export const state = () => {
	return {
		auth: null,
		isRedirect: false,
	};
};
export const mutations = {
	setAuth(state, auth) {
		state.auth = auth;
	},
	SET_IS_REDIRECT(state, payload) {
		state.isRedirect = payload;
	},
};

export const getters = {
	getAuth: state => state.auth,
	isAuth: state => {
		let isAuth = false;
		// console.log('store/index js ', state);
		if (state.auth) {
			if (state.auth.url) {
				if (state.siteSetting && state.siteSetting.$url) {
					let $domain = state.siteSetting.$url;
					if (state.auth.url == $domain) {
						// console.log('this *** ', state.auth.url, $domain);
						isAuth = true;
					}
				}
			}
		}
		return isAuth;
	},
	getUserName: state => {
		let userFullName = "---------";
		if (state.auth) {
			if (state.auth.url) {
				if (state.auth.user) {
					userFullName = state.auth.user.fname;
				}
			}
		}
		return userFullName;
	},
	getIsRedirect: state => {
		return state.isRedirect;
	},
	getToken: (state, getter) => {
		if (getter.isAuth) {
			return state.auth.access_token;
		}
		return null;
	},
};

export const actions = {
	async nuxtServerInit({ state, commit, dispatch, beforeNuxtRender }, props) {
		const { app, req, isDev, redirect } = props;
		let auth = null;
		let hostName = isDev ? `${URL.$url}` : `${req.headers.host}`,
			$token = null;
        console.log({allRequestsIMAN: req});
        
		if (
			(!isDev && hostName && hostName != "localhost:3000") ||
			(isDev && hostName)
		) {
			let $urlWithoutWWW = null;

			if (hostName.includes("www.")) {
				hostName = hostName.split("www.")[1];
			}

			await dispatch("axiosBaseUrl", { host: hostName });

			// Check cookie universal mode about authorization
			if (req.headers.cookie) {
				try {
					let parsed = cookieparser.parse(req.headers.cookie);
					if (parsed.auth) {
						// cookieparser.parse(parsed.auth)
						// auth = parsed.auth
						auth = JSON.parse(parsed.auth);
					}
				} catch (err) {
					console.error(err);
				}
			}
			commit("setAuth", auth);
			if (auth) {
				await dispatch("loginCard/setCountryCode", {
					id: auth.user.country_id,
					text: auth.user.country_text,
				});
			}

			// Initial important API's
			// Site settings in 'settings' API

			await this.$axios
				.$post("settings")
				.then(({ data }) => {
					commit("siteSetting/SET_SETTING", data);
					const defaultLocale = data.settings.language.locale;
					let arr = data.locales.find(
						locale => locale == app.i18n.locale
					);
					app.i18n.defaultLocale = defaultLocale;
					//   console.log(defaultLocale);
					//   console.log("app.i18n.locale ", app.i18n.locale);

					if (!arr || app.i18n.locale == "fr") {
						return redirect(app.localePath("index", defaultLocale));
					}
					return data;
				})
				.catch(err =>
					console.error("nuxtServerInit: initialsettings() ", err)
				);

			// Check for get token when user is loged in
			if (
				state.auth &&
				state.auth.url &&
				state.siteSetting &&
				state.siteSetting.$url
			) {
				let $domain = state.siteSetting.$url;
				if (state.auth.url == $domain) {
					$token = state.auth.access_token;
				}
			}

			// Check if settings API correct and continue?
			if (!state.firstData.firstData.length) {
				// Is token valide in laravel?
				await dispatch("checkToken", { token: $token });

				// Response initial site data
				await dispatch("initialData", { lang: app.i18n.locale });
			}
		}

		console.log("Finish nuxtServerInit");
	},
	async axiosBaseUrl({ commit }, { host }) {
		// Set base url for project API's
		this.$axios.defaults.baseURL = `https://${host}/api/site-api/`;
		commit("siteSetting/SET_URL", `https://${host}/`);
	},
	async checkToken({ commit }, { token }) {
		const { isExpired } = await this.$axios.$post("checkToken", { token });
		if (isExpired) {
			commit("setAuth", null);
		}
	},
	async initialData({ commit }, { lang }) {
		const res = await this.$axios.$post("getFirstPage", { lang });
		commit("firstData/SAVE_DATA", res);
		if (
			res.shops &&
			res.shops.length &&
			res.shops[0].translations &&
			res.shops[0].translations.length
		) {
			// In this commit make monetary unit for product's cards
			commit("firstData/SAVE_MONETARY_UNIT", res.shops[0].translations);
		} else {
			commit("firstData/SAVE_MONETARY_UNIT", [
				{ locale: "en", monetary_unit: "" },
				{ locale: "ar", monetary_unit: "" },
				{ locale: "fa", monetary_unit: "" },
			]);
		}
		return res;
	},
};
