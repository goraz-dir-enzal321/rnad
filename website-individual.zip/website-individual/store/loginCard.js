export const state = () => ({
	phone: null,
	code: null,
	name: null,
	family: null,
	status: 0,
	countryCodes: null,
	countryCodesSelectedId: null,
	countryCodesSelectedText: null,
	isGoToOrderPage: false,
});

export const mutations = {
	SET_STATUS(state, status) {
		state.status = status;
	},
	SET_GO_TO_ORDER_PAGE(state, result) {
		state.isGoToOrderPage = result;
	},
	SET_COUNTRIES(state, codes) {
		state.countryCodes = codes;
	},
	SET_COUNTRY_ID(state, id) {
		state.countryCodesSelectedId = id;
	},
	SET_COUNTRY_TEXT(state, id) {
		state.countryCodesSelectedText = id;
	},
	set_phone(state, data) {
		state.phone = data;
	},
	set_code(state, data) {
		state.code = data;
	},
	set_full_name(state, data) {
		state.name = data.name;
		state.family = data.family;
	},
};
export const getters = {
	getStatus: state => state.status,
	getPhone: state => state.phone,
	getCountryCodes: state => state.countryCodes,
	getCountryId: state => state.countryCodesSelectedId,
	getCountryText: state => state.countryCodesSelectedText,
	getGoToOrderPage: state => state.isGoToOrderPage,
};
export const actions = {
	setGoToOrderPage({ commit }, result) {
		commit("SET_GO_TO_ORDER_PAGE", result);
	},
	setCountryCode({ commit }, countryCode) {
		commit("SET_COUNTRY_ID", countryCode.id);
		commit("SET_COUNTRY_TEXT", countryCode.text);
	},
};
