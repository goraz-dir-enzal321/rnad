import { order } from "~/api";

export const state = () => {
	return {
		form: null,
		formId: null,
		formType: null,
		showForm: false,
		getNewAddress: false,
		selectedAddress: null,
		questions_answered: null,
	};
};
export const mutations = {
	SET_FORM(state, object) {
		state.form = object;
	},
	SET_QUESTION_ANSWERED(state, payload) {
		state.questions_answered = payload;
	},
	SET_FORM_ID(state, id) {
		state.formId = id;
	},
	SELECTED_ADDRESS(state, payload) {
		state.selectedAddress = payload;
	},
	SHOW_FORM(state, payload) {
		state.showForm = payload;
	},
	FORM_TYPE(state, type) {
		state.formType = type;
	},
	GET_NEW_ADDRESS(state, payload) {
		state.getNewAddress = payload;
	},
};

export const getters = {
	getForm: state => state.form,
	getQuestionAnswered: state => state.questions_answered,
	getFormId: state => state.formId,
	getShowForm: state => state.showForm,
	getFormType: state => state.formType,
	getSelectedAddress: state => state.selectedAddress,
	isNewAddress: state => {
		// console.log('state.getNewAddress ', state.getNewAddress);
		return state.getNewAddress;
	},
};

export const actions = {
	questionAnswered({ commit }, questions) {
		commit("SET_QUESTION_ANSWERED", questions);
	},
	formId({ commit }, id) {
		commit("SET_FORM_ID", id);
	},
	showForm({ commit }, payload) {
		commit("SHOW_FORM", payload);
	},
	selectedAddress({ commit }, payload) {
		commit("SELECTED_ADDRESS", payload);
	},
	newAddress({ commit }, payload) {
		commit("GET_NEW_ADDRESS", payload);
	},
	async formType({ commit }, type) {
		commit("FORM_TYPE", type);
		let $data = {
			token: this.getters["getToken"],
			branch_id: this.getters["shop/getShopIdInStore"],
			type_address: this.getters["order/getFormType"],
			lang: this.$i18n.locale,
		};
		return await this.$axios
			.$post(order.showForm, $data)
			.then(res => {
				// res = {"status":true,"has_form":true,"form_description":"all type of form","form_id":14,"questions":[{"question_id":37,"title":"text","hint":"text1","required":true,"type":"TEXT","select_item":[]},{"question_id":38,"title":"time picker","hint":"time picker1","required":true,"type":"TIME_PICKER","select_item":[]},{"question_id":39,"title":"time picker","hint":"time picker1","required":true,"type":"TIME_PICKER","select_item":[]},{"question_id":40,"title":"date picker","hint":"date picker1","required":false,"type":"DATE_PICKER","select_item":[]},{"question_id":41,"title":"singel select","hint":"singel select1","required":false,"type":"SELECT","select_item":[{"item_id":32,"title":"item1"},{"item_id":33,"title":"item2"},{"item_id":34,"title":"item3"},{"item_id":35,"title":"item4"}]},{"question_id":42,"title":"multi select","hint":"multi select1","required":true,"type":"MULTI_SELECT","select_item":[{"item_id":36,"title":"item1"},{"item_id":37,"title":"item2"},{"item_id":38,"title":"item3"},{"item_id":39,"title":"item4"}]},{"question_id":43,"title":"switch btn","hint":"switch btn1","required":true,"type":"SWITCH","select_item":[{"item_id":40,"title":"man"},{"item_id":41,"title":"woman"}]},{"question_id":44,"title":"switch btn۲","hint":"switch btn۲۲","required":false,"type":"SWITCH","select_item":[{"item_id":42,"title":"tiny"},{"item_id":43,"title":"small"},{"item_id":44,"title":"meduim"},{"item_id":45,"title":"large"}]}]}
				if (res.status && res.has_form) {
					commit("SET_QUESTION_ANSWERED", null);
					commit("SHOW_FORM", true);
					commit("SET_FORM", res);
					commit("SET_FORM_ID", res.form_id);
				}
			})
			.catch(err => console.error(err));
	},
};
