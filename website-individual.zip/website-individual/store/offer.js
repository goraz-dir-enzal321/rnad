export const state = () => ({
	dataOffer: {},
	loadingOffer: true,
});

export const mutations = {
	SET_DATA_OFFER(state, data) {
		state.dataOffer = data;
	},
	SET_LOADING_OFFER(state, status) {
		state.loadingOffer = status;
	},
};
export const getters = {
	getDataOffer: state =>
		state.dataOffer && state.dataOffer.products && state.dataOffer.products.length && state.dataOffer.img
			? state.dataOffer
			: null,
	getLoadingOffer: state => state.loadingOffer,
};
export const actions = {
	setDataOffer({ commit }, data) {
		commit("SET_DATA_OFFER", data);
		// commit("SET_LOADING_OFFER", false);
	},
};
