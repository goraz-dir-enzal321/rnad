export const state = () => ({
	categoryBreadcrumbs: [],
	isShowCategoriesModal: false,
	selectedBreadcrumb: null,
	// isShowCategories: [],
});
export const mutations = {
	SET_BREADCRUMBS(state, data) {
		state.categoryBreadcrumbs.push(data);
	},
	SET_EMPTY_BREADCRUMBS(state) {
		state.categoryBreadcrumbs = [];
	},
	SET_IS_SHOW_CATEGORIES_MODAL(state, result) {
		state.isShowCategoriesModal = !state.isShowCategoriesModal;
	},
	SET_SELECTED_BRADCRUMB(state, data) {
		if (data.isStartOrdering2) {
			data.item.parent_id = data.item.id;
		}
		state.selectedBreadcrumb = data.item;
	},
};
export const getters = {
	getSelectedChildren: state => state.categoryBreadcrumbs,
	getIsShowCategoriesModal: state => state.isShowCategoriesModal,
	getSelectedBreadcrumb: state => state.selectedBreadcrumb,
};
export const actions = {
	setCategoryBreadCrumbs({ commit }, categoryBreadcrumbs) {
		commit("SET_BREADCRUMBS", categoryBreadcrumbs);
	},
	setEmptyCategoryBreadCrumbs({ commit }) {
		commit("SET_EMPTY_BREADCRUMBS");
	},
	setSelectedBreadcrumb({ commit }, item) {
		commit("SET_SELECTED_BRADCRUMB", item);
	},
};
