export const state = () => ({
	// api getter
	productData: {},
	timeWorkShop: {},
	plansData: [],
	planIds: [],
	// loading
	loading: false,
	// style shop
	styledProductShop: {
		description_style: "TAB_INFO",
		basket_btn_type: "NONE",
		description_btn: "NONE",
	},
	// opens
	dialogStatus: false,
	dialogStatusVip: false,
	dialogVideo: false,
	openSheetProperties: false,
	openSheetDetails: false,
	openSheetExplanation: false,
	// properties
	propertySelected: [],
	calculationProperty: 0,
	symbolSendPorperties: {},
	// list gallery select
	gallerySelected: {},
});

export const mutations = {
	// Set Api
	SET_PRODUCT_DATA(state, value) {
		state.propertySelected = [];
		state.calculationProperty = 0;
		state.symbolSendPorperties = {};
		state.productData = value;
		if (
			state.productData &&
			state.productData.gallery &&
			state.productData.gallery.length &&
			this.$device.isMobile &&
			state.productData.img
		) {
			state.productData.gallery.unshift({ img: state.productData.img });
		}
	},
	// Plans
	SET_PLANS_DATA(state, value) {
		state.plansData = value;
	},
	// Time to work on clock pm/am
	SET_TIME_WORK_SHOP(state, value) {
		state.timeWorkShop = value;
	},
	// loading
	SET_LOADING(state, value) {
		state.loading = value;
	},
	// other
	SET_STYLED_PRODUCT_SHOP(state, status) {
		state.styledProductShop = status;
	},
	SET_IS_OPEN_SHEET_PROPERTIES(state, object) {
		state.openSheetProperties = null;
		state.openSheetProperties = object;
	},
	SET_IS_OPEN_SHEET_DETAILS(state, status) {
		state.openSheetDetails = status;
	},
	SET_IS_OPEN_SHEET_EXPLANATION(state, status) {
		state.openSheetExplanation = status;
	},
	SET_PRPERTY_SELECTED(state, value) {
		const props = state.propertySelected;
		state.propertySelected = [];
		state.propertySelected = props;
		if (value.type == "empty") {
			var i = 0;
			while (i < state.propertySelected.length) {
				if (state.propertySelected[i].parent_id === value.id) {
					state.propertySelected.splice(i, 1);
				} else {
					++i;
				}
			}
		} else if (value.data && value.id) {
			if (state.propertySelected.length) {
				let $checkIsHavePropSelect = state.propertySelected.findIndex(
					data => data.parent_id == value.id
				);
				if ($checkIsHavePropSelect == -1) {
					state.propertySelected = [
						...state.propertySelected,
						{ ...value.data, parent_id: value.id },
					];
				} else {
					if (value.type == "Multi") {
						if (
							value.data.id ==
							state.propertySelected[$checkIsHavePropSelect].id
						) {
							state.propertySelected[$checkIsHavePropSelect] = {
								...value.data,
								parent_id: value.id,
							};
						} else {
							state.propertySelected = [
								...state.propertySelected,
								{ ...value.data, parent_id: value.id },
							];
						}
					} else if (value.type == "Single")
						state.propertySelected[$checkIsHavePropSelect] = {
							...value.data,
							parent_id: value.id,
						};
				}
			} else {
				value.data.parent_id = value.id;
				state.propertySelected = [
					...state.propertySelected,
					value.data,
				];
			}
		}
		this.commit("productInfo/SET_CALCULATION");
		this.commit("productInfo/SET_SENDER_PROPERTIES");
	},
	SET_SELECT_GALLERY(state, value) {
		state.gallerySelected = value;
	},
	SET_DIALOG_STATUS(state, value) {
		state.dialogStatus = value;
	},
	SET_DIALOG_STATUS_VIP(state, value) {
		state.dialogStatusVip = value;
	},
	SET_DIALOG_VIDEO(state, value) {
		state.dialogVideo = value;
	},
	SET_CALCULATION(state) {
		state.calculationProperty = 0;
		if (
			state.propertySelected &&
			state.propertySelected.length &&
			state.propertySelected.length != 0
		)
			state.propertySelected.forEach(data => {
				if (parseFloat(data.price))
					state.calculationProperty += parseFloat(data.price);
			});
	},
	SET_SENDER_PROPERTIES(state) {
		state.symbolSendPorperties = {};
		state.propertySelected.forEach(value => {
			let toStringParentId = value.parent_id.toString();
			let ids = [];
			state.propertySelected.filter(item => {
				if (item.parent_id == value.parent_id) {
					ids.push(item.id);
				}
			});
			state.symbolSendPorperties[toStringParentId] = {
				name: value.name ? value.name : "",
				img: value.img ? value.img : "",
				ids: ids,
			};
			// state.symbolSendPorperties[toStringParentId] = Array.isArray(value.id) ? value.id : [value.id]
		});
	},
	SET_PlAN_IDS(state, value) {
		state.planIds = value;
	},
};
export const getters = {
	/* APIs */
	// all API
	//! dont use it always <------------//
	getProductData: state => {
		if (state.productData) {
			return state.productData;
		}
		return "";
	},
	// all gallery & defualt image & thumbnail image
	getImage: state => {
		if (state.productData) {
			if (
				state.productData.img ||
				state.productData.gallery ||
				state.productData.thumbnail
			) {
				return {
					image: state.productData.img ? state.productData.img : null,
					gallery: state.productData.gallery
						? state.productData.gallery
						: null,
					thumbnail: state.productData.thumbnail
						? state.productData.thumbnail
						: null,
				};
			}
		}
		return "";
	},
	getExplanation: state => {
		if (state.productData)
			if (state.productData.description)
				return {
					type: "explanation",
					// name:  $t('productInfo.tabs.details'),
					data: state.productData.description,
				};
		return "";
	},
	// Properties -> color & size
	getProperties: state => {
		if (state.productData) {
			if (state.productData.properties) {
				return state.productData.properties;
			}
		}
		return "";
	},
	// comments || viewpoint
	getComments: state => {
		if (state.productData) {
			if (state.productData.comments) {
				return {
					type: "comments",
					// name:  $t('productInfo.tabs.comments'),
					data: state.productData.comments,
				};
			}
		}
		return null;
	},
	// specification || details
	getDetails: state => {
		if (state.productData) {
			if (state.productData.specification) {
				return {
					type: "details",
					// name:  $t('productInfo.tabs.details'),
					data: state.productData.specification,
				};
			}
		}
		return null;
	},
	// videos on the Download -> all
	getVideos: state => {
		if (state.productData) {
			if (state.productData.videos) {
				return {
					type: "videos",
					// name:  $t('productInfo.tabs.videos'),
					data: state.productData.videos,
				};
			}
		}
		return null;
	},
	// video on the abute
	getVideo: state => {
		if (state.productData) {
			if (state.productData.video) {
				return {
					file: state.productData.video,
					title: state.productData.video_title,
				};
			}
		}
		return null;
	},
	// voices on the Download -> all
	getVoices: state => {
		if (state.productData) {
			if (state.productData.voices) {
				return {
					type: "voices",
					// name:  $t('productInfo.tabs.voices'),
					data: state.productData.voices,
				};
			}
		}
		return null;
	},
	// videos on the Download
	getVoice: state => {
		if (state.productData) {
			if (state.productData.voice) {
				return {
					file: state.productData.voice,
					title: state.productData.voice_title,
				};
			}
		}
		return null;
	},
	// All Downloads -> voices & videos
	getDownloads: (state, getters) => {
		if (state.productData) {
			if (
				(state.productData.voices && state.productData.voices.length) ||
				(state.productData.videos && state.productData.videos.length)
			) {
				let dataSender = {
					type: "downloads",
					// name:  $t('productInfo.tabs.play'),
					data: [],
				};
				if (
					getters.getVoices &&
					getters.getVoices.data &&
					getters.getVoices.data.length != 0 &&
					getters.getVoices.data != []
				) {
					dataSender.data.push(getters.getVoices);
				}
				if (
					getters.getVideos &&
					getters.getVideos.data &&
					getters.getVideos.data.length != 0 &&
					getters.getVideos.data != []
				) {
					dataSender.data.push(getters.getVideos);
				}
				if (dataSender.data.length && dataSender.data.length != 0) {
					return dataSender;
				} else {
					return null;
				}
			}
		}
		return null;
	},
	// all nead || see in this method \/
	getOptions: state => {
		if (state.productData) {
			if (state.productData.product_id) {
				return {
					product_id: state.productData.product_id,
					description: state.productData.description,
					unit_sentence: state.productData.unit_sentence,
					price: state.productData.price,
					discount_price: state.productData.discount_price,
					category_id: state.productData.category_id,
					monetary_unit: state.productData.monetary_unit,
					discount: state.productData.discount,
					rate: state.productData.rate,
					review: state.productData.review,
					comments_count: state.productData.comments_count,
					voice_arrange: state.productData.voice_arrange,
					video_arrange: state.productData.video_arrange,
					video: state.productData.video,
					active: state.productData.active,
					existence: state.productData.existence,
					rec_call: state.productData.rec_call,
					name: state.productData.name,
					category: state.productData.category,
					shop_id: state.productData.shop_id,
					single_purchase: state.productData.single_purchase,
				};
			}
		}
		return "";
	},
	// videos on the Download
	getFile: state => {
		if (state.productData) {
			if (state.productData.file) {
				return {
					file: state.productData.file,
					title: state.productData.file_title,
				};
			}
		}
		return null;
	},
	// plans
	getPlansData: state => {
		if (state.plansData) {
			if (state.plansData.length && state.plansData.length != 0) {
				return state.getPlansData;
			}
		}
		return "";
	},
	// Time to work on clock pm/am
	getTimeWorkShop: state => {
		if (state.plansData) {
			if (
				state.timeWorkShop.am_time_start &&
				state.timeWorkShop.am_time_end &&
				state.timeWorkShop.pm_time_start &&
				state.timeWorkShop.pm_time_end
			) {
				return state.timeWorkShop;
			}
		}
		return "";
	},
	/* /APIs */
	/* send other */
	getLoading: state => state.loading,
	getStyledProductShop: state => state.styledProductShop ? state.styledProductShop :"",
	getOpenSheetProperties: state => state.openSheetProperties,
	getOpenSheetDetails: state => state.openSheetDetails,
	getOpenSheetExplanation: state => state.openSheetExplanation,
	getPropertySelected: state => {
		if (state.propertySelected && state.propertySelected.length) {
			return state.propertySelected;
		}
		return "";
	},
	getGallerySelected: state => {
		if (
			state.gallerySelected &&
			Object.keys(state.gallerySelected).length
		) {
			return state.gallerySelected;
		}
		return "";
	},
	getDialogStatus: state => state.dialogStatus,
	getDialogStatusVip: state => state.dialogStatusVip,
	getDialogVideo: state => state.dialogVideo,
	getCalculationProperty: state => state.calculationProperty,
	getSymbolSendPorperties: state =>
		state.symbolSendPorperties ? state.symbolSendPorperties : null,
	setPlanIds: state => state.planIds,
	/* /send other */
};
export const actions = {
	setProductData({ commit }, data) {
		commit("SET_PRODUCT_DATA", data);
	},
	setStyledProductShop({ commit }, status) {
		commit("SET_STYLED_PRODUCT_SHOP", status);
	},
	setPlansData({ commit }, status) {
		commit("SET_PLANS_DATA", status);
	},
	setLoading({ commit }, status) {
		commit("SET_LOADING", status);
	},
	setTimeWorkShop({ commit }, status) {
		commit("SET_TIME_WORK_SHOP", status);
	},
	setOpenSheetProperties({ commit }, object) {
		commit("SET_IS_OPEN_SHEET_PROPERTIES", object);
	},
	setOpenSheetDetails({ commit }, status) {
		commit("SET_IS_OPEN_SHEET_DETAILS", status);
	},
	setOpenSheetExplanation({ commit }, status) {
		commit("SET_IS_OPEN_SHEET_EXPLANATION", status);
	},
	setPropertySelected({ commit }, value) {
		commit("SET_PRPERTY_SELECTED", value);
	},
	setGallerySelected({ commit }, value) {
		commit("SET_SELECT_GALLERY", value);
	},
	setDialogStatus({ commit }, value) {
		commit("SET_DIALOG_STATUS", value);
	},
	setDialogStatusVip({ commit }, value) {
		commit("SET_DIALOG_STATUS_VIP", value);
	},
	setDialogVideo({ commit }, status) {
		commit("SET_DIALOG_VIDEO", status);
	},
	setPlanIds({ commit }, value) {
		commit("SET_PlAN_IDS", value);
	},
};
