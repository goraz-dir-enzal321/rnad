export const state = () => ({
    locationDialog: false,
    lat: null,
    lng: null,
});

export const mutations = {
    SET_LOCATION_DIALOG(state, status) {
        state.locationDialog = status
    },
    SET_LAT_LNG(state, data) {
        state.lat = data.lat;
        state.lng = data.lng;
    },
};
export const getters = {
    getLocationDialog: state => {
        return state.locationDialog;
    },
    getLatLng: state => {
      return { lat: state.lat, lng: state.lng }
    },
};
export const actions = {
    setLocationDialog({ commit }, status) {
        commit('SET_LOCATION_DIALOG', status)
    },
    setLatLng({ commit }, data) {
        commit('SET_LAT_LNG', data)
    },
};
