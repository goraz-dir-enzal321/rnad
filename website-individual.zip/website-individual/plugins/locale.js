import { URL } from '~/config'
export default async ({ app, redirect, store, params, route, $axios, isDev, $i18n, $vuetify, req }) => {
    if (process.client && isDev) {
        $axios.defaults.baseURL = `https://${URL.$url}/api/site-api/`;
    }

    if (process.client && !isDev) {
        const protocol = window.location.protocol;
        const hostname = window.location.hostname;
        const url = `${protocol}//${hostname}/`;
        const baseUrl = `${url}api/site-api/`;
        $axios.defaults.baseURL = baseUrl;
        store.dispatch('siteSetting/saveUrl', `https://${hostname}/`);
    }
}
