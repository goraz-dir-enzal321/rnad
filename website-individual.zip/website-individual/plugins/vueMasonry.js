import Vue from 'vue'
import VueMasonry from 'vue-masonry-css'

export default () => {
    Vue.use(VueMasonry);
}