// src/plugins/vue-leaflet.js
import Vue from 'vue'
import * as Vue2Leaflet from 'vue2-leaflet'

import 'leaflet/dist/leaflet.css'

const VueLeaflet = {

  install(Vue, options) {
    Vue.component('l-map', Vue2Leaflet.LMap)
    Vue.component('l-marker', Vue2Leaflet.LMarker)
    Vue.component('l-tile-layer', Vue2Leaflet.LTileLayer)
  }
};

Vue.use(VueLeaflet);

export default VueLeaflet;
