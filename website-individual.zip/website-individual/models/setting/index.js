const TEXT_TYPES = {
    STATIC_PAGE: 'STATIC_PAGE',
    DYNAMIC_PAGE: 'DYNAMIC_PAGE',
    ACTION_BTN: 'ACTION_BTN',
}
export default class Setting {
    props = null

    constructor(data = []) {
        if (data) {
            this.props = data;
        }
    }

    getLeaderView() {
        return this.props.leader_view
    };

    getDefaultImage() {
        return this.props.default_img
    };

    getTexts() {
        return this.props.texts;
    };

    getTextsUrl(textItem) {
        switch (textItem.type) {
            case 'CONTACT_US':
                return {
                    route: 'contactUs',
                    group: TEXT_TYPES.STATIC_PAGE
                };
            case 'ABOUT':
                return {
                    route: 'about_us',
                    group: TEXT_TYPES.DYNAMIC_PAGE
                };
            case 'ADD_LINK':
                return {
                    route: 'download',
                    group: TEXT_TYPES.STATIC_PAGE
                };
            case 'FAQ':
                return {
                    route: 'faq',
                    group: TEXT_TYPES.DYNAMIC_PAGE
                };
            case 'FEEDBACK':
                return {
                    route: 'survey',
                    group: TEXT_TYPES.STATIC_PAGE
                };
            case 'HOME':
                return {
                    route: 'index',
                    group: TEXT_TYPES.STATIC_PAGE
                };
            case 'PRIVACY':
                return {
                    route: 'privacy_and_policy',
                    group: TEXT_TYPES.DYNAMIC_PAGE
                };
            case 'TERM':
                return {
                    route: 'terms_conditions',
                    group: TEXT_TYPES.DYNAMIC_PAGE
                };
            case 'LANG':
                return {
                    route: 'action',
                    group: TEXT_TYPES.ACTION_BTN
                };
            case 'LOGIN':
                return {
                    route: 'action',
                    group: TEXT_TYPES.ACTION_BTN
                };
            case 'BASKET_BTN':
                return {
                    route: 'action',
                    group: TEXT_TYPES.ACTION_BTN
                };
            case 'FAST_BUY':
                return {
                    route: 'action',
                    group: TEXT_TYPES.ACTION_BTN
                };

            default:
                return {
                    route: 'index',
                    group: TEXT_TYPES.STATIC_PAGE
                };
        }
    };

    hasTextsLength() {
        const result = this.props.texts && this.props.texts.length ? 1 : 0;
        return result;
    };
};