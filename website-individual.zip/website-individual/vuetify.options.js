// vuetify.options.js
import "@mdi/font/css/materialdesignicons.css"; // Ensure you are using css-loader
// import '@mdi/js'
export default {
	//   breakpoint: {},
	icons: {
		iconfont: "mdi", // 'mdi' || 'md' || 'fa' || 'fa4'
	},
	//   lang: {},
	rtl: true,
	//   theme: {}
};
