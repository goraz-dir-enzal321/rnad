module.exports = {
	root: true,
	env: {
		browser: true,
		node: true,
	},
	parserOptions: {
		parser: "babel-esling",
		/* sourceType: 'module',
        ecmaFeatures: {
        legacyDecorators: true */
	},
	extends: [
		"@nuxtjs",
		"prettier",
		"prettier/vue",
		"plugin:vue/essential",
		"plugin:prettier/recommended",
		"plugin:nuxt/recommended",
	],
	plugins: ["vue", "prettier"],
	rules: {
		"vue/no-use-v-if-with-v-for": "off",

		"vue/no-use-v-if-with-v-for": [
			"error",
			{
				allowUsingIterationVar: false,
			},
		],
	},
};
