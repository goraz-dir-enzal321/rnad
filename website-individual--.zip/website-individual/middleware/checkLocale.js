export default async function ({ route, router, redirect, app, store, $axios, $vuetify }) {
    store.dispatch('shop/isOpenCart', false)
}
