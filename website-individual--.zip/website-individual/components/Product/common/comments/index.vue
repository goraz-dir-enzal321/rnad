<template>
	<Fragment>
		<v-col cols="12" v-if="commentsComputed">
			<v-row
				class="text-center"
				align="center"
				v-if="commentsComputed.length"
			>
				<v-divider />
				<v-subheader class="mx-auto">
					{{ $t("header.text.comments") }}
				</v-subheader>
				<v-divider />
			</v-row>
		</v-col>
		<template v-if="canComment == 3">
			<v-card class="mx-auto mb-5" color="yellow lighten-2">
				<v-card-text>
					<div class="black--text darken-4">
						{{ $t("label.buy_for_comment_error") }}
					</div>
				</v-card-text>
			</v-card>
		</template>
		<v-expansion-panels
			multiple
			class="mb-4"
			v-else-if="isAuth && canComment && canComment != 4"
		>
			<v-expansion-panel>
				<v-expansion-panel-header v-slot="{ open }">
					<v-row no-gutters>
						<v-col cols="12" class="text--secondary">
							<v-fade-transition leave-absolute>
								<span v-if="open">
									<v-icon>mdi-account</v-icon>
									{{ userName }}
								</span>
								<span v-else>
									<v-icon>mdi-message-reply-text</v-icon
									><span
										v-html="
											getDynamicText &&
											getDynamicText('COMMENT')
												? getDynamicText('COMMENT')
												: $t(
														'header.text.write_your_review'
												  )
										"
									/>
								</span>
							</v-fade-transition>
						</v-col>
					</v-row>
				</v-expansion-panel-header>
				<v-expansion-panel-content>
					<v-row no-gutters>
						<v-col class="text--secondary text-center" cols="12">
							<v-btn-toggle
								v-model="toggle_exclusive"
								background-color="white"
								light
								backg
								group
								color="blue-grey darken-2"
							>
								<v-btn color="white" value="1">
									<v-icon color="blue-grey darken-2"
										>mdi-emoticon-confused-outline</v-icon
									>
								</v-btn>
								<v-btn color="white" value="2">
									<v-icon color="blue-grey darken-2"
										>mdi-emoticon-sad-outline</v-icon
									>
								</v-btn>
								<v-btn color="white" value="3">
									<v-icon color="blue-grey darken-2"
										>mdi-emoticon-neutral-outline</v-icon
									>
								</v-btn>
								<v-btn color="white" value="4">
									<v-icon color="blue-grey darken-2"
										>mdi-emoticon-cool-outline</v-icon
									>
								</v-btn>
								<v-btn color="white" value="5">
									<v-icon color="blue-grey darken-2"
										>mdi-emoticon-kiss-outline</v-icon
									>
								</v-btn>
							</v-btn-toggle>
						</v-col>
					</v-row>
					<v-row class="pa-4">
						<v-col cols="12">
							<v-form @submit.prevent="submitComment">
								<v-row>
									<v-col cols="12">
										<v-textarea
											v-model="comment"
											name="input-7-1"
											:label="
												$t(
													'form.placeholder.write_your_message'
												)
											"
										/>
									</v-col>
									<v-col cols="12">
										<v-btn
											block
											class="mb-3"
											:loading="loading"
											:disabled="loading"
											type="submit"
											:color="
												getBtnStyle && getBtnStyle.bg
													? getBtnStyle.bg
													: Boolean(getSiteColor)
													? getSiteColor.secondColor
													: 'grey'
											"
											:style="[
												{
													color:
														getBtnStyle &&
														getBtnStyle.text
															? getBtnStyle.text
															: '',
												},
											]"
											>{{ $t("button.submit") }}</v-btn
										>
									</v-col>
								</v-row>
							</v-form>
						</v-col>
					</v-row>
				</v-expansion-panel-content>
			</v-expansion-panel>
		</v-expansion-panels>
		<template v-else-if="!isAuth">
			<v-hover v-slot:default="{ hover }">
				<v-card
					v-on:click="$store.commit('loginCard/SET_STATUS', 1)"
					class="mx-auto mb-5"
					color="cyan darken-4"
					:elevation="hover ? 12 : 2"
				>
					<v-card-text>
						<div class="white--text">
							{{ $t("label.please_sign_In_to_comment") }}
						</div>
					</v-card-text>
				</v-card>
			</v-hover>
		</template>
		<template v-else-if="!canComment">
			<v-card class="mx-auto mb-5" color="yellow lighten-2">
				<v-card-text>
					<div
						class="black--text darken-4"
						v-html="
							getDynamicText && getDynamicText('NO_COMMENT')
								? getDynamicText('NO_COMMENT')
								: $t('label.buy_for_comment')
						"
					/>
				</v-card-text>
			</v-card>
		</template>

		<template v-if="commentsComputed && commentsComputed.length">
			<v-card
				class="mx-auto mb-4"
				v-for="item in commentsComputed"
				:key="`comment-${item.id}`"
			>
				<!-- v-if="item.comment.length" -->
				<v-list-item three-line>
					<v-list-item-content>
						<div class="overline">{{ item.created }}</div>
						<v-list-item-title
							class="font-size-subtitle-1 mb-1"
							v-if="item.owner"
						>
							{{ item.owner.name + " " + item.owner.family }}
						</v-list-item-title>
						<v-list-item-subtitle>
							{{ item.comment }}
							<v-card
								color="teal lighten-5"
								class="my-3"
								v-if="item.rest_answer"
							>
								<v-list-item>
									<v-list-item-content>
										<v-list-item-subtitle>
											{{ item.rest_answer }}
										</v-list-item-subtitle>
									</v-list-item-content>
								</v-list-item>
							</v-card>
						</v-list-item-subtitle>
					</v-list-item-content>
					<v-list-item-avatar tile size="20" color="white">
						<v-icon
							color="blue-grey darken-2"
							v-if="Math.round(item.rate) == 1"
							>mdi-emoticon-confused-outline</v-icon
						>
						<v-icon
							color="amber accent-4"
							v-if="Math.round(item.rate) == 2"
							>mdi-emoticon-sad-outline</v-icon
						>
						<v-icon
							color="blue-grey darken-2"
							v-if="Math.round(item.rate) == 3"
							>mdi-emoticon-neutral-outline</v-icon
						>
						<v-icon
							color="blue-grey darken-2"
							v-if="Math.round(item.rate) == 4"
							>mdi-emoticon-cool-outline</v-icon
						>
						<v-icon
							color="blue-grey darken-2"
							v-if="Math.round(item.rate) == 5"
							>mdi-emoticon-kiss-outline</v-icon
						>
					</v-list-item-avatar>
				</v-list-item>
			</v-card>
			<v-btn
				@click="moreComment"
				:loading="loading"
				:disabled="loading"
				v-if="hasMorePage"
				:color="
					getBtnStyle && getBtnStyle.bg
						? getBtnStyle.bg
						: Boolean(getSiteColor)
						? getSiteColor.secondColor
						: 'grey'
				"
				:style="[
					{
						color:
							getBtnStyle && getBtnStyle.text
								? getBtnStyle.text
								: '',
					},
				]"
				>{{ $t("button.more") }}</v-btn
			>
		</template>
	</Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
import { mapGetters } from "vuex";
export default {
	components: {
		Fragment,
	},
	props: ["product_id", "canComment", "commentsDataProps", "isAuth"],
	data: () => ({
		hasMorePage: true,
		page: 0,
		comment: null,
		toggle_exclusive: null,
		commentsData: null,
		loading: false,
	}),
	computed: {
		...mapGetters({
			getBtnStyle: "siteSetting/getBtnStyle",
			getDynamicText: "siteSetting/getDynamicText",
		}),
		commentsComputed: {
			get() {
				return this.commentsData;
			},
			set(newComments) {
				return this.commentsData.push(newComments);
			},
		},
		userName: {
			get() {
				const $username = this.$store.state.auth
					? this.$store.state.auth.user.fname +
					  " " +
					  this.$store.state.auth.user.lname
					: null;
				return $username;
			},
		},
	},
	watch: {
		commentsDataProps() {
			this.commentsData = this.commentsDataProps;
		},
	},
	mounted() {
		this.commentsData = this.commentsDataProps;
	},
	methods: {
		moreComment() {
			// commentList
			if (this.hasMorePage) {
				this.loading = true;
				this.$axios
					.$post("commentList", {
						product_id: this.product_id,
						page: this.page,
						lang: this.$i18n.locale,
					})
					.then(res => {
						if (this.page == 0) {
							this.commentsData = [];
						}
						if (this.hasMorePage) {
							++this.page;
						}
						if (res.data && res.data.length) {
							res.data.map(comment => {
								return (this.commentsComputed = comment);
							});
						} else {
							this.hasMorePage = false;
						}
					})
					.catch(err => {
						console.error(err);
					})
					.finally(res => {
						this.loading = false;
					});
			}
		},
		submitComment() {
			const data = {
				token: this.$store.state.auth.access_token,
				rate: this.toggle_exclusive,
				comment: this.comment,
				id: this.product_id,
				lang: this.$i18n.locale,
			};
			if (Boolean(this.$route.params.slug)) {
				this.loading = true;
				this.$axios
					.$post("saveComment", data)
					.then(res => {
						this.isShowSnackbar = true;
						this.snackbarText = `${res.message}`;
						this.toggle_exclusive = null;
						this.comment = null;
					})
					.catch(err => {
						console.error(err);
					})
					.finally(res => {
						this.loading = false;
					});
			} // end if
		}, // submitComment()
	},
};
</script>
