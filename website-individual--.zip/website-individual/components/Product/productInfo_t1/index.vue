<template>
	<div>
		<v-container class="pt-0">
			<v-row class="white py-3" v-if="breadcrumb">
				<v-col
					cols="12"
					class="font-size-text-h5 mb-0 py-3 text-center font-weight-medium"
					>{{ breadcrumb }}</v-col
				>
			</v-row>
			<v-row v-if="!Object.keys(productComputed).length">
				<v-col cols="12" md="6">
					<v-skeleton-loader type="image" class="mx-auto mb-3" />
				</v-col>
				<v-col cols="12" md="6">
					<v-skeleton-loader
						type="table-heading, list-item-one-line, divider, article"
						class="mx-auto mb-3"
					/>
				</v-col>
			</v-row>
			<v-row
				v-if="Object.keys(productComputed).length"
				align-content="stretch"
			>
				<v-col cols="12" md="6">
					<v-card>
						<v-img
							v-if="productComputed.image"
							:src="`${getDomain}${productComputed.image}`"
							:lazy-src="`${getDomain}${productComputed.thumbnail}`"
							class="grey lighten-2 mx-auto"
							:contain="true"
						>
							<template v-slot:placeholder>
								<v-row
									class="fill-height ma-0 grey"
									align="center"
									justify="center"
								>
									<v-progress-circular
										indeterminate
										color="grey lighten-5"
									/>
								</v-row>
							</template>
						</v-img>
					</v-card>
				</v-col>
				<v-col cols="12" md="6">
					<v-btn
						block
						color="grey darken-1"
						dark
						class="mb-3"
						nuxt
						:to="localePath('index')"
						v-if="$device.isDesktopOrTablet"
					>
						<v-icon size="20">mdi-menu</v-icon>
						{{ $t("button.back_to_menu") }}
					</v-btn>
					<v-card
						tile
						class="mx-auto"
						:height="descHeight"
						style="overflow: hidden;"
					>
						<v-card-text
							class="d-flex justify-space-between align-center"
						>
							<div
								class="font-size-title grey--text text--darken-3"
							>
								{{ productComputed.name }}
							</div>
							<v-chip
								label
								active
								class="pa-1"
								style="height: auto;"
								v-if="!isShopOpen"
								>{{ $t("label.store_is_closed") }}</v-chip
							>
							<v-chip
								label
								active
								class="pa-1"
								style="height: auto;"
								v-else-if="!productComputed.existence"
								>{{ $t("label.not_exist") }}</v-chip
							>
							<ProductCardButtons
								:product="productComputed"
								:customData="true"
								btnType="DESCRIPTION"
								v-if="isShopOpen && productComputed.existence"
							/>
						</v-card-text>
						<template v-if="productComputed.price > 0">
							<v-card-text
								class="d-flex justify-start align-center py-0"
								v-if="productComputed.discount > 0"
							>
								<div
									:class="
										$vuetify.rtl
											? 'order-2'
											: 'order-0 mr-2'
									"
								>
									{{ productComputed.monetary_unit }}
								</div>
								<div
									class="red--text darken-3 font-size-subtitle-1"
									:class="
										$vuetify.rtl
											? 'order-0 ml-2'
											: 'order-0 mr-2'
									"
								>
									{{
										$numberWithCommas(
											productComputed.discount_price
										)
									}}
								</div>
								<del
									class="font-size-body-2"
									:class="
										$vuetify.rtl
											? 'order-1 ml-2'
											: 'order-0'
									"
									>{{
										$numberWithCommas(productComputed.price)
									}}</del
								>
							</v-card-text>
							<v-card-text
								class="d-flex justify-start align-center py-0"
								v-else
							>
								<div
									:class="
										$vuetify.rtl
											? 'order-1'
											: 'order-0 mr-2'
									"
								>
									{{ productComputed.monetary_unit }}
								</div>
								<div
									class="red--text darken-3 font-size-subtitle-1"
									:class="
										$vuetify.rtl
											? 'order-0 ml-2'
											: 'order-1 mr-2'
									"
								>
									{{
										$numberWithCommas(productComputed.price)
									}}
								</div>
							</v-card-text>
						</template>
						<v-card-title>
							<div class="font-size-body-1">
								{{ $t("header.text.description") }}
							</div>
						</v-card-title>
						<v-card-text
							v-html="
								productComputed.description.length
									? productComputed.description
									: $t('message.text.no_description')
							"
						/>
					</v-card>
					<v-card
						class="mx-auto"
						tile
						v-if="productComputed.description.length > 360"
					>
						<v-divider />
						<v-btn
							tile
							block
							dark
							color="grey"
							text
							@click="toggleHeight"
						>
							<v-icon>{{
								show ? "mdi-chevron-down" : "mdi-chevron-up"
							}}</v-icon>
							{{ show ? $t("button.more") : $t("button.less") }}
						</v-btn>
					</v-card>
				</v-col>
			</v-row>
			<v-row>
				<v-col cols="12" sm="5" class="mx-auto">
					<CommentBox
						:isAuth="isAuth"
						:canComment="canComment"
						:commentsDataProps="commentsData"
						:product_id="productComputed.product_id"
					/>
				</v-col>
			</v-row>
		</v-container>
		<v-snackbar v-model="isShowSnackbar" color="teal">
			{{ snackbarText }}
			<v-btn icon text @click="isShowSnackbar = false">
				<v-icon>mdi-close</v-icon>
			</v-btn>
		</v-snackbar>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import { product } from "~/api";
import ProductCardButtons from "@/components/ProductCard/Buttons";
import CommentBox from "~/components/Product/common/comments";
import * as moment from "moment";

export default {
	name: "product-id",
	components: { ProductCardButtons, CommentBox },
	props: ["slug"],
	data() {
		return {
			// isValidCommentForm: false,
			commentsData: [],
			isShowSnackbar: false,
			snackbarText: null,
			show: false,
			descHeight: "auto",
			open: false,
			productData: [],
			canComment: false,
			isShopOpen: false,
			shopId: null,
			breadcrumb: null,
			colsHeightMatch: null,
		};
	},
	mounted() {
		this.getProductInfo();
	},
	methods: {
		async getProductInfo() {
			await this.$axios
				.$post(product.getProductInfoV1, {
					slug: this.slug,
					lang: this.$i18n.locale,
				})
				.then(res => {
					console.log({ res });
					if (res.status) {
						this.shopId = res.shop_id;
						this.canComment = res.can_comment;
						this.productData = res.products;
						this.productData.shopId = res.shop_id;
						this.commentsData = res.products.comments;
						this.breadcrumb = res.products.breadcrumb;

						this.$store.dispatch("shop/setShopId", res.shop_id);

						const $shop = this.getShops.find(shop => {
							if (shop.id == res.shop_id) {
								this.$store.dispatch(
									"productInfo/setStyledProductShop",
									{
										basket_btn_type:
											shop.card.basket_btn_type,
										description_style:
											shop.card.description_style,
										description_btn:
											shop.card.description_btn,
										has_product_voice:
											shop.has_product_voice,
									}
								);
								return shop;
							}
						});
						if ($shop) {
							this.$store.dispatch(
								"branch/cardStyle",
								$shop.card
							);
						}
						if (this.getBranchWarning)
							this.$store.dispatch("branch/setBranchWarning", {
								beforeBranch: this.getBranchWarning.thisBranch,
								thisBranch: res.min_product_error,
							});
						try {
							let userLocaleUtcTime = moment()
								.utc()
								.format("HH:mm:ss");
							this.isShopOpen =
								(res.work_time.am_time_start <=
									userLocaleUtcTime &&
									userLocaleUtcTime <=
										res.work_time.am_time_end) ||
								(res.work_time.pm_time_start <=
									userLocaleUtcTime &&
									userLocaleUtcTime <=
										res.work_time.pm_time_end);
						} catch (e) {
							console.error("catch ", e);
						}

						this.callResult(res.products);
					} else {
						this.$router.push(this.localePath("index"));
					}
				})
				.finally(() => {
					this.$nextTick(() => {
						this.$nuxt.$loading.finish();
					});
				});
		},

		toggleHeight() {
			this.show = !this.show;
			this.descHeight = this.descHeight == "auto" ? "200" : "auto";
		},
		callResult(products_data) {
			this.$emit("callResultMetaTags", products_data);
		},
	},
	computed: {
		...mapGetters({
			getItemCount: "shop/itemCount",
			getDomain: "siteSetting/getDomain",
			isAuth: "isAuth",
			cartCount: "shop/cartCount",
			getShops: "firstData/getShops",
			getSiteColor: "siteSetting/getSiteColor",
			getBranchWarning: "branch/getBranchWarning",
			getToken: "getToken",
		}),
		productComputed: {
			get() {
				return this.productData;
			},
		},
	},
};
</script>

<style scoped>
.v-chip {
	white-space: normal !important;
	text-align: center !important;
}
</style>
