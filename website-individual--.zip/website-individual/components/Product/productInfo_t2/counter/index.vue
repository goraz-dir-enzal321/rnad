<template>
	<v-col
		cols="12"
		sm="6"
		class="pt-0 direction-ltr add-to-card"
		:class="{
			'order-1': $device.isMobile,
			'order-2': !$device.isMobile,
		}"
	>
		<v-btn
			color="grey darken-1 white--text"
			block
			depressed
			class="mb-2"
			nuxt
			:to="`/${$i18n.locale}/#main-section`"
		>
			<v-icon right class="mx-1">
				mdi-menu
			</v-icon>
			{{ $t("button.back_to_menu") }}
		</v-btn>
		<v-card
			:outlined="$device.isMobile ? true : false"
			:elevation="$device.isMobile ? 2 : 0"
			class="rounded-16 py-1 py-sm-3 px-sm-3 mb-2 mb-md-0"
			v-if="
				getStyledProductShop.has_order_comment ||
				(((getDownloads && !getOptions.single_purchase) ||
					!getDownloads) &&
					getStyledProductShop &&
					getStyledProductShop.description_btn != 'NONE')
			"
		>
			<!-- 
      			rating &
      			comments count &
      			discount price &
      			getCalculationProperty &
      			price &
      			monetary_unit &
      			discount &
      			buy
			-->
			<v-row class="px-3 px-md-0 px-sm-2" align="center">
				<!-- rating & comments count -->
				<template v-if="getStyledProductShop.has_order_comment">
					<!-- rating -->
					<v-col
						cols="7"
						sm="12"
						lg="7"
						class="py-1 d-flex align-center justify-start justify-sm-center justify-lg-center"
						v-if="rating && comments_count"
					>
						<v-rating
							dense
							readonly
							v-model="rating"
							background-color="grey"
							color="orange"
							class="d-inline-block"
						/>
						<span
							class="d-inline-block mt-1 mx-1"
							v-text="rating"
						/>
					</v-col>
					<!-- comments count -->
					<v-col
						cols="5"
						sm="12"
						lg="5"
						class="py-1 justify-start justify-sm-center justify-lg-center d-flex"
						v-if="comments_count"
					>
						<v-spacer
							:class="[
								'd-block d-sm-none d-lg-block',
								{
									'd-none': !$vuetify.rtl,
								},
							]"
						/>
						<span
							class="d-inline-block mt-1 mx-1"
							v-text="comments_count"
						/>
						<v-icon> mdi-account </v-icon>
						<v-spacer
							:class="[
								'd-block d-sm-none d-lg-block',
								{
									'd-none': !$vuetify.rtl,
								},
							]"
						/>
					</v-col>

					<!-- divider -->
					<v-col
						cols="12"
						class="py-1"
						v-if="
							(comments_count) &&
							(discount_price ||
								monetary_unit ||
								price ||
								discount) &&
							getStyledProductShop &&
							getStyledProductShop.description_btn != 'NONE'
						"
					>
						<v-divider />
					</v-col>
				</template>

				<!-- discount & price & monetary_unit & getCalculationProperty -->
				<template
					v-if="
						((getDownloads && !getOptions.single_purchase) ||
							!getDownloads) &&
						getStyledProductShop &&
						getStyledProductShop.description_btn != 'NONE'
					"
				>
					<v-col>
						<v-row no-gutters>
							<portionPrice
								:price="parseFloat(price)"
								:discount_price="parseFloat(discount_price)"
								:monetary_unit="monetary_unit"
								:discount="parseFloat(discount)"
								:unit_sentence="unit_sentence"
							/>
						</v-row>
					</v-col>
					<!-- buy -->
					<v-col cols="12" class="py-0" v-if="!$device.isMobile">
						<counterBuy />
					</v-col>
				</template>
			</v-row>
		</v-card>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import counterBuy from "@/components/Product/productInfo_t2/counter/counterBuy";
import portionPrice from "@/components/Product/productInfo_t2/counter/portionPrice";
export default {
	components: {
		counterBuy,
		portionPrice,
	},
	data: () => ({
		rating: 1,
		discount_price: null,
		monetary_unit: null,
		comments_count: null,
		price: null,
		discount: null,
		unit_sentence: null,
	}),
	computed: {
		...mapGetters({
			getStyledProductShop: "productInfo/getStyledProductShop",
			getOptions: "productInfo/getOptions",
			getCalculationProperty: "productInfo/getCalculationProperty",
			getDownloads: "productInfo/getDownloads",
		}),
	},
	created() {
		if (this.getOptions) {
			this.rating = parseInt(this.getOptions.rate);
			this.discount_price = parseFloat(this.getOptions.discount_price);
			this.monetary_unit = this.getOptions.monetary_unit;
			this.comments_count = this.getOptions.comments_count;
			this.discount = this.getOptions.discount;
			this.price = parseFloat(this.getOptions.price);
			this.unit_sentence = this.getOptions.unit_sentence;
		}
	},
};
</script>
