<template>
	<v-row
		no-gutters
		class="section-loading-product white pb-3 rounded mx-lg-12"
	>
		<!-- title -->
		<v-col cols="12" class="pb-0" v-if="$device.isMobile">
			<v-skeleton-loader type="card-heading" />
		</v-col>
		<!-- image -->
		<v-col cols="12" sm="4" class="ps-0 ps-sm-3">
			<v-row no-gutters class="pt-0 pt-sm-7"
				><v-col cols="12" class="pb-3">
					<v-skeleton-loader
						class="mx-auto rounded-t-lg"
						type="image"
						tile
						:width="$device.isMobile ? '300px' : '100%'"
						:height="$device.isMobile ? '150px' : '185.5px'" />
					<v-skeleton-loader
						class="mx-auto rounded-b-lg"
						type="image"
						tile
						:width="$device.isMobile ? '300px' : '100%'"
						:height="
							$device.isMobile ? '150px' : '185.5px'
						" /></v-col
				><v-col cols="12" v-if="!$device.isMobile"
					><v-row no-gutters=""
						><v-col v-for="index in 5" :key="index" class="px-1"
							><v-skeleton-loader
								height="75"
								type="image" /></v-col></v-row></v-col
			></v-row>
		</v-col>
		<!-- title & properties & buy-->
		<v-col cols="12" sm="8" class="pe-0 pe-sm-3">
			<v-row>
				<!-- title -->
				<v-col cols="12" class="pb-0" v-if="!$device.isMobile">
					<v-skeleton-loader type="card-heading" />
				</v-col>
				<!-- properties & buy -->
				<v-col cols="12" sm>
					<v-row>
						<!-- properties -->
						<v-col
							cols="12"
							sm
							class="mx-5"
							:class="$device.isMobile ? 'order-1' : 'order-0'"
						>
							<v-skeleton-loader type="chip" class="mb-2" />
							<div
								class="d-inline-block me-2"
								v-for="index in 5"
								:key="index"
							>
								<v-skeleton-loader type="button" />
							</div>
						</v-col>
						<!-- buy -->
						<v-col
							cols="12"
							sm
							:class="$device.isMobile ? 'order-0' : 'order-1 '"
						>
							<v-row no-gutters>
								<v-col cols="6" class="ps-2">
									<v-skeleton-loader
										class="mt-1"
										type="text"
									/>
								</v-col>
								<v-col
									cols="6"
									:class="
										$vuetify.rtl
											? 'text-left'
											: 'text-right'
									"
									class="mb-3 section-star pe-2"
								>
									<v-skeleton-loader
										v-for="index in 5"
										:key="index"
										width="16"
										height="16"
										tile
										class="d-inline-block ma-1 rounded-pill"
										type="avatar"
									/>
								</v-col>
								<v-col
									cols="6"
									v-for="index in 2"
									:key="index"
									class="px-2 mb-3"
								>
									<v-skeleton-loader
										class="mt-1"
										type="text"
									/>
								</v-col>
								<v-col cols="6" class="px-2 mb-3">
									<v-skeleton-loader
										class="mt-1"
										type="list-item-avatar-two-line"
									/>
								</v-col>
								<v-spacer></v-spacer>
								<v-col cols="auto" class="px-2 mb-3">
									<v-skeleton-loader
										class="mt-6"
										type="button"
									/>
								</v-col>
							</v-row>
						</v-col>
					</v-row>
				</v-col>
			</v-row>
		</v-col>
		<!-- tabs -->
		<v-col cols="12" class="mt-4 px-3" v-if="!$device.isMobile">
			<v-sheet width="100%" color="grey lighten-4" class="rounded">
				<v-sheet
					v-for="index in 3"
					:key="index"
					width="100"
					height="30"
					class="mx-3 my-1 px-2 rounded"
					color="d-inline-block grey lighten-3"
				>
					<v-skeleton-loader class="mt-2" type="text" />
				</v-sheet>
			</v-sheet>
		</v-col>
		<!-- descroption -->
		<v-col cols="12">
			<v-skeleton-loader type="card-heading" />
			<v-skeleton-loader class="mt-1" type="list-item-three-line" />
			<v-skeleton-loader class="mt-1 mx-4" type="text" />
			<v-skeleton-loader class="mt-1" type="list-item-two-line" />
		</v-col>
	</v-row>
</template>
<style lang="scss" scoped>
.section-loading-product {
	.section-star {
		.v-skeleton-loader__avatar.v-skeleton-loader__bone {
			display: inline-block;
			width: 16px;
			height: 16px;
		}
	}
}
</style>
