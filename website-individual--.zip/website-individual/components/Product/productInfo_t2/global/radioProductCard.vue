<template>
	<v-card
		outlined
		class="section-card-properties-info pa-1 font-size-14 d-inline-block grey--text text--darken-3"
		:min-width="propsMember.name ? 100 : 0"
		:max-width="propsMember.name ? 100000000 : 75"
		v-ripple
	>
		<v-row justify="center">
			<v-col
				class="py-0 px-4 text-no-wrap"
				v-if="propsMember.name"
				v-text="propsMember.name"
			/>
			<v-col class="py-0" v-if="propsMember.img && propsMember.name">
				<v-img
					:src="
						propsMember.img.startsWith(`http`) ||
						propsMember.img.startsWith(`storage/`)
							? propsMember.img.startsWith(`storage/`)
								? getDomain + propsMember.img
								: propsMember.img
							: `${getDomain}storage/${propsMember.img}`
					"
					:contain="true"
					width="20"
					height="20"
				/>
			</v-col>
			<v-col cols="12" class="py-0" v-else-if="propsMember.img">
				<v-img
					:src="
						propsMember.img.startsWith(`http`) ||
						propsMember.img.startsWith(`storage/`)
							? propsMember.img.startsWith(`storage/`)
								? getDomain + propsMember.img
								: propsMember.img
							: `${getDomain}storage/${propsMember.img}`
					"
					:contain="true"
					width="100"
				/>
			</v-col>
		</v-row>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["propsMember"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
