<template>
	<v-card-text class="px-0 py-1 px-sm-3">
		<v-row :no-gutters="$device.isMobile">
			<v-col
				cols="auto"
				class="pt-0 pb-2 font-size-18 font-weight-bold text--darken-3 grey--text"
				v-if="$device.isMobile && getVoices && getVoices.data"
				v-text="$t('productInfo.tabs.play')"
			/>
			<v-col
				cols="12"
				:class="[
					'rounded mb-1',
					{ 'grey lighten-4': !$device.isMobile },
				]"
				v-if="getVideos && getVideos.data && getVideos.data.length"
			>
				<v-row>
					<v-col
						cols="12"
						v-if="getVideos.data && getVideos.data.length"
						:class="[
							'px-0 px-sm-3 pt-sm-0 font-size-19',
							{ 'text-center': $device.isMobile },
						]"
						v-text="$t('productInfo.tabs.videos')"
					>
					</v-col>
					<template v-for="(videoOne, index) in getVideos.data">
						<v-col
							cols="12"
							class="py-1"
							:key="index"
							v-if="videoOne"
						>
							<videoAction
								:videoOne="videoOne"
								v-if="videoOne.file != null"
							/>
							<nonSale :itemSale="videoOne" v-else />
						</v-col>
					</template>
				</v-row>
			</v-col>
			<v-col
				cols="12"
				:class="['rounded', { 'grey lighten-4': !$device.isMobile }]"
				v-if="getVoices && getVoices.data && getVoices.data.length"
			>
				<v-row>
					<v-col
						v-if="getVoices.data"
						:class="[
							'px-0 px-sm-3 pt-sm-0 font-size-19',
							{ 'text-center': $device.isMobile },
						]"
						v-text="$t('productInfo.tabs.voices')"
					/>
					<client-only>
						<template v-for="(item, index) in getVoices.data">
							<v-col
								cols="12"
								class="py-1"
								:key="index"
								v-if="item"
							>
								<voiceAction
									:voiceOne="item"
									v-if="item.file != null"
								/>
								<nonSale :itemSale="item" v-else />
							</v-col>
						</template>
					</client-only>
				</v-row>
			</v-col>
		</v-row>
		<buyVip />
	</v-card-text>
</template>

<script>
import { mapGetters } from "vuex";
import videoAction from "@/components/Product/productInfo_t2/tabs/downloads/videoAction";
import voiceAction from "@/components/Product/productInfo_t2/tabs/downloads/voiceAction";
import nonSale from "@/components/Product/productInfo_t2/tabs/downloads/nonSale";
import buyVip from "@/components/Product/productInfo_t2/buyVip";
export default {
	components: {
		videoAction,
		voiceAction,
		nonSale,
		buyVip,
	},
	computed: {
		...mapGetters({
			getVideos: "productInfo/getVideos",
			getVoices: "productInfo/getVoices",
		}),
	},
	props: ["tabItems"],
};
</script>
