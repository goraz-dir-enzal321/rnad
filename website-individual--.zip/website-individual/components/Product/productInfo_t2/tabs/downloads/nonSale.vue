<template>
	<v-card outlined class="section-downloads-sale overflow-hidden">
		<v-row class="px-3">
			<v-col cols="3" sm="2" lg="1" class="pa-1">
				<v-sheet
					:width="$device.isMobile ? '50px' : '75px'"
					:min-height="$device.isMobile ? '50px' : '75px'"
					class="d-flex justify-center align-center rounded section-blur-box"
					:color="AllColors.site_color"
				>
					<v-img
						v-if="itemSale && itemSale.img"
						:height="$device.isMobile ? '50px' : '75px'"
						class="rounded blur-3"
						:src="
							itemSale.img.startsWith(`http`) ||
							itemSale.img.startsWith(`storage/`)
								? itemSale.img.startsWith(`storage/`)
									? getDomain + itemSale.img
									: itemSale.img
								: `${getDomain}storage/${itemSale.img}`
						"
					/>
					<div class="section-blur-circle text-center white--text">
						<v-icon dark v-text="'mdi-lock-outline'" />
					</div>
				</v-sheet>
			</v-col>
			<v-col
				cols="auto"
				sm="9"
				class="pa-1 d-flex"
				v-if="itemSale.desc || itemSale.duration"
			>
				<v-row no-gutters class="flex-grow-1" align="center">
					<v-col
						cols="12"
						class="py-0 px-2 font-size-14 grey--text text--darken-2"
						v-if="itemSale.duration || itemSale.duration == 0"
						v-text="itemSale.desc"
					/>
				</v-row>
			</v-col>
			<v-col
				cols="12"
				class="pa-1 d-flex align-center justify-end"
				v-if="$device.isMobile"
			>
				<v-btn
					dark
					@click="
						$store.dispatch('productInfo/setDialogStatusVip', true)
					"
					small
					class="darken-4 white--text col flex-shrink-1 py-1"
					:color="AllColors.site_color"
					style="color: white;"
					depressed
				>
					<span
						class="d-inline-block"
						:class="$vuetify.rtl ? 'ml-1 ml-sm-5' : 'mr-1 mr-sm-5'"
						v-text="$t('button.buy')"
					/>
					<v-icon
						color="white"
						right
						v-text="'mdi-shopping-outline'"
					/>
				</v-btn>
				<v-btn
					dark
					@click="$store.commit('loginCard/SET_STATUS', 1)"
					small
					class="col col-5 darken-4 white--text ms-1 py-1"
					:color="AllColors.site_color"
					style="color: white;"
					depressed
					v-if="!isAuth"
				>
					<span v-text="$t('productInfo.hasAlreadyPurchased')" />
				</v-btn>
			</v-col>
			<v-sheet
				class="section-moved-sale"
				v-else
				:color="AllColors.site_color"
			>
				<v-btn
					fab
					dark
					small
					class="darken-4 mx-2 section-moved-lock"
					color="white"
					depressed
				>
					<v-icon
						:style="{ color: AllColors.site_color }"
						v-text="'mdi-lock'"
					/>
				</v-btn>
				<div
					class="d-inline-block section-moved-buy"
					:class="isAuth ? 'section-has-auth-to-move' : null"
				>
					<v-btn
						dark
						@click="$store.commit('loginCard/SET_STATUS', 1)"
						small
						class="darken-4 py-5 rounded-r-pill"
						color="white"
						:style="{ color: AllColors.site_color }"
						v-if="!isAuth"
						v-text="$t('productInfo.hasAlreadyPurchased')"
						depressed
					/><v-btn
						dark
						@click="
							$store.dispatch(
								'productInfo/setDialogStatusVip',
								true
							)
						"
						small
						class="darken-4 py-5"
						:class="isAuth ? 'rounded-pill' : 'rounded-l-pill'"
						color="white"
						:style="{ color: AllColors.site_color }"
						depressed
					>
						<span
							:class="
								$vuetify.rtl ? 'ml-1 ml-sm-5' : 'mr-1 mr-sm-5'
							"
							v-text="$t('button.buy')"
						/>
						<v-icon
							:style="{ color: AllColors.site_color }"
							v-text="'mdi-shopping-outline'"
						/>
					</v-btn>
				</div>
			</v-sheet>
		</v-row>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["itemSale"],
	data: () => ({
		overlay: false,
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getDomain: "siteSetting/getDomain",
			isAuth: "isAuth",
		}),
	},
};
</script>
