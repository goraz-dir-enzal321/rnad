<template>
	<v-card-text class="pa-0 pa-sm-3">
		<v-row>
			<dataExplanation :textDescription="getExplanation.data" />
			<v-col
				cols="12"
				class="pt-0 pb-1"
				v-if="$device.isMobile && getVideo && getVideo.file"
				@click.prevent.stop="() => null"
			>
				<div
					v-if="getVideo.title"
					class="ms-2 mb-2"
					v-html="getVideo.title"
				/>
				<vue-plyr class="mb-3">
					<video controls>
						<source
							:src="
								getVideo.file.startsWith(`http`) ||
								getVideo.file.startsWith(`storage/`)
									? getVideo.file.startsWith(`storage/`)
										? getDomain + getVideo.file
										: getVideo.file
									: `${getDomain}storage/${getVideo.file}`
							"
							type="video/mp4"
						/>
						Your browser does not support the video tag.
					</video>
				</vue-plyr>
			</v-col>
			<v-col cols="12" class="pt-0 pb-1" v-if="getVoice && getVoice.file">
				<div
					v-if="getVoice.title"
					class="ms-2 mb-2"
					v-html="getVoice.title"
					@click.prevent.stop="() => null"
				/>

				<v-row no-gutters class="direction-rtl">
					<v-col
						class="plyr-download mb-3"
						cols="auto"
						@click.stop="() => null"
						v-if="isCanDownload"
					>
						<v-sheet
							:color="
								getSiteColor.color
									? getSiteColor.color
									: 'grey darken-3'
							"
							class="rounded-l-0 rounded-r"
							height="100%"
							width="100%"
						>
							<a
								:href="
									getVoice.file.startsWith(`http`) ||
									getVoice.file.startsWith(`storage/`)
										? getVoice.file.startsWith(`storage/`)
											? getDomain + getVoice.file
											: getVoice.file
										: `${getDomain}storage/${getVoice.file}`
								"
								class="text-decoration-none d-inline-flex justify-center align-center"
								download
								target="_blank"
							>
								<v-icon>mdi-download</v-icon>
							</a>
						</v-sheet>
					</v-col>
					<v-col
						class="flex-shrink-1"
						@click.prevent.stop="() => null"
					>
						<vue-plyr
							:class="['mb-3', { 'rounded-r-0': isCanDownload }]"
						>
							<audio
								controls
								:style="{
									'--plyr-audio-controls-background': getSiteColor.color
										? getSiteColor.color
										: 'grey darken-3',
								}"
							>
								<source
									:src="
										getVoice.file.startsWith(`http`) ||
										getVoice.file.startsWith(`storage/`)
											? getVoice.file.startsWith(
													`storage/`
											  )
												? getDomain + getVoice.file
												: getVoice.file
											: `${getDomain}storage/${getVoice.file}`
									"
									type="audio/mpeg"
								/>
							</audio>
						</vue-plyr>
					</v-col>
				</v-row>
			</v-col>
			<v-col cols="12" class="pt-0 pb-1" v-if="getFile && getFile.file">
				<a
					@click.stop="() => null"
					target="_blank"
					class="text-decoration-none"
					:href="
						getFile.file.startsWith(`http`) ||
						getFile.file.startsWith(`storage/`)
							? getFile.file.startsWith(`storage/`)
								? getDomain + getFile.file
								: getFile.file
							: `${getDomain}storage/${getFile.file}`
					"
					download
				>
					<v-btn
						block
						rounded
						large
						depressed
						:color="
							getSiteColor.color
								? getSiteColor.color
								: 'grey darken-3'
						"
						:dark="
							getSiteColor.color
								? !$wc_hex_is_light(getSiteColor.color)
								: true
						"
						:light="
							getSiteColor.color
								? $wc_hex_is_light(getSiteColor.color)
								: false
						"
					>
						<v-icon
							v-if="!$vuetify.rtl"
							v-text="'mdi-download'"
							left
						/>
						<span
							v-text="
								getFile.title
									? getFile.title
									: $t('button.download')
							"
						/>
						<v-icon
							v-if="$vuetify.rtl"
							v-text="'mdi-download'"
							right
						/>
					</v-btn>
				</a>
			</v-col>
		</v-row>
	</v-card-text>
</template>
<script>
import { mapGetters } from "vuex";
import dataExplanation from "@/components/Product/productInfo_t2/tabs/explanation/dataExplanation";

export default {
	props: ["OnSheet"],
	components: {
		dataExplanation,
	},
	data: () => ({
		isCanDownload: false,
	}),
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getExplanation: "productInfo/getExplanation",
			getVoice: "productInfo/getVoice",
			getVideo: "productInfo/getVideo",
			getOptions: "productInfo/getOptions",
			getFile: "productInfo/getFile",
			getSiteColor: "siteSetting/getSiteColor",
		}),
	},
};
</script>
