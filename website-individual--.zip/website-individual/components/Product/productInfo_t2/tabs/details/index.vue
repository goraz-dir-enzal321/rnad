<template>
	<v-card-text v-if="getDetails && getDetails.data" class="pa-0 pt-2 pa-sm-3">
		<v-row>
			<template v-if="$device.isMobile">
				<v-col
					cols="auto"
					class="pt-0 pb-2 font-size-18 font-weight-bold text--darken-3 grey--text"
					v-if="getDetails.data && getDetails.data.length"
					v-text="$t('productInfo.tabs.details')"
				/>
				<v-spacer></v-spacer>
				<v-col
					cols="auto"
					class="pt-0 pb-2 light-blue--text"
					v-if="getDetails.data && getDetails.data.length > 3"
				>
					{{ $t("productInfo.more") }}
					<v-icon
						class="light-blue--text"
						v-text="
							$vuetify.rtl
								? 'mdi-chevron-left'
								: 'mdi-chevron-right'
						"
					/>
				</v-col>
				<v-col
					cols="12"
					class="pt-0 pb-2 px-3 overflow-y-hidden pos-relative"
					:style="
						getDetails.data && getDetails.data.length > 3
							? 'height: 95px;'
							: null
					"
				>
					<template v-for="(details, index) in getDetails.data">
						<dataDetails
							:details="details"
							v-if="$device.isMobile"
							:key="index"
						/>
					</template>
					<div
						v-if="getDetails.data && getDetails.data.length > 3"
						class="section-less-show-shadow-bottom pos-absolute top-0 left-0 right-0 h-100"
					/>
				</v-col>
				<v-bottom-sheet
					v-model="sheetComputed"
					v-if="getDetails.data && getDetails.data.length > 3"
				>
					<v-sheet
						class="overflow-x-hidden overflow-y rounded-top-16 py-2 px-1 font-size-16 font-weight-light"
						max-height="90vh"
					>
						<v-row no-gutters>
							<div
								v-if="
									getDetails.data &&
									getDetails.data.length > 3
								"
								class="px-3 py-1 font-size-20 font-weight-medium"
								v-text="$t('productInfo.tabs.details')"
							/>
							<v-spacer></v-spacer>
							<v-btn
								depressed
								color="grey"
								text
								class="ps-3 py-1 text--darken-3 font-weight-medium"
								@click="sheetComputed = false"
							>
								<span class="me-n2 d-inline-block">
									{{ $t("productInfo.back") }}
								</span>
								<v-icon right v-text="'mdi-chevron-left'" />
							</v-btn>
							<v-col
								cols="12"
								class="px-3 py-1"
								v-if="
									getDetails.data &&
									getDetails.data.length > 3
								"
							>
								<v-divider />
							</v-col>
						</v-row>
						<template v-for="(details, index) in getDetails.data">
							<v-col
								cols="12"
								class="pt-0 pb-2 px-3"
								:key="index"
							>
								<dataDetails
									:details="details"
									v-if="$device.isMobile"
								/>
							</v-col>
						</template>
					</v-sheet>
					<div class="nothing">{{ openSheet }}</div>
				</v-bottom-sheet>
			</template>
			<template v-else v-for="(details, index) in getDetails.data">
				<v-col cols="12" class="py-1" :key="index">
					<dataDetails :details="details" />
				</v-col>
			</template>
		</v-row>
	</v-card-text>
</template>
<script>
import { mapGetters } from "vuex";
import dataDetails from "@/components/Product/productInfo_t2/tabs/details/dataDetails";
export default {
	data: () => ({
		sheet: false,
	}),
	components: {
		dataDetails,
	},
	computed: {
		...mapGetters({
			getDetails: "productInfo/getDetails",
			getOpenSheetDetails: "productInfo/getOpenSheetDetails",
		}),
		sheetComputed: {
			get() {
				return this.sheet;
			},
			set(value) {
				this.sheet = value;
				this.$store.dispatch("productInfo/setOpenSheetDetails", value);
			},
		},
		openSheet() {
			this.sheetComputed = this.getOpenSheetDetails;
		},
	},
};
</script>
