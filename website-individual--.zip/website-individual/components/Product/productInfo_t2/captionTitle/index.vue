<template>
	<Fragment>
		<p
			class="ma-0 font-weight-medium pb-0"
			:class="[
				$device.isMobile ? 'font-size-21' : 'font-size-23',
				$vuetify.rtl ? 'pr-3' : 'pl-3',
			]"
			v-text="getOptions.name"
		/>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	components: { Fragment },
	computed: { ...mapGetters({ getOptions: "productInfo/getOptions" }) },
};
</script>
