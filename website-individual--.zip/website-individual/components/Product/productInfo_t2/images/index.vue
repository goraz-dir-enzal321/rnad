<template>
	<v-col cols="12" sm="5" v-if="Boolean(Object.keys(getImage))">
		<!-- gallery -->
		<!-- if (on moblile) -->
		<template v-if="$device.isMobile">
			<v-carousel
				v-if="getImage.gallery && getImage.gallery.length"
				:show-arrows="false"
				class="rounded-16"
				:cycle="true"
				interval="5000"
				height="300px"
			>
				<template v-for="(slide, index) in getImage.gallery">
					<v-carousel-item
						v-if="slide && slide.img"
						:ripple="false"
						:key="`slider_${
							slide.id ? slide.id : 'notHaveId' + index
						}`"
						:href="slide.link ? slide.link : 'javascript:void(0)'"
						:target="
							slide.link
								? slide.link.startsWith(getDomain)
									? 'self'
									: 'blank'
								: null
						"
					>
						<v-img
							width="100%"
							height="100%"
							:contain="false"
							class="grey lighten-1"
							:src="
								slide.img.startsWith(`http`) ||
								slide.img.startsWith(`storage/`)
									? slide.img.startsWith(`storage/`)
										? getDomain + slide.img
										: slide.img
									: `${getDomain}storage/${slide.img}`
							"
							:lazy-src="
								slide.img.startsWith(`http`) ||
								slide.img.startsWith(`storage/`)
									? slide.img.startsWith(`storage/`)
										? getDomain + slide.img
										: slide.img
									: `${getDomain}storage/${slide.img}`
							"
							draggable="false"
						>
						</v-img>
					</v-carousel-item>
				</template>
			</v-carousel>
			<v-img
				v-else-if="getImage.image"
				:src="
					getImage.image.startsWith(`http`) ||
					getImage.image.startsWith(`storage/`)
						? getImage.image.startsWith(`storage/`)
							? getDomain + getImage.image
							: getImage.image
						: `${getDomain}storage/${getImage.image}`
				"
				:lazy-src="
					getImage.thumbnail
						? getImage.thumbnail.startsWith(`http`) ||
						  getImage.thumbnail.startsWith(`storage/`)
							? getImage.thumbnail.startsWith(`storage/`)
								? getDomain + getImage.thumbnail
								: getImage.thumbnail
							: `${getDomain}storage/${getImage.thumbnail}`
						: getImage.image.startsWith(`http`) ||
						  getImage.image.startsWith(`storage/`)
						? getImage.image.startsWith(`storage/`)
							? getDomain + getImage.image
							: getImage.image
						: `${getDomain}storage/${getImage.image}`
				"
				aspect-ratio="1"
				class="grey lighten-2 rounded"
				max-width="100%"
			></v-img>
		</template>
		<!-- * if (on desktop) -->
		<v-row justify="center" v-if="!$device.isMobile">
			<v-col cols="9" v-if="getImage.image" class="pos-relative">
				<client-only>
					<pic-zoom
						:height="360"
						class="rounded w-100"
						:idForSetElement="`bigImage`"
						:imageThumb="
							getImage.image.startsWith(`http`) ||
							getImage.image.startsWith(`storage/`)
								? getImage.image.startsWith(`storage/`)
									? getDomain + getImage.image
									: getImage.image
								: `${getDomain}storage/${getImage.image}`
						"
						:imageHires="
							getImage.hires
								? getImage.hires.startsWith(`http`) ||
								  getImage.hires.startsWith(`storage/`)
									? getImage.hires.startsWith(`storage/`)
										? getDomain + getImage.hires
										: getImage.hires
									: `${getDomain}storage/${getImage.hires}`
								: getImage.image
								? getImage.image.startsWith(`http`) ||
								  getImage.image.startsWith(`storage/`)
									? getImage.image.startsWith(`storage/`)
										? getDomain + getImage.image
										: getImage.image
									: `${getDomain}storage/${getImage.image}`
								: null
						"
						:scale="3"
					></pic-zoom>
				</client-only>
			</v-col>
			<!-- <v-col cols="12">  On this \/-->
			<ListGallery
				v-if="
					(getImage.gallery && getImage.gallery.length) ||
					(getVideo && getVideo.file)
				"
			/>
			<!-- </v-col> -->
		</v-row>
		<dialogImages />
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import ListGallery from "@/components/Product/productInfo_t2/images/ListGallery";
import picZoom from "@/components/Product/productInfo_t2/images/picZoom";
import dialogImages from "@/components/Product/productInfo_t2/images/dialogImages";
export default {
	components: {
		ListGallery,
		dialogImages,
		picZoom,
	},
	data: () => ({
		gallery: null,
	}),
	computed: {
		...mapGetters({
			getImage: "productInfo/getImage",
			getDomain: "siteSetting/getDomain",
			isAuth: "isAuth",
			getVideo: "productInfo/getVideo",
		}),
	},
};
</script>
