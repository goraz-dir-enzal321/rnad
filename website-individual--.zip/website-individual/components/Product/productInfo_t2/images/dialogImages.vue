<template>
	<v-dialog v-model="dialogComputed" max-width="750px">
		<v-card>
			<v-row no-gutters>
				<v-col cols="10" class="py-2">
					<v-card-title
						class="font-size-24 font-weight-medium py-0"
						v-text="$t('productInfo.images.gallery')"
					/>
				</v-col>
				<v-col cols="2" class="text-center py-2 d-flex justify-end">
					<v-btn
						class="mx-4"
						color="error"
						icon
						@click="dialogComputed = false"
					>
						<v-icon>mdi-close</v-icon>
					</v-btn>
				</v-col>
				<v-col cols="12" class="pb-1">
					<v-divider></v-divider>
				</v-col>
				<v-col cols="6" class="pa-2 pos-relative overflow-hidden">
					<pic-zoom
						v-if="gallerySelected && gallerySelected.img"
						:height="360"
						class="grey lighten-2 rounded"
						:idForSetElement="`gallery_image_${gallerySelected.id}`"
						:imageThumb="
							gallerySelected.img.startsWith(`http`) ||
							gallerySelected.img.startsWith(`storage/`)
								? gallerySelected.img.startsWith(`storage/`)
									? getDomain + gallerySelected.img
									: gallerySelected.img
								: `${getDomain}storage/${gallerySelected.img}`
						"
						:imageHires="
							gallerySelected.hires
								? gallerySelected.hires.startsWith(`http`) ||
								  gallerySelected.hires.startsWith(`storage/`)
									? gallerySelected.hires.startsWith(
											`storage/`
									  )
										? getDomain + gallerySelected.hires
										: gallerySelected.hires
									: `${getDomain}storage/${gallerySelected.hires}`
								: gallerySelected.img
								? gallerySelected.img.startsWith(`http`) ||
								  gallerySelected.img.startsWith(`storage/`)
									? gallerySelected.img.startsWith(`storage/`)
										? getDomain + gallerySelected.img
										: gallerySelected.img
									: `${getDomain}storage/${gallerySelected.img}`
								: null
						"
						:scale="3"
					></pic-zoom>
				</v-col>
				<v-col cols="6" class="pa-2">
					<radioProduct
						:indexProduct="null"
						:isIndexProduct="false"
						:productMembers="getImage.gallery"
						:defaultAttr="gallerySelected.id"
						saveSelected="setGallerySelected"
						:isMore="false"
					/>
				</v-col>
			</v-row>
		</v-card>
		<div class="nothing" v-text="watchDialogStatus" />
	</v-dialog>
</template>

<script>
import radioProduct from "@/components/Product/productInfo_t2/global/radioProduct";
import picZoom from "@/components/Product/productInfo_t2/images/picZoom";
import { mapGetters } from "vuex";
export default {
	components: { radioProduct, picZoom },
	data: () => ({
		dialog: false,
	}),
	computed: {
		...mapGetters({
			getDialogStatus: "productInfo/getDialogStatus",
			gallerySelected: "productInfo/getGallerySelected",
			getImage: "productInfo/getImage",
			getDomain: "siteSetting/getDomain",
		}),
		dialogComputed: {
			get() {
				return this.dialog;
			},
			set(value) {
				this.$store.dispatch("productInfo/setDialogStatus", value);
				this.dialog = value;
			},
		},
		watchDialogStatus() {
			this.dialogComputed = this.getDialogStatus;
		},
	},
};
</script>
