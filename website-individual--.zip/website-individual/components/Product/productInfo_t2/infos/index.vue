<template>
	<!-- <- image & controles -->
	<v-col
		cols="12"
		sm="6"
		class="pt-0"
		:class="{
			'order-2 pb-0': $device.isMobile,
			'order-1': !$device.isMobile,
		}"
	>
		<v-col v-if="!$device.isMobile" cols="12" class="px-0 pt-0"
			><v-divider
		/></v-col>
		<!-- category -->
		<v-card
			:outlined="$device.isMobile ? true : false"
			:elevation="$device.isMobile ? 2 : 0"
			v-if="getOptions && getOptions.category"
			class="rounded-16 py-1 mb-2 mb-md-0"
		>
			<v-row class="px-3 px-md-0 px-sm-2" align="center">
				<v-col
					cols="auto"
					class="py-2 px-3 grey--text text--darken-4 font-size-17 font-weight-bold"
				>
					Category:
				</v-col>
				<v-col
					cols="auto"
					class="py-2 px-3 light-blue--text"
					v-text="getOptions.category"
				/>
			</v-row>
		</v-card>
		<!-- /category -->
		<!-- properties -->
		<template v-for="(properties, index) in getProperties">
			<selects
				v-if="
					properties &&
					properties.type &&
					properties.members &&
					properties.members.length
				"
				:properties="properties"
				:key="`getProperties-${properties.id}-${index}`"
			/>
		</template>
		<!-- properties -->
	</v-col>
</template>

<script>
import selects from "@/components/Product/productInfo_t2/infos/selects";
import { mapGetters } from "vuex";
export default {
	components: {
		selects,
	},
	computed: {
		...mapGetters({
			getProperties: "productInfo/getProperties",
			getOptions: "productInfo/getOptions",
		}),
	},
};
</script>
