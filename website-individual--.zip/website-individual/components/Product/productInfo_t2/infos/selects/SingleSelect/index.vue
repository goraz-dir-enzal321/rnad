<template>
	<Fragment>
		<!-- change properties & see properties-->
		<v-col
			cols="auto"
			md="12"
			class="light-blue--text section-properties-box py-0"
			v-if="properties.members && properties.members.length != 0"
		>
			<!-- change properties -> open sheet (mobile == true) -> header & card of propery-->
			<template v-if="$device.isMobile && getPropertySelected">
				<selectedProperties
					:isOnTopSheet="false"
					:propertySelected="
						getPropertySelected.find(
							item => item.parent_id == properties.id
						)
					"
				/>
				<v-bottom-sheet v-model="setSheet">
					<v-sheet
						class="text-center section-properties-radio overflow-x-hidden overflow-y"
						max-height="90vh"
					>
						<!-- header & card of propery -->
						<v-row class="px-4">
							<!-- haeder -> title & see which property select -->
							<v-col cols="12">
								<selectedProperties
									:propertiesName="properties.name"
									:propertySelected="
										getPropertySelected.find(
											item =>
												item.parent_id == properties.id
										)
									"
								/>
							</v-col>
							<v-col cols="12" class="pa-0">
								<v-divider />
							</v-col>
							<!-- /haeder -->
							<!-- card of propery -->
							<v-col cols="12">
								<!-- it's radio butten \/ -->
								<radioProduct
									:indexProduct="properties.id"
									:isIndexProduct="true"
									:productMembers="properties.members"
									:defaultAttr="properties.members[0].id"
									saveSelected="setPropertySelected"
									nameComponent="radioProperties"
									:isMore="false"
								/>
							</v-col>
							<!-- /card of propery -->
						</v-row>
						<!-- /header & card of propery -->
					</v-sheet>
				</v-bottom-sheet>
			</template>
			<!-- /change properties (if on moblile)-->
			<!-- change properties -> open sheet (if on desktop)-->
			<template v-else>
				<radioProduct
					:indexProduct="properties.id"
					:isIndexProduct="true"
					:productMembers="properties.members"
					:defaultAttr="properties.members[0].id"
					saveSelected="setPropertySelected"
					:isMore="true"
				/>
				<!-- nameComponent="radioProperties" -->
			</template>
			<!-- /change properties (if on desktop)-->
		</v-col>
		<v-spacer v-if="$device.isMobile" />
		<v-col
			v-if="$device.isMobile"
			cols="auto"
			class="grey--text text--darken-2 section-properties-box font-size-13 pt-1 pb-0"
		>
			({{ properties.members.length }}
			{{ $t("productInfo.more") }})<v-icon>mdi-chevron-down</v-icon>
		</v-col>
		<div class="nothing">{{ openSheetPropertiesComputed }}</div>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
import radioProduct from "@/components/Product/productInfo_t2/global/radioProduct";
import selectedProperties from "@/components/Product/productInfo_t2/infos/selects/SingleSelect/selectedProperties";

export default {
	components: { radioProduct, selectedProperties, Fragment },
	props: ["properties"],
	data: () => ({
		sheet: false,
	}),
	computed: {
		...mapGetters({
			getOpenSheetProperties: "productInfo/getOpenSheetProperties",
			getPropertySelected: "productInfo/getPropertySelected",
		}),
		setSheet: {
			get() {
				if (this.sheet == false) {
					this.$store.dispatch("productInfo/setOpenSheetProperties", {
						status: this.sheet,
						id: this.properties.id,
					});
				}
				return this.sheet;
			},
			set(value) {
				this.sheet = value;
			},
		},
		openSheetPropertiesComputed() {
			if (this.properties.id == this.getOpenSheetProperties.id)
				this.setSheet = this.getOpenSheetProperties.status;
		},
	},
	created() {
		let send_setPropertySelected = {
			id: this.properties.id,
			data: this.properties.members[0],
		};
		this.$store.dispatch(
			"productInfo/setPropertySelected",
			send_setPropertySelected
		);
	},
};
</script>
