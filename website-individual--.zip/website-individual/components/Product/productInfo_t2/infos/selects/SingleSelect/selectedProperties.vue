<template>
	<v-row
		align="center"
		class="px-2 pt-1 font-size-14 grey--text text--darken-3"
		:class="{ 'pt-1': isOnTopSheet == false, 'py-1': isOnTopSheet == true }"
	>
		<!-- title -->
		<v-col
			v-if="propertiesName"
			cols="auto"
			class="font-size-17 font-weight-bold black--text py-sm-0 py-0"
			v-text="propertiesName + ':'"
		/>
		<!-- /title -->
		<!-- property selected -> text || title  & img-->
		<!-- text || title -->
		<v-col
			cols="auto"
			class="pa-0"
			:class="{ 'order-2 px-3': isOnTopSheet == false }"
			v-text="propertySelected.name"
		/>
		<!-- /text || title -->
		<v-spacer></v-spacer>
		<!-- img -->
		<v-col
			cols="auto"
			class="py-0"
			:class="{ 'px-0 order-1': isOnTopSheet == false }"
			v-if="propertySelected.img"
		>
			<v-img
				:src="
					propertySelected.img.startsWith(`http`) ||
					propertySelected.img.startsWith(`storage/`)
						? propertySelected.img.startsWith(`storage/`)
							? getDomain + propertySelected.img
							: propertySelected.img
						: `${getDomain}storage/${propertySelected.img}`
				"
				:contain="true"
				width="20"
				height="20"
			/>
		</v-col>
		<!-- /img -->
		<!-- /property selected-->
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["propertySelected", "propertiesName", "isOnTopSheet"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
