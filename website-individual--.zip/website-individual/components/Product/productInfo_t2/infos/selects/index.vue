<template>
	<v-card
		:outlined="$device.isMobile ? true : false"
		:elevation="$device.isMobile ? 2 : 0"
		v-if="properties && properties.members"
		v-ripple="
			$device.isMobile
				? properties.type == 'CHECKBOX'
					? false
					: true
				: false
		"
		class="rounded-16 section-card-properties py-1 mb-2 mb-md-0"
		@click="
			properties.type == 'RADIOBUTTON'
				? $store.dispatch('productInfo/setOpenSheetProperties', {
						status: true,
						id: properties.id,
				  })
				: null
		"
	>
		<v-row class="py-2 px-3 pa-md-0">
			<!-- title -->
			<v-col
				cols="auto"
				class="font-size-17 font-weight-bold grey--text text--darken-4 py-sm-0 py-0"
				v-text="properties.name + ':'"
			/>
			<template v-if="properties.type == 'RADIOBUTTON'">
				<SingleSelect :properties="properties" />
			</template>
			<template v-else-if="properties.type == 'CHECKBOX'">
				<MultiSelect :properties="properties" />
			</template>
		</v-row>
	</v-card>
</template>

<script>
import SingleSelect from "@/components/Product/productInfo_t2/infos/selects/SingleSelect";
import MultiSelect from "@/components/Product/productInfo_t2/infos/selects/MultiSelect";
export default {
	props: ["properties"],
	components: {
		SingleSelect,
		MultiSelect,
	},

	data: () => ({
		sheet: false,
	}),
};
</script>
