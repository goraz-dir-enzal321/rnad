<template>
	<Fragment>
		<!-- change properties & see properties-->
		<v-col
			cols="auto"
			md="12"
			class="light-blue--text section-properties-box py-0"
			v-if="properties.members && properties.members.length != 0"
		>
			<!-- change properties -> open sheet (mobile == true) -> header & card of propery-->
			<template v-for="(prop, index) in properties.members">
				<v-checkbox
					class="mt-0 v-input--hide-details"
					dense
					v-model="selectedComputed"
					:key="index"
					:label="prop.name"
					:value="prop.id"
				/>
			</template>
			<!-- /change properties (if on desktop)-->
		</v-col>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	props: ["properties"],
	components: {
		Fragment,
	},
	data: () => ({
		selected: [],
	}),
	computed: {
		...mapGetters({}),
		selectedComputed: {
			get() {
				return this.selected;
			},
			set(value) {
				this.selected = value;

				for (let j = 0; j < this.properties.members.length; j++) {
					const element = this.properties.members[j];
					if (
						Array.isArray(value) ||
						(!Array.isArray(value) && element.id == value)
					) {
						if (j == 0) {
							this.$store.dispatch(
								"productInfo/setPropertySelected",
								{
									id: this.properties.id,
									type: "empty",
								}
							);
						}
						if (value.find(item => element.id == item))
							this.$store.dispatch(
								"productInfo/setPropertySelected",
								{
									id: this.properties.id,
									data: element,
									type: "Multi",
								}
							);
					}
				}
			},
		},
	},
};
</script>
