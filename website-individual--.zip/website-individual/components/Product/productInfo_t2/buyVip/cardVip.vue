<template>
	<v-card
		class="mx-auto font-weight-light grey--text text--darken-2 font-size-14 py-3"
		:style="{
			background: `linear-gradient(to top, ${setColorOnCard(
				optionsBuy.bg_color.trim()
			)}5 , #0000)`,
		}"
		:loading="loading"
		max-width="344"
		v-if="getOptions"
	>
		<v-row
			class="ma-0"
			v-if="
				optionsBuy.name ||
				optionsBuy.description ||
				optionsBuy.products ||
				optionsBuy.price
			"
		>
			<v-col
				cols="12"
				class="py-1 px-3 mb-2 font-size-18 font-weight-bold text-center"
				v-if="optionsBuy.name"
				v-text="optionsBuy.name"
			/>
			<v-col
				cols="12"
				class="py-1 px-3"
				v-if="optionsBuy.price && getOptions.monetary_unit"
			>
				<v-btn
					@click="AddToOrder"
					:loading="loading"
					block
					:dark="!$wc_hex_is_light(optionsBuy.bg_color)"
					class="d-flex"
					:color="setColorOnCard(optionsBuy.bg_color.trim())"
				>
					{{ $t("button.buy") }} <v-spacer />
					<template v-if="optionsBuy.price">
						{{ $numberWithCommas($roundDecimal(optionsBuy.price)) }}
					</template>
					<template v-if="getOptions && getOptions.monetary_unit">
						{{ getOptions.monetary_unit }}
					</template>
				</v-btn>
			</v-col>
			<v-col cols="12" v-if="optionsBuy.expire" class="py-1 px-8">
				<ul class="red--text text--darken-3 font-size-12 pa-0">
					<li
						v-text="
							$t('productInfo.buy.designDuration') +
							' ' +
							optionsBuy.expire +
							' ' +
							$t('productInfo.buy.day')
						"
					/>
				</ul>
			</v-col>
			<v-col
				cols="12"
				class="py-1 px-3"
				v-if="optionsBuy.description"
				v-html="optionsBuy.description"
			/>
			<template
				v-if="optionsBuy.products && optionsBuy.products.length == 1"
			>
				<v-col cols="12" class="pt-1 pb-2 px-3">
					<div
						class="py-1 mb-2 font-size-13"
						v-text="
							$t('productInfo.buy.courses') + optionsBuy.name + ':'
						"
					/>
					<div
						class="liDashbefor font-size-13"
						v-for="(item, index) in optionsBuy.products"
						:key="index"
						v-text="item.name"
					/>
				</v-col>
			</template>
			<detailsVip
				v-else-if="optionsBuy.products && optionsBuy.products.length"
				:propsdetails="optionsBuy.products"
				:colorBg="setColorOnCard(optionsBuy.bg_color.trim())"
				:nameCourses="optionsBuy.name"
				:bg_colorHex6="optionsBuy.bg_color"
			/>
		</v-row>
	</v-card>
</template>

<script>
import detailsVip from "@/components/Product/productInfo_t2/buyVip/detailsVip";
import { mapGetters } from "vuex";
export default {
	props: ["optionsBuy", "loading"],
	components: {
		detailsVip,
	},
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getOptions: "productInfo/getOptions",
			getImage: "productInfo/getImage",
			getSymbolSendPorperties: "productInfo/getSymbolSendPorperties",
			isAuth: "isAuth",
			cart: "shop/cart",
		}),
	},
	methods: {
		async AddToOrder() {
			if (this.getOptions) {
				// BTN_TXT
				// BTN_SEL
				let product = {
					btn_text: "",
					btn_type: "NUMERIC",
					count: 1,
					shopId: this.getOptions.shop_id,
					discount_amount: this.getOptions.discount_amount
						? this.getOptions.discount_amount
						: 0,
					discount_price: this.optionsBuy.price
						? this.optionsBuy.price
						: 0,
					min_count: this.getOptions.min_count
						? this.getOptions.min_count
						: "",
					monetary_unit: this.getOptions.monetary_unit
						? this.getOptions.monetary_unit
						: "",
					name: this.optionsBuy.name
						? this.optionsBuy.name
						: this.getOptions.name
						? this.getOptions.name
						: "",
					price: this.optionsBuy.price ? this.optionsBuy.price : "",

					plan_id: this.optionsBuy.id ? this.optionsBuy.id : 0,
					shopId: this.getOptions.shop_id
						? this.getOptions.shop_id
						: null,
					existence: this.getOptions.existence
						? this.getOptions.existence
						: "",
					image: this.getImage.image ? this.getImage.image : "",
					thumbnail: this.getOptions.thumbnail
						? this.getOptions.thumbnail
						: this.getOptions.img,
					properties: {},
				};
				// product_id: this.getOptions.product_id? this.getOptions.product_id: "",
				// console.log("JSON.stringify(data to send add cart)|||",JSON.stringify(product));
				if (
					this.cart.some(item =>
						item.plan_id
							? item.plan_id == this.optionsBuy.id
							: false
					)
				) {
					if (this.$device.isDesktopOrTablet) {
						this.$store.dispatch(
							"snackbar/setText",
							this.$t("productInfo.buy.HaveCourseInCart")
						);
						this.$store.dispatch("snackbar/setColor", "info");
						this.$store.dispatch("snackbar/isShow", true);
					}
					this.$store.dispatch("shop/isOpenCart", true);
				} else {
					await this.$store.dispatch("shop/addToCart", {
						product,
						btn_status: "BTN_SEL",
					});
					if (this.isAuth) {
						this.$router.push(
							this.localePath("order", this.$i18n.locale)
						);
					} else {
						this.$store.commit("loginCard/SET_STATUS", 1);
						this.$store.dispatch(
							"loginCard/setGoToOrderPage",
							true
						);
					}
				}
			}
		},
		setColorOnCard(color) {
			var hex = color;
			if (color.length >= 6) {
				if (hex.charAt(1) && hex.charAt(3) && hex.charAt(5)) {
					hex = "#" + hex.charAt(1) + hex.charAt(3) + hex.charAt(5);
					return hex;
				}
			}
			return hex;
		},
	},
};
</script>
