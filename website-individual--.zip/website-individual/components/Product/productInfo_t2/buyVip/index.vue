<template>
	<v-dialog v-model="dialogComputed" max-width="700">
		<v-card :loading="loading">
			<v-row no-gutters>
				<v-col class="py-2 flex-shrink-1" v-if="getOptions.name">
					<v-card-title
						class="font-weight-medium py-1 pe-0"
						:class="
							$device.isMobile
								? 'font-size-18 font-weight-medium'
								: 'font-size-22'
						"
						v-text="getOptions.name"
					/>
				</v-col>
				<v-col
					cols="auto"
					class="text-center pe-2 py-2 d-flex justify-end"
				>
					<v-btn
						class=""
						color="error"
						icon
						:small="$device.isMobile"
						:loading="loading"
						@click="dialogComputed = false"
					>
						<v-icon
							:small="$device.isMobile"
							v-text="'mdi-close'"
						/>
					</v-btn>
				</v-col>
				<v-col cols="12">
					<v-divider />
				</v-col>
			</v-row>
			<v-row
				class="ma-0 px-1 grey--text text--darken-3 overflow-x-hidden"
			>
				<template v-if="getOptions.single_purchase">
					<v-col cols="12" class="py-2">
						<v-card-text
							class="pa-0 text--darken-4"
							v-if="getOptions.description"
							v-html="getOptions.description"
						/>
					</v-col>

					<v-col cols="12" class="py-2">
						<v-card-text
							class="pa-0"
							v-text="
								$t(
									'productInfo.buy.descriptionBuyProductInPlaySection'
								)
							"
						/>
					</v-col>
					<v-col cols="12" class="pa-2 text-center text-center">
						<v-btn
							min-width="50%"
							class="py-2 px-3 font-size-13 rounded-lg text-shadow-low section-btn-buy-in-dialog"
							dark
							:color="AllColors.site_color"
							@click="AddToOrder()"
							style="white-space: unset; height: auto;"
							:style="`border-color: ${AllColors.site_color}30; box-shadow: 0 5px 20px -6px ${AllColors.site_color}`"
						>
							{{
								$t(
									"productInfo.buy.btnBuyProductInPlaySection",
									{
										nameProduct: getOptions.name,
										priceProduct:
											$numberWithCommas(
												$roundDecimal(
													getOptions.discount_price
												)
											) +
											(getCalculationProperty
												? "+"
												: "") +
											" " +
											(getCalculationProperty
												? $numberWithCommas(
														$roundDecimal(
															getCalculationProperty
														)
												  )
												: "") +
											" " +
											getOptions.monetary_unit,
									}
								)
							}}
							<v-icon right size="15">mdi-cart-outline</v-icon>
						</v-btn>
					</v-col>
					<v-col
						cols="12"
						class="py-2"
						v-if="plansItemsData && plansItemsData.length >= 1"
					>
						<v-card-text
							class="pa-0"
							v-text="$t('productInfo.buy.Course_explanation')"
						/>
					</v-col>
				</template>
				<v-col
					cols="12"
					v-if="plansItemsData && plansItemsData.length >= 1"
				>
					<v-row justify="center" class="px-0 px-sm-5">
						<template v-for="(optionsBuy, index) in plansItemsData">
							<v-col
								cols="12"
								sm="6"
								class="py-2"
								v-if="optionsBuy"
								:key="index"
							>
								<cardVip
									:optionsBuy="optionsBuy"
									:loading="loading"
								/>
							</v-col>
						</template>
					</v-row>
				</v-col>
			</v-row>
		</v-card>
		<div class="nothing" v-text="dialogStatusVipComputed" />
	</v-dialog>
</template>

<script>
import cardVip from "@/components/Product/productInfo_t2/buyVip/cardVip";
import { mapGetters } from "vuex";
import { product } from "@/api";
export default {
	components: { cardVip },
	data: () => ({
		dialog: false,
		loading: false,
		plansItemsData: [],
	}),
	computed: {
		...mapGetters({
			AllColors: "siteSetting/AllColors",
			getDialogStatusVip: "productInfo/getDialogStatusVip",
			getCardStyle: "branch/getCardStyle",
			getOptions: "productInfo/getOptions",
			getImage: "productInfo/getImage",
			getSymbolSendPorperties: "productInfo/getSymbolSendPorperties",
			getCalculationProperty: "productInfo/getCalculationProperty",
			isAuth: "isAuth",
			cart: "shop/cart",
		}),
		dialogStatusVipComputed() {
			this.dialogComputed = this.getDialogStatusVip;
		},
		dialogComputed: {
			get() {
				return this.dialog;
			},
			set(value) {
				this.dialog = value;
				this.$store.dispatch("productInfo/setDialogStatusVip", value);
			},
		},
	},
	// {product, btn_status: 'CHECKBOX'} ADD_ITEM
	methods: {
		getDataPlans() {
			let data = {
				product_id: this.getOptions.product_id,
			};
			this.$axios
				.$post(product.getPlans, data)
				.then(res => {
					if (res.status) {
						this.plansItemsData = res.plans;
						this.$store.dispatch(
							"productInfo/setPlansData",
							res.plans
						);
					}
				})
				.catch(err => {
					console.log("Error :>> ", err);
				})
				.finally(() => {
					this.loading = false;
				});
		},
		async AddToOrder() {
			if (this.getOptions) {
				let product = {
					btn_text: "",
					btn_type: "BTN_SEL",
					count: 1,
					shopId: this.getOptions.shop_id,
					discount_amount: this.getOptions.discount_amount
						? this.getOptions.discount_amount
						: 0,
					discount_price: this.getOptions.discount_price
						? this.getOptions.discount_price
						: 0,
					image: this.getImage.image ? this.getImage.image : "",
					min_count: this.getOptions.min_count
						? this.getOptions.min_count
						: 0,
					monetary_unit: this.getOptions.monetary_unit
						? this.getOptions.monetary_unit
						: "",
					name: this.getOptions.name ? this.getOptions.name : "",
					price: this.getOptions.price ? this.getOptions.price : "",
					product_id: this.getOptions.product_id
						? this.getOptions.product_id
						: "",
				};
				// console.log("product :>> ", product);
				if (
					this.cart.some(item =>
						item.product_id
							? item.product_id == this.getOptions.product_id
							: false
					)
				) {
					if (this.$device.isDesktopOrTablet) {
						this.$store.dispatch(
							"snackbar/setText",
							this.$t("productInfo.buy.HaveProductInCart")
						);
						this.$store.dispatch("snackbar/setColor", "error");
						this.$store.dispatch("snackbar/isShow", true);
					}
					this.$store.dispatch("shop/isOpenCart", true);
				} else {
					await this.$store.dispatch("shop/addToCart", {
						product,
						btn_status: "BTN_SEL",
					});
					if (this.isAuth) {
						this.$router.push(
							this.localePath("order", this.$i18n.locale)
						);
					} else {
						this.$store.commit("loginCard/SET_STATUS", 1);
						this.$store.dispatch(
							"loginCard/setGoToOrderPage",
							true
						);
					}
				}
			}
		},
	},
	created() {
		this.loading = true;
		// console.log("this.getCardStyle :>> ", this.getCardStyle);
		this.getDataPlans();
	},
};
</script>
