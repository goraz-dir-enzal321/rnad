<template>
	<v-card
		:max-width="getCardWidth ? getCardWidth : 250"
		:ripple="false"
		nuxt
		:to="localePath(path)"
	>
		<v-img
			:src="`${getDomain}storage/${product.image}`"
			:lazy-src="`${getDomain}storage/${product.image}`"
			v-if="product.image && Boolean(product.image)"
			class="white--text align-center"
			gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
			height="100px"
		>
			<template v-slot:placeholder>
				<v-skeleton-loader class="mx-auto" type="image" />
			</template>
			<v-card-title>{{
				product.title ? product.title : product.name
			}}</v-card-title>
		</v-img>
		<v-img
			src="images/img-default.jpeg"
			class="white--text align-center"
			gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
			height="100px"
			v-else
		>
			<template v-slot:placeholder>
				<v-skeleton-loader class="mx-auto" type="image" />
			</template>
			<v-card-title>{{
				product.title ? product.title : product.name
			}}</v-card-title>
		</v-img>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	props: ["product", "isOpenBranch", "customData", "btnType", "path"],
	computed: {
		...mapGetters({
			getCardWidth: "branch/getCardWidth",
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
