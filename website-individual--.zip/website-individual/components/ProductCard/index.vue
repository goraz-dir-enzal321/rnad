<template>
	<Fragment>
		<client-only>
			<FullPicCard
				v-if="getCardStyle && getCardStyle.web_style == 'FULL_PIC'"
				:product="product"
				:isOpenBranch="isOpenBranch"
				:customData="customData"
				:btnType="btnType"
				:path="checkLocalePath()"
			/>
			<template v-else>
				<v-card
					else
					:color="
						getItemCount(product.id) > 0 ? 'teal lighten-4' : null
					"
					class="fill-height mx-auto mb-0"
					:max-width="getCardWidth ? getCardWidth : 250"
					min-height="350"
					:ripple="false"
					nuxt
					:to="localePath(checkLocalePath())"
				>
					<!--* images -->
					<v-img
						:src="`${getDomain}storage/${product.image}`"
						:lazy-src="`${getDomain}storage/${product.image}`"
						:width="getCardWidth ? getCardWidth : 250"
						:height="getCardWidth ? getCardWidth : 250"
						v-if="product.image && Boolean(product.image)"
					>
						<template v-slot:placeholder>
							<v-skeleton-loader class="mx-auto" type="image" />
						</template>
						<v-layout
							class="fill-height align-end justify-space-between pa-1"
							v-if="(((getStyledProductShop && getStyledProductShop.has_product_voice) &&
							!product.single_purchase) || !(getStyledProductShop && getStyledProductShop.has_product_voice))"
						>
							<v-layout
								class="justify-space-between align-center"
							>
								<v-chip
									class="ma-2"
									color="red"
									outlined
									label
									small
									style="background-color: #fff !important;"
									v-if="product.discount"
									>{{ product.discount.percent }} %</v-chip
								>
								<v-chip
									:class="[
										'ma-2',
										{ 'pl-0': !$vuetify.rtl },
										{ 'pr-0': $vuetify.rtl },
									]"
									color="red"
									outlined
									label
									small
									style="background-color: #fff !important;"
									v-if="product.cRate"
								>
									<v-icon small color class="mx-1"
										>mdi-star</v-icon
									>
									{{ product.cRate }}
								</v-chip>
							</v-layout>
						</v-layout>
						<v-layout
							class="fill-height align-end justify-space-between"
						>
							<v-layout
								class="justify-space-between align-center fill-height"
							>
								<v-row
									v-if="!product.existence"
									align="center"
									justify="center"
									class="text-center pa-2 fill-height repeating-gradient"
									style="
										background-color: rgba(
											255,
											255,
											255,
											0.77
										);
									"
								>
									<v-col>{{ $t("label.not_exist") }}</v-col>
								</v-row>
							</v-layout>
						</v-layout>
					</v-img>
					<v-img src="images/img-default.jpeg" v-else>
						<template v-slot:placeholder>
							<v-skeleton-loader class="mx-auto" type="image" />
						</template>
						<v-layout
							class="fill-height align-end justify-space-between pa-1"
						>
							<v-layout
								class="justify-space-between align-center"
							>
								<v-chip
									class="ma-2"
									color="red"
									outlined
									label
									small
									style="background-color: #fff !important;"
									v-if="product.discount"
									>{{ product.discount.percent }} %</v-chip
								>
								<v-chip
									:class="[
										'ma-2',
										{ 'pl-0': !$vuetify.rtl },
										{ 'pr-0': $vuetify.rtl },
									]"
									color="red"
									outlined
									label
									small
									style="background-color: #fff !important;"
									v-if="product.cRate"
								>
									<v-icon small color class="mx-1"
										>mdi-star</v-icon
									>
									{{ product.cRate }}
								</v-chip>
							</v-layout>
						</v-layout>
						<v-layout
							class="fill-height align-end justify-space-between"
						>
							<v-layout
								class="justify-space-between align-center fill-height"
							>
								<v-row
									v-if="!product.existence"
									align="center"
									justify="center"
									class="text-center pa-2 fill-height repeating-gradient"
									style="
										background-color: rgba(
											255,
											255,
											255,
											0.77
										);
									"
								>
									<v-col>{{ $t("label.not_exist") }}</v-col>
								</v-row>
							</v-layout>
						</v-layout>
					</v-img>
					<!--*/ images -->
					<!--* title of card -->
					<v-card-title
						class="my-0 py-1 font-size-14 font-weight-regular black--text"
						v-if="product.translations.length"
					>
						<template v-for="translate in product.translations">
							<template v-if="translate.locale == $i18n.locale">
								<template v-if="translate.title.length > 35">{{
									translate.title.substring(0, 36) + "..."
								}}</template>
								<template v-else>{{
									translate.title
								}}</template>
							</template>
						</template>
					</v-card-title>
					<v-card-title
						class="my-0 pt-1 font-size-subtitle-1 black--text"
						v-else
						>{{
							product.title ? product.title : product.name
						}}</v-card-title
					>
					<!--*/ title of card -->
					<!--* text of card -->
					<v-card-text
						v-if="(((getStyledProductShop && getStyledProductShop.has_product_voice) &&
							!product.single_purchase) || !(getStyledProductShop && getStyledProductShop.has_product_voice))"
					>
						<div
							class="d-flex flex-row align-center font-size-subtitle-1 black--text"
							v-if="product.price > 0"
						>
							<!-- price unit -->
							<div
								class="grey--text font-size-caption"
								:class="$vuetify.rtl ? 'order-2' : 'order-0'"
							>
								{{
									getMonetaryUnit
										? getMonetaryUnit.find(
												item =>
													item.locale == $i18n.locale
										  ).monetary_unit
										: ""
								}}
							</div>

							<!-- price & discounts -->
							<div
								class="mx-1"
								:class="$vuetify.rtl ? 'order-0' : 'order-1'"
								v-if="product.discount"
							>
								<!-- Boolean(product.minPrice) ? ((100 - product.discount.percent) * product.minPrice) / 100 : ((100 - product.discount.percent) * product.price) / 100 -->
								<template v-if="Boolean(product.minPrice)">{{
									$numberWithCommas(
										(
											product.minPrice -
											(
												(product.minPrice *
													product.discount.percent) /
												100
											).toFixed(2)
										).toFixed(2)
									)
								}}</template>
								<template v-else>{{
									$numberWithCommas(
										(
											product.price -
											(
												(product.price *
													product.discount.percent) /
												100
											).toFixed(2)
										).toFixed(2)
									)
								}}</template>
							</div>
							<div
								class="mx-1"
								:class="$vuetify.rtl ? 'order-0' : 'order-1'"
								v-else
							>
								{{
									Boolean(product.minPrice)
										? $numberWithCommas(
												$roundDecimal(
													product.minPrice
												).toFixed(2)
										  )
										: $numberWithCommas(
												$roundDecimal(
													product.price
												).toFixed(2)
										  )
								}}
							</div>

							<!-- Badge for discounts -->
							<div
								class="d-flex align-center font-size-caption mx-1"
								:class="$vuetify.rtl ? 'order-1' : 'order-2'"
								v-if="product.discount"
							>
								<div
									class="grey--text lighten-1"
									v-if="product.minprice"
								>
									<del>{{
										$numberWithCommas(product.minprice)
									}}</del>
								</div>
								<div class="grey--text lighten-1" v-else>
									<del>{{
										$numberWithCommas(product.price)
									}}</del>
								</div>
								<!--<v-badge class="font-size-caption" color="red darken-2">
                          <template v-slot:badge>{{product.discount.percent}}%</template>
                </v-badge>-->
							</div>

							<!-- Unit sentence  -->
							<div
								class="mx-1 font-size-caption green--text text--darken-2 order-4"
								v-if="Boolean(product.unit_sentence)"
							>
								{{ product.unit_sentence }}
							</div>
						</div>

						<!-- Add to cart btn -->
						<template v-if="getCardStyle">
							<v-chip
								label
								active
								v-if="!isOpenBranch"
								style="height: auto;"
								>{{ $t("label.store_is_closed") }}</v-chip
							>
							<v-chip
								label
								active
								v-else-if="!product.existence"
								>{{ $t("label.not_exist") }}</v-chip
							>
							<div class="d-flex justify-end">
								<ProductCardButtons
									:product="product"
									:customData="customData"
									:btnType="btnType"
									v-if="isOpenBranch && product.existence"
								/>
							</div>
						</template>
					</v-card-text>
					<!--*/ text of card -->
				</v-card>
			</template>
		</client-only>
	</Fragment>
</template>
<script>
import { mapGetters } from "vuex";
import ProductCardButtons from "@/components/ProductCard/Buttons";
import FullPicCard from "./FullPicCard";
import { Fragment } from "vue-fragment";

export default {
	name: "ProductCard",
	props: ["product", "isOpenBranch", "customData", "btnType"],
	components: { ProductCardButtons, FullPicCard, Fragment },
	computed: {
		...mapGetters({
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getDomain: "siteSetting/getDomain",
			getCardStyle: "branch/getCardStyle",
			getCardWidth: "branch/getCardWidth",
			getItemCount: "shop/itemCount",
			getStyledProductShop: "productInfo/getStyledProductShop",
		}),
	},
	methods: {
		checkLocalePath() {
			let $slug = this.product.id;
			let productTranslations =
				this.product.translations && this.product.translations.length;
			switch (this.getCardStyle.description_style) {
				case "SIMPLE":
					$slug = productTranslations
						? this.product.translations.find(
								item => item.locale == this.$i18n.locale
						  ).slug
						: this.product.slug;
					break;
				case "TAB_INFO":
					$slug = productTranslations
						? this.product.translations[0].product_id
						: this.product.id;
					break;
				default:
					$slug = this.product.id;
					break;
			}
			return { name: "product-slug", params: { slug: $slug } };
		},
	},
};
</script>
<style scoped>
.v-card__title {
	word-break: normal !important;
}
</style>
