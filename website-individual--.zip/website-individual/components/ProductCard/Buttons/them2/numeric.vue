<template>
	<v-row
		no-gutters
		justify="center"
		align="center"
		:class="[
			'rounded dont-break-elemnt',
			{ 'red lighten-1': !isShowDetailBuy },
		]"
	>
		{{/* NUMERIC counter == 0 */}}
		<template v-if="!isShowDetailBuy">
			<v-col v-if="itemCountPorudct == 0">
				<v-btn
					dark
					block
					depressed
					color="red lighten-1"
					@click.prevent="sendCallAddToCard(btnStatus)"
				>
					{{ $t("button.add_to_shoping_cart") }}
				</v-btn>
			</v-col>
			<!-- {{/* NUMERIC counter != 0 */}} -->
			<template v-else>
				{{/* NUMERIC plus */}}
				<v-col>
					<v-btn
						block
						tile
						text
						dark
						@click.prevent="sendCallAddToCard(btnStatus)"
					>
						<v-icon color="white" small>mdi-plus</v-icon>
					</v-btn>
				</v-col>
				{{/* NUMERIC count */}}
				<v-col>
					<div
						class="white rounded mx-0 font-size-body-2 text-center"
						style="min-width: 25px;"
					>
						{{ itemCountPorudct }}
					</div>
				</v-col>
				{{/* NUMERIC (minus -> count ≤ 1) & (trash -> count == 1) */}}
				<v-col>
					<v-btn
						@click.prevent="sendCallMinusToCard()"
						block
						tile
						text
						dark
					>
						<v-icon color="white" small>{{
							itemCountPorudct == 1
								? "mdi-trash-can-outline"
								: "mdi-minus"
						}}</v-icon>
					</v-btn>
				</v-col>
			</template>
		</template>

		<v-col
			sm="12"
			lg="12"
			v-else-if="isShowDetailBuy"
			@click="goToDefaultState"
			class="d-flex pe-1"
			style="cursor: pointer;"
		>
			<v-sheet
				:width="$device.isMobile ? '53.91px' : '40px'"
				height="40px"
				color="red lighten-1"
				class="d-inline-flex pa-3 rounded-pill text-center white--text align-center justify-center font-size-17"
				v-text="itemCountPorudct"
			/>
			<v-row
				no-gutters
				class="d-inline-flex font-size-13 grey--text text--darken-3"
				:class="$vuetify.rtl ? 'mr-1' : 'ml-1'"
			>
				<v-col cols="12">
					{{ $t("productInfo.buy.onShop") }}
				</v-col>
				<v-col cols="12">
					{{ $t("productInfo.buy.View") }}
					<span
						@click="$store.dispatch('shop/isOpenCart', true)"
						class="red--text"
					>
						{{ $t("productInfo.buy.Cart") }}
					</span>
				</v-col>
			</v-row>
		</v-col>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["btnStatus", "productIds"],
	data: () => ({
		isShowDetailBuy: false,
		timeToDefault: null,
	}),
	computed: {
		...mapGetters({
			getItemCount: "shop/itemCount",
		}),
		itemCountPorudct: {
			get() {
				let $count = this.getItemCount(
					this.productIds.product_id
						? this.productIds.product_id
						: this.productIds.id
						? this.productIds.id
						: -1
				);
				this.isShowDetailBuy = false;
				if ($count > 0)
					this.timeToDefault = setTimeout(() => {
						if (
							$count ===
							this.getItemCount(
								this.productIds.product_id
									? this.productIds.product_id
									: this.productIds.id
									? this.productIds.id
									: -1
							)
						) {
							this.isShowDetailBuy = true;
						}
					}, 3000);
				return $count;
			},
		},
	},
	methods: {
		sendCallAddToCard($btn_status) {
			clearTimeout(this.timeToDefault);
			this.$emit("sendAddToCart", $btn_status);
		},
		sendCallMinusToCard($btn_status) {
			clearTimeout(this.timeToDefault);
			this.$store.dispatch(
				"shop/minusItem",
				this.productIds.product_id
					? this.productIds.product_id
					: this.productIds.id
					? this.productIds.id
					: -1
			);
		},
		goToDefaultState() {
			this.isShowDetailBuy = false;
			let $count = this.itemCountPorudct;
			if ($count > 0)
				this.timeToDefault = setTimeout(() => {
					if ($count === this.itemCountPorudct) {
						this.isShowDetailBuy = true;
					}
				}, 3000);
		},
	},
};
// this.$store.commit('loginCard/SET_STATUS', 1)
</script>
