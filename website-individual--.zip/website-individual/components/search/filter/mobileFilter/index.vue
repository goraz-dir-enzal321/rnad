<template>
	<v-row no-gutters>
		<v-btn
			color="black"
			class="rounded-l-0 px-0 flex-shrink-1 flex-grow-1"
			text
			dark
			v-text="$t('search.filters')"
			@click="$store.dispatch('search/setDialogSearchFilter', true)"
		/>
		<!-- <v-divider vertical class="flex-grow-1" />
		<v-btn
			color="black"
			class="rounded-r-0 px-0 flex-shrink-1 flex-grow-1"
			text
			dark
			v-text="$t('search.ordering')"
		/> -->
		<dialogFilter />
	</v-row>
</template>

<script>
import dialogFilter from "@/components/search/filter/mobileFilter/dialogFilter";
export default {
	components: {
		dialogFilter,
	},
	created() {
		this.$store.dispatch("search/setDialogSearchFilter", false);
	},
};
</script>
