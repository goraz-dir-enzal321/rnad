<template>
	<v-col
		cols="12"
		sm="3"
		:class="[
			'pa-1 pa-sm-3',
			{
				'v-card v-sheet v-sheet--outlined theme--light rounded-0':
					$device.isMobile,
			},
		]"
	>
		<mobileFilter v-if="$device.isMobile" />
		<desktopFilter v-else />
	</v-col>
</template>

<script>
import mobileFilter from "@/components/search/filter/mobileFilter/index.vue";
import desktopFilter from "@/components/search/filter/filters/index.vue";
export default {
	components: {
		desktopFilter,
		mobileFilter,
	},
};
</script>
