<template>
	<Fragment>
		<v-card
			outlined
			:class="[
				'rounded-lg card-filter-search mb-3 grey--text text--darken-3',
				{ 'elevation-0 mx-2': $device.isMobile },
			]"
		>
			<filterSearch />
		</v-card>
		<v-card
			outlined
			:class="[
				'rounded-lg card-filter-search mb-3 grey--text text--darken-3',
				{ 'elevation-0 mx-2': $device.isMobile },
			]"
		>
			<filterSwitch :nameData="`has_discount`" />
		</v-card>
		<!-- <v-card
			outlined
			:class="[
				'rounded-lg card-filter-search mb-3 grey--text text--darken-3',
				{ 'elevation-0 mx-2': $device.isMobile },
			]"
		>
			<limitations />
		</v-card> -->
	</Fragment>
</template>

<script>
import { Fragment } from "vue-fragment";
import filterSearch from "@/components/search/filter/filters/filterSearch";
// import limitations from "@/components/search/filter/filters/limitations";
import filterSwitch from "@/components/search/filter/filters/filterSwitch";
export default {
	components: {
		Fragment,
		filterSearch,
		// limitations,
		filterSwitch,
	},
};
</script>
