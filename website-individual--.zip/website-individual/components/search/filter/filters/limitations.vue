<template>
	<v-row class="ma-0 section-drop-of-filter-search">
		<v-col
			cols="12"
			class="section-filter-title-search font-weight-regular"
			@click="
				setDropSearchHeight();
				isShowDetail = !isShowDetail;
			"
		>
			<v-row no-gutters>
				<v-col
					cols="12"
					class="d-flex flex-wrap no-gutters"
					:class="
						$device.isMobile
							? 'pb-0'
							: isShowDetail
							? 'pb-3'
							: 'pb-0'
					"
				>
					<span
						class="col-11 col-auto"
						v-text="'فقط کالا هایی که تخخفیف دار'"
					/>
					<v-icon
						class="col col-auto section-filter-rotate-arrow-search"
						large
						:style="
							$device.isMobile
								? isShowDetail
									? 'opacity: 0'
									: 'opacity: 1'
								: isShowDetail
								? 'transform: rotate(180deg)'
								: null
						"
						v-text="
							$device.isMobile
								? 'mdi-plus-circle-outline'
								: 'mdi-chevron-down'
						"
					/>
					<v-icon
						class="col col-auto section-filter-rotate-arrow-search"
						v-if="$device.isMobile"
						large
						:style="isShowDetail ? 'opacity: 1' : 'opacity: 0'"
						v-text="'mdi-minus-circle'"
					/>
				</v-col>

				<v-col
					cols="12"
					class="px-1"
					v-if="!$device.isMobile"
					:style="{
						opacity: isShowDetail ? 1 : 0,
					}"
				>
					<v-divider />
				</v-col>
			</v-row>
		</v-col>
		<v-col
			cols="12"
			:id="randomNumber"
			class="section-filter-drop-search px-3 py-0"
			:style="
				isShowDetail
					? dropSearchHeight
						? { height: dropSearchHeight + 'px' }
						: 'height: unset'
					: 'height: 0px'
			"
		>
			<v-row class="ma-0 font-weight-light">
				Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam
				recusandae similique ab molestiae aperiam id soluta corporis
				quia ad hic veritatis quibusdam laborum illum, fugiat, tempora
				ullam? Facilis, illo eligendi. Lorem ipsum dolor sit amet
				consectetur adipisicing elit. Aliquam recusandae similique ab
				molestiae aperiam id soluta corporis quia ad hic veritatis
				quibusdam laborum illum, fugiat, tempora ullam? Facilis, illo
				eligendi. Lorem ipsum dolor sit amet consectetur adipisicing
				elit. Aliquam recusandae similique ab molestiae aperiam id
				soluta corporis quia ad hic veritatis quibusdam laborum illum,
				fugiat, tempora ullam? Facilis, illo eligendi. Lorem ipsum dolor
				sit amet consectetur adipisicing elit. Aliquam recusandae
				similique ab molestiae aperiam id soluta corporis quia ad hic
				veritatis quibusdam laborum illum, fugiat, tempora ullam?
				Facilis, illo eligendi. Lorem ipsum dolor sit amet consectetur
				adipisicing elit. Aliquam recusandae similique ab molestiae
				aperiam id soluta corporis quia ad hic veritatis quibusdam
				laborum illum, fugiat, tempora ullam? Facilis, illo eligendi.
				Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam
				recusandae similique ab molestiae aperiam id soluta corporis
				quia ad hic veritatis quibusdam laborum illum, fugiat, tempora
				ullam? Facilis, illo eligendi.
			</v-row>
		</v-col>
	</v-row>
</template>

<script>
export default {
	data: () => ({
		isShowDetail: null,
		randomNumber: Math.floor(Math.random() * 1000000000000000 + 1),
		dropSearchHeight: null,
	}),
	methods: {
		setDropSearchHeight() {
			if (this.isShowDetail && !this.dropSearchHeight) {
				if (document.getElementById(this.randomNumber)) {
					this.dropSearchHeight = document.getElementById(
						this.randomNumber
					).offsetHeight;
				}
			}
		},
	},
	created() {
		if (this.$device.isMobile) this.isShowDetail = false;
		else this.isShowDetail = true;
	},
	mounted() {
		if (!this.$device.isMobile) this.setDropSearchHeight();
	},
};
</script>
