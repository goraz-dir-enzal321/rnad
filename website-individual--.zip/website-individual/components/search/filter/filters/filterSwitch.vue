<template>
	<v-row
		class="ma-0 section-drop-of-filter-search flex-nowrap font-weight-regular"
	>
		<span
			class="flex-shrink-1 col"
			v-text="$t('search.hasDiscounted')"
			@click="computedSwitchFilter = !switchFilter"
		/>
		<v-col cols="auto" class="d-flex align-center">
			<v-switch
				class="pt-0 mt-0"
				v-model="computedSwitchFilter"
				inset
				hide-details="false"
			/>
		</v-col>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["nameData"],
	data: () => ({
		switchFilter: false,
		isSendReqData: true,
	}),
	computed: {
		...mapGetters({
			getFiltersObjectSenderAxios: "search/getFiltersObjectSenderAxios",
		}),
		computedSwitchFilter: {
			get() {
				return this.switchFilter;
			},
			set(value) {
				this.switchFilter = value;
				this.$store.dispatch("search/setAddFilterObjectSenderAxios", {
					has_discount: this.switchFilter,
				});
				if (!this.$device.isMobile) {
					this.$router.push("search");
					this.$store.dispatch("search/setResultSearch").then(() => {
						this.$router.push({
							query: this.getFiltersObjectSenderAxios,
						});
					});
				}
				this.isSendReqData = true;
			},
		},
	},
	mounted() {
		if (
			Object.keys(this.getFiltersObjectSenderAxios) &&
			this.getFiltersObjectSenderAxios.length
		) {
			let findIndex = Object.keys(
				this.getFiltersObjectSenderAxios
			).findIndex(key => this.nameData == key);

			if (findIndex != -1)
				this.computedSwitchFilter =
					Object.values(this.getFiltersObjectSenderAxios)[
						findIndex
					] === "true";
			this.isSendReqData = false;
		}
	},
};
</script>
