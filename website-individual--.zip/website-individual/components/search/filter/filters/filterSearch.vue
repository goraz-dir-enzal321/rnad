<template>
	<v-row class="ma-0">
		<v-col
			cols="12"
			class="pb-2 font-size-13 font-weight-medium"
			:class="$device.isMobile ? 'font-size-14 ' : ''"
			v-text="$t('search.searchResults') + ':'"
		/>
		<v-col cols="12" class="pb-2 pt-0" v-if="!$device.isMobile"
			><v-divider
		/></v-col>
		<v-col cols="12" class="py-2 pt-0">
			<!-- :placeholder="" -->
			<v-text-field
				v-model="textSearchComputed"
				hide-details="false"
				@keyup.enter="searchText()"
				@click:append="searchText()"
				append-icon="mdi-magnify"
				:label="`${$t('search.nameProduct')}...`"
				type="search"
				:rules="[() => !!textSearch]"
				outlined
				dense
			/>
		</v-col>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		textSearch: "",
	}),
	computed: {
		...mapGetters({
			getTextSearch: "search/getTextSearch",
			getFiltersObjectSenderAxios: "search/getFiltersObjectSenderAxios",
		}),

		textSearchComputed: {
			get() {
				return this.textSearch;
			},
			set(value) {
				this.textSearch = value;
				this.$store.dispatch("search/setTextSearch", this.textSearch);
				this.$store.dispatch("search/setAddFilterObjectSenderAxios", {
					keyword: this.textSearch,
				});
			},
		},
	},
	methods: {
		searchText() {
			if (this.textSearch.length) {
				this.$store.dispatch("search/setAddFilterObjectSenderAxios", {
					keyword: this.textSearch,
				});
				this.$store.dispatch("search/setPaginationSearch", 1);
				this.$store.dispatch("search/setResultSearch").then(() => {
					if (this.$route.query != this.getFiltersObjectSenderAxios) {
						this.$router.push("search");
						this.$router.push({
							query: this.getFiltersObjectSenderAxios,
						});
					}
				});
			}
		},
	},
	mounted() {
		this.textSearch = this.getFiltersObjectSenderAxios.keyword
			? this.getFiltersObjectSenderAxios.keyword
			: "";
	},
};
</script>
