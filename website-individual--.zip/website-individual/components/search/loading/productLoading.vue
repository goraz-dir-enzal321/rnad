<template>
	<div>
		<template v-if="$device.isMobile">
			<v-card outlined class="pa-3 d-flex">
				<v-sheet
					width="100"
					height="100"
					class="rounded d-inline-block"
				>
					<v-skeleton-loader
						class="mx-auto mb-2"
						transition="fade-transition"
						type="image"
						height="100%"
						width="100%"
					/>
				</v-sheet>
				<v-col class="flex-skeleton-1">
					<v-skeleton-loader
						class="mb-2"
						transition="fade-transition"
						type="text"
					/>

					<v-skeleton-loader
						class="rounded-t-0"
						transition="fade-transition"
						type="list-item-avatar"
					/>
				</v-col>
			</v-card>
		</template>
		<v-card
			v-else
			tile
			min-height="400"
			outlined
			class="section-product-search pt-3 pb-2"
		>
			<v-skeleton-loader
				transition="fade-transition"
				type="card"
				class="px-2 pb-3"
			/>
			<v-skeleton-loader
				class="pe-6 pb-3"
				transition="fade-transition"
				type="text"
			/>
			<v-skeleton-loader
				class="rounded-t-0"
				transition="fade-transition"
				type="list-item-avatar"
			/>
		</v-card>
	</div>
</template>
