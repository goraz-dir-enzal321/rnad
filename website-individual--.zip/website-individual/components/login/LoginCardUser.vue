<template>
	<v-bottom-sheet v-model="loginCard_status" inset max-width="400px">
		<v-sheet style="position: relative !important;" class="rounded-t-lg">
			<v-btn
				class="mx-2"
				absolute
				left
				top
				dark
				small
				icon
				color="grey"
				@click="loginCard_status = 0"
				style="top: 5px; left: 0; z-index: 99;"
			>
				<v-icon>mdi-close</v-icon>
			</v-btn>
			<v-btn
				block
				tile
				class="pa-5"
				text
				color="grey--text"
				nuxt
				:to="localePath('profile')"
				>{{ $t("label.welcome") }} {{ getUserName }}</v-btn
			>
			<v-list>
				<v-list-item-group color="green">
					<v-list-item
						nuxt
						:to="
							localePath(
								{ name: 'profile', hash: '#profile' },
								$i18n.locale
							)
						"
						@click="(loginCard_status = 0), setTab('profile')"
					>
						<v-list-item-icon>
							<v-icon color="grey darken-2">mdi-account</v-icon>
						</v-list-item-icon>
						<v-list-item-content color="indigo">
							<v-list-item-title color="indigo">{{
								$t("button.profile")
							}}</v-list-item-title>
						</v-list-item-content>
					</v-list-item>
					<!-- :to="localePath('profile')" -->
					<v-list-item
						nuxt
						:to="
							localePath(
								{ name: 'profile', hash: '#messages' },
								$i18n.locale
							)
						"
						@click="(loginCard_status = 0), setTab('messages')"
					>
						<v-list-item-icon>
							<v-icon color="grey darken-2"
								>mdi-android-messages</v-icon
							>
						</v-list-item-icon>
						<v-list-item-content>{{
							$t("button.messages")
						}}</v-list-item-content>
					</v-list-item>
					<v-list-item
						nuxt
						:to="
							localePath(
								{ name: 'profile', hash: '#orders' },
								$i18n.locale
							)
						"
						@click="(loginCard_status = 0), setTab('orders')"
					>
						<v-list-item-icon>
							<v-icon color="grey darken-2"
								>mdi-clipboard-list</v-icon
							>
						</v-list-item-icon>
						<v-list-item-content>
							<v-list-item-title>{{
								$t("button.orders")
							}}</v-list-item-title>
						</v-list-item-content>
					</v-list-item>
					<v-list-item
						v-if="getShops && getShops[0].has_location"
						nuxt
						:to="
							localePath(
								{ name: 'profile', hash: '#addresses' },
								$i18n.locale
							)
						"
						@click="(loginCard_status = 0), setTab('addresses')"
					>
						<v-list-item-icon>
							<v-icon color="grey darken-2"
								>mdi-map-marker</v-icon
							>
						</v-list-item-icon>
						<v-list-item-content>
							<v-list-item-title>{{
								$t("button.addresses")
							}}</v-list-item-title>
						</v-list-item-content>
					</v-list-item>
					<v-list-item
						nuxt
						:to="localePath('download')"
						@click="loginCard_status = 0"
					>
						<v-list-item-icon>
							<v-icon color="grey darken-2"
								>mdi-cellphone-arrow-down</v-icon
							>
						</v-list-item-icon>
						<v-list-item-content>
							<v-list-item-title>{{
								$t("button.app_download")
							}}</v-list-item-title>
						</v-list-item-content>
					</v-list-item>
				</v-list-item-group>
			</v-list>
			<v-btn
				depressed
				tile
				color="grey lighten-1"
				block
				:loading="loading"
				:disabled="loading"
				@click="logout"
				>{{ $t("button.logout") }}</v-btn
			>
		</v-sheet>
	</v-bottom-sheet>
</template>
<script>
const Cookie = process.client ? require("js-cookie") : undefined;
import { mapGetters } from "vuex";
export default {
	name: "loginCardUser",
	data() {
		return {
			loading: false,
		};
	},
	computed: {
		...mapGetters({
			getUserName: "getUserName",
			getShops: "firstData/getShops",
		}),
		loginCard_status: {
			get() {
				return this.$store.state.loginCard.status == 4;
			},
			set(value) {
				this.$store.commit("loginCard/SET_STATUS", value ? value : 0);
			},
		},
	},
	methods: {
		setTab(tabId) {
			this.$store.dispatch("profileTab/setTab", tabId);
		},
		logout() {
			this.loading = true;
			let data = {
				token: this.$store.state.auth.access_token,
				lang: this.$i18n.locale,
			};
			this.$axios
				.$post("logout", data)
				.catch(err => {
					console.error("logout err ", err);
				})
				.finally(() => {
					Cookie.remove("auth");
					this.$store.commit("setAuth", null);
					this.$router.push(this.localePath("index"));
					this.loginCard_status = 0;
					this.loading = false;
				});
		}, // logout()
	},
};
</script>
