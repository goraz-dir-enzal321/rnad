<template>
	<v-bottom-sheet v-model="loginCard_status" inset max-width="400px">
		<v-sheet
			class="text-center pa-5 justify-content-center rounded-t-lg"
			style="position: relative !important;"
		>
			<v-btn
				class="mx-2"
				absolute
				left
				top
				dark
				small
				icon
				color="grey"
				@click="loginCard_status = 0"
				style="top: 5px; left: 0px;"
			>
				<v-icon v-text="'mdi-close'" />
			</v-btn>
			<v-icon size="100" class="my-5" v-text="'mdi-cellphone-key'" />
			<v-form ref="form" @submit.prevent="validate">
				<v-row
					:class="['d-flex ', { 'flex-row-reverse': $vuetify.rtl }]"
					no-gutters
				>
					<template v-if="getCountries && getCountries.length !== 1">
						<v-col cols="12">
							<v-autocomplete
								:items="countryCodes"
								item-text="name"
								item-value="id"
								outlined
								:rules="[rules.required]"
								:label="
									$t('form.placeholder.enter_your_country')
								"
								return-object
								dense
								v-model="country"
								required
								:loading="loading"
								:disabled="loading"
							/>
						</v-col>
						<div class="flex-grow-0">
							<v-autocomplete
								v-model="country"
								color="country-select"
								outlined
								:items="countryCodes"
								item-value="id"
								item-text="code"
								hide-details
								dense
								placeholder="+"
								label="+"
								:rules="[rules.required]"
								style="width: 100px;"
								class="country-select"
								required
								return-object
								:menu-props="{ contentClass: 'country-select' }"
								:loading="loading"
								:disabled="loading"
							/>
						</div>
					</template>
					<template v-else>
						<v-col cols="12" v-if="countryCodes.name">
							<v-card class="mb-3 mx-0" outlined>
								<p
									class="font-size-15 grey--text my-0 px-3 py-2 text--darken-1"
									v-text="countryCodes.name"
								/>
							</v-card>
						</v-col>
						<div class="flex-grow-0" v-if="countryCodes.code">
							<v-card class="mb-3 mx-0" outlined>
								<p
									class="font-size-15 grey--text my-0 px-3 py-2 text--darken-1"
									v-text="countryCodes.code"
								/>
							</v-card>
						</div>
					</template>
					<div class="flex-grow-0 mr-1"></div>
					<div class="flex-grow-1">
						<v-text-field
							dense
							:label="$t('form.placeholder.enter_your_mobile')"
							outlined
							:rules="[rules.required]"
							:loading="loading"
							:disabled="loading"
							v-model="checkInput"
							maxlength="11"
							required
							type="number"
						/>
					</div>
				</v-row>
				<v-btn
					depressed
					color="success"
					block
					:loading="loading"
					:disabled="loading"
					type="submit"
					v-text="$t('button.submit')"
				/>
			</v-form>
		</v-sheet>
	</v-bottom-sheet>
</template>
<script>
import { mapGetters } from "vuex";
import { login } from "@/api";
export default {
	name: "loginCardPhone",
	data() {
		return {
			countryCodes: "",
			countrySelect: "",
			valid: true,
			loading: false,
			form: { phone_number: null, shop_id: this.getMainShopId },
			rules: {
				required: value =>
					!!value || this.$t("form.validation.error.require"),
			},
		};
	},
	computed: {
		...mapGetters({
			getCountries: "firstData/getCountries", // send to created() , fill out the data () countryCodes
			getMainShopId: "siteSetting/getMainShopId",
		}),
		country: {
			get() {
				this.countrySelect =
					Boolean(this.countryCodes) && this.countryCodes.length == 1
						? this.countryCodes[0]
						: this.countrySelect;
				if (Array.isArray(this.countrySelect)) {
					this.getCountries.filter(item => {
						if (this.countrySelect.country_id === item.id) {
							this.countrySelect = item;
						}
					});
				}
				return this.countrySelect;
			},
			set(item) {
				this.countrySelect = item;
			},
		},
		loginCard_status: {
			get() {
				return this.$store.state.loginCard.status == 1;
			},
			set(value) {
				this.$store.commit("loginCard/SET_STATUS", value ? value : 0);
			},
		},
		checkInput: {
			get() {
				return this.form.phone_number;
			},
			set(value) {
				if (/^0/.test(value)) {
					value = value.replace(/^0/, "");
				}
				if (value.length <= 11) {
					this.form.phone_number = value;
				}
			},
		},
	},
	methods: {
		validate() {
			this.$refs.form.validate() ? this.getCode() : (this.valid = false);
		},
		getCode(elem) {
			let data = {
				mobile: this.form.phone_number,
				shop_id: this.getMainShopId,
				lang: this.$i18n.locale,
				country_code_id: this.countrySelect.country_id,
				p_id: this.countrySelect.panel_id
					? this.countrySelect.panel_id
					: null,
			};
			this.loading = true;
			this.$store.commit("loginCard/set_phone", this.form.phone_number);
			this.$store.dispatch("loginCard/setCountryCode", {
				id: this.countrySelect.country_id,
				text: this.countrySelect.code,
			});
			this.$axios
				.$post(login.code, data)
				.then(res => {
					this.loading = false;
					this.loginCard_status = 2;
				})
				.catch(err => {
					(this.loading = false),
						console.error(err, `You don't have ACCESS`);
				});
		},
	},
	created() {
		this.countryCodes =
			Boolean(this.getCountries) && this.getCountries.length == 1
				? this.getCountries[0]
				: this.getCountries;
		for (let u = 0; u < this.getCountries.length; u++) {
			const item = this.getCountries[u];
			if (this.getCountries[0].code === item.code) {
				this.country = item;
			}
		}
	},
};
</script>
<style lang="scss" scoped>
.country-select {
	direction: ltr !important;
	.v-select__selection {
		font-size: 13px;
	}
}
</style>
