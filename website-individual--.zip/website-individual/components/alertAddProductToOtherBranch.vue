<template>
	<v-bottom-sheet
		v-model="sheetComputed"
		inset
		max-width="650px"
		style="overflow-y: auto !important; position: relative !important;"
	>
		<v-alert
			color="warning"
			:type="!$device.isMobile ? 'warning' : null"
			:border="!$device.isMobile ? 'right' : 'top'"
			colored-border
			elevation="2"
			class="mb-0 rounded-b-0 pt-5"
			v-if="
				getAlertAddProductToOtherBranch &&
				getAlertAddProductToOtherBranch.prevShopId
			"
		>
			<div class="pb-4 d-flex">
				<span class="font-size-subtitle-1 font-weight-medium">
					<v-icon left color="warning" v-if="$device.isMobile"
						>mdi-exclamation</v-icon
					>
					{{ $t("message.warning.warn") }}
				</span>
				<v-spacer />
				<v-btn
					small
					color="red"
					outlined
					rounded
					@click="sheetComputed = false"
				>
					<span v-text="$t('button.close')" />
					<v-icon right small>mdi-close</v-icon>
				</v-btn>
			</div>
			<div class="font-size-14 font-weight-regular pb-3">
				{{
					$t("message.warning.warnAddProductToOtherBranch", {
						nameNewBranch: getShop(
							getAlertAddProductToOtherBranch.newShopId
						).name,
					})
				}}
			</div>
			<v-row class="ma-0 pb-1">
				<v-col cols="12" md="6" class="pa-0 pb-1 pa-md-0 pe-md-1">
					<v-btn
						color="warning"
						block
						outlined
						class="rounded-lg"
						@click="sheetComputed = false"
					>
						<span
							v-text="
								$t('button.continuesWithBranch', {
									nameBranch: getShop(
										getAlertAddProductToOtherBranch.prevShopId
									).name,
								})
							"
						/>
					</v-btn>
				</v-col>
				<v-col cols="12" md="6" class="pa-0 ps-md-1">
					<v-btn
						color="warning"
						block
						outlined
						class="rounded-lg"
						@click="addProductToOtherBranch()"
					>
						<span
							v-text="
								$t('button.continuesWithBranch', {
									nameBranch: getShop(
										getAlertAddProductToOtherBranch.newShopId
									).name,
								})
							"
						/>
					</v-btn>
				</v-col>
			</v-row>
		</v-alert>
		<div class="nothing" v-text="openSheet" />
	</v-bottom-sheet>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		sheet: false,
	}),
	computed: {
		...mapGetters({
			getAlertAddProductToOtherBranch:
				"shop/getAlertAddProductToOtherBranch",
			getShop: "firstData/getShop",
		}),
		sheetComputed: {
			get() {
				return this.sheet;
			},
			set(value) {
				this.sheet = value;
				this.$store.dispatch("shop/setAlertAddProductToOtherBranch", {
					statusDialog: value,
					prevShopId: this.getAlertAddProductToOtherBranch.prevShopId,
					newShopId: this.getAlertAddProductToOtherBranch.newShopId,
					data: this.getAlertAddProductToOtherBranch.data,
				});
			},
		},
		openSheet() {
			this.sheetComputed =
				this.getAlertAddProductToOtherBranch &&
				this.getAlertAddProductToOtherBranch.statusDialog
					? this.getAlertAddProductToOtherBranch.statusDialog
					: false;
		},
	},
	methods: {
		async addProductToOtherBranch() {
			await this.$store.dispatch("shop/emptyCart");
			await this.$store.dispatch("shop/addToCart", {
				...this.getAlertAddProductToOtherBranch.data,
				isAddProductToOtherBranch: true,
			});
			this.sheetComputed = false;
			await this.$store.dispatch("shop/isOpenCart", true);
		},
	},
};
</script>
