<template>
	<div
		v-if="blogs.length"
		:style="[
			{
				'background-color': getBlogSettings.bg_color
					? getBlogSettings.bg_color
					: 'grey',
			},
		]"
	>
		<v-container style="height: 100%;">
			<v-row class="fill-height align-center">
				<v-col
					cols="12"
					tag="h5"
					class="font-size-title-custom font-weight-medium text-center py-0"
					:style="[
						{
							color: getBlogSettings.header_txt_color
								? getBlogSettings.header_txt_color
								: '',
						},
					]"
					v-text="getBlogSettings.header_txt"
				/>
				<v-col md="12">
					<blog-card :data="blogs" />
				</v-col>
				<v-col cols="12" class="text-center">
					<v-hover v-slot:default="{ hover }">
						<v-btn
							nuxt
							min-width="150px"
							:to="localePath('blog', $i18n.locale)"
							v-text="getBlogSettings.btn_txt"
							:style="[
								hover
									? {
											'background-color':
												getBlogSettings.btn_txt_color,
											color: getBlogSettings.btn_bg_color,
									  }
									: {
											'background-color':
												getBlogSettings.btn_bg_color,
											color:
												getBlogSettings.btn_txt_color,
									  },
								{ transition: 'all 0.25s ease-in-out' },
							]"
						/>
					</v-hover>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import Card from "@/components/blog/Card";
import { events } from "~/api";

export default {
	watchQuery: true,
	components: { "blog-card": Card },
	data() {
		return {
			blogs: [],
		};
	},
	computed: {
		...mapGetters({
			getBlogSettings: "siteSetting/getBlogSettings",
			getMainShopId: "siteSetting/getMainShopId",
		}),
	},
	mounted() {
		this.getData();
	},
	methods: {
		async getData() {
			let data = {
				shop_id: this.getMainShopId,
			};
			await this.$axios
				.$post(events.blogEvent, data)
				.then(res => {
					this.blogs = res.blogs;
				})
				.catch(err => console.error("Error ", err));
		},
	},
};
</script>
