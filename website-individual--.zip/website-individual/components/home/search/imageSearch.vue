<template>
	<Fragment>
		<template v-if="file">
			<v-img
				v-if="!isVideo"
				class="rounded pos-absolute top-0 right-0 left-0"
				height="100%"
				width="100%"
				:src="
					file.startsWith(`http`) || file.startsWith(`storage/`)
						? file.startsWith(`storage/`)
							? getDomain + file
							: file
						: `${getDomain}storage/${file}`
				"
				:style="
					opacity ? { opacity: `0.${opacity}` } : { opacity: '0.5' }
				"
			/>
			<video
				v-else-if="isVideo"
				loop
				autoplay
				class="rounded pos-absolute h-100"
				:style="
					opacity ? { opacity: `0.${opacity}` } : { opacity: '0.5' }
				"
			>
				<source
					:src="
						file.startsWith(`http`) || file.startsWith(`storage/`)
							? file.startsWith(`storage/`)
								? getDomain + file
								: file
							: `${getDomain}storage/${file}`
					"
					type="video/mp4"
				/>
			</video>
		</template>

		<v-img
			v-else
			class="rounded pos-absolute top-0 right-0 left-0"
			height="100%"
			width="100%"
			src="/images/slider.png"
			:style="opacity ? { opacity: `0.${opacity}` } : { opacity: '0.5' }"
		/>
	</Fragment>
</template>

<script>
import { mapGetters } from "vuex";
import { Fragment } from "vue-fragment";
export default {
	props: ["isVideo", "file", "opacity"],
	components: {
		Fragment,
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
