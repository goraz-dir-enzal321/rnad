<template>
	<v-sheet
		class="row align-center justify-center mx-auto no-gutters"
		min-height="91vh"
		height="90vh"
		color="grey lighten-4"
	>
		<v-col cols="12">
			<v-row align="center" no-gutters justify="center">
				<v-col
					cols="11"
					sm="7"
					class="section-search-home-loading mb-3"
				>
					<v-skeleton-loader
						type="heading"
						class="w-100 h-100 d-inline-block text-center"
					/>
				</v-col>
				<v-col cols="11" sm="7" class="mx-auto mb-6">
					<v-sheet
						height="40"
						class="rounded"
						color="grey lighten-2"
					/>
				</v-col>
				<v-col cols="11" sm="7" class="mb-4">
					<v-skeleton-loader
						type="paragraph"
						class="w-100 h-100 d-inline-block text-center px-3"
					/>
				</v-col>
				<v-col cols="12" class="section-search-home-loading">
					<v-skeleton-loader
						type="button"
						class="w-100 h-100 d-inline-block text-center px-3"
					/>
				</v-col>
			</v-row>
		</v-col>
	</v-sheet>
</template>
