<template>
	<v-card
		class="fill-height"
		@click="getProduct(branch)"
		:elevation="4"
		:loading="getLoadingBranchs"
		:disabled="branch.status != 1 ? true : getLoadingBranchs"
		:ripple="false"
	>
		<!-- :style="$device.isMobile? { width: '212px' }: { width: '100px' }" -->
		<div class="pa-2 d-flex flex-column justify-space-between">
			<div
				:style="{
					height:
						getFirstData.shops.length > 4
							? '176px'
							: $device.isMobile
							? '190px'
							: '200px',
				}"
			>
				<v-img
					:src="
						Boolean(branch.image)
							? `${getDomain}storage/${branch.image}`
							: '/images/slider.jpg'
					"
					:contain="false"
					class="mx-auto rounded"
					:height="
						getFirstData.shops.length > 4
							? '176px'
							: $device.isMobile
							? '190px'
							: '200px'
					"
					:width="
						getFirstData.shops.length > 4
							? '176px'
							: $device.isMobile
							? '200px'
							: '100%'
					"
				/>
			</div>
			<div
				class="font-size-title mb-0 py-3 text-center font-weight-medium"
			>
				{{ getTitleMethod(branch) }}
			</div>
			<v-sheet
				class="d-flex justify-space-between align-items-center font-size-body-2 pa-2 white--text rounded"
				color="black"
				style="line-height: 1.6rem;"
			>
				<span class="text-shadow-low white--text">{{
					branch.status == 1
						? $t("label.active")
						: $t("label.deactivate")
				}}</span>
				<v-icon color="#00ba11" size="26" v-if="branch.status == 1"
					>mdi-circle-slice-8</v-icon
				>
				<v-icon color="red" size="26" v-else>mdi-circle-slice-8</v-icon>
			</v-sheet>
		</div>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import * as moment from "moment";

export default {
	props: {
		branch: {
			type: Object,
			required: true,
		},
	},
	data: () => ({
		type: "selector",
		selector: "#main-section",
		duration: 1000,
		offset: 70,
		easing: "easeInOutCubic",
	}),
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getBranchWarning: "branch/getBranchWarning",
			getDomain: "siteSetting/getDomain",
			getLoadingBranchs: "branch/getLoadingBranchs",
		}),

		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},
		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	methods: {
		getProduct(branch) {
			let shopId = branch.id;
			if (shopId) {
				this.$store.dispatch("shop/setShopId", branch.id);
			}
			this.$store.dispatch("productInfo/setStyledProductShop", {
				basket_btn_type: branch.card.basket_btn_type,
				description_style: branch.card.description_style,
				description_btn: branch.card.description_btn,
				has_product_voice: branch.has_product_voice,
			});

			this.$store.dispatch("branch/setLoadingBranchs", true);
			this.$store.dispatch("branch/setBranchWarning", {
				beforeBranch: this.getBranchWarning.thisBranch,
				thisBranch: branch.min_product_error,
			});
			this.$store.dispatch("branch/setBranch", branch);
			if (branch.product_type == "CATEGORISE") {
				this.$store
					.dispatch("branch/categories", {
						branch: branch,
						branchId: shopId,
						lang: this.$i18n.locale,
					})
					.then(() => {
						this.$store.commit(
							"categories/SET_IS_SHOW_CATEGORIES_MODAL"
						);
						this.$store.dispatch("branch/setLoadingBranchs", false);
					});
			} else if (Boolean(shopId)) {
				this.$axios
					.$post("getBranchProduct", {
						shopId,
						lang: this.$i18n.locale,
					})
					.then(res => {
						if (res.status) {
							// If it branch has_approve. The user needs administrator approval to pay
							this.$store.dispatch(
								"branch/hasApprove",
								branch.has_approve
							);

							// Set card style
							this.$store.dispatch(
								"branch/cardStyle",
								branch.card
							);

							try {
								let userLocaleUtcTime = moment()
									.utc()
									.format("HH:mm:ss");
								let isOpenBranch =
									(branch.am_time_start <=
										userLocaleUtcTime &&
										userLocaleUtcTime <=
											branch.am_time_end) ||
									(branch.pm_time_start <=
										userLocaleUtcTime &&
										userLocaleUtcTime <=
											branch.pm_time_end);
								this.$store.dispatch(
									"branch/setIsOpenBranch",
									isOpenBranch
								);
								this.$vuetify.goTo(this.target, this.options);
								if (!res.categories.length) {
									this.$store.dispatch(
										"snackbar/isShow",
										true
									);
									this.$store.dispatch(
										"snackbar/setText",
										"No any categories"
									);
									this.$store.dispatch(
										"snackbar/setColor",
										"warning"
									);
								} else {
									// this.categoriesComputed = res.categories;
									if (branch.product_type == "CATEGORISE") {
										// this.getCategorise(branch);
										// this.$store.dispatch('branch/categorize', res.categories );
									} else {
										this.$store.dispatch(
											"branch/setBranchSelectedData",
											res.categories
										);
									}
								}
							} catch (e) {
								console.error("catch ", e);
							}
						}
					})
					.catch(error => console.error(error))
					.finally(() =>
						this.$store.dispatch("branch/setLoadingBranchs", false)
					);
			}
		}, // getProduct

		getTitleMethod(branch) {
			if (branch.translations.length) {
				const $item = branch.translations.find(
					item => item.locale == this.$i18n.locale
				);
				if ($item) {
					return $item.title;
				}
			}
			return branch.title ? branch.title : branch.name;
		},
	},
};
</script>
