<template>
	<v-container class="pt-0">
		<v-row v-if="Object.keys(getFirstData).length" class="pt-0">
			<v-col
				cols="12"
				md="12"
				:class="[
					'mx-auto',
					getTheme.type == 'TOP_LARGE_SLIDER' ? 'px-0' : '',
				]"
				v-for="($item, index) in getFirstData.header.VIDEO"
				:key="index"
				v-if="$item"
			>
				<!-- $item.name != 'aparat' -->
				<v-responsive
					:aspect-ratio="
						getTheme.type == 'TOP_LARGE_SLIDER' ? 16 / 9 : 19 / 5
					"
					:height="getTheme.type == 'TOP_LARGE_SLIDER' ? 300 : ''"
				>
					<iframe
						width="100%"
						height="100%"
						:src="$item.link"
						frameborder="0"
						allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
						allowfullscreen
					/>
				</v-responsive>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	name: "videoSection",
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getTheme: "siteSetting/getTheme",
		}),
	},
};
</script>
