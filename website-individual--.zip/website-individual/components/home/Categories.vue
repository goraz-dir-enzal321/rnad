<template>
	<v-container class="white">
		<v-row style="position: relative !important;">
			<div
				style="
					position: fixed;
					top: 0;
					right: 0;
					left: 0;
					bottom: 0;
					background-color: rgba(119, 111, 111, 0.48);
					z-index: 99999;
				"
			>
				<div
					class="fill-height mx-auto"
					style="
						position: relative;
						height: 90vh;
						margin: 2vh;
						overflow: auto;
					"
				>
					<children v-bind:treeData="treeData" />
				</div>
			</div>
		</v-row>
	</v-container>
</template>
<script>
import children from "./Children.vue";

export default {
	name: "categories",
	// props: ['categories'],
	components: { children },
	props: { treeData: Object },
};
</script>
<style scoped>
ul.folders {
	padding: 1rem;
	margin: 0;
	box-sizing: border-box;
	width: 100%;
	list-style: none;
}

ul.folders > li:first-child {
	padding: 1rem 1rem 1rem 0;
}
</style>
