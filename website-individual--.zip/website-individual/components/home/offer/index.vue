<template>
	<v-card
		v-if="getDataOffer"
		elevation="0"
		class="px-0 py-4 pa-md-7 pa-sm-4 section-offer rounded-0"
		:color="getDataOffer.bg_color ? getDataOffer.bg_color : '#ddd'"
		:style="{
			color: getDataOffer.txt_color ? getDataOffer.txt_color : '#222',
		}"
	>
		<v-container class="pa-0">
			<v-row class="mx-0 flex-nowrap" no-gutters justify="space-around">
				<infoOffer
					:img="getDataOffer.img"
					:txt_color="getDataOffer.txt_color"
					:btn_text="getDataOffer.btn_text"
					v-if="!$device.isMobile"
				/>
				<sliderOffer
					:products="getDataOffer.products"
					:productSetting="{
						img: getDataOffer.img,
						txt_color: getDataOffer.txt_color,
						btn_text: getDataOffer.btn_text,
						bg_color: getDataOffer.bg_color
							? getDataOffer.bg_color
							: '#ddd',
					}"
				/>
			</v-row>
		</v-container>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import infoOffer from "@/components/home/offer/infoOffer";
import sliderOffer from "@/components/home/offer/sliderOffer";

export default {
	components: {
		infoOffer,
		sliderOffer,
	},
	computed: {
		...mapGetters({
			getDataOffer: "offer/getDataOffer",
		}),
	},
};
</script>
