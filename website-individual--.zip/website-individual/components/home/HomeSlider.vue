<template>
	<v-carousel
		v-if="getFirstData.header.SLIDER.length !== 0"
		hide-delimiter-background
		:show-arrows="false"
		:cycle="true"
		interval="10000"
		class="rounded-lg"
		:height="
			getTheme.type == 'TOP_LARGE_SLIDER' && $device.isDesktop
				? '600px'
				: '300px'
		"
	>
		<template v-for="slide in getFirstData.header.SLIDER" v-if="slide.img">
			<v-carousel-item
				:ripple="false"
				:key="slide.id"
				:href="slide.link"
				target="blank"
			>
				<v-img
					width="100%"
					height="100%"
					:contain="false"
					:src="`${getDomain}storage/${slide.img}`"
					:lazy-src="`${getDomain}storage/${slide.img}`"
					draggable="false"
					v-if="!$device.isMobile"
				>
					<template v-slot:placeholder>
						<v-row
							class="fill-height ma-0 white"
							align="center"
							justify="center"
						>
							<v-progress-circular indeterminate color="grey" />
						</v-row>
					</template>
				</v-img>
				<v-img
					width="100%"
					height="100%"
					:contain="true"
					:src="`${getDomain}storage/${slide.mob_img}`"
					:lazy-src="`${getDomain}storage/${slide.mob_img}`"
					draggable="false"
					v-else
				>
					<template v-slot:placeholder>
						<v-row
							class="fill-height ma-0 white"
							align="center"
							justify="center"
						>
							<v-progress-circular indeterminate color="grey" />
						</v-row>
					</template>
				</v-img>
			</v-carousel-item>
		</template>
	</v-carousel>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "HomeSlider",
	mounted() {
		this.onResize();
	},
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getDomain: "siteSetting/getDomain",
			getTheme: "siteSetting/getTheme",
		}),
	},
	methods: {
		onResize() {
			this.windowSize = window.innerWidth < 960;
		},
	},
};
</script>
