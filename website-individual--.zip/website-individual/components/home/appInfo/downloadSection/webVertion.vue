<template>
	<v-dialog
		v-model="dialogComputed"
		transition="fade-transition"
		:fullscreen="$device.isMobileOrTablet"
	>
		<v-card class="pos-relative row align-center" tile>
			<v-btn
				class="me-2 mt-1 top-0 left-0"
				color="error"
				icon
				absolute
				@click="dialogComputed = false"
			>
				<v-icon v-text="'mdi-close'" />
			</v-btn>
			<v-row class="ma-0 font-weight-light">
				<v-col class="text-center pt-0 pb-2">
					<v-img
						:src="`${this.getDomain}storage/${this.getSiteFavicon}`"
						width="60"
						class="mx-auto rounded"
						style="border: 1px solid #0001;"
					/>
				</v-col>
				<v-col
					cols="12"
					class="text-center font-weight-medium font-size-18 pt-0 pb-3 black--text"
				>
					{{
						$t("appDownload.informationGetWebVersion", {
							applicationName: getSiteSeo.title,
						})
					}}
				</v-col>
				<v-col cols="12" class="px-7 pt-0 pb-2">
					<v-divider />
				</v-col>

				<v-col cols="12" v-for="index in 3" :key="index">
					<v-row class="ma-0">
						<v-col
							class="pa-0 me-2"
							cols="auto"
							style="width: 30px; height: 30px;"
						>
							<v-img
								width="100%"
								height="100%"
								class="d-inline-block rounded"
								:src="`/icons/webVertion/0${index}.png`"
							/>
						</v-col>
						<div class="col pt-1">
							<span v-text="index + ' -'" />
							{{
								$t(
									`appDownload.stepsGetWebVertion.${index}.one`
								)
							}}
							<span
								class="font-weight-medium"
								v-text="
									index == 1
										? 'share'
										: index == 2
										? 'Add to Home Screen'
										: index == 3
										? 'Add'
										: null
								"
							/>
							{{
								$t(
									`appDownload.stepsGetWebVertion.${index}.two`
								)
							}}
						</div>
					</v-row>
				</v-col>
			</v-row>
			<v-col cols="12" class="align-self-end">
				<v-btn
					block
					depressed
					color="#30c00f"
					dark
					@click="dialogComputed = false"
					class="font-weight-regular text-shadow-low"
					v-text="$t('button.iRealized')"
				/>
			</v-col>
		</v-card>
		<div class="nothing" v-text="dialogWebVertionComputed" />
	</v-dialog>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		dialog: false,
	}),
	computed: {
		...mapGetters({
			getDialogWebVertion: "appDownload/getDialogWebVertion",
			getSiteFavicon: "siteSetting/getSiteFavicon",
			getDomain: "siteSetting/getDomain",
			getSiteSeo: "siteSetting/getSiteSeo",
		}),
		dialogComputed: {
			get() {
				return this.dialog;
			},
			set(value) {
				this.dialog = value;
				this.$store.dispatch("appDownload/setDialogWebVertion", value);
			},
		},
		dialogWebVertionComputed() {
			this.dialogComputed = this.getDialogWebVertion;
		},
	},
};
</script>
