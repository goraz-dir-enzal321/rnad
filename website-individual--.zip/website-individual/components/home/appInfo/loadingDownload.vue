<template>
	<v-col cols="12" sm="6">
		<v-card>
			<v-row class="ma-0">
				<v-skeleton-loader type="text" class="col col-8 pb-1 pt-3" />
				<v-sheet
					class="col col-12 pb-1 pt-0"
					v-for="index in 4"
					:key="index"
				>
					<v-row align="center">
						<v-col cols="auto">
							<v-skeleton-loader
								type="avatar"
								tile
								class="rounded"
							/>
						</v-col>
						<v-col class="flex-skeleton-1">
							<v-skeleton-loader type="text" />
						</v-col>
						<v-col cols="auto">
							<v-skeleton-loader type="button" />
						</v-col>
					</v-row>
				</v-sheet>
			</v-row>
		</v-card>
	</v-col>
</template>
