<template>
	<v-row class="h-100">
		<!-- title -->
		<v-col
			v-if="response.title"
			cols="12"
			class="font-size-display-1 pt-lg-6 font-weight-bold"
			:class="[
				{ 'mx-2 text-center': $device.isMobile },
				{ 'text-center': !response.isHaveOther },
			]"
			v-text="response.title"
		/>
		<!-- description, btn , img -->
		<v-col cols="12" class="py-0">
			<v-row class="h-100" justify="center">
				<!-- img -->
				<v-col
					cols="7"
					sm="5"
					class="py-0 d-inline-flex"
					v-if="response.image && !$device.isMobile"
				>
					<v-img
						class="rounded rounded-b-0"
						:src="
							response.image.startsWith(`http`) ||
							response.image.startsWith(`storage/`)
								? response.image.startsWith(`storage/`)
									? getDomain + response.image
									: response.image
								: `${getDomain}storage/${response.image}`
						"
					/>
				</v-col>
				<!-- description , btn -->
				<v-col class="py-0 px-5" cols="12" sm>
					<v-row>
						<v-col
							v-if="response.description"
							cols="12"
							class="pt-0"
							v-text="response.description"
						/>

						<v-col
							cols="6"
							class="py-0 d-inline-flex align-self-end"
							v-if="response.image && $device.isMobile"
						>
							<v-img
								class="rounded rounded-b-0"
								:src="
									response.image.startsWith(`http`) ||
									response.image.startsWith(`storage/`)
										? response.image.startsWith(`storage/`)
											? getDomain + response.image
											: response.image
										: `${getDomain}storage/${response.image}`
								"
							/>
						</v-col>
						<v-col
							cols="6"
							sm="12"
							:class="{
								'align-self-end text-center': $device.isMobile,
							}"
						>
							<v-btn
								:class="{
									'ms-3': $device.isMobile,
								}"
								depressed
								:color="
									response.color
										? response.color
										: getSiteColor.color
										? getSiteColor.color
										: 'grey darken-3'
								"
								:dark="
									response.color
										? !$wc_hex_is_light(response.color)
										: true
								"
								:light="
									response.color
										? $wc_hex_is_light(response.color)
										: false
								"
								:to="localePath('download', $i18n.locale)"
							>
								<v-icon
									v-text="'mdi-download'"
									:left="$vuetify.rtl"
									:right="!$vuetify.rtl"
								/>
								<span v-text="$t('button.download')" />
							</v-btn>
						</v-col>
					</v-row>
				</v-col>
			</v-row>
		</v-col>
	</v-row>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["response"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
};
</script>
