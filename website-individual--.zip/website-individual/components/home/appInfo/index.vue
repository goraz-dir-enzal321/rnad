<template>
	<v-sheet
		:color="
			getDataAppDownload &&
			getDataAppDownload.settings &&
			getDataAppDownload.settings.colors &&
			getDataAppDownload.settings.colors.bg_color
				? getDataAppDownload.settings.colors.bg_color
				: getSiteColor.color
				? getSiteColor.color
				: 'grey'
		"
		class="overflow-hidden"
		:max-height="$device.isMobile ? 'auto' : 500"
		v-if="
			getDataAppDownload &&
			getDataAppDownload.markets &&
			((getDataAppDownload.markets.android &&
				getDataAppDownload.markets.android.length) ||
				(getDataAppDownload.markets.ios &&
					getDataAppDownload.markets.ios.length)) &&
			getDataAppDownload.settings &&
			getDataAppDownload.settings.texts &&
			(getDataAppDownload.settings.texts.android_title ||
				getDataAppDownload.settings.texts.ios_title)
		"
	>
		<!-- min-height="350" direction-ltr-->
		<v-row
			class="px-lg-16 pt-lg-3"
			justify="center"
			:style="
				getDataAppDownload.settings.colors.txt_color
					? { color: getDataAppDownload.settings.colors.txt_color }
					: { color: '#222' }
			"
		>
			<v-col
				cols="12"
				sm="5"
				v-if="
					getDataAppDownload.markets.android &&
					getDataAppDownload.markets.android.length &&
					getDataAppDownload.settings.texts.android_title
				"
				class="py-0"
			>
				<applicationSection
					:response="{
						isHaveOther:
							getDataAppDownload.markets.ios &&
							getDataAppDownload.markets.ios.length
								? true
								: false,
						title: getDataAppDownload.settings.texts.android_title,
						description:
							getDataAppDownload.settings.texts
								.android_description,
						image: getDataAppDownload.settings.apps_img.android_img,
						color: getDataAppDownload.settings.colors.txt_color,
					}"
				/>
			</v-col>
			<v-col cols="12" class="pa-0 pa-sm-3" sm="auto">
				<v-divider
					:vertical="!$device.isMobile"
					:dark="
						getDataAppDownload.settings.colors &&
						getDataAppDownload.settings.colors.bg_color
							? !$wc_hex_is_light(
									getDataAppDownload.settings.colors.bg_color
							  )
							: getSiteColor.color
							? true
							: true
					"
					v-if="
						getDataAppDownload.markets.android &&
						getDataAppDownload.markets.android.length &&
						getDataAppDownload.markets.ios &&
						getDataAppDownload.markets.ios.length
					"
				/>
			</v-col>
			<v-col
				cols="12"
				sm="5"
				v-if="
					getDataAppDownload.markets.ios &&
					getDataAppDownload.markets.ios.length &&
					getDataAppDownload.settings.texts.ios_title
				"
				class="py-0"
			>
				<applicationSection
					:response="{
						isHaveOther:
							getDataAppDownload.markets.android &&
							getDataAppDownload.markets.android.length
								? true
								: false,
						title: getDataAppDownload.settings.texts.ios_title,
						description:
							getDataAppDownload.settings.texts.ios_description,
						image: getDataAppDownload.settings.apps_img.ios_img,
						color: getDataAppDownload.settings.colors.txt_color,
					}"
				/>
			</v-col>
		</v-row>
	</v-sheet>
</template>

<script>
import { mapGetters } from "vuex";
import { home } from "@/api";
import applicationSection from "@/components/home/appInfo/applicationSection";
export default {
	components: {
		applicationSection,
	},
	data: () => ({
		loading: false,
	}),
	computed: {
		...mapGetters({
			getSiteColor: "siteSetting/getSiteColor",
			getDataAppDownload: "appDownload/getDataAppDownload",
		}),
	},

	mounted() {
		if (!this.getDataAppDownload)
			this.$store.dispatch("appDownload/setDataAppDownload");
	},
};
</script>
