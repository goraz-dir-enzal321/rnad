<template>
	<li
		class="folder d-block mx-auto white border-bottom pa-0 mb-1"
		v-bind:class="[
			treeData.is_root ? 'is-leaf' : 'is-folder',
			treeData.first ? 'h-auto pos-relative min-height-100' : '',
		]"
		style="max-width: 400px;"
	>
		<div
			v-if="loading"
			class="category-loading d-flex justify-center align-center"
		>
			<v-progress-circular indeterminate color="grey" />
		</div>
		<!-- <li class="folder" v-bind:class="[folder.leaf ? 'is-leaf' : 'is-folder']">-->
		<v-sheet
			class="hover-text pa-1 mb-1 d-flex justify-space-between align-center row-children-style"
			v-if="!treeData.first"
			v-on:click="expand(treeData)"
		>
			<span :class="['d-block', $vuetify.rtl ? 'mr-3' : 'ml-3']">{{
				!treeData.first ? treeData.name : ""
			}}</span>
			<span v-if="treeData.child && treeData.child.length"
				><v-icon
					>mdi-chevron-{{ $vuetify.rtl ? "left" : "right" }}</v-icon
				>
			</span>
			<!--            <span  v-if="!treeData.is_root" @click="onClickButton"><v-icon>mdi-keyboard-backspace</v-icon></span>-->
		</v-sheet>
		<!--        v-on:click="backToParent(folder)"-->
		<!--        <ul class="sub-folders" v-if="folder.child && folder.child.length > 0" v-show="folder.expanded">  -->
		<ul
			v-bind:class="[
				isAbsoluteFolder && getState ? ' absolute-folder' : '',
				treeData.first ? 'pb-3' : '',
				'sub-folders w-100 px-1',
			]"
			v-if="treeData.child && treeData.child.length > 0"
			v-show="expanded"
		>
			<li
				style="list-style: none; border-bottom: 1px solid silver;"
				class="mb-2"
			>
				<div class="pa-2 text-center d-flex">
					<!--                    <span class="align-self-start hover-text no-shadow" v-if="!treeData.is_root" @click="onClickButton"><v-icon>mdi-arrow-left</v-icon></span>-->
					<span
						class="align-self-start hover-text no-shadow"
						@click="onClickButton(treeData)"
						v-if="!treeData.first"
						><v-icon
							>mdi-arrow-{{
								$vuetify.rtl ? "right" : "left"
							}}</v-icon
						></span
					>
					<span
						class="align-self-start hover-text no-shadow"
						@click="closeCategoryBox(treeData)"
						v-if="treeData.first"
						><v-icon size="27">mdi-close</v-icon></span
					>
					<span
						:class="[!treeData.first ? '' : '', 'font-weight-bold']"
						style="width: 85%;"
						>{{
							treeData.first
								? $t("header.text.category")
								: heading
						}}</span
					>
				</div>
			</li>
			<children
				v-for="(item, index) in treeData.child"
				v-bind:treeData="item"
				v-bind:objIndex="index"
				@clicked="onClickChild"
				:key="item.id"
			/>
		</ul>
		<!-- <div class="folder-empty" v-else >No Data</div> -->
		<!-- <div class="folder-empty" v-else v-show="!folder.leaf && folder.expanded">No Data</div> -->
	</li>
</template>
<script>
import * as moment from "moment";
import { mapGetters } from "vuex";

export default {
	name: "children",
	props: { treeData: Object, objIndex: Number },
	data() {
		return {
			expanded: !!this.treeData.first,
			leaf: false,
			hideOther: false,
			isAbsoluteFolder: false,
			thisId: null,
			type: "selector",
			selector: "#main-section",
			duration: 1000,
			offset: 70,
			easing: "easeInOutCubic",
			loading: false,
			heading: this.$t("header.text.category"),
		};
	},
	mounted() {
		/*if(!this.treeData.first && this.getSelectedChildren.length) {
                this.getSelectedChildren.find(child => {
                    if(this.treeData.id === child.id) {
                        // console.log('Ok child ', this.treeData.id, child.id);
                        this.expand2(child)
                    }
                });
                // console.log(this.treeData)
            }*/
		this.test();
	},
	computed: {
		...mapGetters({
			getBranchSelectedForCategories:
				"branch/getBranchSelectedForCategories",
			getSelectedChildren: "categories/getSelectedChildren",
		}),
		getState: {
			get() {
				if (this.getSelectedChildren.length) {
					this.getSelectedChildren.find(child => {
						if (this.treeData.id === child.id) {
							// console.log('Ok child ', this.treeData.id, child.id);
							/*if(child.id == 25) {
                                    this.heading = child.name;
                                    this.expanded = true;
                                    this.isAbsoluteFolder = true;
                                    if(child.id == 147) {
                                        // this.expanded = false;
                                        // this.isAbsoluteFolder = false;
                                        return;
                                    }
                                }*/
						}
					});
					// console.log(this.treeData)
				}
				return this.expanded;
			},
			set(val) {
				this.expanded = val;
			},
		},
		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},
		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	methods: {
		test() {
			/*if(this.getSelectedChildren.length) {
                    this.getSelectedChildren.find((obj, key) => {
                        const { childIndex, data: child } = obj;
                        if(childIndex === this.objIndex) {
                            this.expand2(child, childIndex)
                            console.log('key ', this.getSelectedChildren.length, '  ', key)
                             if(key > 2) {
                                this.expanded = false;
                                this.isAbsoluteFolder = false;
                             }
                        }

                    });
                }*/
		},
		onClickButton(childItem) {
			// console.log('onClickButton')
			if (!this.treeData.first && childItem.id == this.treeData.id) {
				this.isAbsoluteFolder = false;
				this.expanded = false;
			}
		},
		expand(child) {
			// this.$store.dispatch('categories/setSelectedChild', {data: child, childIndex: this.objIndex});
			// console.log('child ', this.$store.getters['categories/getSelectedChildren']);

			if (this.leaf) {
				return;
			}
			if (child.child && !child.child.length) {
				this.loading = true;
				// this.$store.dispatch('branch/categories', {branch:branch, branchId: shopId, lang: this.$i18n.locale } );
				// getBranchSelectedForCategories
				if (!this.getBranchSelectedForCategories) {
					this.$store.dispatch("branch/emptyCategories");
					return;
				}
				let $branch = this.getBranchSelectedForCategories;
				let $data = {
					category_id: child.id,
					lang: this.$i18n.locale,
				};
				this.$axios
					.$post("getCategoryProducts", $data)
					.then(res => {
						if (res.status) {
							// If it branch has_approve. The user needs administrator approval to pay
							this.$store.dispatch(
								"branch/hasApprove",
								$branch.has_approve
							);

							// Set card style
							this.$store.dispatch(
								"branch/cardStyle",
								$branch.card
							);

							this.$store.dispatch(
								"productInfo/setStyledProductShop",
								{
									basket_btn_type:
										$branch.card.basket_btn_type,
									description_style:
										$branch.card.description_style,
									description_btn:
										$branch.card.description_btn,
									has_product_voice:
										$branch.has_product_voice,
								}
							);
							try {
								let userLocaleUtcTime = moment()
									.utc()
									.format("HH:mm:ss");
								let isOpenBranch =
									($branch.am_time_start <=
										userLocaleUtcTime &&
										userLocaleUtcTime <=
											$branch.am_time_end) ||
									($branch.pm_time_start <=
										userLocaleUtcTime &&
										userLocaleUtcTime <=
											$branch.pm_time_end);
								this.$store.dispatch(
									"branch/setIsOpenBranch",
									isOpenBranch
								);
								this.$vuetify.goTo(this.target, this.options);
								if (!Object.keys(res.categories).length) {
									this.$store.dispatch(
										"snackbar/isShow",
										true
									);
									this.$store.dispatch(
										"snackbar/setText",
										"No any categories"
									);
									this.$store.dispatch(
										"snackbar/setColor",
										"warning"
									);
								} else {
									this.$store.dispatch(
										"branch/setBranchSelectedData",
										res.categories
									);
								}
							} catch (e) {
								console.error("catch ", e);
							}
						}
					})
					.catch(err => console.error(err))
					.finally(() => {
						this.loading = false;
						// this.$store.dispatch('branch/emptyCategories');
						this.$store.commit(
							"categories/SET_IS_SHOW_CATEGORIES_MODAL",
							false
						);
					});
				return;
			}
			this.heading = child.name;
			this.expanded = !this.expanded;
			this.isAbsoluteFolder = true;
		},
		expand2(child, childIndex) {
			// console.log('child.id ', child.id);
			/*this.thisId = child.id;
                console.log('child.id  ', this.expanded, this.isAbsoluteFolder );

                if(child.id == 25) {
                    this.heading = child.name;
                    this.expanded = true;
                    this.isAbsoluteFolder = true;

                    if(child.id == 147) {
                        this.expanded = false;
                        this.isAbsoluteFolder = false;
                        return;
                    }


                    return child;
                }*/
		},
		onClickChild(childItem, treeData) {
			// console.log('onClickChild')
			// console.log('this.$store.getters[\'branch/getCatId\'] ', this.treeData , this.$store.getters['branch/getCatId']);
			/*console.log('childItem, treeData ', childItem, '  ',treeData)
                if(childItem.id == treeData) {
                    this.isAbsoluteFolder = false;
                    this.expanded = false;
                }*/
		},
		closeCategoryBox() {
			// console.log('closeCategoryBox');
			this.$store.dispatch("branch/emptyCategories");
		},
	},
};
</script>
<style scoped>
li.is-folder {
	padding: 1rem;
	border-left: 1px solid #d3d3d3;
	margin-bottom: 0.5rem;
}
li .hover-text:hover {
	cursor: pointer;
}
li .hover-text:not(.no-shadow):hover {
	background-color: #eee;
}
li.is-folder > span {
	/*padding: 0.5rem;
        border: 1px solid #d3d3d3;
        cursor: pointer;
        display:inline-block*/
}
li.is-leaf {
	padding: 0 0 0 1rem;
	color: #000;
}
ul.sub-folders {
	/*padding: 1rem 1rem 0 0;*/
	margin: 0;
	/*box-sizing: border-box;*/
	/*width: 100%;*/
	/*list-style: none*/
}
ul.sub-folders.absolute-folder {
	position: absolute;
	top: 0;
	bottom: 0;
	right: 0;
	left: 0;
	background-color: #fff;
	color: #35495e;
	/*padding-top: 50px !important;*/
}
ul .hide-sub-folder {
	display: none !important;
}
ul .category-loading {
	position: absolute;
	top: 0;
	bottom: 0;
	right: 0;
	left: 0;
	background-color: rgba(255, 255, 255, 0.49);
}
div.folder-empty {
	padding: 1rem 1rem 0 1rem;
	color: #000;
	opacity: 0.5;
}
.min-height-100 {
	min-height: 100%;
}
</style>
