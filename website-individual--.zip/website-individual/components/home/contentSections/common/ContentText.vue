<template>
	<v-col :class="classColumn" :style="txtColor ? { color: txtColor } : null">
		<h4 class="font-weight-medium" v-text="tinyTitle" v-if="tinyTitle" />
		<h2
			class="font-size-title-custom mb-3 font-weight-medium"
			v-text="title"
			v-if="title"
		/>
		<p
			class="sfProLight text-justify"
			v-if="contentTxt"
			v-html="contentTxt"
		/>
		<template v-if="link && btnTxt">
			<v-hover v-slot:default="{ hover }">
				<v-btn
					:outlined="!hover"
					:color="hover ? 'white--text' : getSiteColor.color"
					rounded
					min-width="150px"
					class="more-style"
					:style="
						hover
							? {
									borderColor: 'transparent !important',
									backgroundColor: getSiteColor.color,
							  }
							: {
									color: txtColor ? txtColor : '',
							  }
					"
					:href="link"
					:target="link ? '_blank' : ''"
					v-text="btnTxt"
				/>
			</v-hover>
		</template>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: [
		"tinyTitle",
		"title",
		"contentTxt",
		"txtColor",
		"link",
		"btnTxt",
		"classColumn",
	],
	computed: {
		...mapGetters({
			getSiteColor: "siteSetting/getSiteColor",
		}),
	},
};
</script>

<style scoped>
.more-style {
	transition: all 0.25s ease-in-out;
	border: 1px solid !important;
}
</style>
