<template>
	<v-container
		v-if="getStartOrder2"
		:style="[
			{
				'background-color': getStartOrder2.bg_color
					? getStartOrder2.bg_color
					: 'grey',
			},
		]"
		id="select-branch"
		fluid
	>
		<v-row class="fill-height align-center justify-content-center">
			<v-container style="height: 100%;">
				<v-row class="fill-height align-center">
					<v-col
						cols="12"
						tag="h5"
						class="text-center font-size-title"
						v-if="getStartOrder2.title"
						:style="{
							color: getStartOrder2.txt_color
								? getStartOrder2.txt_color
								: '',
						}"
						v-text="getStartOrder2.title"
					/>
					<v-col cols="12" v-if="getStartOrder2.text">
						<div
							class="text-justify"
							v-html="getStartOrder2.text"
							:style="{
								color: getStartOrder2.txt_color
									? getStartOrder2.txt_color
									: '',
							}"
						/>
					</v-col>
					<v-col
						v-for="(cat, index) in getStartOrder2.cats"
						v-if="
							cat &&
							getStartOrder2.card &&
							getStartOrder2.card !== 'NONE'
						"
						:key="index"
						cols="12"
						md="3"
						lg="3"
						xl="2"
						class="section-startOrdering-welcome-main"
					>
						<v-hover v-slot:default="{ hover }">
							<v-card
								:width="
									getStartOrder2.card != 'RECTANGLE'
										? 250
										: ''
								"
								:ripple="false"
								class="mx-auto"
								hover
								:class="
									getStartOrder2.card == 'RECTANGLE'
										? 'overflow-hidden'
										: 'mb-3'
								"
								:elevation="
									getStartOrder2.card == 'RECTANGLE' && hover
										? 8
										: getStartOrder2.card == 'RECTANGLE'
										? 1
										: 0
								"
								color="transparent"
								:loading="loading"
								:disabled="loading"
								@click="
									getProduct(
										getFirstData.shops[0].product_type,
										cat.id
									)
								"
							>
								<v-img
									:src="
										getDomain +
										(cat.img
											? cat.img
											: getSiteSetting.getDefaultImage())
									"
									class="white--text"
									:width="
										getStartOrder2.card != 'RECTANGLE'
											? 250
											: ''
									"
									:height="
										getStartOrder2.card != 'RECTANGLE'
											? 250
											: ''
									"
									:class="[
										hover &&
										getStartOrder2.card != 'RECTANGLE'
											? 'elevation-3'
											: null,
										getStartOrder2.card == 'SQUARE'
											? 'rounded-lg'
											: getStartOrder2.card == 'CIRCLE'
											? 'rounded-circle'
											: '',
									]"
									:aspect-ratio="
										getStartOrder2.card == 'RECTANGLE'
											? 2.76 / 1
											: 1 / 1
									"
									:contain="false"
								>
									<template v-slot:placeholder>
										<v-skeleton-loader
											class="mx-auto section-startOrdering-welcome-main-skeleton-loader"
											type="image"
										/>
									</template>
									<v-row
										align="end"
										class="lightbox px-2 fill-height"
										v-if="
											getStartOrder2.card == 'RECTANGLE'
										"
									>
										<v-col
											:class="[
												$device.isMobile
													? 'pb-2 pt-0'
													: 'py-0',
											]"
											style="
												background-color: rgb(
													0 0 0 / 45%
												);
											"
										>
											<div
												class="subheading white--text"
												:style="
													getStartOrder2.txt_color
														? {
																color:
																	getStartOrder2.txt_color,
														  }
														: null
												"
												v-text="cat.name"
											/>
										</v-col>
									</v-row>
								</v-img>
								<v-card-title
									v-if="getStartOrder2.card != 'RECTANGLE'"
									class="justify-center"
									:style="[
										{
											color: getStartOrder2.txt_color
												? getStartOrder2.txt_color
												: '',
										},
									]"
									v-text="cat.name"
								/>
							</v-card>
						</v-hover>
					</v-col>
				</v-row>
			</v-container>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "StartOrdering2",
	data: () => ({
		selectedCatId: null,
		loading: false,
		isClickedOnStartOrdering2: false,
	}),
	computed: {
		...mapGetters({
			getStartOrder2: "firstData/getStartOrder2",
			getDomain: "siteSetting/getDomain",
			getSiteSetting: "siteSetting/getSiteSetting",
			getDefaultImg: "siteSetting/getDefaultImg",
			getFirstData: "firstData/getFirstData",
			getBranchWarning: "branch/getBranchWarning",
			getSelectedChildren: "categories/getSelectedChildren",
			getCategoriesChildren: "branch/getCategoriesChildren",
			getSelectedBreadcrumb: "categories/getSelectedBreadcrumb",
		}),
		startOrderingData() {
			return this.getFirstData.header.START_ORDER[0];
		},
		getSelectedBreadcrumbComputed() {
			this.$store.commit("categories/SET_IS_SHOW_CATEGORIES_MODAL");
			return this.getSelectedBreadcrumb;
		},
	},
	watch: {
		getCategoriesChildren(newVal, oldVal) {
			if (newVal && this.isClickedOnStartOrdering2) {
				newVal.map((val, key) => {
					if (val && val.id == this.selectedCatId) {
						this.changeCategory(val);
					}
				});
			}
		},
	},
	methods: {
		getProduct(productType, catId) {
			this.loading = true;
			this.selectedCatId = catId;
			this.isClickedOnStartOrdering2 = true;
			this.$store.dispatch("branch/setBranchWarning", {
				beforeBranch: this.getBranchWarning.thisBranch,
				thisBranch: this.getFirstData.shops[0].min_product_error,
			});
			this.$store.dispatch(
				"branch/setBranch",
				this.getFirstData.shops[0]
			);
			this.$store.dispatch(
				"shop/setShopId",
				this.getFirstData.shops[0].id
			);
			this.$store.dispatch("productInfo/setStyledProductShop", {
				basket_btn_type: this.getFirstData.shops[0].card
					.basket_btn_type,
				description_style: this.getFirstData.shops[0].card
					.description_style,
				description_btn: this.getFirstData.shops[0].card
					.description_btn,
				has_product_voice: this.getFirstData.shops[0].has_product_voice,
			});

			if (productType == "CATEGORISE") {
				this.$store
					.dispatch("branch/categories", {
						branch: this.getFirstData.shops[0],
						branchId: this.getFirstData.shops[0].id,
						lang: this.$i18n.locale,
					})
					.then(res => {
						this.getSelectedBreadcrumbComputed;
						this.loading = false;
					});
			}
		},
		changeCategory(item) {
			this.$store.dispatch("categories/setSelectedBreadcrumb", {
				item,
				isStartOrdering2: true,
			});
			this.isClickedOnStartOrdering2 = false;
		},
	},
};
</script>
