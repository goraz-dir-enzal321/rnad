<template>
	<v-card class="mb-8">
		<v-card-text>
			<v-row align="start">
				<v-col cols="10" class>
					<v-text-field
						v-model="inputValue"
						:label="$t('form.label.introductory_code')"
						:hint="hint"
						persistent-hint
						outlined
						flat
						:error="error"
						:loading="loading"
						:disabled="disabled || loading"
					/>
				</v-col>
				<v-col cols class>
					<v-btn
						x-large
						color="error"
						class="w-100"
						:loading="loading"
						:disabled="disabled"
						@click="checkDiscount"
						v-text="$t('button.check')"
					/>
				</v-col>
				<v-col cols="12" class="text-center pa-0">
					<v-sheet
						v-if="discount"
						color="red darken-1 white--text pa-4 mb-2 mx-n1"
						>{{ discount }} %
						{{ $t("label.your_received_discount") }}</v-sheet
					>
					<v-sheet
						v-if="
							getShop(shop_id) &&
							getShop(shop_id).has_free_delivery == 1 &&
							+delivery_cost
						"
						color="orange lighten-2 white--text pa-4 mb-2 mx-n1"
						>{{ $t("label.delivery_cost") }}
						{{ $numberWithCommas($roundDecimal(+delivery_cost)) }}
						{{ unit }} {{ $t("label.are_free") }}</v-sheet
					>
				</v-col>
			</v-row>
		</v-card-text>
		<!-- hi -->
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";
import { order } from "@/api";
export default {
	name: "leadership-discount",
	//   middleware: "authenticated",
	props: [
		"branch_id",
		"shop_id",
		"total_price",
		"unit",
		"delivery_cost",
		"leader_info",
	],
	data() {
		return {
			inputValue: this.leader_info ? this.leader_info.discount_code : "",
			loading: false,
			hint: "",
			discount: 0,
			error: false,
			disabled:
				this.leader_info && this.leader_info.discount_code
					? true
					: false,
		};
	},
	computed: {
		...mapGetters({
			getShop: "firstData/getShop",
		}),
	},
	watch: {
		leader_info: function (newVal, oldVal) {
			this.inputValue = newVal ? newVal.discount_code : "";
			this.disabled = !!(newVal && newVal.discount_code);
			if (newVal) {
				this.checkDiscount();
			}
		},
	},
	methods: {
		async checkDiscount() {
			let params = {
				branch_id: this.branch_id,
				shop_id: this.shop_id,
				user_id: this.$store.state.auth.user.user_id,
				code: this.inputValue,
				total_price: this.total_price,
			};
			this.loading = true;
			await this.$axios
				.$post(order.checkLeaderCode, params)
				.then(res => {
					if (!res.status) {
						this.hint = this.$t(
							"message.error.your_code_not_found"
						);
						this.error = true;
					} else if (res.data) {
						this.callResult(res.data);
						this.error = false;
						this.disabled = true;
						this.hint = this.$t("message.success.successShortText");
						this.discount = res.data.discount_percent;
					}
				})
				.catch(err => console.error({ err }))
				.finally(() => (this.loading = false));
		},
		callResult(data) {
			this.$emit("callResultLeadershipDiscount", data);
		},
	},
};
</script>
