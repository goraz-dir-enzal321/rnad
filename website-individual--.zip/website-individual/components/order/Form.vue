<template>
	<v-row justify="center">
		<v-dialog
			v-model="getShowForm"
			fullscreen
			hide-overlay
			persistent
			transition="dialog-bottom-transition"
		>
			<v-card color="grey lighten-3" v-if="getForm">
				<v-toolbar
					v-if="getForm.form_description"
					primary
					fixed
					dark
					dense
					tile
					:color="Boolean(getSiteColor) ? getSiteColor.color : 'grey'"
				>
					<v-btn
						icon
						small
						@click="$store.dispatch('order/showForm', false), $store.dispatch('order/selectedAddress', false)"
					>
						<v-icon>mdi-close</v-icon>
					</v-btn>
					<v-toolbar-title class="mx-auto">{{getForm.form_description}}</v-toolbar-title>
				</v-toolbar>
				<v-form ref="form" @submit.prevent="saveForm" v-model="isValidForm">
					<v-container>
						<v-row>
							<v-col cols="12" md="6" lg="4" v-for="(form, index) in (getForm.questions)" :key="index">
								<v-card class="pa-3" v-if="form.type === 'TEXT'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-text-field
										:label="form.hint"
										v-model="texts['items_'+form.question_id]"
										:blur="switchChange('textField_'+form.question_id, form, texts['items_'+form.question_id])"
										:placeholder="form.hint"
										:rules="form.required ? requiredRule : []"
										outlined
										dense
										autocomplete="off"
									/>
								</v-card>
								<v-card class="pa-3" v-if="form.type === 'TIME_PICKER'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-dialog
										:ref="'timepickerDialog' + form.question_id"
										v-model="modal['isOpenDialog'+form.question_id]"
										:return-value.sync="time['timepicker_'+form.question_id]"
										persistent
										width="290px"
									>
										<template v-slot:activator="{ on }">
											<v-text-field
												v-model="time['timepicker_'+form.question_id]"
												:rules="form.required ? requiredRule : []"
												:label="form.hint"
												v-on="on"
												dense
												outlined
											/>
										</template>
										<v-time-picker
											v-if="modal['isOpenDialog'+form.question_id]"
											v-model="time['timepicker_'+form.question_id]"
											full-width
											format="24hr"
										>
											<v-spacer />
											<v-btn
												text
												color="primary"
												@click="modal['isOpenDialog'+form.question_id] = false"
											>{{$t('button.cancel')}}</v-btn>
											<v-btn
												text
												color="primary"
												@click="setTimepicker('timepickerDialog'+form.question_id, time['timepicker_'+form.question_id], form)"
											>Ok</v-btn>
										</v-time-picker>
									</v-dialog>
								</v-card>
								<v-card class="pa-3" v-if="form.type === 'DATE_PICKER'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-dialog
										:ref="'datepickerDialog' + form.question_id"
										v-model="datepickerModal['isOpenDialog'+form.question_id]"
										:return-value.sync="date['datepicker_'+form.question_id]"
										persistent
										width="330px"
									>
										<template v-slot:activator="{ on }">
											<v-text-field
												v-model="date['datepicker_'+form.question_id]"
												:rules="form.required ? requiredRule : []"
												:label="form.hint"
												readonly
												v-on="on"
												dense
												outlined
											/>
										</template>
										<v-date-picker
											v-if="datepickerModal['isOpenDialog'+form.question_id]"
											v-model="date['datepicker_'+form.question_id]"
											width="290px"
											:first-day-of-week="0"
											:show-current="true"
											title
											actions
											locale="en"
										>
											<v-spacer />
											<v-btn
												text
												color="primary"
												@click="datepickerModal['isOpenDialog'+form.question_id] = false"
											>{{$t('button.cancel')}}</v-btn>
											<v-btn
												text
												color="primary"
												@click="setDatepicker('datepickerDialog'+form.question_id, date['datepicker_'+form.question_id], form)"
											>Ok</v-btn>
										</v-date-picker>
									</v-dialog>
								</v-card>
								<v-card class="pa-3" v-if="form.type === 'SELECT'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-autocomplete
										:items="form.select_item"
										v-model="selectVal['items_'+form.question_id]"
										@change="switchChange('select_'+form.question_id, form, selectVal['items_'+form.question_id])"
										item-text="title"
										item-value="item_id"
										outlined
										dense
										chips
										small-chips
										:label="form.hint"
										:rules="form.required ? requiredRule : []"
										:required="form.required"
										autocomplete="off"
									/>
								</v-card>
								<v-card class="pa-3" v-if="form.type === 'MULTI_SELECT'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-autocomplete
										:items="form.select_item"
										v-model="multiSelectVal['items_'+form.question_id]"
										@change="switchChange('multiSelect_'+form.question_id, form, multiSelectVal['items_'+form.question_id])"
										item-text="title"
										item-value="item_id"
										outlined
										dense
										chips
										return-object
										small-chips
										:label="form.hint"
										multiple
										:rules="form.required ? requiredMultipleSelectRule : []"
										autocomplete="off"
									/>
								</v-card>
								<v-card class="pa-3" v-if="form.type === 'SWITCH'">
									<v-card-subtitle>{{form.title}}</v-card-subtitle>
									<v-autocomplete
										:items="form.select_item"
										v-model="switchVal['items_'+form.question_id]"
										@change="switchChange('switch_'+form.question_id, form,  switchVal['items_'+form.question_id])"
										item-text="title"
										item-value="item_id"
										outlined
										dense
										chips
										small-chips
										:label="form.hint"
										:rules="form.required ? requiredRule : []"
										:required="form.required"
										autocomplete="off"
									/>
								</v-card>
							</v-col>
							<v-col cols="12" class="text-center">
								<v-btn
									width="290px"
									class="mx-auto"
									@click="validate"
									:color="(getBtnStyle && getBtnStyle.bg) ? getBtnStyle.bg : Boolean(getSiteColor) ? getSiteColor.secondColor : 'grey'"
									:style="[{'color': (getBtnStyle && getBtnStyle.text) ? getBtnStyle.text : ''}]"
								>{{$t('button.submit')}}</v-btn>
							</v-col>
						</v-row>
					</v-container>
				</v-form>
			</v-card>
		</v-dialog>
	</v-row>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "OrderForm",
	data() {
		return {
			loading: false,
			notifications: false,
			sound: true,
			widgets: false,
			isValidForm: false,
			time: [], // All timePickers data
			date: [], // All datePickers data
			texts: [], // All textfields data
			modal: [], //
			datepickerModal: [],
			menu: false,
			multiSelectVal: [],
			selectVal: [],
			switchVal: [],
			form_info: [],
			requiredRule: [
				v => !!v || this.$t("form.validation.error.require"),
			],
			requiredMultipleSelectRule: [
				v => v.length > 0 || this.$t("form.validation.error.require"),
			],
		};
	},
	computed: {
		...mapGetters({
			getShowForm: "order/getShowForm",
			getForm: "order/getForm",
			getQuestionAnswered: "order/getQuestionAnswered",
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			getToken: "getToken",
			isAuth: "isAuth",
		}),
	},
	watch: {
		getShowForm(val) {
			if (!this.getQuestionAnswered) {
				this.time = [];
				this.date = [];
				this.texts = [];
				this.modal = [];
				this.datepickerModal = [];
				this.menu = false;
				this.multiSelectVal = [];
				this.selectVal = [];
				this.switchVal = [];
				this.form_info = [];
			}
		},
	},
	methods: {
		validate() {
			if (this.$refs.form.validate()) {
				this.saveForm();
			} else {
				this.$store.dispatch("snackbar/isShow", true);
				this.$store.dispatch(
					"snackbar/setText",
					this.$t("message.error.not_valid_form")
				);
				this.$store.dispatch("snackbar/setColor", "warning");
			}
		},
		saveForm() {
			try {
				this.$store.dispatch("order/questionAnswered", this.form_info);
				this.$store.dispatch("order/showForm", false);
				this.$store.dispatch("order/selectedAddress", true);
			} catch (e) {
				alert("Error");
				console.error(e);
			}
		},
		setTimepicker(dialogNumber, time, form) {
			this.$refs[dialogNumber][0].save(time);
			this.switchChange(time, form, time);
		},
		setDatepicker(dialogNumber, date, form) {
			this.$refs[dialogNumber][0].save(date);
			this.switchChange(date, form, date);
		},
		switchChange($i, $form, $value) {
			if (Boolean($i) && Boolean($value)) {
				const $data = {
					type: $form.type,
					question_id: $form.question_id,
					answer: $value,
				};
				if (Array.isArray($value) && !$value.length) {
					const $hasItem = this.form_info.find(
						item => item.question_id == $form.question_id
					);
					const $hasItemIndex = this.form_info.indexOf($hasItem);
					if (Boolean($hasItem)) {
						this.form_info.splice($hasItemIndex, 1);
					}
				} else {
					if (this.form_info.length) {
						const $hasItem = this.form_info.find(
							item => item.question_id == $form.question_id
						);
						const $hasItemIndex = this.form_info.indexOf($hasItem);

						if (!$hasItem) {
							if ($form.type == "MULTI_SELECT") {
								$data.answer = "" + $value[0].item_id;
							}
							this.form_info.push($data);
						} // !$hasItem
						if ($hasItem && $hasItem.type == "MULTI_SELECT") {
							let $answer = "";
							if ($value.length) {
								let $comma = $value.length > 1 ? "," : "";
								for (let $i in $value) {
									if (+$i + 1 == $value.length) {
										$comma = "";
									}
									if ($value[$i].item_id) {
										$answer += $value[$i].item_id + $comma;
									}
								}
								$data.answer = $answer;
							}
							this.form_info.splice($hasItemIndex, 1);
							if ($answer.length && $value.length) {
								this.form_info.push($data);
							}
						} else if (
							$hasItem &&
							$hasItem.type != "MULTI_SELECT"
						) {
							this.form_info[$hasItemIndex] = $data;
						}
					} else {
                  this.form_info.push($data);
					}
				}
			} else {
				const $hasItem = this.form_info.find(
					item => item.question_id == $form.question_id
				);
				const $hasItemIndex = this.form_info.indexOf($hasItem);
				// if (Boolean($hasItem) && this.form_info && $hasItemIndex) {
				if (Boolean($hasItem)) {
					this.form_info.splice($hasItemIndex, 1);
				} // remove object from array
			}
		},
	},
};
</script>