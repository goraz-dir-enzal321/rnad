<template>
	<v-container>
		<v-row>
			<v-col cols="12" md="3" lg="4" v-for="item in data" :key="item.id">
				<v-hover v-slot:default="{ hover }">
					<v-card
						:elevation="hover ? 2 : 1"
						hover
						nuxt
						:ripple="false"
						:to="
							localePath(
								{
									name: 'blog-id-slug',
									params: { id: item.id, slug: item.slug },
								},
								$i18n.loccale
							)
						"
					>
						<div style="height: 300px;">
							<v-img
								:src="`${getDomain}/${item.img}`"
								height="300"
								:lazy-src="`${getDomain}/${item.img}`"
							>
								<template v-slot:placeholder>
									<v-card
										width="100%"
										height="300px"
										:aspect-ratio="1 / 1"
										class="fill-height ma-0 d-flex align-center justify-center"
										align="center"
										justify="center"
										elevation="0"
										color="#0003"
									>
										<v-progress-circular
											indeterminate
											:width="2"
											color="grey lighten-5"
										/>
									</v-card>
								</template>
							</v-img>
						</div>
						<v-card-text
							class="font-size-text-h6 grey--text text--darken-4 font-weight-medium"
							v-html="
								item.title
									? item.title
									: $t('message.text.no_description')
							"
						/>
						<v-card-actions
							class="grey--text text--darken-3 font-weight-light"
						>
							<v-row no-gutters justify="space-between">
								<div
									class="font-size-caption"
									v-text="item.category.title"
								/>
								<div
									class="font-size-caption"
									v-text="getLocaleDate(item.created_at)"
								/>
							</v-row>
						</v-card-actions>
					</v-card>
				</v-hover>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
import { utcToLocale } from "~/utils/date";

export default {
	name: "blog-card",
	props: ["data"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
	methods: {
		getLocaleDate(utcTime) {
			let locale = this.$i18n.locale;
			if (locale == "fa") {
				return utcToLocale(utcTime, "jYYYY/jM/jD", locale);
			}
			return utcToLocale(utcTime, "YYYY/MM/DD", locale);
		},
	},
};
</script>
