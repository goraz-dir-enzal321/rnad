<template>
	<!-- Question answer -->
	<v-row class="d-flex" no-gutters>

		<v-col class="d-flex pb-3" cols="12">
			<v-col class="d-flex font-size-13 py-0" cols="auto" v-text="ask"/>
			<v-col class="d-flex flex-shrink-1 align-center">
				<v-divider />
			</v-col>
		</v-col>

		<v-col class="d-flex font-size-12 px-3" cols="12" v-text="answer"/>
	</v-row>
</template>
<script>
export default {
	props: ["ask", "answer"],
};
</script>
