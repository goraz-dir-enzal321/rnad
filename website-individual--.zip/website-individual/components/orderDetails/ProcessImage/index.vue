<template>
	<div
		class="section-process-elevation pa-5 rounded-lg overflow-x overflow-y-hidden d-flex align-center"
		:max-width="!$device.isMobile ? 800 : '100%'"
		style="white-space: nowrap"
		id="processImage"
	>
		<v-sheet
			class="d-inline-block justify-center pa-2 px-md-4"
			v-for="(process, index) in getAllOrderProcess"
			:key="index"
			:style="{ opacity: id == process.id ? 1 : '.3' }"
		>
			<v-img
				:width="id == process.id ? 161 : 95"
				:height="id == process.id ? 161 : 95"
				class="d-inline-block rounded"
				:lazy-src="`${getDomain}${
					process.process_img ? process.process_img : getDefaultImg
				}`"
				:src="`${getDomain}${
					process.process_img ? process.process_img : getDefaultImg
				}`"
			/>
			<div
				class="text-center"
				:class="
					id == process.id
						? 'font-size-15 font-weight-medium'
						: 'font-size-12'
				"
				v-text="process.name"
			/>
		</v-sheet>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	props: ["id"],
	computed: {
		...mapGetters({
			getAllOrderProcess: "orderDetails/getAllOrderProcess",
			//SiteSetting getters
			getDomain: "siteSetting/getDomain",
			getDefaultImg: "siteSetting/getDefaultImg",
		}),
	},
	mounted() {
		let indexActiveProcess = this.getAllOrderProcess.findIndex(
			process => this.id == process.id
		);
		let elementProcressImage = document.getElementById("processImage");

		if (indexActiveProcess != -1 && elementProcressImage) {
			setTimeout(() => {
				elementProcressImage.scrollLeft = this.$vuetify.rtl
					? -95 * indexActiveProcess
					: 95 * indexActiveProcess;
			}, 100);
		}
	},
};
</script>

<style scoped>
.section-process-elevation {
	box-shadow: 0px 3px 1px 0px rgb(0 0 0 / 1%),
		0px 2px 2px 0px rgb(0 0 0 / 14%), 0px 0px 0px 0.5px rgb(0 0 0 / 12%);
}
</style>
