 <template>
	<v-card class="d-flex elevation-1 rounded-lg ma-2" :class="$device.isDesktopOrTablet ? 'mt-7' : null" outlined>
		<v-col
			class="font-weight-medium pa-2 flex-shrink-1"
			v-text="$t('orderDetails.labels.orderNumber') + ' ' + getOrderCode"
		/>
		<v-col
			class="font-weight-medium pa-2"
			cols="auto"
			v-text="$t('orderDetails.labels.payment') + ' ' +getPaymentType"
		/>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	computed: {
		...mapGetters({
			getOrderCode: "orderDetails/getOrderCode",
			getPaymentType: "orderDetails/getPaymentType",
		}),
	},
};
</script>
