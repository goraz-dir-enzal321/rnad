<template>
	<v-col
		class="d-flex justify-content-center pa-0"
	>
		<v-col class="pa-1">
			<v-col
				class="font-size-18 text-center"
				v-text="$t('orderDetails.labels.second')"
			/>
			<v-col class="d-flex pa-0">
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'r' : 'l'}`"
					v-text="seconds[1] ? seconds[1] : seconds[0]"
				/>
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'l' : 'r'}`"
					v-text="seconds[1] ? seconds[0] : 0"
				/>
			</v-col>
		</v-col>
		<v-col class="pa-1">
			<v-col
				class="font-size-18 text-center"
				v-text="$t('orderDetails.labels.minutes')"
			/>
			<v-col class="d-flex pa-0">
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'r' : 'l'}`"
					v-text="minutes[1] ? minutes[1] : minutes[0]"
				/>
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'l' : 'r'}`"
					v-text="minutes[1] ? minutes[0] : 0"
				/>
			</v-col>
		</v-col>
		<v-col class="pa-1" v-if="days || hours">
			<v-col
				class="font-size-18 text-center"
				v-text="$t('orderDetails.labels.hours')"
			/>
			<v-col class="d-flex pa-0">
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'r' : 'l'}`"
					v-text="hours[1] ? hours[1] : hours[0]"
				/>
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'l' : 'r'}`"
					v-text="hours[1] ? hours[0] : 0"
				/>
			</v-col>
		</v-col>
		<v-col class="pa-1" v-if="days">
			<v-col
				class="font-size-18 text-center"
				v-text="$t('orderDetails.labels.days')"
			/>
			<v-col class="d-flex pa-0">
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'r' : 'l'}`"
					v-text="days[1] ? days[1] : days[0]"
				/>
				<div
					class="pa-2 font-size-20 section-time-card text-center"
					:class="`rounded-${$vuetify.rtl ? 'l' : 'r'}`"
					v-text="days[1] ? days[0] : 0"
				/>
			</v-col>
		</v-col>
	</v-col>
</template>



<script>
import { Fragment } from "vue-fragment";
export default {
	props: {
		date: String,
	},
	components: {
		Fragment,
	},
	data: () => ({
		now: Math.trunc(new Date().getTime() / 1000),
	}),
	mounted() {
		window.setInterval(() => {
			this.now = Math.trunc(new Date().getTime() / 1000);
		}, 1000);
	},
	computed: {
		dateInMilliseconds() {
			return Math.trunc(Date.parse(this.date) / 1000);
		},
		seconds() {
			return String(Math.abs((this.dateInMilliseconds - this.now) % 60))
				.toString()
				.split("");
		},
		minutes() {
			return String(
				Math.abs(Math.trunc((this.dateInMilliseconds - this.now) / 60) % 60)
			)
				.toString()
				.split("");
		},
		hours() {
			return String(
			Math.abs(Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60) % 24)
			)
				.toString()
				.split("");
		},
		days() {
			return String(
				Math.abs(Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60 / 24))
			)
				.toString()
				.split("");
		},
	},
};
</script>

<style scoped>
.section-time-card {
	box-shadow: 0px 3px 1px 0px rgb(0 0 0 / 1%),
		0px 2px 2px 0px rgb(0 0 0 / 14%), 0px 0px 0px 0.5px rgb(0 0 0 / 12%);
	background: #fff;
	width: 50%;
}
</style>