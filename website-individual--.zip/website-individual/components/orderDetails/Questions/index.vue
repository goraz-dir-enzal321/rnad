<template>
	<v-col
		md="4"
		cols="12"
		class="pe-md-3 pt-4"
		v-if="getQuestions && getQuestions.length"
	>
		<!-- Questions title -->
		<div
			class="font-weight-medium ma-1"
			v-text="$t('orderDetails.labels.questions')"
		/>
		<v-card class="rounded-lg elevation-2" outlined>
			<template v-for="(items, index) in getQuestions">
				<v-col class="d-flex px-0" :key="index" v-if="items">
					<!-- QuestionAnswer component -->
					<QuestionAnswer :ask="items.ask" :answer="items.answer" />
				</v-col>
			</template>
		</v-card>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";
import QuestionAnswer from "@/components/orderDetails/QuestionAnswer";
export default {
	components: {
		QuestionAnswer,
	},
	computed: {
		...mapGetters({
			//OrderDetails getters ==> received order questions []
			getQuestions: "orderDetails/getQuestions",
		}),
	},
};
</script>
