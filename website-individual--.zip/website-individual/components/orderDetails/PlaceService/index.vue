<template>
	<v-col md="4" cols="12" class="pe-md-3 pt-4" v-if="getAddress">
		<!-- Place of service title -->
		<div
			class="ma-1 font-weight-medium"
			v-text="$t('orderDetails.labels.placeOfService')"
		/>

		<v-card class="rounded-lg elevation-2" outlined>
			<!-- send Of address -->
			<div
				class="d-flex pa-3 pb-0"
				v-text="$t('orderDetails.labels.sendOfAddress')"
			/>

			<div class="d-flex pa-3 pb-0">
				<v-col
					class="d-flex font-size-13 pa-0 font-size-14"
					cols="auto"
					v-text="$t('orderDetails.labels.to')"
				/>
				<v-col class="flex-shrink-1">
					<v-divider />
				</v-col>
			</div>

			<div class="font-size-12 pa-3" v-text="getAddress" />
			<!-- LocationMap bottun -->
			<!--<div :class="$vuetify.rtl ? 'text-left' : 'text-right'">
				 <v-btn
					color="green"
					text
					class="rounded-lg rounded-br-0 rounded-tl-0"
					:class="`rounded-${
						$vuetify.rtl ? 'br-0 rounded-tl-0' : 'bl-0 rounded-tr-0'
					}`"
					>{{ $t("orderDetails.buttons.viewLocation") }}
				</v-btn> 
			</div>-->
		</v-card>
	</v-col>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	computed: {
		...mapGetters({
			//orderDetails getters
			getAddress: "orderDetails/getAddress",
			// getLocation: "orderDetails/getLocation",
		}),
	},
};
</script>
