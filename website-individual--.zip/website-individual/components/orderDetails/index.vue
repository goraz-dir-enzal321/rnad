<template>
	<v-card
		class="rounded-0 pa-0 pt-2 pa-sm-3 mx-auto"
		max-width="1400px"
	>
		<!-- order tracer title -->
		<Title />
		<!-- order tracer status -->
		<OrderStatus />
		<v-row class="pa-2" no-gutters>
			<!-- order tracer product info -->
			<OrderInfo />
			<!-- order tracer price list -->
			<PurchaseInvoice />

			<!-- order tracer place of service -->
			<PlaceService />
			<!-- order tracer questions -->
			<Questions />
		</v-row>
	</v-card>
</template>

<script>
import Title from "@/components/orderDetails/Title";
import OrderStatus from "@/components/orderDetails/OrderStatus";
import OrderInfo from "@/components/orderDetails/OrderInfo";
import PlaceService from "@/components/orderDetails/PlaceService";
import Questions from "@/components/orderDetails/Questions";
import PurchaseInvoice from "@/components/orderDetails/PurchaseInvoice";
export default {
	components: {
		Title,
		OrderStatus,
		OrderInfo,
		PlaceService,
		Questions,
		PurchaseInvoice,
	},
};
</script>
