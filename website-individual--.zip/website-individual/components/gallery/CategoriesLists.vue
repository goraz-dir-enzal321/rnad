<template>
	<v-card class="pa-3" flat>
		<v-card-title class="pa-0" v-text="item.name" />
		<v-divider class="red darken-3" />
		<div :class="['d-flex mt-2', { 'flex-column': $device.isMobile }]">
			<v-card
				v-for="(image, index) in item.imgs"
				:key="image.id"
				flat
				class="pa-1 text-center"
			>
				<v-img
					:src="imageLink(image.thumbnail)"
					:height="index == 0 ? '150' : 100"
					:width="index == 0 ? '150' : 100"
					class="mx-auto"
				/>
				<v-card-text v-text="image.description" class="pb-0" />
			</v-card>
			<v-hover v-slot:default="{ hover }">
				<v-card
					:elevation="hover ? 4 : 0"
					:class="[
						'd-flex align-center mr-auto text-center grey lighten-3 mt-3',
						$device.isMobile ? 'pa-3' : 'pa-0',
					]"
					:width="$device.isMobile ? '100%' : '70'"
					:to="
						localePath({
							name: 'gallery-id-slug',
							params: { id: item.id, slug: item.slug },
						})
					"
					nuxt
					flat
				>
					<v-card-text class="pa-0">{{
						$t("label.click_for_more")
					}}</v-card-text>
				</v-card>
			</v-hover>
		</div>
	</v-card>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	name: "gallery-categories-lists",
	props: ["item"],
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
	},
	methods: {
		imageLink(link) {
			let $link = "/images/section-bg.jpg";

			if (link) $link = this.getDomain + "/" + link;

			return $link;
		},
	},
};
</script>
