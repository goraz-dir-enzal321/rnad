<template>
	<v-footer
		padless
		v-if="getFirstData.header && getFirstData.header.FOOTER_IMAGE"
	>
		<v-card class="flex" flat tile>
			<v-card-text class="py-2 justify-space-between d-flex align-center">
				<v-container>
					<v-row class="align-center">
						<v-col
							cols="12"
							sm
							:class="[
								'font-size-title',
								{ 'text-center': $device.isMobile },
							]"
							>{{
								$store.getters["siteSetting/getCompanyName"]
							}}</v-col
						>
						<v-col cols="12" sm class="d-flex justify-end">
							<div class="d-flex" style="width: 100%;">
								<div
									v-for="item in getFirstData.header
										.FOOTER_IMAGE"
									v-if="item"
									:key="item.id"
									:class="[
										{ 'text-center': $device.isMobile },
									]"
									style="width: 100%;"
								>
									<div
										style="width: 100%;"
										class="text-center"
									>
										{{ item.title }}
									</div>
									<v-img
										class="mx-auto"
										max-width="500px"
										max-height="100%"
										:width="
											$device.isMobileOrTablet
												? '100%'
												: '500px'
										"
										contain
										:src="`${getDomain}storage/${item.img}`"
									/>
								</div>
							</div>
						</v-col>
					</v-row>
				</v-container>
			</v-card-text>
		</v-card>
	</v-footer>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "FooterImage",
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			getFirstData: "firstData/getFirstData",
		}),
	},
};
</script>
