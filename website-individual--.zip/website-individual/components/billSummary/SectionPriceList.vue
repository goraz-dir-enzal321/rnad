<template>
	<v-col
		cols="12"
		class="d-flex justify-space-between"
		:class="data.isSubset ? 'pt-0 pb-3 pr-6' : 'pt-2 pl-3 pb-4 pr-0'"
	>
		<div
			v-text="data.title"
			:class="data.isSubset ? 'font-weight-require' : 'font-weight-bold'"
		/>
		<div>
			<span v-text="$numberWithCommas(+data.price)" />
			<span class="font-size-13" v-text="data.monetaryUnit" />
		</div>
	</v-col>
</template>

<script>
export default {
	props: ["data"],
};
</script>
