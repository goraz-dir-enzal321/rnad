<template>
	<v-sheet class="section-button-continue-buying" min-height="56">
		<v-row class="ma-0">
			<v-bottom-sheet v-model="isOpen" inset>
				<template v-slot:activator="{ on, attrs }">
					<v-col cols="6" v-bind="attrs" v-on="on">
						<div
							class="font-size-13 red--text"
							v-text="$t('billSummary.priceDetails')"
						/>
						<span
							class="font-size-20 font-weight-medium"
							v-text="$numberWithCommas(+getPayablePrice)"
							style="color: #525252;"
						/>
						<span
							class="font-size-13"
							v-text="
								getMonetaryUnit
									? getMonetaryUnit.find(
											item => item.locale == $i18n.locale
									  ).monetary_unit
									: ''
							"
						/>
					</v-col>
				</template>
				<v-card class="pa-4 rounded-t-lg rounded-b-0">
					<div class="d-flex mb-4">
						<span
							class="font-size-18 font-weight-bold"
							v-text="$t('billSummary.priceDetails')"
						/>
						<v-spacer />
						<v-btn
							dark
							small
							color="red"
							text
							icon
							@click="isOpen = !isOpen"
						>
							<v-icon small>mdi-close</v-icon>
						</v-btn>
					</div>
					<PriceLists/>
				</v-card>
			</v-bottom-sheet>
			<v-col cols="6" class="d-flex align-center">
				<v-btn
					class="font-size-16 px-4 font-weight-regular rounded-lg"
					block
					large
					depressed
					color="green accent-4 text-shadow-low"
					dark
					@click="$store.dispatch('order2/setGoToPage', 1)"
				>
               {{title}}
					<template v-slot:loader>
						<div class="stage">
							<div class="dot-flashing" />
						</div>
					</template>
				</v-btn>
			</v-col>
		</v-row>
	</v-sheet>
</template>

<script>
import { mapGetters } from "vuex";
import PriceLists from "~/components/billSummary/PriceLists.vue";
export default {
	props: ["title"],
	components: {
		PriceLists,
	},
	data: () => ({
		isOpen: false,
	}),
	computed: {
		...mapGetters({
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getPayablePrice: "shop/getPayablePrice",
		}),
	},
};
</script>
