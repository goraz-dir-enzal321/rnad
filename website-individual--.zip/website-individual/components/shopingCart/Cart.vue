<template>
	<v-card
		class="mx-auto rounded-lg mb-2"
		color="#F9F9F9"
		max-width="430"
		max-height="100%"
	>
		<!-- if (getCartLists) box cart product -->
		<v-sheet
			color="grey lighten-4 pa-2 mt-2"
			v-if="getCartLists.length"
			height="270"
			class="rounded-t-lg"
			style="overflow-y: auto !important;"
		>
			<!-- loop product (getCartLists) -->
			<v-card
				class="mx-auto mb-2 pb-1"
				flat
				v-for="(item, index) in getCartLists"
				:key="index + ' - ' + item.product_id"
			>
				<v-list-item three-line>
					<v-list-item-content>
						<!-- name -->
						<v-list-item-title
							class="d-sm-flex justify-sm-space-between flex-wrap mb-1"
						>
							<div
								style="white-space: normal;"
								v-if="typeof item.name == 'object'"
							>
								{{
									item.name.find(
										translate =>
											translate.locale == $i18n.locale
									).title
								}}
							</div>
							<div style="white-space: normal;" v-else>
								{{ item.name }}
							</div>
							<div>
								<ProductCardButtons
									:product="item"
									:customData="true"
									btnType="BASKET"
								/>
							</div>
						</v-list-item-title>
						<v-divider />
						<!-- if(discount_price) price & discount_price & getMonetaryUnit-->
						<v-list-item-subtitle
							class="d-flex justify-start"
							v-if="item.discount_amount"
						>
							<span
								:class="
									$vuetify.rtl
										? 'mx-2 order-2'
										: 'order-0 mr-1'
								"
								>{{
									getMonetaryUnit
										? getMonetaryUnit.find(
												item =>
													item.locale == $i18n.locale
										  ).monetary_unit
										: ""
								}}</span
							>
							<span
								:class="[
									$vuetify.rtl ? 'order-0 ml-2' : 'order-1',
									'red--text',
								]"
							>
								{{
									$numberWithCommas(
										+item.price +
											(item.calculationProperty
												? item.calculationProperty
												: 0) -
											(+item.price +
												(item.calculationProperty
													? item.calculationProperty
													: 0)) *
												(item.discount_amount / 100)
									)
								}}
							</span>
							<del
								:class="
									$vuetify.rtl ? 'order-1' : 'mx-2 order-2'
								"
								>{{
									$numberWithCommas(
										+item.price +
											(item.calculationProperty
												? item.calculationProperty
												: 0)
									)
								}}</del
							>
						</v-list-item-subtitle>
						<!-- if(!discount_price) price & getMonetaryUnit-->
						<v-list-item-subtitle
							class="d-flex justify-start"
							v-else
						>
							<span
								:class="
									$vuetify.rtl ? 'mr-2 order-1' : 'order-0'
								"
							>
								{{
									getMonetaryUnit
										? getMonetaryUnit.find(
												item =>
													item.locale == $i18n.locale
										  ).monetary_unit
										: ""
								}}
							</span>
							<span
								:class="
									$vuetify.rtl ? 'order-0' : 'ml-1 order-1'
								"
								>{{
									$numberWithCommas(
										+item.price +
											(item.calculationProperty
												? item.calculationProperty
												: 0)
									)
								}}</span
							>
						</v-list-item-subtitle>
						<!-- if(properties) properties.name -->
						<v-list-item-subtitle
							class="d-flex flex-wrap font-size-12 justify-start"
							v-if="item.properties && item.properties.length"
						>
							<v-col
								cols="6"
								v-for="(props, index) in item.properties"
								:key="index"
								class="pa-0 liDashbefor"
							>
								{{ props.name }}
							</v-col>
						</v-list-item-subtitle>
						<!-- remove product or (×)-->
						<v-btn
							absolute
							fab
							depressed
							top
							:right="$vuetify.rtl ? false : true"
							:left="$vuetify.rtl ? true : false"
							x-small
							color="white black--text"
							:style="[
								$vuetify.rtl
									? { top: 0, left: 0 }
									: { top: 0, right: 0 },
							]"
							@click="
								$store.dispatch(
									'shop/removeItem',
									item.product_id
								)
							"
						>
							<v-icon>mdi-close</v-icon>
						</v-btn>
					</v-list-item-content>
					<!-- image  -->
					<v-list-item-avatar
						tile
						size="80"
						color="grey"
						class="rounded"
					>
						<v-img
							class="rounded"
							:src="
								item.image
									? item.image.startsWith(`http`) ||
									  item.image.startsWith(`storage/`)
										? item.image.startsWith(`storage/`)
											? getDomain + item.image
											: item.image
										: `${getDomain}storage/${item.image}`
									: getDefaultImg
									? getDefaultImg.startsWith(`http`) ||
									  getDefaultImg.startsWith(`storage/`)
										? getDefaultImg.startsWith(`storage/`)
											? getDomain + getDefaultImg
											: getDefaultImg
										: `${getDomain}storage/${getDefaultImg}`
									: 'images/img-default.jpeg'
							"
							:lazy-src="
								item.image
									? item.image.startsWith(`http`) ||
									  item.image.startsWith(`storage/`)
										? item.image.startsWith(`storage/`)
											? getDomain + item.image
											: item.image
										: `${getDomain}storage/${item.image}`
									: getDefaultImg
									? getDefaultImg.startsWith(`http`) ||
									  getDefaultImg.startsWith(`storage/`)
										? getDefaultImg.startsWith(`storage/`)
											? getDomain + getDefaultImg
											: getDefaultImg
										: `${getDomain}storage/${getDefaultImg}`
									: 'images/img-default.jpeg'
							"
							min-height="50"
						>
							<template v-slot:placeholder>
								<v-row
									class="fill-height ma-0 grey"
									align="center"
									justify="center"
								>
									<v-progress-circular
										indeterminate
										color="grey lighten-5"
									/>
								</v-row>
							</template>
						</v-img>
					</v-list-item-avatar>
				</v-list-item>
				<!-- alert for buty more -->
				<v-sheet
					class="mx-2 mb-2 pa-2 red accent-4 white--text font-size-caption"
					v-if="(item.count < item.min_count)"
				>
					<template
						v-if="(getBranchWarning.beforeBranch || getBranchWarning.thisBranch)"
					>
						{{
							getLimitErrorText(getBranchWarning, item.min_count)
						}}
					</template>
					<template v-else>
						{{ $t("message.error.minimum_number_is") }}:
						{{ item.min_count }}
					</template>
				</v-sheet>
			</v-card>
		</v-sheet>
		<!-- if(!getCartLists) img (empty)-->
		<v-sheet v-else>
			<v-img
				src="/images/empty.png"
				lazy-src="/images/empty.png"
				class="mx-auto mb-1 mt-3 rounded-t-lg"
				:contain="false"
				draggable="false"
				height="270px"
				style="background-color: #fff;"
			>
				<template v-slot:placeholder>
					<v-row
						class="fill-height ma-0 grey"
						align="center"
						justify="center"
					>
						<v-progress-circular
							indeterminate
							color="grey lighten-5"
						/>
					</v-row>
				</template>
			</v-img>
		</v-sheet>
		<v-divider />
		<v-list color="white" class="rounded-b-lg py-0">
			<!-- all price -->
			<v-list-item>
				<v-list-item-title
					class="d-flex justify-start"
					v-text="$t('label.sum')"
				/>
				<!--
            <v-list-item-icon>
               <v-icon>icon - {{ item }}</v-icon>
            </v-list-item-icon>
            -->
				<v-list-item-subtitle class="d-flex justify-end">
					<span
						class="mx-4"
						v-text="$numberWithCommas(+getAllPrices)"
					/>
					<span
						v-text="
							getMonetaryUnit
								? getMonetaryUnit.find(
										item => item.locale == $i18n.locale
								  ).monetary_unit
								: ''
						"
					/>
				</v-list-item-subtitle>
			</v-list-item>
			<!-- all discount -->
			<v-list-item>
				<v-list-item-title
					class="d-flex justify-start"
					v-text="$t('label.discount')"
				/>
				<v-list-item-subtitle class="d-flex justify-end">
					<span
						class="mx-4"
						v-text="$numberWithCommas(getAllDiscount)"
					/>
					<span
						v-text="
							getMonetaryUnit
								? getMonetaryUnit.find(
										item => item.locale == $i18n.locale
								  ).monetary_unit
								: ''
						"
					/>
				</v-list-item-subtitle>
			</v-list-item>
			<!-- all payable price -->
			<v-list-item>
				<v-list-item-title
					class="d-flex justify-start font-size-subtitle-1 font-weight-bold"
				>
					{{ $t("label.total_payment") }}</v-list-item-title
				>
				<v-list-item-subtitle
					class="d-flex justify-end font-size-subtitle-1 font-weight-bold"
				>
					<span class="mx-4">{{
						$numberWithCommas(+getPayablePrice)
					}}</span>
					<span>{{
						getMonetaryUnit
							? getMonetaryUnit.find(
									item => item.locale == $i18n.locale
							  ).monetary_unit
							: ""
					}}</span>
				</v-list-item-subtitle>
			</v-list-item>
			<!-- isn't in page order -->
			<v-list-item class="text-center" v-if="isBtn">
				<v-list-item-content>
					<!-- if(auth) -->
					<template v-if="isAuth">
						<!-- have cart -->
						<v-btn
							depressed
							v-if="cartCount > 0"
							:disabled="hasCountError === 'YES'"
							color="success"
							nuxt
							:to="localePath('order', this.$i18n.locale)"
							><v-icon>mdi-cart-arrow-right</v-icon>
							{{ $t("button.next") }}</v-btn
						>
						<!-- else have is empty -->
						<v-btn
							depressed
							v-else-if="cartCount == 0 && Boolean(isMenu)"
							disabled
							color="primary"
							><v-icon>mdi-cart-outline</v-icon>
							{{ $t("button.cart_empty") }}</v-btn
						>
						<!-- else cartCount == 0 && !Boolean(isMenu) -->
						<v-btn
							depressed
							v-else-if="!Boolean(isMenu)"
							color="primary"
							nuxt
							:to="localePath('index')"
							>{{ $t("button.go_to_menu") }}</v-btn
						>
					</template>
					<!-- else if(cartCount == 0) -->
					<v-btn
						disabled
						depressed
						v-else-if="cartCount == 0"
						color="primary"
						><v-icon>mdi-cart-outline</v-icon>
						{{ $t("button.cart_empty") }}</v-btn
					>
					<!-- else if(cartCount > 0) -->
					<v-btn
						depressed
						v-else-if="cartCount > 0"
						color="primary"
						:disabled="hasCountError === 'YES'"
						@click="openLoginCard"
						><v-icon>mdi-cart-arrow-right</v-icon>
						{{ $t("button.next") }}</v-btn
					>
				</v-list-item-content>
			</v-list-item>
		</v-list>
	</v-card>
</template>

<script>
const Cookie = process.client ? require("js-cookie") : undefined;
import { mapGetters } from "vuex";
import ProductCardButtons from "~/components/ProductCard/Buttons";

export default {
	name: "Cart",
	props: ["isBtn", "isMenu"],
	components: { ProductCardButtons },
	data() {
		return {
			showImage: true,
		};
	},
	computed: {
		...mapGetters({
			getCartLists: "shop/cart",
			getAllPrices: "shop/allPrice",
			getAllDiscount: "shop/discounts",
			getPayablePrice: "shop/getPayablePrice",
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getDomain: "siteSetting/getDomain",
			getDefaultImg: "siteSetting/getDefaultImg",
			getItemCount: "shop/itemCount",
			hasCountError: "shop/hasCountError",
			cartCount: "shop/cartCount",
			isAuth: "isAuth",
			getBranchWarning: "branch/getBranchWarning",
		}),
	},
	methods: {
		openLoginCard() {
			if (this.isAuth) {
				this.$store.commit("loginCard/SET_STATUS", 4);
			} else this.$store.commit("loginCard/SET_STATUS", 1);
		}, // openLoginCard
		getLimitErrorText(branchWarning, count) {
			let $text = branchWarning.beforeBranch
				? branchWarning.beforeBranch
				: branchWarning.thisBranch;
			return $text.toString().replace(/%s/g, " " + count + " ");
		},
	},
};
</script>
