<template>
	<div>
		<v-sheet
			color="grey lighten-4"
			:elevation="1"
			class="mx-auto pa-3 mb-3"
			v-html="
				getDynamicText && getDynamicText('MY_ORDER')
					? getDynamicText('MY_ORDER')
					: $t('header.text.your_orders')
			"
		/>
		<v-expansion-panels
			v-model="expansionPanels"
			multiple
			focusable
			:readonly="false"
			class="mb-3"
		>
			<v-row class="align-stretch">
				<v-col
					cols="12"
					sm="9"
					md="8"
					class="mx-auto"
					v-for="(order, index) in ordersComputed"
					:key="index"
				>
					<v-expansion-panel active-class="fill-height">
						<v-expansion-panel-header class="py-2">
							<div class="d-flex flex-column align-start">
								<span class="mb-3">
									<!--     -->
									<!-- {{$t('label.order_id')}}: {{order.code}} {{nowUtc}} {{approve_wait_accept}} {{nowUtc+approve_wait_accept}}-->
									{{ $t("label.order_id") }}: {{ order.code }}
									<v-chip
										v-if="
											order.status === 'VERIFIED' &&
											time >
												addMinuteToDate(
													order.verify_time,
													approve_wait_payment
												)
										"
										class="mx-2 sfProLight"
										color="red darken-2 white--text"
										label
										small
										outlined
										v-text="order.translate_status"
									/>

									<v-chip
										v-else-if="
											order.status === 'UNVERIFIED' &&
											time >
												addMinuteToDate(
													order.created_at,
													approve_wait_accept
												)
										"
										class="mx-2 sfProLight"
										color="red darken-2 white--text"
										label
										small
										outlined
										v-text="order.translate_status"
									/>

									<v-chip
										label
										small
										class="mx-2 sfProLight"
										v-else
										:color="getLabelColor(order)"
										:outlined="order.status == 'REJECTED'"
										v-text="order.translate_status"
									/>
								</span>
								<client-only>
									<span
										>{{ $t("label.order_date") }}:
										{{
											getLocaleDate(order.created_at)
										}}</span
									>
								</client-only>
							</div>
						</v-expansion-panel-header>
						<v-expansion-panel-content>
							<v-sheet
								class="ma-3 pa-4"
								color="teal lighten-4"
								v-if="
									order.status == 'UNVERIFIED' &&
									approve_sentence
								"
								v-text="approve_sentence"
							/>
							<v-sheet
								class="ma-3 pa-4"
								v-if="
									order.status != 'ACCEPTED' &&
									order.status != 'UNVERIFIED' &&
									order.status == 'VERIFIED' &&
									order.status == 'APPROVED' &&
									order.status == 'REJECTED'
								"
								:color="
									getBtnStyle && getBtnStyle.bg
										? getBtnStyle.bg
										: Boolean(getSiteColor)
										? getSiteColor.secondColor
										: 'grey'
								"
								:style="[
									{
										color:
											getBtnStyle && getBtnStyle.text
												? getBtnStyle.text
												: '',
									},
								]"
							>
								<span
									v-if="
										order.status == 'VERIFIED' &&
										time <
											addMinuteToDate(
												order.verify_time,
												approve_wait_payment
											)
									"
								>
									{{ $t("label.need_to_complete") }}
									<br />
								</span>
								<span
									v-if="
										order.status == 'VERIFIED' &&
										time >
											addMinuteToDate(
												order.verify_time,
												approve_wait_payment
											)
									"
								>
									{{ $t("label.payment_end") }}
									<br />
								</span>
								<span v-if="order.status == 'APPROVED'">
									{{ $t("label.payment_done") }}
									<br />
								</span>
								<span
									v-if="
										order.status == 'REJECTED' &&
										order.reject &&
										order.reject.reason
									"
								>
									{{ $t("label.manager") }}:
									{{ order.reject.reason }}
									<br />
								</span>
								<!--<span v-if="order.status == 'UNVERIFIED'">{{$t('label.take_time')}}</span>
								<span v-if="order.status == 'VERIFIED'">{{$t('label.payment_time_available')}}</span>-->
							</v-sheet>

							<v-sheet
								class="ma-3 pa-4 text-center"
								style="
									border: 1px solid silver;
									border-radius: 5px;
								"
								v-if="
									order.status == 'VERIFIED' &&
									time <
										addMinuteToDate(
											order.verify_time,
											approve_wait_payment
										) &&
									gateway_list.length
								"
							>
								<h4 class="text-center mb-3">
									{{ $t("label.choose_payment_type") }}
								</h4>
								<v-divider />
								<v-radio-group
									v-model="paymentMethod"
									:mandatory="false"
									:disabled="loading"
								>
									<v-radio
										color="teal darken-1"
										v-for="(item, index) in payment_list"
										:key="index"
										:value="item"
										:label="item.name"
										@change="paymentMethodChange(item.type)"
									/>
								</v-radio-group>
								<v-divider
									class="pt-3"
									v-if="isOnlineModeSelected"
								/>
								<h4
									class="text-center mb-3"
									v-if="isOnlineModeSelected"
								>
									{{ $t("form.label.select") }}
								</h4>
								<v-radio-group
									v-model="gatewaySelected"
									:mandatory="false"
									v-if="isOnlineModeSelected"
									:disabled="loading"
								>
									<v-radio
										color="teal darken-1"
										v-for="(item, index) in gateway_list"
										:key="index"
										:value="item.id"
										:label="item.name"
									/>
								</v-radio-group>

								<v-divider class="pt-3" />
								<span class="font-size-title">{{
									$t("label.payable_price")
								}}</span>
								:
								<span
									>{{ order.total_price }}
									{{
										getMonetaryUnit
											? getMonetaryUnit.find(
													item =>
														item.locale ==
														$i18n.locale
											  ).monetary_unit
											: ""
									}}</span
								>
								<br />
								<v-btn
									color="teal darken-1"
									:disabled="loading || !paymentMethod"
									:loading="loading"
									@click="getApprovePayment(order)"
									>{{ $t("button.save_order") }}</v-btn
								>
							</v-sheet>
							<v-divider />
							<div class="pa-3">
								<v-sheet
									color="blue-grey lighten-5 pa-2 mb-2"
									v-for="(item, index) in order.items"
									:key="index"
								>
									<v-flex
										d-flex
										flex-row
										justify-space-between
									>
										<nuxt-link
											v-if="item.product_slug"
											v-bind:to="
												localePath({
													name: 'product-slug',
													params: {
														slug: item.product_id,
													},
												})
											"
											v-text="item.product_name"
										/>
										<div
											v-else-if="item.product_name"
											v-text="item.product_name"
										/>
										<div class="d-flex">
											<div class="mx-2">
												{{ item.count }}
												<v-icon size="15"
													>mdi-close</v-icon
												>
											</div>
											{{ item.price }}
											{{
												getMonetaryUnit
													? getMonetaryUnit.find(
															item =>
																item.locale ==
																$i18n.locale
													  ).monetary_unit
													: ""
											}}
										</div>
									</v-flex>
								</v-sheet>
								<v-divider />
								<v-flex
									d-flex
									flex-row
									justify-space-between
									class="py-3 font-size-body-2 font-weight-medium"
								>
									<div>{{ $t("label.sum") }}</div>
									<div>
										{{ order.total_price }}
										{{
											getMonetaryUnit
												? getMonetaryUnit.find(
														item =>
															item.locale ==
															$i18n.locale
												  ).monetary_unit
												: ""
										}}
									</div>
								</v-flex>
								<v-sheet
									color="blue-grey lighten-5 pa-2 mb-2 rounded"
								>
									<div>
										<v-icon>mdi-playlist-edit</v-icon>
										{{ $t("header.text.description") }}
									</div>
									<div>
										{{
											order.description
												? order.description
												: "-----"
										}}
									</div>
								</v-sheet>
								<v-sheet
									color="blue-grey lighten-5 pa-2 mb-2 rounded"
								>
									<div>
										<v-icon>mdi-map-marker</v-icon>
										{{ $t("label.address") }}
									</div>
									<div v-if="order.address">
										{{ order.address }}
									</div>
									<div v-else>-----</div>
								</v-sheet>
							</div>
							<!-- <v-divider v-if="order.cancel_button" /> -->
							<v-divider v-if="order.cancellation" />
							<!-- <v-sheet class="ma-3 pa-4 text-center" v-if="order.cancel_button"> -->
							<!-- <v-sheet
								class="ma-3 pa-4 text-center"
								v-if="order.cancellation"
							>
								<v-btn
									color="red accent-4"
									@click="cancelOrder(order)"
									:loading="loading"
									:disabled="loading"
									v-text="$t('button.cancel_order')"
								/>
							</v-sheet> -->
							<v-sheet class="pa-3 text-center">
								<v-btn
									color="primary"
									dark
                           depressed
                           large
                           block
									@click="$router.push(`/${$i18n.locale}/o/${order.id}`)"
									:loading="loading"
									:disabled="loading"
									v-text="
										$t('orderDetails.labels.getOrderDetail')
									"
								/>
							</v-sheet>
						</v-expansion-panel-content>
					</v-expansion-panel>
				</v-col>
			</v-row>
		</v-expansion-panels>
		<v-row class="text-center">
			<v-col cols="12">
				<v-btn
					class="my-2 mx-auto"
					:loading="loading"
					:disabled="loading"
					v-on:click="getOrdersApi"
					v-if="hasMoreData"
					width="280px"
					:color="
						getBtnStyle && getBtnStyle.bg
							? getBtnStyle.bg
							: Boolean(getSiteColor)
							? getSiteColor.secondColor
							: 'grey'
					"
					:style="[
						{
							color:
								getBtnStyle && getBtnStyle.text
									? getBtnStyle.text
									: '',
						},
					]"
					>{{ $t("button.more") }}</v-btn
				>
			</v-col>
		</v-row>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import { profile } from "~/api";
import { jalaliDate } from "~/utils/date";

export default {
	data() {
		return {
			loading: false,
			orders: [],
			paginate: 0,
			hasMoreData: true,
			paymentMethod: null,
			payment_list: null,
			expansionPanels: [0],
			approve_sentence: null,
			approve_wait_accept: null,
			approve_wait_payment: null,
			totalSecondsForCountTimer: 0,
			time: null,
			nowUtc: null,
			nowDateUtc: null,
			getTimeResult: null,
			gateway_list: [],
			isOnlineModeSelected: false,
			gatewaySelected: null,
		};
	},
	computed: {
		...mapGetters({
			getCountryId: "loginCard/getCountryId",
			getCountryText: "loginCard/getCountryText",
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getFirstData: "firstData/getFirstData",
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			getDynamicText: "siteSetting/getDynamicText",
			getToken: "getToken",
			getAuth: "getAuth",
		}),
		ordersComputed: {
			get(data) {
				return this.orders;
			},
		},
	},
	mounted() {
		this.getOrdersApi();
	},
	methods: {
		getOrdersApi() {
			this.loading = true;

			this.$axios
				.$post(profile.orderHistory, {
					token: this.getToken,
					page: this.paginate,
					lang: this.$i18n.locale,
					branch_id: this.getFirstData.shops[0].id,
				})
				.then(res => {
					if (
						res.status &&
						res.data.orders &&
						res.data.orders.length
					) {
						this.paginate += 1;
						res.data.orders.map(item => {
							return this.orders.push(item);
						});
						this.gateway_list = res.data.gateway_list;
						this.payment_list = res.data.payment_list;
						this.approve_sentence = res.data.approve_sentence;
						this.approve_wait_accept = res.data.approve_wait_accept;
						this.approve_wait_payment =
							res.data.approve_wait_payment;
						// this.nowUtc = res.data.now_utc.split(" ")[1];
						this.nowDateUtc = res.data.now_utc;
						this.getIntervalTime(this.nowDateUtc);
					} else {
						return (this.hasMoreData = false);
					}
				})
				.catch(error => console.error("error ", error))
				.finally(() => (this.loading = false));
		},
		getApprovePayment(order, paymentId) {
			this.loading = true;
			if (this.isOnlineModeSelected && !this.gatewaySelected) {
				this.$store.dispatch("snackbar/isShow", true);
				this.$store.dispatch("snackbar/setColor", "warning");
				this.$store.dispatch(
					"snackbar/setText",
					this.$t("label.choose_payment_type")
				);
				this.loading = false;
				return false;
			}
			let $d = {
				user_info: {
					country_code_id: this.getCountryId,
					country_code: this.getCountryText,
					mobile: this.getAuth.user.mobile,
					user_id: order.user_id,
					shop_id: this.getFirstData.shops[0].id,
					// gateway_type_id : this.paymentMethod,
				},
				type_payment: this.paymentMethod
					? this.paymentMethod.type
					: null,
				payment_type_id: this.paymentMethod
					? this.paymentMethod.id
					: null,
				gateway_type_id: this.isOnlineModeSelected
					? this.gatewaySelected
					: null,
				order_id: order.id,
				token: this.getToken,
				lang: this.$i18n.locale,
			};

			let $data = JSON.stringify($d);

			this.$axios
				.$post(profile.approvePayment, $d)
				.then(res => {
					this.$store.dispatch("snackbar/isShow", true);
					this.$store.dispatch("snackbar/setColor", "teal");
					this.$store.dispatch("snackbar/setText", res.message);
					if (res.status) {
						if (
							res.order &&
							(res.order.length ||
								Object.keys(res.order).length) &&
							Boolean(res.order.gate_url)
						) {
							window.location.href = res.order.gate_url;
							return true;
						}
						this.paymentMethod = null;
						this.gatewaySelected = null;
						this.isOnlineModeSelected = false;
						window.location.reload();
					}
				})
				.catch(error => console.error("error ", error))
				.finally(() => (this.loading = false));
		},
		getLabelColor(order) {
			// let $result =  this.getBtnStyle.bg ? this.getBtnStyle.bg : Boolean(this.getSiteColor) ? this.getSiteColor.secondColor : 'grey';
			let $result = "teal white--text";
			if (order.cancel_id || order.reject || order.status == "FAILED") {
				$result = "red darken-2 white--text";
			}
			if (order.reject) {
				$result = "red darken-2 white--text";
			}
			if (order.status == "VERIFIED") {
				$result = "warning white--text";
			}
			if (order.status == "ACCEPTING") {
				$result = "teal white--text";
			}
			return $result;
		},
		getIntervalTime(nowDateUtc) {
			nowDateUtc = new Date(nowDateUtc);
			this.getTimeResult = nowDateUtc;
			setInterval(() => {
				this.getTimeResult = new Date(
					this.getTimeResult.getTime() + 1000
				);
				this.time = this.getTimeResult.getTime();
			}, 1000);

			/*
                let $getTime = serverTime.getHours() +':'+ serverTime.getMinutes() +':'+ serverTime.getSeconds(); // time string
                let $getTimeWithSplit = $getTime.split(':'); // split it at the colons

                // minutes are worth 60 seconds. Hours are worth 60 minutes.
                let $seconds = (+$getTimeWithSplit[0]) * 60 * 60 + (+$getTimeWithSplit[1]) * 60 + (+$getTimeWithSplit[2]);

                               this.totalSecondsForCountTimer = Number($seconds);
                             setInterval(() => {
                                   ++this.totalSecondsForCountTimer;
                                   let $resultTime = null;
                                   let hour = Math.floor(this.totalSecondsForCountTimer / 3600);
                                   let minute = Math.floor((this.totalSecondsForCountTimer - hour * 3600) / 60);
                                   let seconds = this.totalSecondsForCountTimer - (hour * 3600 + minute * 60);
                                   try {
                                       $resultTime = (hour.toString().length < 2 ? ("0" + hour) : hour) + ":" + (minute.toString().length < 2 ? ("0" + minute) : minute) + ":" + (seconds.toString().length < 2 ? ("0" + seconds) : seconds)
                                   } catch (error) {
                                       console.error('countTimer try catch has error => ', error)
                                   }
                                   this.time = $resultTime;

                                   // this.time = $resultTime;
                                   return $resultTime
                               }, 5000);*/
		},
		addMinuteToDate(date, time_in_minute) {
			date = new Date(date);
			return date.setTime(date.getTime() + time_in_minute * 60 * 1000);
		},
		paymentMethodChange(type) {
			if (type === "ONLINE") {
				this.isOnlineModeSelected = true;
			} else {
				this.isOnlineModeSelected = false;
				this.gatewaySelected = null;
			}
		},
		cancelOrder(order) {
			try {
				this.loading = true;
				this.$axios
					.$post(profile.cancelOrder, {
						token: this.getToken,
						order_id: order.id,
						shop_id: this.getFirstData.shops[0].id,
					})
					.then(res => {
						if (res && res.status) {
							window.location.reload();
						} else {
							this.$store.dispatch("snackbar/isShow", true);
							this.$store.dispatch(
								"snackbar/setColor",
								"red darken-2"
							);
							this.$store.dispatch("snackbar/setText", res.order);
						}
					})
					.catch(err => console.error(err))
					.finally(() => (this.loading = false));
			} catch (error) {
				console.error(error);
			}
		},
		getLocaleDate(utcTime) {
			let locale = this.$i18n.locale;
			if (locale == "fa") {
				return jalaliDate(utcTime, "jYYYY/jM/jD", locale);
			}
			return jalaliDate(utcTime, "YYYY/MM/DD", locale);
		},
	},
};
</script>
