<template>
	<!-- Start app bar tag -->
	<v-app-bar
		fixed
		class="px-0 section-the-haeder"
		:color="isScrollWasTopColor()"
		:style="isScrollWasTop ? 'box-shadow: 0 0 0 0' : null"
		v-if="
			Boolean(getSettingLength) && Object.keys(getHeaderSettings).length
		"
	>
		<!-- App bar header that is shared between desktop and mobile -->
		<v-col
			class="d-flex justify-space-between align-center col-sm-12 col-md-auto px-0"
		>
			<!-- drawer button -->
			<div
				v-ripple
				v-if="$device.isMobile && $route.path == `/${$i18n.locale}`"
				dark
				@click="drawer = !drawer"
				class="section-header-menu"
				:class="drawer ? 'section-drawer-close' : ''"
				:style="{
					backgroundColor: getSiteColor
						? getSiteColor.color
						: 'blue-grey darken-1',
				}"
			>
				<span class="section-header-menu-top" />
				<span class="section-header-menu-center" />
				<span class="section-header-menu-bottom" />
			</div>

			<!-- back button -->
			<div
				v-else-if="
					$device.isMobile && $route.path !== `/${$i18n.locale}`
				"
				class="px-0"
				@click="pageBack()"
			>
				<v-icon size="30" dark> mdi-chevron-right </v-icon>
			</div>

			<!-- site logo-->
			<v-toolbar-title>
				<nuxt-link :to="localePath('index')">
					<v-img
						v-if="getSiteLogo"
						:src="`${getDomain}storage/${getSiteLogo}`"
						:lazy-src="`${getDomain}storage/${getSiteLogo}`"
						:contain="true"
						:height="$device.isMobile ? 48 : 56"
						:width="$device.isMobile ? null : 64"
					/>
					<v-btn text color="white" v-else>LOGO</v-btn>
				</nuxt-link>
			</v-toolbar-title>

			<!-- CategoriesLists button -->
			<v-btn
				v-if="$device.isMobile"
				@click="
					$store.commit('categories/SET_IS_SHOW_CATEGORIES_MODAL')
				"
				dark
				text
				class="font-size-18"
				v-text="$t('button.start')"
			/>
		</v-col>
		<!-- Mobile related codes -->
		<template v-if="$device.isMobile && getSettingLength">
			<!-- Navigation drawer -->
			<v-navigation-drawer
				v-model="drawer"
				absolute
				:right="$vuetify.rtl"
				height="1000"
				width="100%"
			>
				<!-- Profile and signin buttons -->
				<v-row no-gutters>
					<v-col class="d-flex pa-3 pt-2">
						<v-spacer />
						<v-btn
							class="font-size-16 rounded-lg grey lighten-3"
							depressed
							large
							@click="openLoginCard()"
						>
							{{
								isAuth
									? $t("button.view_profile")
									: $t("button.sign_in")
							}}
							<v-icon size="30" class="ms-2">
								{{
									isAuth ? "mdi-account-outline" : "mdi-login"
								}}
							</v-icon>
						</v-btn>
					</v-col>
				</v-row>
				<!-- Site link lists -->
				<v-list nav dense>
					<v-list-item-group
						active-class="deep-purple--text text--accent-4"
						class="row no-gutters"
					>
						<!-- Get all link -->
						<v-col
							cols="12"
							v-for="(
								textItem, index
							) in getSiteSetting.getTexts()"
							:key="index"
							:class="
								textItem.type == 'HOME' ? 'order-first' : null
							"
							v-if="
								getSiteSetting.getTextsUrl(textItem).group !==
								'ACTION_BTN'
							"
						>
							<!-- These are static pages -->
							<v-list-item
								v-if="
									getSiteSetting.getTextsUrl(textItem)
										.group == 'STATIC_PAGE'
								"
								text
								dense
								nuxt
								:to="
									localePath(
										getSiteSetting.getTextsUrl(textItem)
											.route,
										$i18n.locale
									)
								"
								v-text="textItem.name"
								class="px-4 py-1"
							/>
							<!-- These are dynamic pages -->
							<v-list-item
								v-else-if="
									getSiteSetting.getTextsUrl(textItem)
										.group == 'DYNAMIC_PAGE'
								"
								text
								dense
								nuxt
								:to="`/${$i18n.locale}/page/${
									getSiteSetting.getTextsUrl(textItem).route
								}`"
								v-text="textItem.name"
								class="px-4 py-1"
							/>
							<v-divider />
						</v-col>
					</v-list-item-group>
					<div
						v-for="(lang, index) in getTranslations"
						:key="index"
						v-if="lang.locale !== $i18n.locale"
					>
						<v-list-item
							text
							dense
							nuxt
							@click="changeLang(lang.locale)"
							class="px-4 py-1"
						>
							{{
								`${
									lang.locale == "fa"
										? $t("button.fa")
										: lang.locale == "en"
										? $t("button.en")
										: lang.locale == "ar"
										? $t("button.ar")
										: lang.locale
								}`
							}}
						</v-list-item>

						<v-divider v-if="index == getTranslations.length - 1" />
					</div>
				</v-list>
			</v-navigation-drawer>
		</template>
		<!-- Desktop related codes -->
		<v-row
			no-gutters
			v-else-if="!$device.isMobile && getSettingLength"
			justify="center"
			align="center"
		>
			<!-- Get all site links -->
			<v-col cols="auto" class="ps-3 d-flex">
				<template
					v-for="(textItem, index) in getSiteSetting.getTexts()"
					v-if="
						textItem.location == 'HEADER' ||
						textItem.location == 'BOTH'
					"
				>
					<!-- These are dynamic pages -->
					<v-btn
						v-if="
							getSiteSetting.getTextsUrl(textItem).group ==
							'DYNAMIC_PAGE'
						"
						class="mx-1 black--text font-size-13"
						:class="[
							isScrollWasTop
								? 'section-header-btn-noScroll'
								: 'section-header-btn-scrolled',
							textItem.type == 'HOME' ? 'order-first' : null,
						]"
						min-width="85"
						:key="index"
						nuxt
						:to="`/${$i18n.locale}/page/${
							getSiteSetting.getTextsUrl(textItem).route
						}`"
						exact
					>
						{{ textItem.name }}
					</v-btn>
					<!-- These are static pages -->
					<v-btn
						v-else-if="
							getSiteSetting.getTextsUrl(textItem).group ==
							'STATIC_PAGE'
						"
						class="mx-1 black--text font-size-13"
						:class="[
							isScrollWasTop
								? 'section-header-btn-noScroll'
								: 'section-header-btn-scrolled',
							textItem.type == 'HOME' ? 'order-first' : null,
						]"
						min-width="85"
						:key="index"
						nuxt
						:to="
							localePath(
								getSiteSetting.getTextsUrl(textItem).route,
								$i18n.locale
							)
						"
						exact
					>
						{{ textItem.name }}
					</v-btn>
				</template>
			</v-col>
			<v-spacer />
			<!-- this is language change button -->
			<v-col cols="auto" class="d-flex">
				<template
					v-for="locale in $store.getters['siteSetting/getLocales']"
				>
					<v-btn
						class="mx-1 black--text font-size-13"
						:class="
							isScrollWasTop
								? 'section-header-btn-noScroll'
								: 'section-header-btn-scrolled'
						"
						min-width="85"
						v-if="locale !== $i18n.locale"
						:key="`locale-key-${locale}`"
						@click="changeLang(locale)"
					>
						{{
							locale == "fa"
								? $t("button.fa")
								: locale == "en"
								? $t("button.en")
								: locale == "ar"
								? $t("button.ar")
								: locale
						}}
						<v-divider
							vertical
							v-if="locale.length > 2"
						/> </v-btn></template
				><template
					v-for="(textItem, index) in getSiteSetting.getTexts()"
					v-if="
						textItem.location == 'HEADER' ||
						textItem.location == 'BOTH'
					"
					><v-btn
						v-if="
							getSiteSetting.getTextsUrl(textItem).group ==
								'ACTION_BTN' && textItem.type == 'LOGIN'
						"
						@click="openLoginCard"
						class="mx-1 order-first black--text font-size-13"
						:class="
							isScrollWasTop
								? 'section-header-btn-noScroll'
								: 'section-header-btn-scrolled'
						"
						min-width="85"
						:key="index"
					>
						{{ isAuth ? getUserName : textItem.name }}
						<v-icon
							size="25"
							:class="$vuetify.rtl ? 'mr-3' : 'ml-3'"
							>{{
								isAuth ? "mdi-account-outline" : "mdi-login"
							}}</v-icon
						>
					</v-btn>
					<!-- Cart button -->
					<v-badge
						:class="cartCount ? 'ms-2' : null"
						:color="
							getSiteColor
								? getSiteColor.color
								: 'blue-grey darken-1'
						"
						:content="cartCount"
						:bordered="!isScrollWasTop"
						:value="cartCount"
						overlap
						:left="$vuetify.rtl"
						v-else-if="
							$device.isDesktop &&
							getSiteSetting.getTextsUrl(textItem).group ==
								'ACTION_BTN' &&
							textItem.type == 'BASKET_BTN'
						"
						:key="index"
					>
						<v-btn
							class="mx-1 order-last black--text font-size-13"
							:class="
								isScrollWasTop
									? 'section-header-btn-noScroll'
									: 'section-header-btn-scrolled'
							"
							min-width="85"
							@click="$store.dispatch('shop/isOpenCart', true)"
						>
							<span>{{ textItem.name }}</span>
							<v-icon
								size="20"
								:class="$vuetify.rtl ? 'mr-2' : 'ml-2'"
								>mdi-cart-outline</v-icon
							>
						</v-btn>
					</v-badge>
				</template>
			</v-col>
		</v-row>
	</v-app-bar>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		drawer: false,
		background: false,
		isScrollWasTop: false,
		type: "selector",
		selector: "#swiper-section",
		duration: 1000,
		offset: 50,
		easing: "easeInOutCubic",
	}),
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			cartCount: "shop/cartCount",
			isAuth: "isAuth",
			getUserName: "getUserName",
			getSiteLogo: "siteSetting/getSiteLogo",
			getDomain: "siteSetting/getDomain",
			getSiteColor: "siteSetting/getSiteColor",
			getHeaderSettings: "siteSetting/getHeaderSettings",
			getSettingLength: "siteSetting/getSettingLength",
			getTranslations: "siteSetting/getTranslations",
			getSiteSetting: "siteSetting/getSiteSetting",
			getTextsUrl: "siteSetting/getTextsUrl",
			getBoxSearch: "search/getBoxSearch",
			getStartOrder2: "firstData/getStartOrder2",
		}),

		target() {
			const value = this[this.type];
			if (!isNaN(value)) return Number(value);
			else return value;
		},

		options() {
			return {
				duration: this.duration,
				offset: this.offset,
				easing: this.easing,
			};
		},
	},
	mounted() {
		if (!this.$device.isMobile) this.isScrollWasTop = true;
		// Checks if scrolling is done
		document.addEventListener("scroll", () => {
			return window.scrollY < 100
				? (this.isScrollWasTop = true)
				: (this.isScrollWasTop = false);
		});

		// Get all categories
		this.getStartOrder2.cats.map(cat => this.getCategories(cat.id));
	},
	methods: {

		// Change site language
		changeLang(locale) {
			window.location.href = `${window.location.origin}/${locale}`;
		},

		// open login card
		openLoginCard() {
			if (this.isAuth) {
				this.$store.commit("loginCard/SET_STATUS", 4);
			} else this.$store.commit("loginCard/SET_STATUS", 1);
		},

		// Return to previous page
		pageBack() {
			// If it is on the order page, it will be redirected to the main page
			if (
				this.cartCount == 0 &&
				this.$router.currentRoute.path == `/${this.$i18n.locale}/order`
			) {
				this.$router.push("index");
			} else {
				window.history.back();
			}
		},

		// Get all categories
		getCategories(catID) {
			var productType = this.getFirstData.shops[0].product_type;

			if (productType == "CATEGORISE") {
				this.$store
					.dispatch("branch/categories", {
						branch: this.getFirstData.shops[0],
						branchId: this.getFirstData.shops[0].id,
						lang: this.$i18n.locale,
					})
					.then(res => {
						this.getCategoriesChildren(newVal);
					});
			}
		},

		// Set categories
		getCategoriesChildren(newVal) {
			if (newVal) {
				newVal.map((val, key) => {
					if (val) {
						this.changeCategory(val);
					}
				});
			}
		},

		// Change category
		changeCategory(item) {
			this.$store.dispatch("categories/setSelectedBreadcrumb", {
				item,
			});
		},

		// Check if the header can be deleted by scrolling
		isScrollWasTopColor() {
			//
			let routeScroll = false;
			// Pages that the header needs to change
			if (
				this.$route.path.startsWith(`/${this.$i18n.locale}/page`) ||
				this.$route.path.startsWith(
					`/${this.$i18n.locale}/contactUs`
				) ||
				this.$route.path.startsWith(`/${this.$i18n.locale}/survey`) ||
				this.$route.path.startsWith(
					`/${this.$i18n.locale}/invitation`
				) ||
				(this.$route.name == "index___" + this.$i18n.locale &&
					this.getBoxSearch)
			)
				routeScroll = true;

			// If it is mobile, select the site color
			if (this.$device.isMobile) {
				if (this.getSiteColor) return this.getSiteColor.color;
				else return "blue-grey darken-1";
			}
			// If it is a desktop, check the background and scroll ability
			else {
				if (this.background || (this.isScrollWasTop && routeScroll))
					return "transparent";
				else if (this.getSiteColor) return this.getSiteColor.color;
				else return "blue-grey darken-1";
			}
		},
	},
};
</script>

<style scoped lang="scss">
// Header styles
.section-the-haeder {
	transition: all 0.5s ease;
	// Menu button styles
	.section-header-menu {
		width: 46.5px;
		height: 46.5px;
		padding: 7px;
		border-radius: 50%;
		z-index: 5;
		position: relative;
		transition: all 0.25s ease;
		.section-header-menu-top {
			transition: inherit;
			position: absolute;
			height: 1px;
			margin: 1px 1.7px;
			width: 27.5px;
			background-color: #fff;
			border-radius: 5px;
			display: inline-block;
			top: calc(50% - 9px);
		}
		.section-header-menu-center {
			transition: inherit;
			width: 27.5px;
			height: 1px;
			margin: 1px 1.7px;
			position: absolute;
			height: 1px;
			background-color: #fff;
			border-radius: 5px;
			display: block;
			top: calc(50% - 1px);
		}
		.section-header-menu-bottom {
			transition: inherit;
			position: absolute;
			margin: 1px 1.7px;
			height: 1px;
			width: 27.5px;
			background-color: #fff;
			border-radius: 5px;
			display: inline-block;
			top: calc(50% + 7px);
		}
	}
	// Close button styles
	.section-drawer-close {
		transform: rotate(0);
		.section-header-menu-top {
			transform: rotate(45deg);
			top: calc(50% - 1px);
			margin: 1px 3px;
		}
		.section-header-menu-center {
			transform: scaleX(0);
		}
		.section-header-menu-bottom {
			margin: 1px 3px;
			transform: rotate(-45deg);
			top: calc(50%);
		}
	}
}
// Header styles after scroll
.section-header-btn-scrolled {
	box-shadow: 0 0 8px 0 #00000040;
	background-color: #efefef !important;
	height: 34.5px !important;
	border-radius: 6px !important;
}
// Header styles before scroll
.section-header-btn-noScroll {
	box-shadow: 0px 0px 0px 0px rgb(0 0 0 / 0%);
	background-color: #ffff !important;
	height: 34.5px !important;
	border-radius: 6px !important;
}
</style>