// import axios from 'axios'
// export default {
//   auth: {
//     me:     data => axios.get(`/user/${data}`),
//     login:  data => axios.post('/confirmCode', data),
//     signup: data => axios.post('/signUp', data),
//     logout: token => axios.post('/logout', token),
//   }
// }

export const home = {
	getAppDownload: "getAppMarketsInfo",
};
export const search = {
	resultSearch: "search",
};
export const order = {
	showForm: "showForm",
	checkLeaderCode: "checkLeaderCode",
};
export const product = {
	getProductInfoV1: "getProductInfo",
	getProductInfoV2: "v1/getProductInfo",
	// plan of onclick No Sale | use on componnnet (no-salse)
	getPlans: "getPlans",
};

export const orderDetails = "orderDetails";

export const survey = {
	saveFeedback: "saveFeedback",
};
export const profile = {
	orderHistory: "orderHistory",
	approvePayment: "approvePayment",
	cancelOrder: "cancelOrder",
};

export const callRequest = "callRequest";

export const blog = {
	blogCategories: "blogCategories",
	blogList: "blogList",
	blogDetail: "blogDetail",
};

export const events = {
	blogEvent: "blogEvent",
};

export const gallery = {
	galleryCategories: "galleryCategories",
	galleryList: "galleryList",
	galleriesShow: "galleriesShow",
};

export const login = {
	signUp: "signUp",
	code: "getCode",
	checkLeaderSignUp: "checkLeaderSignUp",
};
