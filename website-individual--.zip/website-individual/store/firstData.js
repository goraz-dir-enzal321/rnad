// state
export const state = () => ({
	firstData: {},
	monetaryUnit: "unit",
});

// mutations
export const mutations = {
	SAVE_DATA(state, data) {
		state.firstData = data;
		this.dispatch("search/setBoxSearch", data);
		this.dispatch(
			"offer/setDataOffer",
			data && data.header && data.header.OFFER && data.header.OFFER[0]
				? data.header.OFFER[0]
				: null
		);
	},
	SAVE_MONETARY_UNIT(state, unit) {
		state.monetaryUnit = unit;
	},
};

// getters
export const getters = {
	getAreaPriceFreeDelivery(state) {
		if (
			Object.keys(state.firstData) &&
			state.firstData.shops &&
			state.firstData.shops.length != 0
		) {
			// && state.firstData.free_delivery_price
			let sendingArrayObjectFreeDelivery = [];
			if (state.firstData.shops.length != 1) {
				state.firstData.shops.forEach(element => {
					sendingArrayObjectFreeDelivery[element.id] =
						element.free_delivery_price;
				});
				return sendingArrayObjectFreeDelivery;
			} else {
				sendingArrayObjectFreeDelivery[state.firstData.shops[0].id] =
					state.firstData.shops[0].free_delivery_price;
				return sendingArrayObjectFreeDelivery;
			}
		}
	},
	getTaxFirstBranch(state) {
		if (
			Object.keys(state.firstData) &&
			state.firstData.shops &&
			state.firstData.shops.length == 1 &&
			state.firstData.shops[0].tax
		) {
			return state.firstData.shops[0].tax;
		} else if (
			Object.keys(state.firstData) &&
			state.firstData.shops &&
			state.firstData.shops.filter(shop => shop.status).length == 1 &&
			state.firstData.shops[
				state.firstData.shops.findIndex(shop => shop.status)
			].tax
		) {
			return state.firstData.shops[
				state.firstData.shops.findIndex(shop => shop.status)
			].tax;
		}
		return null;
	},
	getCommissionFirstBranch(state) {
		if (
			Object.keys(state.firstData) &&
			state.firstData.shops &&
			state.firstData.shops.length == 1
		) {
			return {
				percent: state.firstData.shops[0].commission_percent,
				mount: state.firstData.shops[0].commission_mount,
			};
		} else if (
			Object.keys(state.firstData) &&
			state.firstData.shops &&
			state.firstData.shops.filter(shop => shop.status).length == 1
		) {
			return {
				percent:
					state.firstData.shops[
						state.firstData.shops.findIndex(shop => shop.status)
					].commission_percent,
				mount:
					state.firstData.shops[
						state.firstData.shops.findIndex(shop => shop.status)
					].commission_mount,
			};
		}
		return null;
	},
	getCountries(state) {
		if (Object.keys(state.firstData)) {
			if (state.firstData.countries) {
				return state.firstData.countries;
			}
		}
		return "";
	},
	getPageTitle(state) {
		// if(Object.keys(state.firstData)) {
		//   if(Boolean(state.firstData.shops)) {
		//     if(state.firstData.shops.translations.length) {
		//       // let $result = Boolean(state.firstData.shops.translations.find(translate => translate.locale == this.$i18n).title) ? state.firstData.shops.translations.find(translate => translate.locale == this.$i18n).title : Boolean(state.firstData.shops.title) ? state.firstData.shops.title : state.firstData.shops.name;
		//       // console.logconsole.log('$result ', $result);

		//       return 'web';
		//     }
		//   }
		// }
		return "";
	},
	getShops(state) {
		if (Object.keys(state.firstData) && Boolean(state.firstData.shops)) {
			return state.firstData.shops;
		}
		return null;
	},
	getShop: state => id => {
		if (Object.keys(state.firstData) && Boolean(state.firstData.shops)) {
			return state.firstData.shops.find(shop => shop.id == id);
		}
		return null;
	},
	getCallUs(state) {
		if (
			Object.keys(state.firstData) &&
			Boolean(state.firstData.header) &&
			state.firstData.header.hasOwnProperty("CALL_US") &&
			state.firstData.header.CALL_US.length
		) {
			return state.firstData.header.CALL_US[0];
		}
		return null;
	},
	getFirstData: state => state.firstData,
	getMonetaryUnit: state => state.monetaryUnit,
	getHasFirstData(state) {
		if (Object.keys(state.firstData).length) {
			return true;
		}
		return null;
	},
	getHasStartOrder2: state =>
		Object.keys(state.firstData) &&
		Boolean(state.firstData.header) &&
		state.firstData.header.FIRST_CAT &&
		state.firstData.header.FIRST_CAT.length &&
		!!state.firstData.header.FIRST_CAT[0],
	getStartOrder2(state) {
		if (
			Object.keys(state.firstData) &&
			Boolean(state.firstData.header) &&
			state.firstData.header.hasOwnProperty("FIRST_CAT") &&
			state.firstData.header.FIRST_CAT.length
		) {
			return state.firstData.header.FIRST_CAT[0];
		}
		return {};
	},
};

// actions
export const actions = {
	save({ commit }, data) {
		commit("SAVE_DATA", data);
	},
	monetaryUnit({ commit }, unit) {
		commit("SAVE_MONETARY_UNIT", unit);
	},
};
