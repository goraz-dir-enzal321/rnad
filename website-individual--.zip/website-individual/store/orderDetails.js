import { orderDetails } from "@/api";

export const state = () => ({
	//Information received from the server
	orderDetail: {},
	orderPlans: {},
	shop: {},
	orderStatus: null,
	loading: null,
	orderPriceList: null,
});

export const mutations = {
	// Set order details
	SET_ORDER_DETAIL(state, _object) {
		state.orderDetail = _object;
	},
	// Set order plans
	SET_ORDER_PLANS(state, _array) {
		state.orderPlans = _array;
	},
	//  Set order status
	SET_ORDER_STATUS(state, _boolean) {
		state.orderStatus = _boolean;
	},
	// Set shop for this order
	SET_SHOP(state, _object) {
		state.shop = _object;
	},
	// Change loading state
	SET_LOADING(state, _boolean) {
		state.loading = _boolean;
	},
	//Change loading state
	SET_ORDER_PRICE_LIST(state, _object) {
		state.orderPriceList = _object;
	},
};

export const getters = {
	// *orderDerails getters
	// Get order number details
	getOrderDetailId: state => state.orderDetail.order_id,
	// Get user ID
	getUserId: state => state.orderDetail.user_id,
	// Get order details
	getOrderDetail: state => state.orderDetail,
	// Get order branch ID
	getBranchId: state => state.orderDetail.branch_id,
	// Get order code
	getOrderCode: state => state.orderDetail.code,
	// Get payment type details
	getPaymentType: state => state.orderDetail.payment_type,
	// Get order details
	getOrderItems: state => state.orderDetail.items,
	// Get receive service location
	// getLocation: state => state.orderDetail.location,
	// Get receive service address
	getAddress: state => state.orderDetail.address,
	// Get questions
	getQuestions: state => state.orderDetail.questions,
	// Get area time
	getAreaTime: state => state.orderDetail.area_time,
	// Get product time
	getProductTime: state => state.orderDetail.product_time,
	// Get created time
	getCreatedAt: state => state.orderDetail.created_at,
	// Get sales invoice details
	getSalesInvoice: state => ({
		totalDiscount: state.orderDetail.total_discount,
		taxPercent: state.orderDetail.tax_percent,
		commissionMount: state.orderDetail.commission_mount,
		commissionPercent: state.orderDetail.commission_percent,
		deliveryPrice: state.orderDetail.delivery_price,
		totalPrice: state.orderDetail.total_price,
	}),
	// Get order price list
	getOrderPriceList: state => state.orderPriceList,
	// */orderDerails getters

	// orderPlans getter
	getOrderPlans: state => state.orderPlans,

	// orderStatus getter
	getOrderStatus: state => state.orderStatus,

	// *Shop getters
	// Get Shop monetary unit
	getShopMonetaryUnit: state => state.shop.monetary_unit,

	// Get shop id
	getShopID: state => state.shop.id,
	//this order process
	getOrderProcess: state => {
		if (Object.keys(state.shop) && Boolean(state.shop.order_process)) {
			return state.shop.order_process.find(
				process => process.id == state.orderDetail.process_id
			);
		}
		return null;
	},
	// All order process
	getAllOrderProcess: state => state.shop.order_process,

	// */Shop getters

	// loading getter
	getLoading: state => state.loading,
};

export const actions = {
	async getApiOrderDetail({ commit, dispatch }, _numberOderId) {
		// Change loading state true
		commit("SET_LOADING", true);
		await this.$axios
			.$post(orderDetails, {
				token: this.getters["getToken"],
				order_id: _numberOderId,
				lang: this.$i18n.locale,
			})
			.then(res => {
				// Set order status
				commit("SET_ORDER_STATUS", res.status);
				if (res.status == true) {
					// Set order details
					commit("SET_ORDER_DETAIL", res.order);
					// Set order plans
					commit("SET_ORDER_PLANS", res.plans);
					// Fetch shop data for this order
					commit(
						"SET_SHOP",
						this.getters["firstData/getShop"](res.order.branch_id)
					);
					// Set order all items price list
					dispatch("setTotalPriceProps");
				} else if (res.status == false) {
					let vm = this;
					setTimeout(function () {
						vm.$router.push(`/${vm.$i18n.locale}`);
					}, 5000);
				}
				// Change loading state false
				commit("SET_LOADING", false);
			})
			.catch(err => {
				console.log("ERROR is: ===>", err);
				// this.dispatch("snackbar/isShow", true);
				// this.dispatch("snackbar/setText", err);
				// this.dispatch("snackbar/setColor", "warning");
			});
	},

	setTotalPriceProps({ commit, getters }) {
		let collectItems = 0;
		let propPrice = 0;
		let salesInvoice = getters.getSalesInvoice;
		for (let item of getters.getOrderItems && getters.getOrderItems.length
			? getters.getOrderItems
			: getters.getOrderPlans) {
			// Checked exist prop info in item and sum props price
			if (item.prop_info) {
				for (let prop of item.prop_info) {
					propPrice += +prop.price;
				}
			}
			collectItems += (+propPrice + +item.price) * item.count;
		}

		// Send to mutations
		commit("SET_ORDER_PRICE_LIST", {
			collectItems: collectItems,
			tax: (+salesInvoice.totalPrice * +salesInvoice.taxPercent) / 100,
			totalWage:
				(+salesInvoice.totalPrice * +salesInvoice.commissionPercent) /
					100 +
				+salesInvoice.commissionMount,
		});
	},
};
