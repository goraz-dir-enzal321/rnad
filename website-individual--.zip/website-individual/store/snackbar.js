export const state = () => ({
    isShowSnackbar: false,
    text: '',
    color: 'teal darken-4',
});
export const mutations = {
    SET_IS_SHOW(state, payload) {
        state.isShowSnackbar = payload;
    },
    SET_TEXT(state, text) {
        state.text = text;
    },
    SET_COLOR(state, color) {
        state.color = color;
    },
};
export const getters = {
    getIsShowSnackbar: state => {
        return state.isShowSnackbar;
    },
    getSnackbarText: state => {
        return state.text;
    },
    getSnackbarColor: state => {
        return state.color;
    },
};
export const actions = {
    isShow({commit}, isShow) {
        commit('SET_IS_SHOW', isShow);
    },
    setText({commit}, text) {
        commit('SET_TEXT', text);
    },
    setColor({commit}, color) {
        commit('SET_COLOR', color);
    },
};
