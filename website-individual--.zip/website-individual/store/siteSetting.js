import { Setting } from "@/models";

export const state = () => {
	return {
		$setting: [],
		$url: null,
	};
};
export const mutations = {
	SET_SETTING(state, payload) {
		state.$setting = payload;
	},
	SET_URL(state, payload) {
		state.$url = payload;
	},
};
export const getters = {
	getDomain: state => {
		if (Boolean(state.$url)) {
			let $domain = state.$url;
			return $domain;
		}
	},
	getSmsPanel: state => {
		if (Boolean(state.$setting)) {
			if (Boolean(state.$setting.settings)) {
				if (Boolean(state.$setting.settings.has_sms_panel)) {
					return state.$setting.settings.has_sms_panel;
				}
			}
		}
		return null;
	},
	getCompanyName: state => {
		if (Boolean(state.$setting)) {
			if (Boolean(state.$setting.settings)) {
				return state.$setting.settings.company_name;
			}
		}
		return null;
	},
	getSettingLength: state => {
		if (Boolean(state.$setting) && Boolean(state.$setting.settings)) {
			return Object.keys(state.$setting).length;
		}
		return 0;
	},
	getSiteLogo: state => {
		if (Boolean(state.$setting)) {
			if (Boolean(state.$setting.settings)) {
				let $siteLogo = state.$setting.settings.logo;
				return $siteLogo;
			}
		}
		return false;
	},
	getSiteColor: state => {
		if (Boolean(state.$setting)) {
			if (Boolean(state.$setting.settings)) {
				let $siteColor = state.$setting.settings.site_color;
				let $secondColor = ColorLuminance($siteColor, -0.1);
				return { color: $siteColor, secondColor: $secondColor };
			}
		}
	},
	AllColors: state => {
		if (Boolean(state.$setting) && Boolean(state.$setting.settings)) {
			let colors = {};
			if (state.$setting.settings.site_color) {
				colors.site_color = state.$setting.settings.site_color;
			}
			if (state.$setting.settings.bg_color) {
				colors.bg_color = state.$setting.settings.bg_color;
			}
			if (state.$setting.settings.btn_bg_color) {
				colors.btn_bg_color = state.$setting.settings.btn_bg_color;
			}
			if (state.$setting.settings.btn_txt_color) {
				colors.btn_txt_color = state.$setting.settings.btn_txt_color;
			}
			if (state.$setting.settings.app_bg_color) {
				colors.app_bg_color = state.$setting.settings.app_bg_color;
			}
			if (state.$setting.settings.app_text_color) {
				colors.app_text_color = state.$setting.settings.app_text_color;
			}
			if (state.$setting.settings.app_btn_color) {
				colors.app_btn_color = state.$setting.settings.app_btn_color;
			}
			if (state.$setting.settings.app_btn_text_color) {
				colors.app_btn_text_color =
					state.$setting.settings.app_btn_text_color;
			}
			if (state.$setting.settings.branches_bg_color) {
				colors.branches_bg_color =
					state.$setting.settings.branches_bg_color;
			}
			if (state.$setting.settings.start_order_btn_color) {
				colors.start_order_btn_color =
					state.$setting.settings.start_order_btn_color;
			} // next \/
			if (state.$setting.settings.book_now_btn_color) {
				colors.book_now_btn_color =
					state.$setting.settings.book_now_btn_color;
			}
			// if(state.$setting.settings.start_order_btn_color){
			//   colors.start_order_btn_color = state.$setting.settings.start_order_btn_color
			// }
			return colors;
		}
	},
	getBgColor: state => {
		if (Boolean(state.$setting) && Boolean(state.$setting.settings)) {
			let $bgColor = state.$setting.settings.bg_color;
			return $bgColor;
		}
	},
	getHeaderSettings: state => {
		if (Boolean(state.$setting) && Boolean(state.$setting.settings)) {
			return state.$setting.settings.header;
		}
	},
	getDefaultLang: state => {
		if (state.$setting) {
			if (state.$setting.settings) {
				let locale = state.$setting.settings.default_lang;
				return locale;
			}
		}
	},
	getLocales: state => {
		let locales = state.$setting.locales;
		return locales;
	},
	getMainShopId: state => {
		if (Boolean(state.$setting)) {
			if (Boolean(state.$setting.settings)) {
				return state.$setting.settings.shop_id;
			}
		}
	},
	getTopic: state => {
		if (state.$setting) {
			if (state.$setting.settings) {
				let $topic = state.$setting.settings.topic;
				return $topic;
			}
		}
		return null;
	},
	getMonetaryUnit: state => {
		/*if(state.$setting) {
          if (state.$setting.settings) {
            let $topic = state.$setting.settings.topic;
            return $topic;
          }
        }*/
		return state.monetaryUnit;
	},
	getTheme: state => {
		if (state.$setting) {
			if (state.$setting.settings) {
				return state.$setting.settings.theme;
			}
		}
		return null;
	},
	getSwiperBgColor: state => {
		if (state.$setting) {
			if (state.$setting.settings) {
				return state.$setting.settings.branches_bg_color;
			}
		}
		return null;
	},
	getBranchTitle: state =>
		state.$setting &&
		state.$setting.settings &&
		state.$setting.settings.branches_title
			? state.$setting.settings.branches_title
			: null,
	getBtnStyle: state => {
		if (state.$setting) {
			if (state.$setting.settings && state.$setting.settings.btn_style) {
				return state.$setting.settings.btn_style;
			}
		}
		return null;
	},
	getTranslations: state => {
		if (state.$setting) {
			if (
				state.$setting.settings &&
				state.$setting.settings.translations.length
			) {
				return state.$setting.settings.translations;
			}
		}
		return null;
	},
	getBlogSettings: state => {
		if (state.$setting) {
			if (state.$setting.settings && state.$setting.settings.blog) {
				return state.$setting.settings.blog;
			}
		}
		return null;
	},
	getHasBlog: state => {
		if (state.$setting) {
			if (state.$setting.settings && state.$setting.settings.has_blog) {
				return state.$setting.settings.has_blog;
			}
		}
		return null;
	},
	getGallerySettings: state => {
		if (state.$setting) {
			if (state.$setting.settings && state.$setting.settings.gallery) {
				return state.$setting.settings.gallery;
			}
		}
		return null;
	},
	getHasGallery: state => {
		if (state.$setting) {
			if (
				state.$setting.settings &&
				state.$setting.settings.has_gallery
			) {
				return state.$setting.settings.has_gallery;
			}
		}
		return null;
	},
	getSiteSetting: state => {
		if (state.$setting) {
			return new Setting(state.$setting.settings);
		}
		return new Setting();
	},
	getDynamicText: state => type => {
		if (
			Object.keys(state.$setting) &&
			Boolean(state.$setting.settings.dynamic_texts)
		) {
			let $item = state.$setting.settings.dynamic_texts.find(
				item => item.type == type
			);
			return $item ? $item.text : null;
		}
		return null;
	},
	getDefaultImg: state => {
		return state.$setting &&
			state.$setting.settings &&
			state.$setting.settings.default_img
			? state.$setting.settings.default_img
			: null;
	},
	getSiteFavicon: state => {
		if (Boolean(state.$setting) && Boolean(state.$setting.settings)) {
			let $siteFavicon = state.$setting.settings.favicon;
			return $siteFavicon;
		}
		return false;
	},
	getSiteSeo: state => {
		if (
			Boolean(state.$setting) &&
			Boolean(state.$setting.settings) &&
			state.$setting.settings.seo
		) {
			let $siteSeo = state.$setting.settings.seo;
			return $siteSeo;
		}
		return {
			desc: null,
			title: null,
		};
	},
	getUseFloatDigit: state => number => {
		if (
			Boolean(state.$setting) &&
			Boolean(state.$setting.settings) &&
			state.$setting.settings.use_float_digit == 0
		) {
			return Math.round(number);
		}
		return number;
	},

	getHeaderVersion: state => {
		let headerVersion= "new"
		return headerVersion	
	}
};
export const actions = {
	saveSettings({ commit }, payload) {
		commit("SET_SETTING", payload);
	},
	saveUrl({ commit }, url) {
		commit("SET_URL", url);
	},
};

const ColorLuminance = (hex, lum) => {
	// validate hex string
	hex = String(hex).replace(/[^0-9a-f]/gi, "");
	if (hex.length < 6) {
		hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
	}
	lum = lum || 0;

	// convert to decimal and change luminosity
	var rgb = "#",
		c,
		i;
	for (i = 0; i < 3; i++) {
		c = parseInt(hex.substr(i * 2, 2), 16);
		c = Math.round(Math.min(Math.max(0, c + c * lum), 255)).toString(16);
		rgb += ("00" + c).substr(c.length);
	}

	return rgb;
};
