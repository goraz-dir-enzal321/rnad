import { search } from "@/api";
export const state = () => ({
	boxDataSearch: {},
	boxLoadingDataSearch: true,
	textSearch: "",
	paginationSearch: "",
	// textSearchNotFound: "",
	dataResponseSearch: {},
	dialogSearchFilter: false,
	loadingFilter: false,
	loadingSearch: false,
	filtersObjectSenderAxios: null,
	// makeUrlFilter: "",
});

export const mutations = {
	// box on home
	SET_BOX_SEARCH(state, object) {
		state.boxDataSearch = object;
	},
	// loading on page search
	SET_LOADING_BOX_SEARCH(state, object) {
		state.boxLoadingDataSearch = object;
	},
	// loading on page search
	SET_TEXT_SEARCH(state, text) {
		state.textSearch = text;
	},
	SET_PAGINATION_SEARCH(state, number) {
		state.paginationSearch = number;
	},
	// SET_TEXT_SEARCH_NOT_FOUND(state, text) {
	// 	state.textSearchNotFound = text;
	// },
	SET_DATA_RESPONSE_SEARCH(state, object) {
		state.dataResponseSearch = object;
	},
	// if in mobile
	SET_DIALOG_SEARCH_FILTER(state, boolean) {
		state.dialogSearchFilter = boolean;
	},
	// loading
	SET_LOADING_FILTER(state, boolean) {
		state.loadingFilter = boolean;
	},
	SET_LOADING_SEARCH(state, boolean) {
		state.loadingSearch = boolean;
	},
	SET_FILTERS_OBJECT_SENDER_AXIOS(state, object) {
		state.filtersObjectSenderAxios = object;
	},
	SET_ADD_FILTER_OBJECT_SENDER_AXIOS(state, object) {
		if (Object.keys(object)[0])
			state.filtersObjectSenderAxios[
				Object.keys(object)[0]
			] = Object.values(object)[0];
	},
	// SET_MAKE_URL_FILTER(state) {
	// 	if (Object.keys(state.filtersObjectSenderAxios)?.length) {
	// 		state.makeUrlFilter = "";
	// 		Object.keys(state.filtersObjectSenderAxios).forEach(
	// 			(key, index) => {
	// 				if (
	// 					Object.keys(state.filtersObjectSenderAxios).length -
	// 						1 ==
	// 					index
	// 				) {
	// 					state.makeUrlFilter += `${key}=${
	// 						Object.values(state.filtersObjectSenderAxios)[index]
	// 					}`;
	// 				} else
	// 					state.makeUrlFilter += `${key}=${
	// 						Object.values(state.filtersObjectSenderAxios)[index]
	// 					}&`;
	// 			}
	// 		);
	// 	}
	// },
};
export const getters = {
	getBoxSearch: state => state.boxDataSearch,
	getLoadingBoxSearch: state => state.boxLoadingDataSearch,
	getTextSearch: state => state.textSearch,
	getPageSearch: state => state.paginationSearch,
	// getTextSearchNotFound: state => state.textSearchNotFound,
	getDataResponseSearch: state => state.dataResponseSearch,
	getDialogSearchFilter: state => state.dialogSearchFilter,
	getLoadingFilter: state => state.loadingFilter,
	getLoadingSearch: state => state.loadingSearch,
	getFiltersObjectSenderAxios: state => state.filtersObjectSenderAxios, // for see what have filter
	// getMakeUrlFilter: state =>
	// 	Object.keys(state.makeUrlFilter)?.length ? state.makeUrlFilter : null, // for see what have filter
};
export const actions = {
	setBoxSearch({ commit }, data) {
		commit(
			"SET_BOX_SEARCH",
			data.header && data.header.SEARCH && data.header.SEARCH[0]
				? data.header.SEARCH[0]
				: null
		);
		commit("SET_LOADING_BOX_SEARCH", false);
	},
	setTextSearch({ commit }, text) {
		commit("SET_TEXT_SEARCH", text);
	},
	setPaginationSearch({ commit }, number) {
		commit("SET_PAGINATION_SEARCH", number);
	},
	// loading
	setLoadingFilter({ commit }, boolean) {
		commit("SET_LOADING_FILTER", boolean);
	},
	setLoadingSearch({ commit }, boolean) {
		commit("SET_LOADING_SEARCH", boolean);
	},
	// setTextSearchNotFound({ commit }, text) {
	// 	commit("SET_TEXT_SEARCH_NOT_FOUND", text);
	// },
	setDataResponseSearch({ commit }, object) {
		commit("SET_DATA_RESPONSE_SEARCH", object);
	},
	// if in mobile
	setDialogSearchFilter({ commit }, object) {
		commit("SET_DIALOG_SEARCH_FILTER", object);
	},
	setFiltersObjectSenderAxios({ commit }, object) {
		commit("SET_FILTERS_OBJECT_SENDER_AXIOS", object);
	},
	setAddFilterObjectSenderAxios({ commit }, object) {
		commit("SET_ADD_FILTER_OBJECT_SENDER_AXIOS", object);
	},
	// setMakeUrlFilter({ commit }) {
	// 	commit("SET_MAKE_URL_FILTER");
	// },

	async setResultSearch({ state, dispatch }, isJustTextSearch = false) {
		dispatch("setDialogSearchFilter", false);
		dispatch("setLoadingSearch", true);
		/* console.log("{...)", {
			...(isJustTextSearch
				? { keyword: state.textSearch }
				: state.filtersObjectSenderAxios),
			shop_id: this.getters["siteSetting/getMainShopId"],
			page: state.paginationSearch ? state.paginationSearch : 1,
		}); */

		await this.$axios
			.$post(search.resultSearch, {
				...(isJustTextSearch
					? { keyword: state.textSearch }
					: this.$device.isMobile
					? {
							keyword: state.textSearch,
							...state.filtersObjectSenderAxios,
					  }
					: state.filtersObjectSenderAxios),
				shop_id: this.getters["siteSetting/getMainShopId"],
				page: state.paginationSearch ? state.paginationSearch : 1,
			})
			.then(res => {
				console.log("res", res);
				if (res.status) {
					// if (res.items && res.items.length)
					dispatch("setDataResponseSearch", res);
					// else dispatch("setTextSearchNotFound", state.textSearch);
				}
			})
			.catch(err => {
				console.log("Error :>> ", err);
			})
			.finally(() => {
				dispatch("setLoadingSearch", false);
				// dispatch("setMakeUrlFilter");
			});
		// commit("SET_TEXT_SEARCH", text);
	},
};
