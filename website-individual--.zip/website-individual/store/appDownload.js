import { home } from "@/api";

export const state = () => ({
	dataAppDownload: null,
	loadingDownload: false,
	isHasWebVertion: false,
	dialogWebVertion: false,
});

export const mutations = {
	SET_DATA_APP_DOWNLOAD(state, object) {
		state.dataAppDownload = object;
	},
	SET_LOADING_DOWNLOAD(state, boolean) {
		state.loadingDownload = boolean;
	},
	SET_DIALOG_WEB_VERTION(state, status) {
		state.dialogWebVertion = status;
   },
	SET_IS_HAS_WEB_VERTION(state, status) {
		state.isHasWebVertion = status;
	},
};
export const getters = {
	getDataAppDownload: state =>
		state.dataAppDownload ? state.dataAppDownload : null,
	getLoadingDownload: state => state.loadingDownload,
	getDialogWebVertion: state => state.dialogWebVertion,
	getIsHasWebVertion: state => state.isHasWebVertion,
};
export const actions = {
	setDataApplicationDownload({ commit }, boolean) {
		commit("SET_DATA_APP_DOWNLOAD", boolean);
	},
	setLoadingDownload({ commit }, boolean) {
		commit("SET_LOADING_DOWNLOAD", boolean);
	},
	setDataAppDownload({ dispatch }) {
		dispatch("setLoadingDownload", true);
		this.$axios
			.$post(home.getAppDownload, {
				shop_id: this.getters["siteSetting/getMainShopId"],
			})
			.then(res => {
				if (res.status) {
					dispatch("setDataApplicationDownload", res);
					dispatch("setIsHasWebVertion", res.markets && res.markets.web_app ? res.markets.web_app : false);
				}
			})
			.catch(err => {
				console.log("Error :>> ", err);
			})
			.finally(() => {
				dispatch("setLoadingDownload", false);
			});
   },
	setDialogWebVertion({ commit }, status) {
		commit("SET_DIALOG_WEB_VERTION", status);
	},
	setIsHasWebVertion({ commit }, status) {
		commit("SET_IS_HAS_WEB_VERTION", status);
	},
};
