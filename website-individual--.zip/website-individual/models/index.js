export { default as Setting } from "./setting";
// export { default as Setting } from "search";
