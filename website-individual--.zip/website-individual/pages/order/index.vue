<template>
	<div>
		<v-container>
			<v-row>
				<v-col cols="12">
					<v-form v-model="valid">
						<v-container>
							<v-row>
								<v-col cols="12" md="8">
									<!-- textarea -->
									<v-textarea
										v-model="descriptionComputed"
										:label="
											$t('form.label.explain_request')
										"
										:placeholder="
											$t(
												'form.placeholder.explain_request'
											)
										"
										solo
									/>
									<!-- /textarea -->
									<!-- location -->
									<v-card
										class="mb-8"
										:loading="loading"
										:disabled="loading"
										v-if="
											getShop(getHasShopIdCart)
												? getShop(getHasShopIdCart)
														.has_send_product ==
														1 ||
												  getShop(getHasShopIdCart)
														.has_fixed_address == 1
												: false
										"
									>
										<v-card-text>
											<p
												class="font-size-title"
												v-text="
													$t(
														'label.where_do_you_need_order'
													)
												"
											/>
											<v-radio-group
												v-model="addressGroup"
												:mandatory="false"
												:loading="loading"
												:disabled="loading"
												class="radio-full-width w-100"
											>
												<v-skeleton-loader
													type="list-item-avatar-two-line"
													tile
													v-if="isShowLoader"
												/>
												<v-radio
													v-if="
														getShop(
															getHasShopIdCart
														).has_send_product == 1
													"
													name="address"
													color="green darken-1"
													:value="address.id"
													class="align-start w-100"
													v-for="address in addressesComputed"
													:key="address.id"
													@change="
														getShowForm(
															address.type,
															address.area &&
																address.area
																	.price
																? address.area
																		.price
																: 0
														)
													"
												>
													<template v-slot:label>
														<div
															class="d-flex w-100"
															:class="
																$vuetify.rtl
																	? 'text-right'
																	: 'text-left'
															"
														>
															<div
																class="flex-shrink-1 flex-grow-1"
															>
																<div
																	class="font-size-subtitle-2 font-weight-bold"
																	v-text="
																		Boolean(
																			address.area
																		)
																			? address
																					.area
																					.name
																			: '-----'
																	"
																/>
																<div
																	class="font-size-body-2 px-3"
																	v-text="
																		address.address
																	"
																/>
															</div>
															<v-btn
																depressed
																rounded
																color="green darken-1 white--text"
																@click.prevent="
																	$store.dispatch(
																		'order/showForm',
																		true
																	)
																"
																v-if="
																	address.id ==
																		selectedAddress &&
																	getForm
																"
															>
																<v-icon
																	left
																	dark
																	v-text="
																		'mdi-table-eye'
																	"
																/>

																{{
																	$t(
																		"button.viewForm"
																	)
																}}
															</v-btn>
														</div>
													</template>
												</v-radio>
												<v-radio
													v-if="
														getShop(
															getHasShopIdCart
														).has_fixed_address == 1
													"
													name="address"
													color="green darken-1"
													:value="address.id"
													class="align-start w-100"
													v-for="address in fixedAddressesComputed"
													:key="address.id"
													@change="areaPrice = 0"
												>
													<template v-slot:label>
														<div
															class="d-flex flex-column align-start w-100"
														>
															<div
																class="font-size-subtitle-2 d-flex font-weight-bold w-100"
																v-text="
																	address.name
																"
															/>
															<div
																class="font-size-body-2 d-flex justify-space-between w-100 px-3"
															>
																<div
																	v-text="
																		address.description
																	"
																/>
															</div>
														</div>
													</template>
												</v-radio>
											</v-radio-group>
											<v-divider />
											<v-btn
												block
												dark
												class="ma-auto mt-3"
												min-width="300px"
												@click="goToSaveAddress"
												:color="
													getBtnStyle &&
													getBtnStyle.bg
														? getBtnStyle.bg
														: Boolean(getSiteColor)
														? getSiteColor.secondColor
														: 'grey'
												"
												:style="[
													{
														color:
															getBtnStyle &&
															getBtnStyle.text
																? getBtnStyle.text
																: '',
													},
												]"
											>
												<v-icon>mdi-plus</v-icon>
												{{ $t("button.new_address") }}
											</v-btn>
										</v-card-text>
									</v-card>
									<!-- /location -->
									<!-- type acsept mony -->
									<v-card
										class="mb-8"
										v-if="!Boolean(getHasApprove)"
									>
										<v-card-text>
											<p class="font-size-title">
												{{
													$t(
														"label.choose_payment_type"
													)
												}}
											</p>
											<v-skeleton-loader
												type="list-item-avatar-two-line"
												tile
												v-if="isShowLoader"
											/>
											<v-radio-group
												v-model="paymentMethod"
												:mandatory="false"
											>
												<v-radio
													:label="item.name"
													color="green darken-1"
													:value="item"
													v-for="item in paymentMethodsComputed"
													:key="item.id"
													@change="
														paymentMethodChange(
															item.type
														)
													"
												/>
											</v-radio-group>
										</v-card-text>
									</v-card>
									<!-- /type acsept mony -->
									<!-- type online || if (type acsept mony) = online -->
									<v-card
										class="mb-8"
										v-if="
											isOnlineModeSelected &&
											Boolean(gatewayLists)
										"
									>
										<v-card-text>
											<p class="font-size-title">
												{{ $t("label.online_payment") }}
											</p>
											<v-radio-group
												v-model="gatewaySelected"
												:mandatory="false"
											>
												<v-radio
													:label="item.name"
													color="green darken-1"
													:value="item.id"
													v-for="item in gatewayLists"
													:key="item.id"
												/>
											</v-radio-group>
										</v-card-text>
									</v-card>
									<!-- /type online || if (type acsept mony) = online -->
									<!-- mode *VIP* -->
									<v-card class="mb-8" v-if="vipComputed">
										<template v-if="vipComputed.isShopVip">
											<v-card-text
												class="d-flex align-items-center"
												v-if="!vipComputed.isUserVip"
											>
												<p class="ma-0">
													{{ $t("label.vip_member") }}
												</p>
												<v-btn
													:to="
														localePath(
															'vipMembership',
															$i18n.locale
														)
													"
													target="_blank"
													outlined
													class="ml-3"
													color="primary"
													small
												>
													{{ $t("button.more") }}
												</v-btn>
											</v-card-text>
											<v-card-text
												class="d-flex align-items-center"
												v-else-if="
													vipComputed.vip_detail
												"
											>
												<p class="ma-0">
													{{
														$t("label.vip_discount")
													}}
													({{
														vipComputed.vip_detail
															.days_left
													}}
													{{
														$t(
															"label.vip_days_left"
														)
													}})
												</p>
											</v-card-text>
										</template>
									</v-card>
									<!-- /mode *VIP* -->
									<LeadershipDiscount
										v-if="
											getBranch &&
											getBranch.has_leader_discount ==
												1 &&
											leader_discount_percent != 0 &&
											(getSiteSetting.getLeaderView() ==
												'SIGNUP' ||
												getSiteSetting.getLeaderView() ==
													'BASKET')
										"
										:isAutoDiscountCheck="
											isAutoDiscountCheck
										"
										@callResultLeadershipDiscount="
											resultLeadershipDiscount
										"
										:branch_id="getHasShopIdCart"
										:total_price="getPayablePrice"
										:shop_id="getMainShopId"
										:unit="
											getMonetaryUnit
												? getMonetaryUnit.find(
														item =>
															item.locale ==
															$i18n.locale
												  ).monetary_unit
												: ''
										"
										:delivery_cost="
											getBranch
												? getBranch.free_delivery_price
												: 0
										"
										:leader_info="leader_info"
									/>
									<!-- saw mony || saw How many the amount payable -->
									<v-card class="mb-8">
										<v-card-text class="text-center">
											<div
												class="mb-2 font-weight-medium"
											>
												<span
													class="font-size-title"
													v-text="
														$t(
															'label.payable_price'
														)
													"
												/>
												<span
													class="font-size-title"
													v-if="getTaxFirstBranch"
												>
													+
													{{
														getTaxFirstBranch + "%"
													}}
													{{
														$t("label.valueAddTax")
													}}
												</span>
												<span
													class="font-size-title"
													v-if="
														getCommissionFirstBranch
													"
												>
													<template
														v-if="
															+getCommissionFirstBranch.percent
														"
													>
														+
														{{
															getCommissionFirstBranch.percent +
															"%"
														}}
														{{ $t("label.wage") }}
													</template>

													<template
														v-if="
															+getCommissionFirstBranch.mount
														"
													>
														+
														{{
															getCommissionFirstBranch.mount
														}}<span
															class="font-size-13"
															>{{
																getMonetaryUnit
																	? getMonetaryUnit.find(
																			item =>
																				item.locale ==
																				$i18n.locale
																	  )
																			.monetary_unit
																	: ""
															}}
														</span>
														{{ $t("label.wage") }}
													</template>
												</span>
											</div>
											<template v-if="vipComputed">
												<template
													v-if="vipComputed.isShopVip"
												>
													<template
														v-if="
															vipComputed.isUserVip
														"
													>
														<p
															class="font-size-title"
															v-if="
																!getPayablePriceWithVip(
																	vipComputed.vip_percent
																)
															"
														>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-0 ml-2'
																		: 'order-1 mr-2'
																"
															>
																{{
																	$numberWithCommas(
																		getUseFloatDigit(
																			getPayablePriceWithLeaderDiscount(
																				getPayablePrice,
																				leader_discount_percent
																			) +
																				getTaxFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				) +
																				getCommissionFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				)
																		)
																	)
																}}
																{{
																	areaPrice &&
																	freeDelivery >=
																		getPayablePrice
																		? "+"
																		: ""
																}}
																{{
																	areaPrice &&
																	areaPrice !=
																		0 &&
																	freeDelivery >=
																		getPayablePrice
																		? $numberWithCommas(
																				areaPrice
																		  )
																		: ""
																}}
																{{
																	getMonetaryUnit
																		? getMonetaryUnit.find(
																				item =>
																					item.locale ==
																					$i18n.locale
																		  )
																				.monetary_unit
																		: ""
																}}
															</span>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-1'
																		: 'order-0'
																"
															>
																{{
																	getMonetaryUnit
																		? getMonetaryUnit.find(
																				item =>
																					item.locale ==
																					$i18n.locale
																		  )
																				.monetary_unit
																		: ""
																}}
															</span>
														</p>
														<del
															class="grey--text"
															v-if="
																getPayablePriceWithVip(
																	vipComputed.vip_percent
																)
															"
														>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-0 ml-2'
																		: 'order-1 mr-2'
																"
																>{{
																	$numberWithCommas(
																		getUseFloatDigit(
																			getPayablePriceWithLeaderDiscount(
																				getPayablePrice,
																				leader_discount_percent
																			) +
																				getTaxFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				) +
																				getCommissionFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				)
																		)
																	)
																}}</span
															>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-1'
																		: 'order-0'
																"
																>{{
																	getMonetaryUnit
																		? getMonetaryUnit.find(
																				item =>
																					item.locale ==
																					$i18n.locale
																		  )
																				.monetary_unit
																		: ""
																}}</span
															>
														</del>
														<p
															class="font-size-title"
															v-if="
																getPayablePriceWithVip(
																	vipComputed.vip_percent
																)
															"
														>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-0 ml-2'
																		: 'order-0'
																"
																>VIP</span
															>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-1 ml-2'
																		: 'order-2 mx-2'
																"
															>
																{{
																	$numberWithCommas(
																		getUseFloatDigit(
																			getPayablePriceWithVip(
																				vipComputed.vip_percent
																			) +
																				getTaxFirstBranchPrice(
																					getPayablePriceWithVip(
																						vipComputed.vip_percent
																					)
																				) +
																				getCommissionFirstBranchPrice(
																					getPayablePriceWithVip(
																						vipComputed.vip_percent
																					)
																				)
																		)
																	)
																}}
																{{
																	areaPrice &&
																	freeDelivery >=
																		getPayablePrice
																		? "+"
																		: ""
																}}
																{{
																	areaPrice &&
																	areaPrice !=
																		0 &&
																	freeDelivery >=
																		getPayablePrice
																		? $numberWithCommas(
																				areaPrice
																		  )
																		: ""
																}}
															</span>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-2'
																		: 'order-1'
																"
																>{{
																	getMonetaryUnit
																		? getMonetaryUnit.find(
																				item =>
																					item.locale ==
																					$i18n.locale
																		  )
																				.monetary_unit
																		: ""
																}}</span
															>
														</p>
													</template>
													<template v-else>
														<p
															class="font-size-title d-flex justify-center"
														>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-1 ml-2'
																		: 'order-1 mr-2'
																"
															>
																<span>{{
																	$numberWithCommas(
																		getUseFloatDigit(
																			getPayablePriceWithLeaderDiscount(
																				getPayablePrice,
																				leader_discount_percent
																			) +
																				getTaxFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				) +
																				getCommissionFirstBranchPrice(
																					getPayablePriceWithLeaderDiscount(
																						getPayablePrice,
																						leader_discount_percent
																					)
																				)
																		)
																	)
																}}</span>
																<span>
																	{{
																		areaPrice &&
																		freeDelivery >=
																			getPayablePrice
																			? "+"
																			: ""
																	}}
																	{{
																		areaPrice &&
																		areaPrice !=
																			0 &&
																		freeDelivery >=
																			getPayablePrice
																			? $numberWithCommas(
																					areaPrice
																			  )
																			: ""
																	}}
																</span>
															</span>
															<span
																:class="
																	$vuetify.rtl
																		? 'order-2'
																		: 'order-0'
																"
																>{{
																	getMonetaryUnit
																		? getMonetaryUnit.find(
																				item =>
																					item.locale ==
																					$i18n.locale
																		  )
																				.monetary_unit
																		: ""
																}}</span
															>
														</p>
													</template>
												</template>
												<template v-else>
													<p class="font-size-title">
														<span>
															{{
																$numberWithCommas(
																	getUseFloatDigit(
																		+getPayablePriceWithLeaderDiscount(
																			getPayablePrice,
																			leader_discount_percent
																		) +
																			getTaxFirstBranchPrice(
																				getPayablePriceWithLeaderDiscount(
																					getPayablePrice,
																					leader_discount_percent
																				)
																			) +
																			getCommissionFirstBranchPrice(
																				getPayablePriceWithLeaderDiscount(
																					getPayablePrice,
																					leader_discount_percent
																				)
																			)
																	)
																)
															}}
															{{
																areaPrice &&
																freeDelivery >=
																	getPayablePrice
																	? "+"
																	: ""
															}}
														</span>
														<span>
															{{
																areaPrice &&
																areaPrice !=
																	0 &&
																freeDelivery >=
																	getPayablePrice
																	? $numberWithCommas(
																			areaPrice
																	  )
																	: ""
															}}
															{{
																getMonetaryUnit
																	? getMonetaryUnit.find(
																			item =>
																				item.locale ==
																				$i18n.locale
																	  )
																			.monetary_unit
																	: ""
															}}
														</span>
													</p>
												</template>
											</template>
											<template v-else>
												<p class="font-size-title">
													<span>
														{{
															$numberWithCommas(
																getUseFloatDigit(
																	getPayablePriceWithLeaderDiscount(
																		getPayablePrice,
																		leader_discount_percent
																	) +
																		getTaxFirstBranchPrice(
																			getPayablePriceWithLeaderDiscount(
																				getPayablePrice,
																				leader_discount_percent
																			)
																		) +
																		getCommissionFirstBranchPrice(
																			getPayablePriceWithLeaderDiscount(
																				getPayablePrice,
																				leader_discount_percent
																			)
																		)
																)
															)
														}}
														{{
															areaPrice &&
															freeDelivery >=
																getPayablePrice
																? "+"
																: ""
														}}
													</span>
													<span>{{
														areaPrice &&
														areaPrice != 0 &&
														freeDelivery >=
															getPayablePrice
															? $numberWithCommas(
																	areaPrice
															  )
															: ""
													}}</span>
													<span>{{
														getMonetaryUnit
															? getMonetaryUnit.find(
																	item =>
																		item.locale ==
																		$i18n.locale
															  ).monetary_unit
															: ""
													}}</span>
												</p>
											</template>
											<!-- <p class="font-size-title" v-if="vipComputed && vipComputed.vip_percent"> {{getPayablePriceWithVip(vipComputed.vip_percent)}} {{ getMonetaryUnit ? getMonetaryUnit.find(item => item.locale == $i18n.locale).monetary_unit : '' }} </p>-->
											<v-btn
												@click="saveOrder"
												:disabled="!isAuth || loading"
												:loading="loading"
												:color="
													getBtnStyle &&
													getBtnStyle.bg
														? getBtnStyle.bg
														: Boolean(getSiteColor)
														? getSiteColor.secondColor
														: 'grey'
												"
												:style="[
													{
														color:
															getBtnStyle &&
															getBtnStyle.text
																? getBtnStyle.text
																: '',
													},
												]"
											>
												{{ $t("button.save_order") }}
											</v-btn>
										</v-card-text>
									</v-card>
									<!-- /saw mony || saw How many the amount payable -->
								</v-col>
								<!-- Cart -->
								<v-col
									cols="12"
									md="4"
									v-if="!$device.isMobile"
								>
									<Cart :isBtn="false" />
								</v-col>
								<!-- /Cart -->
							</v-row>
						</v-container>
					</v-form>
				</v-col>
				<!-- Options for send order -->
				<OrderForm v-if="getForm" />
			</v-row>
		</v-container>
		<v-snackbar
			:left="$vuetify.rtl"
			:right="!$vuetify.rtl"
			v-model="isShowSnackbar"
			color="cyan darken-2"
		>
			{{ snackbarText }}
			<v-btn icon text @click="isShowSnackbar = false">
				<v-icon>mdi-close</v-icon>
			</v-btn>
		</v-snackbar>
	</div>
</template>

<script>
import Cart from "@/components/shopingCart/Cart";
import OrderForm from "~/components/order/Form";
import LeadershipDiscount from "~/components/order/LeadershipDiscount";
import { mapGetters } from "vuex";

export default {
	name: "order",
	middleware: "authenticated",
	components: { Cart, OrderForm, LeadershipDiscount },
	data() {
		return {
			loading: false,
			description: null,
			isShowSnackbar: false,
			snackbarText: "",
			valid: false,
			selectedAddress: null,
			paymentMethod: null,
			addresses: [],
			fixedAddresses: [],
			paymentMethods: [],
			isShowLoader: true,
			vip: null,
			areaPrice: null,
			isOnlineModeSelected: false,
			gatewaySelected: null,
			freeDelivery: null,
			gatewayLists: null,
			leader_discount_percent: null,
			leader_discount_id: null,
			leader_info: null,
			isAutoDiscountCheck: false,
		};
	},
	computed: {
		...mapGetters({
			// index
			isAuth: "isAuth",
			getToken: "getToken",
			// first data \/
			getAreaPriceFreeDelivery: "firstData/getAreaPriceFreeDelivery",
			getMonetaryUnit: "firstData/getMonetaryUnit",
			getShop: "firstData/getShop",
			getTaxFirstBranch: "firstData/getTaxFirstBranch",
			getTaxFirstBranchPrice: "shop/getTaxFirstBranchPrice",
			getCommissionFirstBranch: "firstData/getCommissionFirstBranch",
			getCommissionFirstBranchPrice: "shop/getCommissionFirstBranchPrice",
			// site setting \/
			getBtnStyle: "siteSetting/getBtnStyle",
			getSiteColor: "siteSetting/getSiteColor",
			getMainShopId: "siteSetting/getMainShopId",
			getSiteSetting: "siteSetting/getSiteSetting",
			getUseFloatDigit: "siteSetting/getUseFloatDigit",
			// shop \/
			cart: "shop/cart",
			hasCountError: "shop/hasCountError",
			cartCount: "shop/cartCount",
			getPayablePrice: "shop/getPayablePrice",
			getHasShopIdCart: "shop/getHasShopIdCart",
			getPayablePriceWithVip: "shop/getPayablePriceWithVip",
			// order \/
			getQuestionAnswered: "order/getQuestionAnswered",
			getFormId: "order/getFormId",
			getForm: "order/getForm",
			getFormType: "order/getFormType",
			getSelectedAddress: "order/getSelectedAddress",
			// login card \/
			getCountryId: "loginCard/getCountryId",
			getCountryText: "loginCard/getCountryText",
			// branch \/
			getHasApprove: "branch/getHasApprove",
			getBranch: "branch/getBranch",
		}),

		descriptionComputed: {
			get() {
				return this.description;
			},
			set(val) {
				this.description = val;
			},
		},
		addressGroup: {
			// address
			get() {
				if (this.getSelectedAddress === false) {
					this.selectedAddress = null;
					this.$store.dispatch("order/selectedAddress", null);
				}
				return this.selectedAddress;
			},
			set(val) {
				this.selectedAddress = val;
			},
		},
		addressesComputed: {
			// address
			get() {
				return this.addresses;
			},
		},
		fixedAddressesComputed: {
			// address
			get() {
				return this.fixedAddresses;
			},
		},
		paymentMethodsComputed: {
			// type payment
			get() {
				return this.paymentMethods;
			},
		},
		vipComputed: {
			// is vip
			get() {
				return this.vip;
			},
		},
	},
	mounted() {
		this.descriptionComputed = this.description;
		this.checkAccessLevel();
		this.getOrderPageApi();
		this.$store.dispatch("order/showForm", false);
		this.$store.dispatch("loginCard/setGoToOrderPage", false);
	},
	methods: {
		paymentMethodChange(type) {
			if (type === "ONLINE") {
				this.isOnlineModeSelected = true;
				this.gatewaySelected =
					this.gatewayLists && this.gatewayLists.length
						? this.gatewayLists[0].id
						: null;
			} else {
				this.isOnlineModeSelected = false;
				this.gatewaySelected = null;
			}
		},
		goToSaveAddress() {
			this.$store.dispatch("profileTab/setTab", "tab-4");
			this.$store.dispatch("order/newAddress", true);
			this.$router.push(this.localePath("profile") + "#addresses");
		},
		checkAccessLevel() {
			if (this.cartCount <= 0 || !this.isAuth) {
				this.$router.push(this.localePath("index", this.$i18n.locale));
			}
		}, // checkAccessLevel()
		async getOrderPageApi() {
			let data = {
				token: this.getToken,
				branch_id: this.getHasShopIdCart,
				lang: this.$i18n.locale,
			};
			await this.$axios
				.$post("orderPage", data)
				.then(res => {
					if (res) {
						this.paymentMethods = res.paymentMethods;
						this.gatewayLists = res.gateway_list;
						this.vip = res.vip;
						this.leader_info = res.leader_info;
						this.isAutoDiscountCheck = true;
						this.addresses = res.addresses;
						if (
							this.getShop(this.getHasShopIdCart)
								.has_fixed_address == 1
						) {
							this.fixedAddresses = res.fixed_addresses
								? res.fixed_addresses
								: [];
						}
						this.isShowLoader = false;
					}
				})
				.catch(error => console.error(error));
		}, // getOrderPageApi()
		getAddressType(selectedAddressId) {
			let $address = this.fixedAddressesComputed.find(
				address => address.id == selectedAddressId
			);
			if ($address) {
				return $address.type;
			}
			return "NONE";
		},
		saveOrder() {
			this.loading = true;
			if (this.cartCount > 0) {
				let $typeAddress = this.getFormType ? this.getFormType : "NONE";

				if (
					this.getShop(this.getHasShopIdCart).has_fixed_address == 1
				) {
					$typeAddress = this.getFormType
						? this.getFormType
						: this.getAddressType(this.selectedAddress);
				}

				if (
					this.getQuestionAnswered &&
					this.getSelectedAddress === false
				) {
					this.isShowSnackbar = true;
					this.snackbarText = this.$t(
						"form.label.address_not_selected"
					);
					this.selectedAddress = null;
					this.loading = false;
					return false;
				}
				if (
					!this.selectedAddress &&
					this.getShop(this.getHasShopIdCart).has_send_product == 1
				) {
					this.isShowSnackbar = true;
					this.snackbarText = this.$t(
						"form.label.address_not_selected"
					);
					this.selectedAddress = null;
					this.loading = false;
					return false;
				}
				if (this.hasCountError === "YES") {
					this.isShowSnackbar = true;
					this.snackbarText = this.$t(
						"message.error.please_pay_attention_to_the_minimum"
					);
					this.loading = false;
					return false;
				}
				if (this.isOnlineModeSelected && !this.gatewaySelected) {
					this.isShowSnackbar = true;
					this.snackbarText = this.$t("label.choose_payment_type");
					this.loading = false;
					return false;
				}

				let $products = [];
				let planIds = 0;
				let $produIndex = 0;
				this.cart.map((val, key) => {
					if (val.product_id) {
						let itemPorps = [];
						if (val.properties) {
							Object.values(val.properties).filter(item => {
								if (item && item.ids && item.ids.length) {
									item.ids.filter(setArrayItemProps => {
										if (setArrayItemProps) {
											itemPorps.push(setArrayItemProps);
										}
									});
								}
							});
						}
						let $item = {
							index: $produIndex,
							product_id: val.product_id,
							count: val.count,
							properties: itemPorps,
						};
						$products.push($item);
					}
					if (val.plan_id) {
						planIds = val.plan_id;
					}
					$produIndex++;
				});
				let $totalPayment = +this.getPayablePrice;

				if (
					this.vipComputed &&
					this.vipComputed.isShopVip &&
					this.vipComputed.isUserVip &&
					this.getPayablePriceWithVip(this.vipComputed.vip_percent)
				) {
					$totalPayment = this.getPayablePriceWithVip(
						+this.vipComputed.vip_percent
					);
				}
				$totalPayment = this.getPayablePriceWithLeaderDiscount(
					$totalPayment,
					this.leader_discount_percent
				);
				let $data = {
					order_info: {
						plan_id: planIds ? planIds : 0,
						address_id: this.selectedAddress,
						description: this.description,
						products: $products,
						count_reservation: null,
						date_reservation: null,
						gateway_type_id: this.isOnlineModeSelected
							? this.gatewaySelected
							: null,
						table_id: 0,
						total_payment: $totalPayment,
						type_payment: this.paymentMethod
							? this.paymentMethod.type
							: null,
						payment_type_id: this.paymentMethod
							? this.paymentMethod.id
							: null,
						type_address: $typeAddress,
						area_price: +this.areaPrice,
						form_info:
							this.getFormId &&
							this.getQuestionAnswered &&
							this.getQuestionAnswered.length
								? {
										form_id: this.getFormId
											? this.getFormId
											: null,
										questions: this.getQuestionAnswered
											? this.getQuestionAnswered
											: null,
								  }
								: null,
						leader_discount_id: this.leader_discount_id,
						/* leader_discount_id: this.leader_info
							? this.leader_info.discount_id
							: null, */
					},
					user_info: {
						country_code: this.getCountryText,
						country_code_id: this.getCountryId,
						branch_id: this.getHasShopIdCart,
						mobile: this.$store.state.auth.user.mobile,
						shop_id: this.$store.state.auth.user.shop_id,
						user_id: this.$store.state.auth.user.user_id,
					},
				}; // data
				if (+this.getCommissionFirstBranchPrice($totalPayment))
					$data.order_info.commission_price = +this.getCommissionFirstBranchPrice(
						$totalPayment
					);
				if (+this.getTaxFirstBranchPrice($totalPayment)) {
					$data.order_info.tax_price = +this.getTaxFirstBranchPrice(
						$totalPayment
					);
				}
				let d = JSON.stringify($data);
				this.$axios
					.$post("saveOrder", {
						token: this.$store.state.auth.access_token,
						lang: this.$i18n.locale,
						data: d,
					})
					.then(res => {
						this.isShowSnackbar = true;
						this.snackbarText = res.message;
						if (res.status) {
							if (
								res.order &&
								(res.order.length ||
									Object.keys(res.order).length) &&
								Boolean(res.order.gate_url)
							) {
								window.location.href = res.order.gate_url;
								return true;
							} else {
								this.$store.dispatch("shop/emptyCart");
								this.$store.dispatch(
									"profileTab/setTab",
									"tab-3"
								);
								this.$router.push(
									this.localePath(
										{ name: "profile", hash: "#orders" },
										this.$i18n.locale
									)
								);
								this.$store.dispatch("branch/hasApprove", null);
								return true;
							}
						}
					})
					.catch(error => {
						console.error(error);
						this.isShowSnackbar = true;
						this.snackbarText = this.$t("message.error.title");
					})
					.finally(() => (this.loading = false));
			} // if(this.cartCount > 0)
			else {
				this.$router.push(this.localePath("index", this.$i18n.locale));
				this.loading = false;
			}
		},
		getShowForm(type, areaPrice) {
			this.loading = true;
			this.$store
				.dispatch("order/formType", type)
				.then(() => {
					if (
						this.getAreaPriceFreeDelivery &&
						this.getAreaPriceFreeDelivery[this.getHasShopIdCart]
					) {
						this.freeDelivery = parseFloat(
							this.getAreaPriceFreeDelivery[this.getHasShopIdCart]
						);
						let $Payment = parseFloat(this.getPayablePrice);
						if (
							this.vipComputed &&
							this.vipComputed.isShopVip &&
							this.vipComputed.isUserVip
						) {
							if (
								!this.getPayablePriceWithVip(
									this.vipComputed.vip_percent
								)
							) {
								$Payment = parseFloat(this.getPayablePrice);
							}
							if (
								this.getPayablePriceWithVip(
									this.vipComputed.vip_percent
								)
							) {
								$Payment = parseFloat(
									this.getPayablePriceWithVip(
										this.vipComputed.vip_percent
									)
								);
							}
						}
						if (this.freeDelivery <= $Payment) {
							this.areaPrice = 0;
						} else {
							this.areaPrice = areaPrice;
						}
					} else {
						this.areaPrice = areaPrice;
					}
				})
				.finally(() => {
					this.loading = false;
				});
		},
		resultLeadershipDiscount(data) {
			if (data) {
				this.leader_discount_id = data.discount_id;
				this.leader_discount_percent = data.discount_percent;
			}
		},
		totalMethod() {
			let total = 0;

			return total;
		},
		getPayablePriceWithLeaderDiscount(payablePrice, leaderDiscountPercent) {
			let price = 0;
			let precent = leaderDiscountPercent ? leaderDiscountPercent : 0;
			price = payablePrice - (payablePrice * precent) / 100;
			return price;
		},
	}, // methods:{}
};
</script>

<style scoped>
.radio-full-width .v-input__control,
.radio-full-width .v-label {
	width: 100% !important;
}
</style>
