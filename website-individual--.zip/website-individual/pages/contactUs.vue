<template>
	<v-container class="pt-sm-0">
		<v-row>
			<v-col cols="12" class="pt-sm-0">
				<v-card
					:height="$device.isMobile ? '160px' : '250px'"
					class="rounded-lg"
				>
					<v-img
						src="/images/head_wallpaper.jpg"
						height="100%"
						lazy-src="/images/head_wallpaper.jpg"
						gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
					>
						<v-card-title
							class="font-size-display-1 white--text ms-12 fill-height"
							>{{ $t("header.page.contact_us") }}</v-card-title
						>
					</v-img>
				</v-card>
			</v-col>
			<v-col cols="12" v-if="branchesComputed.length">
				<v-card
					tile
					class="mb-4 rounded-lg"
					v-for="(branch, index) in branchesComputed"
					:key="`branch-id-${branch.id}`"
					v-if="index == 0"
				>
					<v-container>
						<v-row class="mb-3">
							<v-col
								cols="12"
								v-if="branch.phone_numbers.length && index == 0"
							>
								<div>
									{{ $t("form.label.name") }}:
									{{
										$store.getters[
											"siteSetting/getCompanyName"
										]
									}}
								</div>
							</v-col>
							<v-col
								cols="12"
								md="6"
								v-if="branch.phone_numbers.length"
							>
								<v-list dense>
									<v-subheader>{{
										$t("label.contact_numbers")
									}}</v-subheader>

									<v-list-item
										v-for="phone in branch.phone_numbers"
										:key="phone.number"
									>
										<v-list-item-icon>
											<v-icon
												size="17"
												color="teal darken-2"
												>mdi-circle-slice-8</v-icon
											>
											<!--                        <v-icon color="teal darken-1">mdi-phone</v-icon>-->
										</v-list-item-icon>
										<v-list-item-title
											>{{
												phone.translations.length
													? phone.translations.find(
															item =>
																item.locale ==
																$i18n.locale
													  ).title
													: ""
											}}
											:
											{{
												phone.number
											}}</v-list-item-title
										>
									</v-list-item>
								</v-list>
							</v-col>
							<v-col
								cols="12"
								sm="6"
								md="6"
								v-if="branch.address"
							>
								<v-list dense>
									<v-subheader>{{
										$t("label.addresses")
									}}</v-subheader>
									<v-list-item>
										<v-list-item-icon>
											<v-icon color="orange"
												>mdi-map-marker</v-icon
											>
										</v-list-item-icon>
										<v-list-item-title
											>{{ $t("label.location") }}:
											{{
												branch.address
											}}</v-list-item-title
										>
									</v-list-item>
								</v-list>
							</v-col>
							<v-col cols="12" sm="6" md="6">
								<v-list dense>
									<!--                    <v-subheader>{{$t('label.fallow_us_on')}}</v-subheader>-->
									<v-list-item-group v-if="branch.socials">
										<v-list-item
											v-for="(
												social, index
											) in branch.socials"
											:key="index"
											:href="
												Boolean(social.link)
													? social.link
													: undefined
											"
											target="blank"
										>
											<v-list-item-icon>
												<!-- <v-icon v-if="Boolean(social.icon)">{{social.icon}}</v-icon> -->
												<v-img
													v-if="social.icon"
													width="24"
													height="24"
													:src="`${getDomain}/images/socials/${social.icon}`"
													:lazy-src="`${getDomain}/images/socials/${social.icon}`"
												/>
											</v-list-item-icon>

											<v-list-item-title>{{
												social.translations.length
													? social.translations.find(
															item =>
																item.locale ==
																$i18n.locale
													  ).title
													: social.title
											}}</v-list-item-title>
										</v-list-item>
									</v-list-item-group>
								</v-list>
							</v-col>
							<v-col cols="12" sm="6" md="6">
								<v-list dense>
									<v-subheader>{{
										$t("label.work_times")
									}}</v-subheader>
									<v-list-item>
										<!--                      <v-list-item-title>{{branch.am_time_start}} - {{ getLocaleTime(branch.am_time_start) }}</v-list-item-title>-->
										<v-list-item-title
											>{{
												getLocaleTime(
													branch.am_time_start
												)
											}}
											-
											{{
												branch.am_time_end ==
												branch.pm_time_start
													? getLocaleTime(
															branch.pm_time_end
													  )
													: getLocaleTime(
															branch.am_time_end
													  )
											}}</v-list-item-title
										>
										<!--                      <v-list-item-title>{{branch.am_time_start}} - {{branch.am_time_end == branch.pm_time_start ? branch.pm_time_end : branch.am_time_end}}</v-list-item-title>-->
									</v-list-item>
									<v-list-item
										v-if="
											branch.am_time_end !==
											branch.pm_time_start
										"
									>
										<v-list-item-title
											>{{
												getLocaleTime(
													branch.pm_time_start
												)
											}}
											-
											{{
												getLocaleTime(
													branch.pm_time_end
												)
											}}</v-list-item-title
										>
									</v-list-item>
								</v-list>
							</v-col>
						</v-row>
					</v-container>
				</v-card>
			</v-col>
			<!-- <v-col cols="12" sm="6" class="mx-auto">
          <v-card>
            <v-img src="/images/construction.jpeg" lazy-src="/images/construction.jpeg">
              gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
            </v-img>
          </v-card>
        </v-col>-->
		</v-row>
		<v-row>
			<v-col cols="12" style="z-index: 1">
				<div id="map-wrap" style="height: 350px; width: 100%"></div>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
import * as moment from "moment";

export default {
	name: "contactUs",
	data: () => ({
		branches: [],
	}),
	mounted() {
		this.getBranchLists();
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
		}),
		branchesComputed: {
			get() {
				return this.branches;
			},
		},
	},
	methods: {
		getLocaleTime(time) {
			return moment.utc(time, "HH:mm:ss").local().format("HH:mm:ss");
		},
		async getBranchLists() {
			await this.$axios
				.$post("contactUs", { lang: this.$i18n.locale })
				.then(res => {
					const { data } = res;
					this.branches = data;
					if (data) {
						if (data[0].lat && data[0].lng) {
							/********************/
							let map = L.map("map-wrap", {
								attributionControl: false,
								zoomControl: false,
							}).setView(L.latLng(data[0].lat, data[0].lng), 16);
							let greenIcon = L.icon({
								iconUrl: "/icons/ic_location.png",
								iconSize: [24, 41], // size of the icon
								shadowSize: [26, 60], // size of the shadow
								iconAnchor: [22, 54], // point of the icon which will correspond to marker's location
								shadowAnchor: [4, 62], // the same for the shadow
								popupAnchor: [-3, -46], // point from which the popup should open relative to the iconAnchor
							});
							L.tileLayer(
								"http://{s}.tile.osm.org/{z}/{x}/{y}.png?apikey=c09591ed1cec46ff9ec390e6958a7516",
								{
									maxZoom: 18,
									attribution:
										'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
										'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
										'Imagery Â© <a href="https://www.mapbox.com/">Mapbox</a>',
									detectRetina: true,
									// maxNativeZoom: 15
								}
							).addTo(map);
							let marker = L.marker([data[0].lat, data[0].lng], {
								draggable: true,
								autoPan: true,
								icon: greenIcon,
							}).addTo(map);

							/*console.log('getMap');
                let lat = '34.095315';
                let lng = '49.700984';
                let latlng = L.latLng(lat, lng);

                // initialize the map on the "map" div with a given center and zoom
                let map = new L.map('map-wrap', {
                    center: latlng,
                    zoom: 18
                });
                // create a new tile layer
                let tileUrl = 'https://tile.thunderforest.com/transport/{z}/{x}/{y}.png?apikey=c09591ed1cec46ff9ec390e6958a7516';
                let layer = new L.TileLayer(tileUrl, {maxZoom: 18});
                let marker = L.marker(latlng).addTo(map);

                // add the layer to the map
                map.addLayer(layer);*/

							// marker.bindPopup("<span>زودپز فود</span>").openPopup();
							/********************/

							/*var map = L.map("map-wrap", {
                attributionControl: false,
                zoomControl: false
              }).setView(L.latLng(data[0].lat, data[0].lng), 16);
              L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
                detectRetina: true,
                // maxNativeZoom: 15
              }).addTo(map);*/
						}
					}
				})
				.catch(error => {
					console.error("contactUs.vue methods: error ", error);
				});
		},
	},
};
</script>

<style scoped>
.v-list-item__title,
.v-list-item__subtitle {
	white-space: normal !important;
}
</style>
