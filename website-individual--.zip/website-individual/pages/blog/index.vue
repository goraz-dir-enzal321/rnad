<template>
	<v-container fluid>
		<v-row class="flex-row justify-space-between" style="height: 100%;">
			{{/* category */}}
			<v-col cols="12" md="3">
				<blog-categories
					:style="{ top: $device.isMobile ? '0' : '60px' }"
					:categories="blogCategories"
					@callCategory="newBlogs"
				/>
			</v-col>
			{{/* blog */}}
			<v-col md="9">
				<blog-card :data="getBlogs" />
			</v-col>
		</v-row>
		{{/* pagination */}}
		<div class="text-center mb-12" v-if="paginationLength">
			<v-pagination
				v-model="pageCumputed"
				:length="paginationLength"
				:total-visible="7"
			/>
		</div>
	</v-container>
</template>

<script>
import categories from "~/components/blog/Categories";
import CardMasonry from "~/components/blog/CardMasonry";
import { blog } from "~/api";
import { mapGetters } from "vuex";
export default {
	name: "blogs",
	components: {
		"blog-categories": categories,
		"blog-card": CardMasonry,
	},
	async asyncData({ app, store, redirect }) {
		let blogCategories = [];
		let blogs = [];
		let page = 1;
		let paginationLength = 0;
		const shopId = store.getters["siteSetting/getMainShopId"];
		const has_blog = store.getters["siteSetting/getHasBlog"];
		const default_lang = store.getters["siteSetting/getDefaultLang"];

		if (!has_blog) {
			return redirect(app.localePath("index", default_lang));
		} else {
			await app.$axios
				.post(blog.blogCategories, {
					shop_id: shopId,
					page: page,
				})
				.then(res => res.data)
				.then(res => {
					if (res.status) {
						blogCategories = res.blogCategories;
						blogs = res.blogs;
						paginationLength = res.paginationLength;
					}
				})
				.catch(err => console.error("Error ", err));
		}

		return {
			page,
			blogs,
			blogCategories,
			paginationLength,
			loading: false,
		};
	},
	computed: {
		...mapGetters({
			getBlogSettings: "siteSetting/getBlogSettings",
		}),
		getBlogs: {
			set(data) {
				this.blogs = data;
			},
			get() {
				return this.blogs;
			},
		},
		pageCumputed: {
			get() {
				return this.page;
			},
			set(val) {
				this.page = val;
				this.getBlogs().then(res => console.log("res", res));
			},
		},
	},
	methods: {
		async getBlogs() {
			await this.$axios
				.post("blogCategories", {
					shop_id: this.$store.getters["siteSetting/getMainShopId"],
					page: this.page,
				})
				.then(res => res.data)
				.then(res => {
					if (res.status) {
						this.blogCategories = res.blogCategories;
						this.blogs = res.blogs;
						this.paginationLength = res.paginationLength;
					}
				})
				.catch(err => console.error("Error ", err));
		},
		newBlogs(data) {
			this.blogs = data.blogs;
			this.paginationLength = data.paginationLength;
			this.$nextTick(() => {
				this.$nuxt.$loading.finish();
			});
		},
	},
};
</script>
