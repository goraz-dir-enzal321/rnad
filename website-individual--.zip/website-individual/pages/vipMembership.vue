<template>
	<v-container>
		<v-row>
			<!--<v-col cols="12" sm="12">
                    <v-card>
                        <v-img src="/images/head_wallpaper.jpg" height="160px" lazy-src="/images/head_wallpaper.jpg"
                               gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)">
                            <v-card-title class="white&#45;&#45;text align-center justify-center fill-height pa-0">VIP
                            </v-card-title>
                        </v-img>
                    </v-card>
                </v-col>-->
			<v-col cols="12">
				<v-card tile class="fill-height">
					<v-card-text v-if="!vipComputed">
						<v-skeleton-loader type="card" class="mx-auto mb-3" />
						<v-skeleton-loader
							type="paragraph"
							class="mx-auto text-center"
						/>
					</v-card-text>

					<v-card-text v-if="vipComputed">
						<v-img
							v-if="vipComputed.image"
							:src="`${getDomain}storage/${vipComputed.image}`"
							:lazy-src="`${getDomain}storage/${vipComputed.image}`"
							draggable="false"
							max-width="300px"
							class="mx-auto mb-3"
						>
							<template v-slot:placeholder>
								<v-row
									class="fill-height ma-0 grey"
									align="center"
									justify="center"
								>
									<v-progress-circular
										indeterminate
										color="grey lighten-5"
									/>
								</v-row>
							</template>
						</v-img>
						<v-sheet
							color="grey lighten-4"
							:elevation="1"
							class="mx-auto pa-3 mb-3 text-center"
							max-width="300px"
							>{{ $t("label.you_can_membership") }}
						</v-sheet>
						<v-sheet
							v-if="vipComputed.period || vipComputed.percent"
							:elevation="0"
							class="mx-auto pa-3 mb-3 text-center"
							max-width="300px"
						>
							<v-chip
								class="ma-2"
								v-if="vipComputed.percent"
								color="warning"
								text-color="white"
							>
								{{ $t("label.discount") }}:
								{{ vipComputed.percent }} %
							</v-chip>
							<v-chip
								class="ma-2"
								v-if="vipComputed.period"
								color="teal"
								text-color="white"
							>
								{{ $t("label.days") }}:
								{{ vipComputed.period }}
							</v-chip>
						</v-sheet>
						<p
							class="ma-0"
							v-if="vipComputed.translations"
							v-html="
								vipComputed.translations.find(
									item => item.locale == $i18n.locale
								).text
							"
						/>
					</v-card-text>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>
<script>
import { mapGetters } from "vuex";

export default {
	name: "vip",
	data() {
		return { vip: null };
	},
	mounted() {
		this.getVipDetails();
	},
	computed: {
		...mapGetters({
			getDomain: "siteSetting/getDomain",
			isAuth: "isAuth",
			getToken: "getToken",
		}),
		vipComputed() {
			return this.vip;
		},
	},
	methods: {
		getVipDetails() {
			this.$axios
				.$post("getVipMoreDetails", { lang: this.$i18n.locale })
				.then(res => {
					if (res.status) {
						this.vip = res.data;
					} else {
						this.$router.push(this.localePath("index"));
					}
				})
				.catch(error => {
					console.error("error vip page", error);
				});
		},
	},
};
</script>
