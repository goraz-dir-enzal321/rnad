<template>
	<v-container>
		<v-row>
			<v-col cols="12" sm="12">
				<v-card>
					<v-img
						src="/images/head_wallpaper.jpg"
						height="160px"
						lazy-src="/images/head_wallpaper.jpg"
						gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
					>
						<v-card-title
							class="font-size-display-1 white--text align-end fill-height pa-0"
						>
							<div>
								<v-icon color="white" class="mx-1"
									>mdi-account</v-icon
								>
								{{ userName }}
							</div>
							<v-tabs
								v-model="tabComputed"
								color="grey darken-2"
								background-color="white"
								slider-color="green lighten-1"
								center-active
								show-arrows
							>
								<v-tab
									optional
									:key="1"
									:to="`#profile`"
									@click="tabComputed = 'profile'"
									exact
								>
									<v-icon color="grey darken-2" class="mx-1"
										>mdi-account</v-icon
									>
									{{ $t("tab.profile") }}
								</v-tab>
								<v-tab
									optional
									:key="2"
									:to="`#messages`"
									@click="tabComputed = 'messages'"
									exact
								>
									<v-icon color="grey darken-2" class="mx-1"
										>mdi-android-messages</v-icon
									>
									{{ $t("tab.messages") }}
								</v-tab>
								<v-tab
									optional
									:key="3"
									:to="`#orders`"
									@click="tabComputed = 'orders'"
									exact
								>
									<v-icon color="grey darken-2" class="mx-1"
										>mdi-clipboard-list</v-icon
									>
									{{ $t("tab.orders") }}
								</v-tab>
								<v-tab
									optional
									:key="4"
									:to="`#addresses`"
									@click="tabComputed = 'addresses'"
									exact
									v-if="
										getShops &&
										(getShops[0].has_send_product == 1 ||
											getShops[0].has_fixed_address == 1)
									"
								>
									<v-icon color="grey darken-2" class="mx-1"
										>mdi-map-marker</v-icon
									>
									{{ $t("tab.addresses") }}
								</v-tab>
							</v-tabs>
						</v-card-title>
					</v-img>
				</v-card>
			</v-col>
			<v-col cols="12" sm="12">
				<v-tabs-items
					v-model="tabComputed"
					active-class="transparent"
					class="transparent"
				>
					<v-tab-item :key="1" :value="`profile`">
						<Profile />
					</v-tab-item>
					<v-tab-item
						:key="2"
						:value="`messages`"
						class="transparent"
					>
						<Messages />
					</v-tab-item>
					<v-tab-item :key="3" :value="`orders`" class="transparent">
						<Orders />
					</v-tab-item>
					<v-tab-item
						:key="4"
						:value="`addresses`"
						class="transparent"
						v-if="
							getShops &&
							(getShops[0].has_send_product == 1 ||
								getShops[0].has_fixed_address == 1)
						"
					>
						<Addresses />
					</v-tab-item>
				</v-tabs-items>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import Profile from "@/components/profile/Profile";
import Messages from "@/components/profile/Messages";
import Orders from "@/components/profile/Orders";
import Addresses from "@/components/profile/Addresses";
import { mapGetters } from "vuex";

// const Cookie = process.client ? require("js-cookie") : undefined;
// const cookieparser = process.server ? require('cookieparser') : undefined

export default {
	name: "panel",
	components: { Profile, Messages, Orders, Addresses },
	middleware: "authenticated",
	data: () => ({ tab: null }),
	computed: {
		...mapGetters({
			getTab: "profileTab/getTab",
			getUserName: "getUserName",
			getShops: "firstData/getShops",
		}),
		tabComputed: {
			get() {
				this.tab = this.$store.state.profileTab.tab;
				return this.tab;
			},
			set(tabId) {
				this.$store.dispatch(
					"profileTab/setTab",
					tabId ? tabId : "profile"
				);
			},
		},
		userName: {
			get() {
				const $username = this.getUserName;
				return $username;
			},
		},
	},
};
</script>

<style scoped>
.v-tabs-slider-wrapper {
	height: 4px !important;
}
.v-tab {
	text-transform: none !important;
	letter-spacing: unset !important;
}
</style>
