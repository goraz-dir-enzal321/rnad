<template>
	<v-container fluid class="section-search grey lighten-4 pa-0 pa-sm-3">
		<v-row class="mx-0 flex-sm-wrap">
			<filterBoxSearch v-if="!getLoadingFilter" />
			<result v-if="!getLoadingSearch" />
			<loading />
			<pagination />
		</v-row>
	</v-container>
</template>
<script>
import filterBoxSearch from "@/components/search/filter/index.vue";
import result from "@/components/search/result/index.vue";
import loading from "@/components/search/loading/index.vue";
import pagination from "@/components/search/pagination";
import { mapGetters } from "vuex";
export default {
	components: {
		filterBoxSearch,
		result,
		loading,
		pagination,
	},
	computed: {
		...mapGetters({
			getLoadingFilter: "search/getLoadingFilter",
			getLoadingSearch: "search/getLoadingSearch",
		}),
	},
	mounted() {
		this.$store.dispatch("search/setLoadingFilter", false);
		this.$store.dispatch("search/setLoadingSearch", false);
	},
	created() {
		if (this.getLoadingFilter == false) {
			this.$store.dispatch("search/setLoadingFilter", true);
		}
		if (this.getLoadingSearch == false) {
			this.$store.dispatch("search/setLoadingSearch", true);
		}
		this.$store.dispatch(
			"search/setFiltersObjectSenderAxios",
			this.$route.query
		);
		this.$store.dispatch("search/setResultSearch");
	},
};
</script>
