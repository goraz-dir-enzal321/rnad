<template>
	<v-container fluid>
		<v-row class="flex-row justify-space-between" style="height: 100%;">
			<v-col md="12">
				<EventsCard :blogs="blogs" />
			</v-col>
			<v-col md="12" v-if="false">
				<v-btn v-text="$t('button.more')" @click="moreNews" />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import EventsCard from "@/components/events/EventsCard";
import { events } from "~/api";

export default {
	watchQuery: true,
	components: { EventsCard },
	async asyncData({ app, store, redirect }) {
		const default_lang = store.getters["siteSetting/getDefaultLang"];

		let isActivePage = false;
		if (!isActivePage) {
			return redirect(app.localePath("index", default_lang));
		}

		let blogs = [];

		await app.$axios
			.post(events.blogEvent, {
				shop_id: store.getters["siteSetting/getMainShopId"],
			})
			.then(res => res.data)
			.then(res => {
				if (res.status) {
					blogs = res.blogs;
				}
			})
			.catch(err => console.error("Error ", err));

		return { blogs };
	},
	methods: {
		moreNews() {
			console.log("clicked");
		},
	},
};
</script>
