<template>
	<div>
		<template
			v-if="
				Object.keys(getFirstData).length &&
				getSettingLength &&
				shop_description_style == 'SIMPLE'
			"
		>
			<Porduction-info-v1
				:slug="$route.params.slug"
				:res="resDataProduct"
				@callResultMetaTags="resultMetaTags"
			/>
		</template>
		<template
			v-else-if="
				Object.keys(getFirstData).length &&
				getSettingLength &&
				shop_description_style == 'TAB_INFO'
			"
		>
			<Porduction-info-v2
				:res="resDataProduct"
				:slug="$route.params.slug"
				@callResultMetaTags="resultMetaTags"
			/>
		</template>
	</div>
</template>

<script>
import productInfo_t1 from "@/components/Product/productInfo_t1";
import productInfo_t2 from "@/components/Product/productInfo_t2";
import { mapGetters } from "vuex";
import { product } from "~/api";

export default {
	components: {
		"Porduction-info-v1": productInfo_t1,
		"Porduction-info-v2": productInfo_t2,
	},
	data: () => ({
		shop_description_style: null,
		resDataProduct: null,
		metaTags: {
			title: null,
			desc: null,
		},
	}),
	computed: {
		...mapGetters({
			getFirstData: "firstData/getFirstData",
			getSettingLength: "siteSetting/getSettingLength",
			getShops: "firstData/getShops",
			getShopIdInStore: "shop/getShopIdInStore",
		}),
	},
	mounted() {
		this.$nextTick(() => {
			this.$nuxt.$loading.start();
		});
		this.getData();
	},
	methods: {
		getData() {
			if (this.getShops) {
				/* 	if (this.getShopIdInStore) {
					const $shop = this.getShops.find(shop => {
						if (shop.id == this.getShopIdInStore) {
							this.$store.dispatch(
								"productInfo/setTimeWorkShop",
								{
									am_time_start: shop.am_time_start,
									am_time_end: shop.am_time_end,
									pm_time_start: shop.pm_time_start,
									pm_time_end: shop.pm_time_end,
								}
							);
							return shop;
						}
					});
					if ($shop) {
						this.shop_description_style =
							$shop.card.description_style;
						this.$store.dispatch("branch/cardStyle", $shop.card);
					}
				} else { */
				if (/^[0-9]*$/.test(this.$route.params.slug)) {
					this.shop_description_style = "TAB_INFO";
				} else {
					this.shop_description_style = "SIMPLE";
				}
				// }
			}
		},
		resultMetaTags(products_data) {
			if (products_data) {
				this.metaTags = {
					title: products_data.seo_title,
					desc: products_data.seo_desc,
				};
			}
		},
	},
	head() {
		return {
			title: this.metaTags.title,
			meta: [
				{
					hid: "description",
					name: "description",
					content: this.metaTags.desc,
				},
				{
					hid: "og:type",
					name: "og:type",
					content: "website",
				},
				{
					hid: "og:title",
					name: "og:title",
					content: this.metaTags.title,
				},
				{
					hid: "og:description",
					name: "og:description",
					content: this.metaTags.desc,
				},
				{
					hid: "og:image:alt",
					name: "og:image:alt",
					content: this.metaTags.title,
				},
				{
					hid: "og:image:type",
					name: "og:image:type",
					content: "image/png",
				},
				{
					hid: "twitter:title",
					name: "twitter:title",
					content: this.metaTags.title,
				},
				{
					hid: "twitter:description",
					name: "twitter:description",
					content: this.metaTags.desc,
				},
			],
		};
	},
};
</script>
