<template>
	<v-container class="pt-sm-0">
		<v-row>
			<v-col cols="12" class="pt-sm-0">
				<v-card
					:height="$device.isMobile ? '160px' : '250px'"
					class="rounded-lg"
				>
					<v-img
						src="/images/head_wallpaper.jpg"
						height="100%"
						lazy-src="/images/head_wallpaper.jpg"
						gradient="to top right, rgba(100,115,201,.33), rgba(25,32,72,.7)"
					>
						<v-card-title
							class="font-size-display-1 white--text ms-13 fill-height"
							>{{ $t("header.page.invitation") }}</v-card-title
						>
					</v-img>
				</v-card>
			</v-col>
		</v-row>
		<v-row>
			<v-col cols="12" sm="8" class="mx-auto">
				<v-card class="rounded-lg">
					<v-card-text>
						<v-sheet
							color="grey lighten-2"
							class="text-center pa-5 mb-4 rounded"
						>
							{{ $t("content.hello") }}
							<br />
							{{ $t("content.your_friend_text") }}
						</v-sheet>
						<p
							v-html="
								getDynamicText && getDynamicText('INVITATION')
									? getDynamicText('INVITATION')
									: $t('content.text_1')
							"
						/>
						<v-sheet
							color="grey lighten-2"
							class="pa-5 mb-4 rounded"
						>
							<div class="mb-3">
								{{ $t("content.text_2") }}
							</div>
							<div class="mb-3">
								{{ $t("content.text_3") }}
							</div>
							<v-btn
								class="mb-4"
								:to="localePath('download')"
								color="teal lighten-1 white--text"
								:loading="loading"
								:disabled="loading"
								>{{ $t("button.app_download") }}</v-btn
							>
							<div class="mb-3">
								{{ $t("content.text_4") }}
							</div>
							<v-btn
								class="mb-4"
								v-if="$route.params.id"
								:href="`${getTopic}://invitation/${$route.params.id}`"
								color="amber darken-1"
								:loading="loading"
								:disabled="loading"
								>{{ $t("button.get_gift") }}</v-btn
							>
							<br />
						</v-sheet>
						<p class="mb-3">{{ $t("content.text_5") }}</p>
						<p class="mb-3">{{ $t("content.text_6") }}</p>
					</v-card-text>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	data: () => ({
		loading: false,
	}),
	computed: {
		...mapGetters({
			getTopic: "siteSetting/getTopic",
			getDynamicText: "siteSetting/getDynamicText",
		}),
	},
};
</script>
