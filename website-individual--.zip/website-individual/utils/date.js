import * as moment from "moment";
import * as jMoment from 'jalali-moment';

export const utcToLocale = (utcTime, format = 'jYYYY/jM/jD HH:mm', $locale = 'en') => {
    // @param
    // utcTime such as created_at
    let exam = new Date(utcTime + ' UTC').toString();
    let result = (jMoment.utc(exam)).locale($locale).format(format);
    return result;
}

export const jalaliDate = (date, format = 'jYYYY/jM/jD') => {
    if (date) {
        let result = jMoment(date).format(format);
        return result;
    }
    return ''
}

export const getUserUtcDate = (format = 'HH:mm:ss', $locale = 'en') => {
    return moment().utc().format(format);
}