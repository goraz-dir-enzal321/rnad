<template>
	<v-app
		dark
		:style="`background: ${getBgColor}`"
		:class="$i18n.locale == 'fa' ? 'rtl-fa' : ''"
	>
		<!-- Old header -->
		<Header v-if="getHeaderVersion == 'old'" />
		<!-- New header -->
		<Header2 v-else-if="getHeaderVersion == 'new'" />
		<v-content>
			<!-- <div v-if="$nuxt.isOffline">You are offline</div> -->
			<!-- <div v-if="$nuxt.isOnline">You are online</div> -->
			<Nuxt />
			<LoginCards />
		</v-content>
		<template
			v-if="
				Boolean(Object.keys(getFirstData).length) &&
				Boolean(Object.keys(getFirstData.header).length)
			"
		>
			<CallInfo />
		</template>
		<FooterSymbol />
		<FooterImage />
		<Footer />
		<!-- Complete purchase button -->
		<v-slide-y-reverse-transition>
			<v-btn
				v-show="
					$device.isMobile &&
					cartCount > 0 &&
					$route.path !== `/${$i18n.locale}/order`
				"
				fixed
				dark
				color="green"
				class="ma-3 justify-space-between rounded-lg"
				width="95%"
				style="z-index: 3"
				:style="{
					bottom: /\/fa\/product\/[0-9]*$/.test($route.path)
						? '48px'
						: '0',
				}"
				height="50"
				@click="completePurchase()"
			>
				<span
					v-text="$t('button.completePurchase')"
					class="font-size-16"
				/>
				<span class="font-size-16">
					{{
						$numberWithCommas(getPayablePrice) +
						" " +
						`${
							getMonetaryUnit
								? getMonetaryUnit.find(
										item => item.locale == $i18n.locale
								  ).monetary_unit
								: ""
						}`
					}}
				</span>
			</v-btn>
		</v-slide-y-reverse-transition>

		<v-snackbar
			v-model="isShowSnackbarComputed"
			:color="getSnackbarColor"
			bottom
			left
		>
			<v-row no-gutters align="center">
				<v-col class="flex-shrink-1" v-text="getSnackbarText" />
				<v-col cols="auto">
					<v-btn
						icon
						text
						@click="$store.dispatch('snackbar/isShow', false)"
					>
						<v-icon v-text="'mdi-close'" />
					</v-btn>
				</v-col>
			</v-row>
		</v-snackbar>
		<!-- <LoginCards /> -->
		<alertAddProductToOtherBranch />
		<absoluteCart
			:isBtn="true"
			v-if="$route.path !== `/${$i18n.locale}/order`"
		/>
	</v-app>
</template>

<script>
import Header from "@/components/Header";
import Header2 from "@/components/Header2";
import Footer from "@/components/Footer";
import FooterImage from "~/components/FooterImage";
import FooterSymbol from "@/components/FooterSymbol";
import LoginCards from "@/components/login/LoginCards";
import CallInfo from "~/components/home/CallInfo";
import alertAddProductToOtherBranch from "~/components/alertAddProductToOtherBranch.vue";
import absoluteCart from "@/components/shopingCart/absoluteCart.vue";
import { mapGetters } from "vuex";
export default {
	components: {
		Header,
		Header2,
		LoginCards,
		Footer,
		absoluteCart,
		FooterSymbol,
		FooterImage,
		CallInfo,
		alertAddProductToOtherBranch,
	},
	head() {
		return {
			title: this.getSiteSeo.title,
			meta: [
				{
					hid: "description",
					name: "description",
					content: this.getSiteSeo.desc,
				},
				{
					hid: "og:type",
					name: "og:type",
					content: "website",
				},
				{
					hid: "og:title",
					name: "og:title",
					content: this.getSiteSeo.title,
				},
				{
					hid: "og:description",
					name: "og:description",
					content: this.getSiteSeo.desc,
				},
				{
					hid: "og:image:alt",
					name: "og:image:alt",
					content: this.getSiteSeo.title,
				},
				{
					hid: "og:image:type",
					name: "og:image:type",
					content: "image/png",
				},
				{
					hid: "twitter:title",
					name: "twitter:title",
					content: this.getSiteSeo.title,
				},
				{
					hid: "twitter:description",
					name: this.getSiteSeo.title,
					content: this.getSiteSeo.desc,
				},
			],
			link: [
				{
					rel: "icon",
					type: "image/x-icon",
					href: `${this.getDomain}storage/${this.getSiteFavicon}`,
				},
				{
					rel: "shortcut icon",
					sizes: "192x192",
					href: `${this.getDomain}storage/${this.getSiteFavicon}`,
				},
				{
					rel: "icon",
					sizes: "192x192",
					type: "image/png",
					href: `${this.getDomain}storage/${this.getSiteFavicon}`,
				},
				{
					rel: "apple-touch-icon",
					sizes: "180x180",
					type: "image/png",
					href: `${this.getDomain}storage/${this.getSiteFavicon}`,
				},
				{
					rel: "apple-touch-icon-precomposed",
					sizes: "128x128",
					type: "image/png",
					href: `${this.getDomain}storage/${this.getSiteFavicon}`,
				},
				{
					rel: "manifest",
					href: `/data/manifast.json`,
				},
			],
		};
	},
	mounted() {
		this.$nextTick(() => {
			this.$nuxt.$loading.start();
			// setTimeout(() => this.$nuxt.$loading.finish(), 2000)
		});
		this.changeDir();

		/* if (process.client) {
			document.addEventListener('contextmenu', function(e) {
				e.preventDefault();
			});
			document.onkeydown = function(e) {
				if(e.keyCode == 123) {
				return false;
				}
				if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
				return false;
				}
				if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
				return false;
				}
				if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
				return false;
				}
				if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
				return false;
				}
			}
		} */
	},
	computed: {
		...mapGetters({
			getBgColor: "siteSetting/getBgColor",
			getHeaderVersion: "siteSetting/getHeaderVersion",
			getFirstData: "firstData/getFirstData",
			getIsShowSnackbar: "snackbar/getIsShowSnackbar",
			getSnackbarColor: "snackbar/getSnackbarColor",
			getSnackbarText: "snackbar/getSnackbarText",
			getSiteFavicon: "siteSetting/getSiteFavicon",
			getSiteSeo: "siteSetting/getSiteSeo",
			getDomain: "siteSetting/getDomain",
			getPayablePrice: "shop/getPayablePrice",
			getMonetaryUnit: "firstData/getMonetaryUnit",
			cartCount: "shop/cartCount",
		}),
		isShowSnackbarComputed: {
			get() {
				return this.getIsShowSnackbar;
			},
			set(value) {
				this.$store.dispatch("snackbar/isShow", value);
			},
		},
	},
	methods: {
		changeDir() {
			const $locale = this.$i18n.locale;
			if ($locale == "fa" || $locale == "ar") {
				this.$vuetify.rtl = true;
			} else {
				this.$vuetify.rtl = false;
			}
		},
		completePurchase() {
			this.$router.push(this.localePath("order", this.$i18n.locale));
		},
	},
};
</script>

